#!/usr/bin/env python3
"""Offline frozen delivery preparation, pinned Git plans, and exact recovery.

No networking or credential handling. See docs/DELIVERY.md for contracts.
"""
from __future__ import annotations
import argparse
import base64
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile

import lumen_cli as lumen
import publication_guard as guard


class DeliveryError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise DeliveryError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False) + '\n').encode()


def load(path):
    return guard.load_json(str(path))


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    path.chmod(0o644)


def blob(data, width=40):
    body = b'blob ' + str(len(data)).encode() + b'\0' + data
    return (hashlib.sha1(body) if width == 40 else hashlib.sha256(body)).hexdigest()


def record(path, data, mode='100644'):
    return {'path': path, 'bytes': len(data), 'sha256': sha(data),
            'git_blob_sha': blob(data), 'mode': mode}


def no_symlink_path(path):
    require(not any(p.is_symlink() for p in (path.absolute(), *path.absolute().parents)),
            f'symlink path/ancestor refused: {path}')


def atomic_save(path, data):
    """Atomic evidence replacement; callers validate existing evidence first."""
    no_symlink_path(path)
    with tempfile.NamedTemporaryFile(prefix='.delivery-evidence-', dir=path.parent.parent, delete=False) as f:
        temporary = Path(f.name)
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    try:
        temporary.chmod(0o644)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def evidence_file(path, data):
    if path.exists() or path.is_symlink():
        require(regular(path) == data, f'divergent recovery evidence; refusing overwrite: {path}')
    else:
        atomic_save(path,data)


def regular(path):
    require(path.is_file() and not path.is_symlink(), f'not a regular file: {path}')
    require(not any(p.is_symlink() for p in path.absolute().parents), f'symlink ancestor: {path}')
    return path.read_bytes()


def inventory(root):
    rows = []
    for path in sorted(root.rglob('*')):
        require(not path.is_symlink(), f'symlink refused: {path}')
        if path.is_dir():
            continue
        data = regular(path)
        mode = stat.S_IMODE(path.stat().st_mode)
        require(mode in (0o644, 0o755), f'unsupported mode: {path}')
        rows.append(record(path.relative_to(root).as_posix(), data, f'100{mode:o}'))
    return sorted(rows,key=lambda row:row['path'])


def strict_checkpoint(path):
    manifest = lumen.verify_worktree_checkpoint(path)
    rows = manifest['members']
    names = [r['path'] for r in rows]
    require(len(names) == len(set(names)), 'duplicate checkpoint manifest members')
    with zipfile.ZipFile(path) as archive:
        require(set(archive.namelist()) == set(names) | {'LUMEN-CHECKPOINT.json', 'README.txt'},
                'unexpected checkpoint archive members')
    for row in rows:
        guard.path_name(row['path'])
        require(row['path'].startswith('Lumen/') and row['mode'] in ('0644', '0755'),
                'unsupported checkpoint path/mode')
    return manifest


def exact_restore(path, manifest):
    expected = [dict(path=r['path'][6:], bytes=r['bytes'], sha256=r['sha256'], mode='100'+r['mode'][1:])
                for r in manifest['members']]
    actual = [{k: r[k] for k in ('path', 'bytes', 'sha256', 'mode')} for r in inventory(path)]
    require(sorted(expected, key=lambda r:r['path']) == actual, 'restore destination differs; refusing overwrite')
    expected_dirs = {str(p) for r in expected for p in Path(r['path']).parents if str(p) != '.'}
    actual_dirs = {p.relative_to(path).as_posix() for p in path.rglob('*') if p.is_dir()}
    require(expected_dirs == actual_dirs, 'restore directory set differs; refusing overwrite')


def reopen(archive, target):
    manifest = strict_checkpoint(archive)
    no_symlink_path(target)
    if target.exists():
        require(target.is_dir(), 'restore target is not a directory')
        exact_restore(target, manifest)
        return manifest
    lumen.cmd_reopen(argparse.Namespace(checkpoint=str(archive.resolve()), into=str(target.resolve()), verify_only=False))
    exact_restore(target, manifest)
    return manifest


def handoff_inventory(path):
    handoff = load(path / 'HANDOFF.json')
    require(handoff['schema'] == 'lumen.handoff/v3', 'unsupported HANDOFF')
    selected = {'HANDOFF.json', 'RELEASE.json', 'README.txt', 'SHA256SUMS', 'Lumen.html.sha256'}
    for item in [handoff['primary'], *handoff['archives']]:
        name = guard.path_name(item['file'])
        require('/' not in name and name not in selected, 'invalid/duplicate HANDOFF file')
        selected.add(name)
        data = regular(path / name)
        require(sha(data) == item['sha256'] and len(data) == item['bytes'], 'HANDOFF artifact hash mismatch')
    release = load(path/'RELEASE.json')
    sites = [item for item in handoff['archives'] if item.get('role') == 'github-pages-projection']
    require(len(sites) == 1, 'HANDOFF requires exactly one Pages projection')
    site = sites[0]
    require(release.get('schema') == 'lumen.release/v2' and release.get('edition') == handoff['edition'] and
            release.get('source_fingerprint_sha256') == handoff['source_fingerprint_sha256'] and
            release.get('archive') == site['file'] and release.get('sha256') == site['sha256'] and
            release.get('bytes') == site['bytes'], 'RELEASE/HANDOFF identity mismatch')
    require({r['path'] for r in inventory(path)} == selected, 'unexpected/missing HANDOFF files')
    return handoff, inventory(path)


def profile_check(profile):
    require(set(profile) == {'public', 'private'}, 'profile requires public and private destinations')
    for scope,destination in profile.items():
        required = {'repository','prefix','branch'}
        require(required <= set(destination) and set(destination) <= required | ({'primary_alias'} if scope == 'public' else set()), 'destination requires repository, prefix, branch; only public permits primary_alias')
        branch = destination['branch']
        guard.path_name(branch)
        require(not any(c in branch for c in ('..','@{','~','^',':','?','*','[','\\',' ')) and not branch.endswith('.') and not any(p.startswith('.') or p.endswith('.lock') for p in branch.split('/')), 'invalid destination branch')
        require(re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', destination['repository']), 'invalid repository')
        guard.path_name(destination['prefix'])
        if 'primary_alias' in destination:
            alias = guard.path_name(destination['primary_alias'])
            prefix = destination['prefix']
            require(alias.endswith('.html'), 'primary alias must name an HTML file')
            require(alias != prefix and not alias.startswith(prefix+'/') and not prefix.startswith(alias+'/'), 'primary alias must be outside and noncolliding with release subtree')
    require(profile['public']['repository'] != profile['private']['repository'], 'public/private repositories must differ')


def prepare(args):
    require(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,99}', args.release_id), 'invalid release ID')
    require(args.review.strip(), 'review reference is required')
    profile = load(args.profile)
    profile_check(profile)
    archive_bytes = regular(Path(args.checkpoint))
    request = {'release_id': args.release_id, 'review': args.review, 'profile': profile,
               'checkpoint_sha256': sha(archive_bytes), 'part_bytes': args.part_bytes,
               'source_date_epoch': None if args.handoff else os.environ.get('SOURCE_DATE_EPOCH')}
    supplied = None
    if args.handoff:
        supplied = handoff_inventory(Path(args.handoff))
        request['supplied_public_inventory_sha256'] = sha(encoded(supplied[1]))
    output = Path(os.path.abspath(args.output))
    no_symlink_path(output)
    if output.exists():
        state = load(output / 'DELIVERY.json')
        require(state['request'] == request, 'stable release/output conflict')
        for scope in ('public', 'private'):
            require(inventory(output / scope) == state[scope+'_inventory'], 'prepared payload was modified')
        return state
    output.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix='.delivery-', dir=output.parent))
    try:
        frozen_archive = staging / 'checkpoint.zip'
        save(frozen_archive, archive_bytes)
        manifest = reopen(frozen_archive, staging / 'snapshot')
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
        if supplied:
            reference_clock = supplied[0]['generated_at']
            snapshot_clock = load(staging/'snapshot/content/data/source-snapshot.json')['captured_at']
            if reference_clock == snapshot_clock:
                env.pop('SOURCE_DATE_EPOCH',None)
            else:
                instant = dt.datetime.fromisoformat(reference_clock.replace('Z','+00:00'))
                require(instant.tzinfo is not None and instant.microsecond == 0, 'unsupported handoff reference clock')
                env['SOURCE_DATE_EPOCH'] = str(int(instant.timestamp()))
            env['LUMEN_BUILD_TIME'] = reference_clock
        subprocess.run([sys.executable, 'tools/lumen_cli.py', 'ship', '--output', str(staging/'handoff')],
                       cwd=staging/'snapshot', env=env, check=True)
        # Ship may write only generated state; every selected editable file must stay frozen.
        with zipfile.ZipFile(frozen_archive) as archive:
            for row in manifest['members']:
                file = staging/'snapshot'/row['path'][6:]
                require(regular(file) == archive.read(row['path']) and stat.S_IMODE(file.stat().st_mode) == int(row['mode'],8), 'ship changed frozen source')
        selected = set()
        for name in lumen.CHECKPOINT_ROOTS:
            base = staging/'snapshot'/name
            paths = [base] if base.is_file() else base.rglob('*') if base.exists() else []
            for file in paths:
                require(not file.is_symlink(), 'ship added source symlink')
                if file.is_file() and '__pycache__' not in file.parts and not file.name.endswith('.pyc') and file.name != '.DS_Store':
                    selected.add('Lumen/'+file.relative_to(staging/'snapshot').as_posix())
        require(selected == {r['path'] for r in manifest['members']}, 'ship changed selected source file set')
        handoff, public_rows = handoff_inventory(staging/'handoff')
        require(handoff['edition'] == manifest['edition'], 'public/private edition mismatch')
        if supplied:
            require(public_rows == supplied[1], 'supplied public handoff differs from frozen private build')
        for row in public_rows:
            dest = profile['public']['prefix']+'/'+args.release_id+'/'+row['path']
            save(staging/'public'/dest, regular(staging/'handoff'/row['path']))
        alias = profile['public'].get('primary_alias')
        if alias:
            save(staging/'public'/alias, regular(staging/'handoff'/handoff['primary']['file']))
        private_prefix = profile['private']['prefix']+'/'+args.release_id
        encoded_archive = base64.b64encode(archive_bytes) + b'\n'
        parts_prefix = private_prefix+'/checkpoint.zip.base64.parts'
        transport = {'schema': 'lumen.chunked-checkpoint-transport/v1', 'edition': manifest['edition'],
                     'encoding': 'Concatenate ordered parts; verify part and encoded SHA256; strict-decode base64 after trimming trailing newline; verify archive SHA256 before opening ZIP.',
                     'parts': [], 'encoded_sha256': sha(encoded_archive), 'archive_sha256': sha(archive_bytes),
                     'archive_bytes': len(archive_bytes), 'archive_name': 'checkpoint.zip',
                     'content_identity_sha256': manifest['content_identity_sha256']}
        require(args.part_bytes > 0, 'part bytes must be positive')
        for number, start in enumerate(range(0, len(encoded_archive), args.part_bytes), 1):
            path = parts_prefix+f'/part-{number:06}'
            data = encoded_archive[start:start+args.part_bytes]
            save(staging/'private'/path, data)
            transport['parts'].append({k:v for k,v in record(path,data).items() if k != 'mode'})
        transport_path = parts_prefix+'/manifest.json'
        save(staging/'private'/transport_path, encoded(transport))
        state = {'schema': 'lumen.delivery/v1', 'request': request, 'edition': manifest['edition'],
                 'private_members': len(manifest['members']),
                 'private_content_identity_sha256': manifest['content_identity_sha256'],
                 'public_source_fingerprint_sha256': handoff['source_fingerprint_sha256'],
                 'transport_path': transport_path, 'transport_sha256': sha(encoded(transport)),
                 'outcomes': {'local_bundle': 'prepared', 'local_private_bytes': 'verified',
                              'remote_private': 'unobserved', 'remote_public': 'unobserved',
                              'remote_pointer': 'unobserved'},
                 'verification_scope': 'local frozen bytes only; no remote publication or custody asserted'}
        for scope in ('public','private'):
            rows = inventory(staging/scope)
            state[scope+'_inventory'] = rows
            state[scope+'_inventory_sha256'] = sha(encoded(rows))
        shutil.rmtree(staging/'snapshot')
        shutil.rmtree(staging/'handoff')
        frozen_archive.unlink()
        save(staging/'DELIVERY.json', encoded(state))
        require(not output.exists(), 'output appeared during prepare')
        staging.rename(output)
        return state
    finally:
        if staging.exists():
            shutil.rmtree(staging)


def recursive_tree(files, width):
    directories = {''}
    for name in files:
        directories.update(str(p) for p in Path(name).parents if str(p) != '.')
    require(not (directories & files.keys()), 'file/directory collision')
    entries = dict(files)
    for directory in sorted(directories, key=lambda x:x.count('/')+bool(x), reverse=True):
        children = [(p.rpartition('/')[2], item) for p,item in entries.items() if p.rpartition('/')[0] == directory]
        digest = guard.tree_hash(children, width)
        if directory:
            entries[directory] = {'mode':'040000', 'type':'tree', 'sha':digest}
        else:
            return {'sha':digest, 'truncated':False, 'tree':[dict(path=p, **v) for p,v in sorted(entries.items())]}


def verify_primary_alias(state, bundle):
    destination = state['request']['profile']['public']
    alias = destination.get('primary_alias')
    if not alias:
        return
    release = bundle/'public'/destination['prefix']/state['request']['release_id']
    handoff = load(release/'HANDOFF.json')
    primary = guard.path_name(handoff['primary']['file'])
    require('/' not in primary, 'invalid HANDOFF primary path')
    require(regular(bundle/'public'/alias) == regular(release/primary), 'primary alias differs from exact HANDOFF primary')


def plan(args):
    bundle = Path(args.bundle)
    state_bytes = regular(bundle/'DELIVERY.json')
    state = json.loads(state_bytes,object_pairs_hook=guard.unique_object)
    if args.scope == 'public':
        verify_primary_alias(state,bundle)
    rows = inventory(bundle/args.scope)
    require(rows == state[args.scope+'_inventory'] and sha(encoded(rows)) == state[args.scope+'_inventory_sha256'], 'payload inventory mismatch')
    pin = guard.oid(args.baseline_tree_sha, 'baseline pin')
    baseline_bytes = regular(Path(args.baseline))
    baseline = json.loads(baseline_bytes,object_pairs_hook=guard.unique_object)
    before = guard.complete_tree(baseline, pin, 'baseline')
    after = dict(before)
    changes = []
    primary_alias = state['request']['profile']['public'].get('primary_alias') if args.scope == 'public' else None
    for row in rows:
        path = guard.path_name(row['path'])
        new = {'mode':row['mode'], 'type':'blob', 'sha':blob(regular(bundle/args.scope/path),len(pin))}
        require(path == primary_alias or path not in before or before[path] == new, 'stable release ID conflicts with existing destination bytes/mode: '+path)
        if before.get(path) != new:
            changes.append({'path':path, 'before':before.get(path), 'after':new})
            after[path] = new
    candidate = recursive_tree(after, len(pin))
    manifest = {'schema_version':1, 'baseline_tree_sha':pin, 'candidate_tree_sha':candidate['sha'], 'changes':changes}
    guard.verify(baseline,candidate,manifest,baseline_tree_sha=pin,candidate_tree_sha=candidate['sha'])
    commit = guard.oid(args.baseline_commit,'baseline commit',len(pin))
    out = Path(args.output)
    no_symlink_path(out)
    allowed = {'REQUEST.json','candidate-tree.json','change-plan.json','OPERATION.json'}
    if out.exists():
        require(out.is_dir(), 'plan output is not a directory')
        present = {p.name for p in out.iterdir()}
        require(present <= allowed and (not present or 'REQUEST.json' in present), 'unexpected/unpinned existing plan evidence')
    else:
        out.mkdir(parents=True)
    request = {'schema':'lumen.delivery-plan-request/v1','bundle_sha256':sha(state_bytes),
               'scope':args.scope,'baseline_sha256':sha(baseline_bytes),'baseline_tree_sha':pin,
               'baseline_commit':commit,'inventory_sha256':sha(encoded(rows))}
    evidence_file(out/'REQUEST.json',encoded(request))
    evidence_file(out/'candidate-tree.json',encoded(candidate))
    evidence_file(out/'change-plan.json',encoded(manifest))
    evidence_file(out/'OPERATION.json',encoded({'schema':'lumen.delivery-operation/v1', 'destination':state['request']['profile'][args.scope],
         'release_id':state['request']['release_id'], 'review':state['request']['review'],
         'baseline_commit':commit,
         'baseline_tree_sha':pin, 'candidate_tree_sha':candidate['sha'],
         'payload_inventory_sha256':state[args.scope+'_inventory_sha256'],
         'status':'prepared; connector must authenticate commit/tree association and use compare-and-swap ref update'}))
    return manifest


def read_transport(root, manifest_path, transport_pin=None):
    transport_bytes = regular(root/manifest_path)
    if transport_pin is not None:
        require(sha(transport_bytes) == transport_pin, 'transport pin mismatch')
    transport = json.loads(transport_bytes,object_pairs_hook=guard.unique_object)
    require(transport['schema'] == 'lumen.chunked-checkpoint-transport/v1', 'unsupported transport')
    parts = []
    names = set()
    for row in transport['parts']:
        path = guard.path_name(row['path'])
        require(path not in names, 'duplicate part')
        names.add(path)
        data = regular(root/path)
        require(len(data) == row['bytes'] and sha(data) == row['sha256'] and blob(data) == row['git_blob_sha'], 'part verification failed')
        parts.append(data)
    data = b''.join(parts)
    require(sha(data) == transport['encoded_sha256'], 'encoded archive hash mismatch/order changed')
    require(data.endswith(b'\n'), 'missing encoded final newline')
    archive = base64.b64decode(data[:-1], validate=True)
    require(len(archive) == transport['archive_bytes'] and sha(archive) == transport['archive_sha256'], 'archive verification failed')
    return transport_bytes, transport, archive


def recover(args):
    pointer_bytes = regular(Path(args.pointer))
    require(sha(pointer_bytes) == args.pointer_sha256, 'recovery pointer pin mismatch')
    pointer = json.loads(pointer_bytes,object_pairs_hook=guard.unique_object)
    established_pointer = type(pointer.get('schema_version')) is int and pointer['schema_version'] == 1
    if established_pointer:
        require(isinstance(pointer.get('project_id'),str) and pointer['project_id'], 'missing project ID')
        require(re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',pointer.get('repository','')), 'invalid private repository')
        guard.oid(pointer['verified_source_commit'], 'immutable private commit')
        require(pointer.get('encoding','').startswith('lumen.chunked-checkpoint-transport/v1'), 'unsupported pointer encoding')
        manifest_path = guard.path_name(pointer['checkpoint_path'])
        transport_pin = pointer.get('transport_manifest_sha256')
        for key in ('checkpoint_sha256','content_identity_sha256'):
            require(re.fullmatch(r'[0-9a-f]{64}',pointer.get(key,'')), 'invalid pointer '+key)
        require(isinstance(pointer.get('edition'),str) and pointer['edition'], 'missing pointer edition')
    else:
        # Compatibility-only thin internal pointer; normal operators use field-notes-current.json.
        require(pointer.get('schema') == 'lumen.delivery-recovery-pointer/v1', 'unsupported pointer')
        guard.oid(pointer['commit'], 'immutable private commit')
        manifest_path = guard.path_name(pointer['transport_path'])
        transport_pin = pointer['transport_sha256']
    root = Path(args.parts)
    transport_bytes, transport, archive = read_transport(root,manifest_path,transport_pin)
    if established_pointer:
        require(transport['archive_sha256'] == pointer['checkpoint_sha256'] and transport['content_identity_sha256'] == pointer['content_identity_sha256'] and transport['edition'] == pointer['edition'], 'pointer/archive/transport identity mismatch')
    output = Path(os.path.abspath(args.output))
    target = Path(os.path.abspath(args.into))
    no_symlink_path(output)
    no_symlink_path(target)
    require(not target.is_relative_to(output) and not output.is_relative_to(target), 'restore and evidence destinations must be disjoint')
    request = {'schema':'lumen.delivery-restore-request/v1',
               'pointer_sha256':sha(pointer_bytes), 'transport_sha256':sha(transport_bytes),
               'archive_sha256':sha(archive), 'parts_root':str(root.absolute()),
               'destination':str(target)}
    if output.exists():
        require(output.is_dir(), 'recovery evidence output is not a directory')
        present = {p.name for p in output.iterdir()}
        require(present <= {'REQUEST.json','checkpoint.zip','RESTORE.json'}, 'unexpected recovery evidence; refusing overwrite')
        require(not present or 'REQUEST.json' in present, 'recovery evidence missing pinned request')
    else:
        output.mkdir(parents=True)
    evidence_file(output/'REQUEST.json',encoded(request))
    evidence_file(output/'checkpoint.zip',archive)
    verified = strict_checkpoint(output/'checkpoint.zip')
    require(verified['content_identity_sha256'] == transport['content_identity_sha256'] and verified['edition'] == transport['edition'], 'checkpoint identity mismatch')
    result = {'schema':'lumen.delivery-restore/v1', 'pointer_sha256':sha(pointer_bytes), 'archive_sha256':sha(archive),
              'content_identity_sha256':verified['content_identity_sha256'], 'members':len(verified['members']),
              'destination':str(target), 'status':'exact-restore-verified', 'remote_authentication':'connector responsibility'}
    receipt_path = output/'RESTORE.json'
    if receipt_path.exists() or receipt_path.is_symlink():
        previous = json.loads(regular(receipt_path),object_pairs_hook=guard.unique_object)
        require(set(previous) == set(result) | {'verified_at'}, 'divergent restore receipt fields')
        stamp = previous.pop('verified_at')
        require(isinstance(stamp,str) and stamp.endswith('Z'), 'invalid prior verification time')
        dt.datetime.fromisoformat(stamp[:-1]+'+00:00')
        require(previous == result, 'divergent restore receipt; refusing overwrite')
    reopen(output/'checkpoint.zip',target)
    # This records the verification just performed, never an inferred earlier completion.
    result['verified_at'] = dt.datetime.now(dt.timezone.utc).isoformat().replace('+00:00','Z')
    atomic_save(receipt_path,encoded(result))
    return result


def verify_observation(observation, operation, change_plan, expected_rows, returned, *, private):
    require(isinstance(observation,dict) and set(observation) == {'repository','baseline_commit','baseline_tree','commit','ref','tree'},
            'observation requires complete repository, baseline commit/tree, commit, ref, tree; boolean authentication flags are not evidence')
    repository = observation['repository']
    require(repository['full_name'] == operation['destination']['repository'], 'repository identity mismatch')
    require(repository['private'] is private, 'repository visibility mismatch')
    baseline = observation['baseline_commit']
    commit = observation['commit']
    width = len(guard.oid(operation['baseline_commit'],'operation baseline commit'))
    require(guard.oid(baseline['sha'],'observed baseline commit',width) == operation['baseline_commit'], 'baseline commit mismatch')
    require(baseline['tree']['sha'] == operation['baseline_tree_sha'], 'baseline commit/tree mismatch')
    commit_sha = guard.oid(commit['sha'],'observed immutable commit',width)
    require(commit_sha != operation['baseline_commit'], 'publication commit cannot equal its parent')
    require(commit['tree']['sha'] == operation['candidate_tree_sha'], 'commit tree mismatch')
    require([p['sha'] for p in commit['parents']] == [operation['baseline_commit']], 'commit parent mismatch')
    ref = observation['ref']
    require(ref['ref'] == 'refs/heads/'+operation['destination']['branch'], 'observed branch differs from intended destination branch')
    require(ref['object']['type'] == 'commit' and ref['object']['sha'] == commit_sha, 'ref does not identify observed commit')
    guard.verify(observation['baseline_tree'],observation['tree'],change_plan,
                 baseline_tree_sha=operation['baseline_tree_sha'],candidate_tree_sha=operation['candidate_tree_sha'])
    files = guard.complete_tree(observation['tree'],operation['candidate_tree_sha'],'returned tree')
    observed_entries = {entry['path']:entry for entry in observation['tree']['tree']}
    rows = inventory(returned)
    require(rows == expected_rows and sha(encoded(rows)) == operation['payload_inventory_sha256'], 'returned payload set/bytes/modes differ from inventory')
    for row in rows:
        expected = {'mode':row['mode'],'type':'blob','sha':blob(regular(returned/row['path']),width)}
        require(files.get(row['path']) == expected, 'returned payload does not match immutable tree: '+row['path'])
        require(observed_entries[row['path']].get('size') == row['bytes'], 'missing/wrong observed blob size: '+row['path'])
    return {'repository':repository['full_name'],'commit':commit_sha,'tree':operation['candidate_tree_sha'],
            'ref':ref['ref'],'payload_inventory_sha256':sha(encoded(rows)),
            'status':'returned-bytes-verified',
            'origin_boundary':'Repository/commit/ref/tree observations are supplied by the authorized connector/caller; this offline tool does not authenticate their origin.'}


def verified_evidence(path, result):
    if path.exists() or path.is_symlink():
        previous = json.loads(regular(path),object_pairs_hook=guard.unique_object)
        stamp = previous.pop('verified_at',None)
        require(isinstance(stamp,str) and stamp.endswith('Z'), 'missing previous verification timestamp')
        dt.datetime.fromisoformat(stamp[:-1]+'+00:00')
        require(previous == result, 'divergent verification evidence; refusing overwrite')
        return dict(previous,verified_at=stamp)
    result = dict(result,verified_at=dt.datetime.now(dt.timezone.utc).isoformat().replace('+00:00','Z'))
    atomic_save(path,encoded(result))
    return result


def finalize_phase(scope, state, bundle_hash, plan_dir, observation_path, returned, output, rows, destination):
    operation_bytes = regular(plan_dir/'OPERATION.json')
    plan_bytes = regular(plan_dir/'change-plan.json')
    request = {'schema':'lumen.delivery-finalize-request/v1','scope':scope,'bundle_sha256':bundle_hash,
               'operation_sha256':sha(operation_bytes),'plan_sha256':sha(plan_bytes),
               'returned_root':str(returned.absolute()),'payload_inventory_sha256':sha(encoded(rows))}
    # Pin the reviewed operation/target, not a failed observation. Corrected evidence
    # gets a new immutable attempt under the same unchanged operation.
    evidence_file(output/(scope+'-REQUEST.json'),encoded(request))
    try:
        observed_bytes = regular(observation_path)
        observed_error = None
    except (ValueError,OSError) as exc:
        observed_bytes = b''
        observed_error = str(exc)
    try:
        returned_state = {'inventory_sha256':sha(encoded(inventory(returned)))}
    except (ValueError,OSError) as exc:
        returned_state = {'error':str(exc)}
    attempt = {'request_sha256':sha(encoded(request)),'observation_sha256':sha(observed_bytes),
               'observation_error':observed_error,'returned_state':returned_state}
    attempt_dir = output/(scope+'-attempts')/sha(encoded(attempt))
    no_symlink_path(attempt_dir); attempt_dir.mkdir(parents=True,exist_ok=True)
    require({p.name for p in attempt_dir.iterdir()} <= {'REQUEST.json','OBSERVATION.json','CHECK.json'}, 'unexpected attempt evidence')
    evidence_file(attempt_dir/'REQUEST.json',encoded(attempt))
    evidence_file(attempt_dir/'OBSERVATION.json',observed_bytes)
    try:
        require(observed_error is None, 'observation unavailable: '+str(observed_error))
        operation = json.loads(operation_bytes,object_pairs_hook=guard.unique_object)
        change_plan = json.loads(plan_bytes,object_pairs_hook=guard.unique_object)
        observation = json.loads(observed_bytes,object_pairs_hook=guard.unique_object)
        require(operation['schema'] == 'lumen.delivery-operation/v1', 'unsupported operation')
        require(operation['destination'] == destination and operation['release_id'] == state['request']['release_id'] and operation['review'] == state['request']['review'], 'operation does not match reviewed bundle')
        require(operation['payload_inventory_sha256'] == sha(encoded(rows)), 'operation inventory pin mismatch')
        result = verify_observation(observation,operation,change_plan,rows,returned,private=scope != 'public')
        check = {'status':'observation-and-payload-verified','result':result}
    except (ValueError,KeyError,TypeError,OSError,lumen.LumenError) as exc:
        check = {'status':'verification-failed','error':str(exc)}
        verified_evidence(attempt_dir/'CHECK.json',check)
        raise
    verified_evidence(attempt_dir/'CHECK.json',check)
    return result, observation


def finalize(args):
    bundle = Path(args.bundle)
    state_bytes = regular(bundle/'DELIVERY.json')
    state = json.loads(state_bytes,object_pairs_hook=guard.unique_object)
    for scope in ('private','public'):
        require(inventory(bundle/scope) == state[scope+'_inventory'] and sha(encoded(state[scope+'_inventory'])) == state[scope+'_inventory_sha256'], 'prepared bundle inventory mismatch')
    verify_primary_alias(state,bundle)
    require(isinstance(args.project_id,str) and args.project_id.strip(), 'project ID is required')
    pointer_path = guard.path_name(args.pointer_path)
    output = Path(os.path.abspath(args.output)); no_symlink_path(output)
    require(not output.is_relative_to(bundle.absolute()) and not bundle.absolute().is_relative_to(output), 'finalization output and bundle must be disjoint')
    allowed = {'FINALIZE-REQUEST.json','private-REQUEST.json','private-VERIFIED.json',
               'public-REQUEST.json','public-VERIFIED.json','pointer-REQUEST.json','pointer-VERIFIED.json',
               'pointer-payload','pointer-plan','OUTCOMES.json','private-attempts','public-attempts','pointer-attempts'}
    if output.exists():
        require(output.is_dir() and {p.name for p in output.iterdir()} <= allowed, 'unexpected finalization evidence')
    else:
        output.mkdir(parents=True)
    request = {'schema':'lumen.delivery-finalization/v1','bundle_sha256':sha(state_bytes),
               'project_id':args.project_id,'pointer_path':pointer_path}
    evidence_file(output/'FINALIZE-REQUEST.json',encoded(request))
    previous_outcomes = None
    if (output/'OUTCOMES.json').exists():
        previous_outcomes = json.loads(regular(output/'OUTCOMES.json'),object_pairs_hook=guard.unique_object)
        require(set(previous_outcomes) == {'schema','private','public','pointer'} and previous_outcomes['schema'] == 'lumen.delivery-finalization-outcomes/v1', 'divergent finalization outcomes')
        for scope in ('public','pointer'):
            prior = previous_outcomes[scope]
            require(isinstance(prior,dict) and prior.get('status') in ('unobserved','publication-pending','returned-bytes-verified','verification-failed'), 'invalid previous phase outcome')
            if prior['status'] == 'returned-bytes-verified':
                require(regular(output/(scope+'-VERIFIED.json')) == encoded(prior), 'divergent prior verification outcome')
    private, observation = finalize_phase('private',state,sha(state_bytes),Path(args.private_plan),
        Path(args.private_observation),Path(args.private_returned),output,state['private_inventory'],state['request']['profile']['private'])
    transport_bytes, transport, archive = read_transport(Path(args.private_returned),state['transport_path'],state['transport_sha256'])
    with tempfile.TemporaryDirectory(prefix='.delivery-finalize-',dir=output.parent) as temp:
        path = Path(temp)/'checkpoint.zip'; save(path,archive); checkpoint = strict_checkpoint(path)
    require(sha(archive) == state['request']['checkpoint_sha256'] and checkpoint['content_identity_sha256'] == state['private_content_identity_sha256'] and checkpoint['edition'] == state['edition'] and transport['content_identity_sha256'] == checkpoint['content_identity_sha256'] and transport['edition'] == checkpoint['edition'], 'private checkpoint/transport/bundle identity mismatch')
    private.update(checkpoint_sha256=sha(archive),content_identity_sha256=checkpoint['content_identity_sha256'],edition=checkpoint['edition'])
    private = verified_evidence(output/'private-VERIFIED.json',private)
    pointer = {'schema_version':1,'project_id':args.project_id,'repository':private['repository'],
               'verified_source_commit':private['commit'],'checkpoint_path':state['transport_path'],
               'checkpoint_sha256':sha(archive),'transport_manifest_sha256':sha(transport_bytes),
               'encoding':'lumen.chunked-checkpoint-transport/v1; fetch ordered parts at verified_source_commit; verify per-part and concatenated text hashes; decode base64; verify ZIP hash',
               'content_identity_sha256':checkpoint['content_identity_sha256'],'edition':checkpoint['edition']}
    payload = output/'pointer-payload'/pointer_path
    no_symlink_path(payload); payload.parent.mkdir(parents=True,exist_ok=True)
    evidence_file(payload,encoded(pointer))
    pointer_rows = inventory(output/'pointer-payload')
    require(pointer_rows == [record(pointer_path,encoded(pointer))], 'unexpected pointer payload files')
    baseline = observation['tree']; before = guard.complete_tree(baseline,private['tree'],'pointer baseline')
    after = dict(before); new = {'mode':'100644','type':'blob','sha':blob(encoded(pointer),len(private['tree']))}
    require(before.get(pointer_path) != new, 'pointer already equals draft in private baseline; supply independently reviewed pointer evidence')
    after[pointer_path] = new; candidate = recursive_tree(after,len(private['tree']))
    pointer_plan = {'schema_version':1,'baseline_tree_sha':private['tree'],'candidate_tree_sha':candidate['sha'],
                    'changes':[{'path':pointer_path,'before':before.get(pointer_path),'after':new}]}
    guard.verify(baseline,candidate,pointer_plan,baseline_tree_sha=private['tree'],candidate_tree_sha=candidate['sha'])
    operation = {'schema':'lumen.delivery-operation/v1','destination':state['request']['profile']['private'],
                 'release_id':state['request']['release_id'],'review':state['request']['review'],
                 'baseline_commit':private['commit'],'baseline_tree_sha':private['tree'],'candidate_tree_sha':candidate['sha'],
                 'payload_inventory_sha256':sha(encoded(pointer_rows)),
                 'status':'pointer-publication-pending; authorized connector must publish and return immutable observations and bytes'}
    pointer_plan_dir = output/'pointer-plan'; no_symlink_path(pointer_plan_dir); pointer_plan_dir.mkdir(exist_ok=True)
    require({p.name for p in pointer_plan_dir.iterdir()} <= {'OPERATION.json','change-plan.json','candidate-tree.json'}, 'unexpected pointer plan files')
    for name,value in [('OPERATION.json',operation),('change-plan.json',pointer_plan),('candidate-tree.json',candidate)]:
        evidence_file(pointer_plan_dir/name,encoded(value))
    outcomes = {'schema':'lumen.delivery-finalization-outcomes/v1','private':private,
                'public':{'status':'unobserved'},'pointer':{'status':'publication-pending','draft_sha256':sha(encoded(pointer))}}
    if previous_outcomes:
        outcomes['public'] = previous_outcomes['public']
        outcomes['pointer'] = previous_outcomes['pointer']
    # Private verification and pointer draft are durable before any optional public work.
    atomic_save(output/'OUTCOMES.json',encoded(outcomes))
    for scope in ('public','pointer'):
        values = [getattr(args,scope+'_observation'),getattr(args,scope+'_returned')]
        if scope == 'public': values.append(args.public_plan)
        if not any(values): continue
        try:
            require(all(values), f'{scope} evidence arguments must be supplied together')
            result,_ = finalize_phase(scope,state,sha(state_bytes),Path(args.public_plan) if scope == 'public' else pointer_plan_dir,
                Path(values[0]),Path(values[1]),output,state['public_inventory'] if scope == 'public' else pointer_rows,
                state['request']['profile']['public' if scope == 'public' else 'private'])
            outcomes[scope] = verified_evidence(output/(scope+'-VERIFIED.json'),result)
        except (ValueError,KeyError,TypeError,OSError,lumen.LumenError) as exc:
            outcomes[scope] = {'status':'verification-failed','error':str(exc),'private_result_retained':True}
        atomic_save(output/'OUTCOMES.json',encoded(outcomes))
    return outcomes


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command',required=True)
    s = sub.add_parser('prepare')
    for name in ('release-id','profile','review','checkpoint','output'):
        s.add_argument('--'+name,required=True)
    s.add_argument('--handoff', help='existing HANDOFF directory, required to match rebuilt frozen bytes exactly')
    s.add_argument('--part-bytes',type=int,default=160000)
    s = sub.add_parser('plan')
    for name in ('bundle','baseline','baseline-tree-sha','baseline-commit','output'):
        s.add_argument('--'+name,required=True)
    s.add_argument('--scope',choices=('public','private'),required=True)
    s = sub.add_parser('recover')
    for name in ('pointer','pointer-sha256','parts','into','output'):
        s.add_argument('--'+name,required=True)
    s = sub.add_parser('finalize')
    for name in ('bundle','private-plan','private-observation','private-returned','project-id','output'):
        s.add_argument('--'+name,required=True)
    s.add_argument('--pointer-path',default='recovery/field-notes-current.json')
    for name in ('public-plan','public-observation','public-returned','pointer-observation','pointer-returned'):
        s.add_argument('--'+name)
    return p


def main():
    args = parser().parse_args()
    try:
        result = {'prepare':prepare,'plan':plan,'recover':recover,'finalize':finalize}[args.command](args)
    except (ValueError, KeyError, TypeError, OSError, subprocess.CalledProcessError, lumen.LumenError) as exc:
        print(f'delivery: REJECTED: {exc}',file=sys.stderr)
        return 1
    print(json.dumps(result,sort_keys=True))
    if args.command == 'finalize' and any(result[scope]['status'] == 'verification-failed' for scope in ('public','pointer')):
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
