"""Offline synthetic adapter contracts; never recurse into the ship test gate."""
import argparse
import base64
import hashlib
import json
import shutil
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'tools'))
import delivery as d


class DeliveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.checkpoint = self.root/'input.zip'
        files = [('config.json',b'{"edition":"test"}\n',0o644),
                 ('content/data/source-snapshot.json',b'{"captured_at":"2026-01-01T00:00:00Z"}\n',0o644),
                 ('content/draft.txt',b'PRIVATE DRAFT\n',0o644),
                 ('lumen',b'#!/bin/sh\n',0o755)]
        self.manifest = {'schema':d.lumen.CHECKPOINT_SCHEMA, 'edition':'test',
            'content_identity_sha256':d.lumen.checkpoint_fingerprint(files),
            'members':[{'path':'Lumen/'+p,'bytes':len(b),'sha256':d.sha(b),'mode':f'{m:04o}'} for p,b,m in files]}
        with zipfile.ZipFile(self.checkpoint,'w') as z:
            for p,b,m in [('LUMEN-CHECKPOINT.json',d.encoded(self.manifest),0o644),('README.txt',b'recovery',0o644),*[(f'Lumen/{p}',b,m) for p,b,m in files]]:
                i=zipfile.ZipInfo(p); i.external_attr=m<<16; z.writestr(i,b)
        self.profile = self.root/'profile.json'
        d.save(self.profile,d.encoded({'public':{'repository':'example/public','prefix':'releases','branch':'main'},'private':{'repository':'example/private','prefix':'backups','branch':'main'}}))
        self.args = argparse.Namespace(release_id='test-1',review='local-review-1',profile=str(self.profile),
            checkpoint=str(self.checkpoint),output=str(self.root/'bundle'),handoff=None,part_bytes=100)

    def tearDown(self):
        self.temp.cleanup()

    def ship(self, command, cwd, env, check):
        # Verify orchestration uses frozen source, not any live canonical path.
        self.assertEqual((cwd/'content/draft.txt').read_bytes(),b'PRIVATE DRAFT\n')
        self.assertEqual(env['PYTHONDONTWRITEBYTECODE'],'1')
        output=Path(command[-1]); output.mkdir()
        entries=[]
        for name in ('Lumen.html','site.zip','repository.zip'):
            data=b'PUBLIC '+name.encode(); d.save(output/name,data)
            entries.append({'file':name,'bytes':len(data),'sha256':d.sha(data)})
        entries[1]['role']='github-pages-projection'; entries[2]['role']='ordinary-github-worktree'
        handoff={'schema':'lumen.handoff/v3','edition':'test','generated_at':'2026-01-01T00:00:00Z',
            'source_fingerprint_sha256':'1'*64,'primary':entries[0],'archives':entries[1:]}
        if env.get('SOURCE_DATE_EPOCH'):
            handoff['generated_at']=d.dt.datetime.fromtimestamp(int(env['SOURCE_DATE_EPOCH']),d.dt.timezone.utc).isoformat().replace('+00:00','Z')
        release={'schema':'lumen.release/v2','edition':'test','source_fingerprint_sha256':'1'*64,
                 'archive':entries[1]['file'],'sha256':entries[1]['sha256'],'bytes':entries[1]['bytes']}
        for name,data in [('RELEASE.json',d.encoded(release)),('HANDOFF.json',d.encoded(handoff)),('README.txt',b'public readme'),('SHA256SUMS',b'sums'),('Lumen.html.sha256',b'sum')]:
            d.save(output/name,data)

    def prepare(self):
        with patch.object(d.subprocess,'run',side_effect=self.ship):
            return d.prepare(self.args)

    def pointer(self,state):
        pointer={'schema_version':1,'project_id':'synthetic-test','repository':'example/private',
                 'verified_source_commit':'a'*40,'checkpoint_path':state['transport_path'],
                 'transport_manifest_sha256':state['transport_sha256'],
                 'checkpoint_sha256':state['request']['checkpoint_sha256'],
                 'content_identity_sha256':state['private_content_identity_sha256'],
                 'edition':state['edition'],'encoding':'lumen.chunked-checkpoint-transport/v1; ordered parts'}
        path=self.root/'pointer.json'; d.save(path,d.encoded(pointer))
        return argparse.Namespace(pointer=str(path),pointer_sha256=d.sha(path.read_bytes()),
            parts=str(self.root/'bundle/private'),into=str(self.root/'restore'),output=str(self.root/'recovery'))

    def test_roundtrip_and_private_exclusion(self):
        state=self.prepare()
        self.assertNotEqual(state['private_content_identity_sha256'],state['public_source_fingerprint_sha256'])
        self.assertFalse(any(b'PRIVATE DRAFT' in p.read_bytes() for p in (self.root/'bundle/public').rglob('*') if p.is_file()))
        result=d.recover(self.pointer(state))
        self.assertEqual(result['status'],'exact-restore-verified')
        self.assertEqual((self.root/'restore/content/draft.txt').read_bytes(),b'PRIVATE DRAFT\n')
        self.assertEqual((self.root/'restore/lumen').stat().st_mode&0o777,0o755)

    def test_stable_replay_and_conflict(self):
        state=self.prepare()
        self.assertEqual(d.prepare(self.args),state)
        self.args.review='different'
        with self.assertRaises(d.DeliveryError): d.prepare(self.args)

    def test_modified_bundle_refused(self):
        self.prepare(); next((self.root/'bundle/public').rglob('Lumen.html')).write_text('changed')
        with self.assertRaises(d.DeliveryError): d.prepare(self.args)

    def test_changed_checkpoint_conflicts(self):
        self.prepare(); self.checkpoint.write_bytes(self.checkpoint.read_bytes()+b'changed')
        with self.assertRaises(d.DeliveryError): d.prepare(self.args)

    def test_supplied_mixed_handoff_refused(self):
        output=self.root/'other'; frozen=self.root/'frozen'; d.reopen(self.checkpoint,frozen)
        self.ship(['ship',str(output)],frozen,{'PYTHONDONTWRITEBYTECODE':'1'},True)
        h=d.load(output/'HANDOFF.json'); h['source_fingerprint_sha256']='2'*64
        d.save(output/'HANDOFF.json',d.encoded(h))
        release=d.load(output/'RELEASE.json'); release['source_fingerprint_sha256']='2'*64
        d.save(output/'RELEASE.json',d.encoded(release)); self.args.handoff=str(output)
        with self.assertRaises(d.DeliveryError): self.prepare()
        self.assertFalse(Path(self.args.output).exists())

    def test_altered_or_missing_parts(self):
        state=self.prepare(); args=self.pointer(state)
        manifest=d.load(Path(args.parts)/state['transport_path']); path=Path(args.parts)/manifest['parts'][0]['path']
        original=path.read_bytes(); path.write_bytes(b'wrong')
        with self.assertRaises(d.DeliveryError): d.recover(args)
        path.unlink()
        with self.assertRaises(d.DeliveryError): d.recover(args)
        path.write_bytes(original)

    def test_reordered_parts_even_with_new_transport_pin(self):
        state=self.prepare(); args=self.pointer(state)
        path=Path(args.parts)/state['transport_path']; transport=d.load(path)
        transport['parts'].reverse(); d.save(path,d.encoded(transport))
        pointer=d.load(args.pointer); pointer['transport_manifest_sha256']=d.sha(path.read_bytes())
        d.save(Path(args.pointer),d.encoded(pointer)); args.pointer_sha256=d.sha(Path(args.pointer).read_bytes())
        with self.assertRaises(d.DeliveryError): d.recover(args)

    def test_mismatched_checkpoint_identity(self):
        state=self.prepare(); args=self.pointer(state)
        path=Path(args.parts)/state['transport_path']; transport=d.load(path)
        transport['content_identity_sha256']='0'*64; d.save(path,d.encoded(transport))
        pointer=d.load(args.pointer); pointer['transport_manifest_sha256']=d.sha(path.read_bytes())
        d.save(Path(args.pointer),d.encoded(pointer)); args.pointer_sha256=d.sha(Path(args.pointer).read_bytes())
        with self.assertRaises(d.DeliveryError): d.recover(args)
        self.assertFalse(Path(args.into).exists())

    def test_restore_replay_and_modified_refusal(self):
        state=self.prepare(); args=self.pointer(state); d.recover(args)
        args.output=str(self.root/'recovery2'); d.recover(args)
        (Path(args.into)/'content/draft.txt').write_text('user edit')
        args.output=str(self.root/'recovery3')
        with self.assertRaises(d.DeliveryError): d.recover(args)
        self.assertEqual((Path(args.into)/'content/draft.txt').read_text(),'user edit')

    def test_mode_or_extra_file_refused(self):
        state=self.prepare(); args=self.pointer(state); d.recover(args)
        (Path(args.into)/'lumen').chmod(0o644); args.output=str(self.root/'mode-fail')
        with self.assertRaises(d.DeliveryError): d.recover(args)
        (Path(args.into)/'lumen').chmod(0o755); (Path(args.into)/'extra').write_text('extra')
        args.output=str(self.root/'extra-fail')
        with self.assertRaises(d.DeliveryError): d.recover(args)

    def test_pointer_pin_and_symlink_refused(self):
        state=self.prepare(); args=self.pointer(state); args.pointer_sha256='0'*64
        with self.assertRaises(d.DeliveryError): d.recover(args)
        args=self.pointer(state)
        (self.root/'restore').symlink_to(self.root/'absent')
        with self.assertRaises(d.DeliveryError): d.recover(args)

    def test_plan_preserves_unselected_baseline(self):
        state=self.prepare()
        base=d.recursive_tree({'unselected.txt':{'mode':'100644','type':'blob','sha':d.blob(b'old')}},40)
        path=self.root/'baseline.json'; d.save(path,d.encoded(base))
        args=argparse.Namespace(bundle=self.args.output,baseline=str(path),baseline_tree_sha=base['sha'],baseline_commit='b'*40,scope='public',output=str(self.root/'plan'))
        plan=d.plan(args)
        self.assertNotIn('unselected.txt',[c['path'] for c in plan['changes']])
        candidate=d.load(self.root/'plan/candidate-tree.json')
        self.assertEqual(d.guard.complete_tree(candidate,candidate['sha'],'candidate')['unselected.txt']['sha'],d.blob(b'old'))
        base['truncated']=True; d.save(path,d.encoded(base)); args.output=str(self.root/'bad-plan')
        with self.assertRaises(d.guard.GuardError): d.plan(args)

    def test_ship_source_mutation_refused(self):
        def mutated(command,cwd,env,check):
            self.ship(command,cwd,env,check)
            (cwd/'content/draft.txt').write_text('changed')
        with patch.object(d.subprocess,'run',side_effect=mutated):
            with self.assertRaises(d.DeliveryError): d.prepare(self.args)
        self.assertFalse(Path(self.args.output).exists())

    def test_plan_stable_id_conflict_across_bundles(self):
        state=self.prepare()
        selected=state['public_inventory'][0]['path']
        base=d.recursive_tree({selected:{'mode':'100644','type':'blob','sha':d.blob(b'different')}},40)
        path=self.root/'baseline.json'; d.save(path,d.encoded(base))
        args=argparse.Namespace(bundle=self.args.output,baseline=str(path),baseline_tree_sha=base['sha'],baseline_commit='b'*40,scope='public',output=str(self.root/'plan'))
        with self.assertRaises(d.DeliveryError): d.plan(args)
        self.assertFalse(Path(args.output).exists())

    def test_added_source_during_ship_refused(self):
        def mutated(command,cwd,env,check):
            self.ship(command,cwd,env,check)
            (cwd/'content/new-draft.txt').write_text('new draft')
        with patch.object(d.subprocess,'run',side_effect=mutated):
            with self.assertRaises(d.DeliveryError): d.prepare(self.args)
        self.assertFalse(Path(self.args.output).exists())

    def test_extra_directory_restore_refused(self):
        state=self.prepare(); args=self.pointer(state); d.recover(args)
        (Path(args.into)/'extra-directory').mkdir(); args.output=str(self.root/'extra-dir-fail')
        with self.assertRaises(d.DeliveryError): d.recover(args)

    def test_same_evidence_output_replay(self):
        state=self.prepare(); args=self.pointer(state)
        first=d.recover(args); original=(Path(args.output)/'checkpoint.zip').read_bytes()
        second=d.recover(args)
        self.assertGreater(second['verified_at'],first['verified_at'])
        self.assertNotIn('completed_at',second)
        self.assertEqual((Path(args.output)/'checkpoint.zip').read_bytes(),original)
        first.pop('verified_at'); second.pop('verified_at'); self.assertEqual(first,second)
        self.assertEqual(state['outcomes']['remote_private'],'unobserved')
        self.assertNotIn('private_verified',state['outcomes'])

    def test_resume_after_request_before_archive(self):
        state=self.prepare(); args=self.pointer(state); original=d.evidence_file
        def interrupted(path,data):
            if path.name=='checkpoint.zip': raise RuntimeError('simulated interruption')
            original(path,data)
        with patch.object(d,'evidence_file',side_effect=interrupted):
            with self.assertRaises(RuntimeError): d.recover(args)
        self.assertTrue((Path(args.output)/'REQUEST.json').exists())
        self.assertFalse(Path(args.into).exists())
        self.assertEqual(d.recover(args)['status'],'exact-restore-verified')

    def test_resume_after_restore_before_receipt(self):
        state=self.prepare(); args=self.pointer(state); original=d.atomic_save
        def interrupted(path,data):
            if path.name=='RESTORE.json': raise RuntimeError('simulated lost acknowledgement')
            original(path,data)
        with patch.object(d,'atomic_save',side_effect=interrupted):
            with self.assertRaises(RuntimeError): d.recover(args)
        self.assertTrue(Path(args.into).exists())
        self.assertFalse((Path(args.output)/'RESTORE.json').exists())
        self.assertEqual(d.recover(args)['status'],'exact-restore-verified')

    def test_replay_refuses_changed_request_or_evidence(self):
        state=self.prepare(); args=self.pointer(state); d.recover(args)
        original_into=args.into; args.into=str(self.root/'different-target')
        with self.assertRaises(d.DeliveryError): d.recover(args)
        self.assertFalse(Path(args.into).exists()); args.into=original_into
        archive=Path(args.output)/'checkpoint.zip'; archive.write_bytes(b'changed evidence')
        with self.assertRaises(d.DeliveryError): d.recover(args)
        self.assertEqual(archive.read_bytes(),b'changed evidence')

    def test_replay_refuses_divergent_receipt_or_target(self):
        state=self.prepare(); args=self.pointer(state); d.recover(args)
        receipt=Path(args.output)/'RESTORE.json'; original=receipt.read_bytes()
        receipt.write_text('{}')
        with self.assertRaises(d.DeliveryError): d.recover(args)
        self.assertEqual(receipt.read_text(),'{}'); receipt.write_bytes(original)
        (Path(args.into)/'content/draft.txt').write_text('edited')
        with self.assertRaises(d.DeliveryError): d.recover(args)
        self.assertEqual(receipt.read_bytes(),original)
        self.assertEqual((Path(args.into)/'content/draft.txt').read_text(),'edited')

    def test_output_and_target_symlink_ancestors_refused(self):
        state=self.prepare(); args=self.pointer(state)
        directory=self.root/'real'; directory.mkdir(); link=self.root/'link'; link.symlink_to(directory,target_is_directory=True)
        args.output=str(link/'evidence')
        with self.assertRaises(d.DeliveryError): d.recover(args)
        self.assertFalse((directory/'evidence').exists())
        args.output=str(self.root/'evidence'); args.into=str(link/'target')
        with self.assertRaises(d.DeliveryError): d.recover(args)
        self.assertFalse((directory/'target').exists())
        self.args.output=str(link/'prepared')
        with self.assertRaises(d.DeliveryError): self.prepare()

    def test_existing_pointer_without_optional_transport_pin(self):
        state=self.prepare(); args=self.pointer(state)
        pointer=d.load(args.pointer); del pointer['transport_manifest_sha256']
        d.save(Path(args.pointer),d.encoded(pointer)); args.pointer_sha256=d.sha(Path(args.pointer).read_bytes())
        self.assertEqual(d.recover(args)['status'],'exact-restore-verified')

    def test_existing_pointer_identity_conflicts(self):
        state=self.prepare(); args=self.pointer(state)
        original=d.load(args.pointer)
        for field,value in [('checkpoint_sha256','f'*64),('content_identity_sha256','f'*64),('edition','wrong')]:
            pointer=dict(original); pointer[field]=value
            d.save(Path(args.pointer),d.encoded(pointer)); args.pointer_sha256=d.sha(Path(args.pointer).read_bytes())
            with self.assertRaises(d.DeliveryError): d.recover(args)
        self.assertFalse(Path(args.into).exists())

    def finalization_fixture(self):
        state=self.prepare()
        args=argparse.Namespace(bundle=self.args.output,project_id='synthetic-test',pointer_path='recovery/field-notes-current.json',
            output=str(self.root/'finalized'),public_plan=None,public_observation=None,public_returned=None,
            pointer_observation=None,pointer_returned=None)
        for scope,commit in [('private','a'*40),('public','c'*40)]:
            baseline=d.recursive_tree({'keep.txt':{'mode':'100644','type':'blob','sha':d.blob(b'keep')}},40)
            baseline_path=self.root/(scope+'-baseline.json'); d.save(baseline_path,d.encoded(baseline))
            plan_dir=self.root/(scope+'-plan')
            d.plan(argparse.Namespace(bundle=self.args.output,scope=scope,baseline=str(baseline_path),
                baseline_tree_sha=baseline['sha'],baseline_commit='b'*40,output=str(plan_dir)))
            candidate=d.load(plan_dir/'candidate-tree.json')
            sizes={r['path']:r['bytes'] for r in state[scope+'_inventory']}
            for entry in candidate['tree']:
                if entry['path'] in sizes: entry['size']=sizes[entry['path']]
            observed={'repository':{'full_name':'example/'+scope,'private':scope=='private'},
                'baseline_commit':{'sha':'b'*40,'tree':{'sha':baseline['sha']},'parents':[]},'baseline_tree':baseline,
                'commit':{'sha':commit,'tree':{'sha':candidate['sha']},'parents':[{'sha':'b'*40}]},
                'ref':{'ref':'refs/heads/main','object':{'type':'commit','sha':commit}},'tree':candidate}
            observed_path=self.root/(scope+'-observed.json'); d.save(observed_path,d.encoded(observed))
            returned=self.root/(scope+'-returned'); shutil.copytree(self.root/'bundle'/scope,returned)
            if scope=='private':
                args.private_plan=str(plan_dir); args.private_observation=str(observed_path); args.private_returned=str(returned)
        return args,state

    def add_public(self,args):
        args.public_plan=str(self.root/'public-plan'); args.public_observation=str(self.root/'public-observed.json'); args.public_returned=str(self.root/'public-returned')

    def test_finalize_private_and_generated_existing_pointer(self):
        args,state=self.finalization_fixture(); result=d.finalize(args)
        self.assertEqual(result['private']['status'],'returned-bytes-verified')
        self.assertEqual(result['pointer']['status'],'publication-pending')
        pointer=d.load(Path(args.output)/'pointer-payload/recovery/field-notes-current.json')
        self.assertEqual(pointer['verified_source_commit'],'a'*40)
        self.assertEqual(pointer['checkpoint_sha256'],state['request']['checkpoint_sha256'])
        self.assertNotIn('source_mirror_commit',pointer); self.assertNotIn('tests_passed',pointer)
        self.assertNotIn('public_preview_commit',pointer)
        restored=self.pointer(state)
        restored.pointer=str(Path(args.output)/'pointer-payload/recovery/field-notes-current.json')
        restored.pointer_sha256=d.sha(Path(restored.pointer).read_bytes())
        self.assertEqual(d.recover(restored)['status'],'exact-restore-verified')
        self.assertEqual(d.finalize(args)['private']['commit'],'a'*40)

    def test_finalize_wrong_observations_fail_closed(self):
        args,state=self.finalization_fixture(); original=d.load(args.private_observation)
        edits=[lambda x:x['repository'].update(private=False),
               lambda x:x['repository'].update(full_name='wrong/repo'),
               lambda x:x['commit']['tree'].update(sha='f'*40),
               lambda x:x['commit'].update(parents=[{'sha':'f'*40}]),
               lambda x:x['ref']['object'].update(sha='f'*40),
               lambda x:x['baseline_commit']['tree'].update(sha='f'*40),
               lambda x:x['tree'].update(truncated=True),
               lambda x:x.update(authenticated=True),
               lambda x:x.pop('ref')]
        for index,edit in enumerate(edits):
            observed=json.loads(json.dumps(original)); edit(observed)
            d.save(Path(args.private_observation),d.encoded(observed)); args.output=str(self.root/f'bad-final-{index}')
            with self.assertRaises((d.DeliveryError,d.guard.GuardError,KeyError)): d.finalize(args)
            self.assertFalse((Path(args.output)/'private-VERIFIED.json').exists())

    def test_finalize_returned_bytes_modes_and_set(self):
        args,state=self.finalization_fixture(); root=Path(args.private_returned)
        path=root/state['private_inventory'][0]['path']; original=path.read_bytes()
        path.write_bytes(b'wrong')
        with self.assertRaises(d.DeliveryError): d.finalize(args)
        path.write_bytes(original); path.chmod(0o755)
        with self.assertRaises(d.DeliveryError): d.finalize(args)
        path.chmod(0o644); (root/'extra').write_text('extra')
        with self.assertRaises(d.DeliveryError): d.finalize(args)
        (root/'extra').unlink()
        self.assertEqual(d.finalize(args)['private']['status'],'returned-bytes-verified')

    def test_finalize_public_failure_retains_private(self):
        args,state=self.finalization_fixture(); self.add_public(args)
        observed=d.load(args.public_observation); observed['commit']['parents']=[]
        d.save(Path(args.public_observation),d.encoded(observed))
        result=d.finalize(args)
        self.assertEqual(result['private']['status'],'returned-bytes-verified')
        self.assertEqual(result['public']['status'],'verification-failed')
        self.assertTrue((Path(args.output)/'private-VERIFIED.json').exists())
        self.assertTrue((Path(args.output)/'pointer-payload/recovery/field-notes-current.json').exists())
        self.assertEqual(d.finalize(args)['public']['status'],'verification-failed')

    def test_finalize_public_independently_verified(self):
        args,state=self.finalization_fixture(); self.add_public(args)
        result=d.finalize(args)
        self.assertEqual(result['public']['commit'],'c'*40)
        self.assertEqual(result['private']['commit'],'a'*40)
        self.assertEqual(result['pointer']['status'],'publication-pending')

    def pointer_observation(self,args):
        out=Path(args.output); op=d.load(out/'pointer-plan/OPERATION.json')
        prior=d.load(args.private_observation)
        observed={'repository':prior['repository'],'baseline_commit':prior['commit'],'baseline_tree':prior['tree'],
            'commit':{'sha':'d'*40,'tree':{'sha':op['candidate_tree_sha']},'parents':[{'sha':'a'*40}]},
            'ref':{'ref':'refs/heads/main','object':{'type':'commit','sha':'d'*40}},
            'tree':d.load(out/'pointer-plan/candidate-tree.json')}
        sizes={r['path']:r['bytes'] for r in d.inventory(out/'pointer-payload')}
        for entry in observed['tree']['tree']:
            if entry['path'] in sizes: entry['size']=sizes[entry['path']]
        path=self.root/'pointer-observed.json'; d.save(path,d.encoded(observed)); args.pointer_observation=str(path)
        returned=self.root/'pointer-returned'; shutil.copytree(out/'pointer-payload',returned); args.pointer_returned=str(returned)

    def test_finalize_pointer_requires_own_readback(self):
        args,state=self.finalization_fixture(); d.finalize(args); self.pointer_observation(args)
        result=d.finalize(args)
        self.assertEqual(result['pointer']['status'],'returned-bytes-verified')
        self.assertEqual(result['pointer']['commit'],'d'*40)
        self.assertEqual(d.finalize(args)['pointer']['commit'],'d'*40)

    def test_finalize_pointer_wrong_bytes_keeps_private(self):
        args,state=self.finalization_fixture(); d.finalize(args); self.pointer_observation(args)
        path=Path(args.pointer_returned)/'recovery/field-notes-current.json'; path.write_text('{}')
        result=d.finalize(args)
        self.assertEqual(result['pointer']['status'],'verification-failed')
        self.assertEqual(result['private']['status'],'returned-bytes-verified')
        self.assertFalse((Path(args.output)/'pointer-VERIFIED.json').exists())

    def test_finalize_changed_pinned_request_refused(self):
        args,state=self.finalization_fixture(); d.finalize(args)
        observed=d.load(args.private_observation); observed['ref']['ref']='refs/heads/other'
        d.save(Path(args.private_observation),d.encoded(observed))
        with self.assertRaises(d.DeliveryError): d.finalize(args)
        self.assertTrue((Path(args.output)/'private-VERIFIED.json').exists())

    def test_finalize_prior_public_evidence_retained_when_omitted(self):
        args,state=self.finalization_fixture(); self.add_public(args)
        prior=d.finalize(args)['public']
        args.public_plan=args.public_observation=args.public_returned=None
        self.assertEqual(d.finalize(args)['public'],prior)

    def test_finalize_observed_blob_size_required(self):
        args,state=self.finalization_fixture(); observed=d.load(args.private_observation)
        selected=state['private_inventory'][0]['path']
        next(r for r in observed['tree']['tree'] if r['path']==selected).pop('size')
        d.save(Path(args.private_observation),d.encoded(observed))
        with self.assertRaises(d.DeliveryError): d.finalize(args)

    def test_finalize_missing_public_file_is_partial_failure(self):
        args,state=self.finalization_fixture(); self.add_public(args)
        Path(args.public_observation).unlink()
        result=d.finalize(args)
        self.assertEqual(result['public']['status'],'verification-failed')
        self.assertEqual(result['private']['status'],'returned-bytes-verified')

    def test_finalize_cli_partial_failure_is_nonzero(self):
        args,state=self.finalization_fixture(); self.add_public(args)
        Path(args.public_observation).write_text('{}')
        command=[sys.executable,str(Path(d.__file__)),'finalize']
        for name in ('bundle','private_plan','private_observation','private_returned','project_id','output',
                     'public_plan','public_observation','public_returned'):
            command.extend(['--'+name.replace('_','-'),getattr(args,name)])
        result=d.subprocess.run(command,capture_output=True,text=True)
        self.assertEqual(result.returncode,1)
        self.assertEqual(json.loads(result.stdout)['private']['status'],'returned-bytes-verified')

    def test_finalize_replay_after_private_receipt_interruption(self):
        args,state=self.finalization_fixture(); original=d.evidence_file
        def interrupted(path,data):
            if path.name=='field-notes-current.json': raise RuntimeError('simulated interruption')
            original(path,data)
        with patch.object(d,'evidence_file',side_effect=interrupted):
            with self.assertRaises(RuntimeError): d.finalize(args)
        self.assertTrue((Path(args.output)/'private-VERIFIED.json').exists())
        self.assertEqual(d.finalize(args)['pointer']['status'],'publication-pending')

    def test_finalize_failed_public_then_correct_same_output(self):
        args,state=self.finalization_fixture(); self.add_public(args)
        original=Path(args.public_observation).read_bytes(); Path(args.public_observation).write_text('{}')
        failed=d.finalize(args); private_receipt=(Path(args.output)/'private-VERIFIED.json').read_bytes()
        self.assertEqual(failed['public']['status'],'verification-failed')
        failed_attempts={p.name:(p/'CHECK.json').read_bytes() for p in (Path(args.output)/'public-attempts').iterdir()}
        Path(args.public_observation).write_bytes(original)
        corrected=d.finalize(args)
        self.assertEqual(corrected['public']['status'],'returned-bytes-verified')
        self.assertEqual((Path(args.output)/'private-VERIFIED.json').read_bytes(),private_receipt)
        self.assertEqual(len(list((Path(args.output)/'public-attempts').iterdir())),2)
        for name,data in failed_attempts.items():
            self.assertEqual((Path(args.output)/'public-attempts'/name/'CHECK.json').read_bytes(),data)

    def test_finalize_verified_target_cannot_change(self):
        args,state=self.finalization_fixture(); self.add_public(args); d.finalize(args)
        receipt=Path(args.output)/'public-VERIFIED.json'; original=receipt.read_bytes()
        observed=d.load(args.public_observation); observed['commit']['sha']='e'*40; observed['ref']['object']['sha']='e'*40
        d.save(Path(args.public_observation),d.encoded(observed))
        self.assertEqual(d.finalize(args)['public']['status'],'verification-failed')
        self.assertEqual(receipt.read_bytes(),original)
        operation=Path(args.public_plan)/'OPERATION.json'; value=d.load(operation); value['destination']['branch']='other'
        d.save(operation,d.encoded(value))
        self.assertEqual(d.finalize(args)['public']['status'],'verification-failed')
        self.assertEqual(receipt.read_bytes(),original)

    def test_finalize_exact_intended_branch(self):
        args,state=self.finalization_fixture(); observed=d.load(args.private_observation)
        observed['ref']['ref']='refs/heads/unintended'; d.save(Path(args.private_observation),d.encoded(observed))
        with self.assertRaises(d.DeliveryError): d.finalize(args)
        observed['ref']['ref']='refs/heads/main'; d.save(Path(args.private_observation),d.encoded(observed))
        self.assertEqual(d.finalize(args)['private']['ref'],'refs/heads/main')

    def test_lumen_delivery_forwarding_and_discoverability(self):
        cli=Path(d.__file__).parent/'lumen_cli.py'
        help_result=d.subprocess.run([sys.executable,str(cli),'--help'],capture_output=True,text=True)
        self.assertEqual(help_result.returncode,0); self.assertIn('delivery',help_result.stdout)
        forwarded=d.subprocess.run([sys.executable,str(cli),'delivery','finalize','--help'],capture_output=True,text=True)
        self.assertEqual(forwarded.returncode,0); self.assertIn('--private-observation',forwarded.stdout)
        invalid=d.subprocess.run([sys.executable,str(cli),'delivery','unknown-operation'],capture_output=True,text=True)
        self.assertEqual(invalid.returncode,2)

    def test_plan_same_output_replay_interruption_and_conflict(self):
        state=self.prepare()
        baseline=d.recursive_tree({'keep':{'mode':'100644','type':'blob','sha':d.blob(b'keep')}},40)
        path=self.root/'baseline.json'; d.save(path,d.encoded(baseline))
        args=argparse.Namespace(bundle=self.args.output,scope='private',baseline=str(path),baseline_tree_sha=baseline['sha'],baseline_commit='b'*40,output=str(self.root/'retry-plan'))
        original=d.evidence_file
        def interrupted(path,data):
            if path.name=='change-plan.json': raise RuntimeError('simulated interruption')
            original(path,data)
        with patch.object(d,'evidence_file',side_effect=interrupted):
            with self.assertRaises(RuntimeError): d.plan(args)
        self.assertTrue((Path(args.output)/'REQUEST.json').exists())
        first=d.plan(args)
        exact={p.name:p.read_bytes() for p in Path(args.output).iterdir()}
        self.assertEqual(d.plan(args),first)
        self.assertEqual({p.name:p.read_bytes() for p in Path(args.output).iterdir()},exact)
        args.baseline_commit='c'*40
        with self.assertRaises(d.DeliveryError): d.plan(args)
        self.assertEqual({p.name:p.read_bytes() for p in Path(args.output).iterdir()},exact)
        args.baseline_commit='b'*40
        candidate=Path(args.output)/'candidate-tree.json'; candidate.write_text('{}')
        with self.assertRaises(d.DeliveryError): d.plan(args)
        self.assertEqual(candidate.read_text(),'{}')

    def test_primary_alias_exact_bytes_and_guarded_update(self):
        profile=d.load(self.profile); profile['public']['primary_alias']='previews/current.html'
        d.save(self.profile,d.encoded(profile)); state=self.prepare()
        root=self.root/'bundle/public'; alias=root/'previews/current.html'
        primary=root/'releases/test-1/Lumen.html'
        self.assertEqual(alias.read_bytes(),primary.read_bytes())
        baseline=d.recursive_tree({'previews/current.html':{'mode':'100644','type':'blob','sha':d.blob(b'old preview')},
            'unrelated.html':{'mode':'100644','type':'blob','sha':d.blob(b'untouched')}},40)
        path=self.root/'baseline.json'; d.save(path,d.encoded(baseline))
        args=argparse.Namespace(bundle=self.args.output,scope='public',baseline=str(path),baseline_tree_sha=baseline['sha'],baseline_commit='b'*40,output=str(self.root/'alias-plan'))
        result=d.plan(args)
        change=next(c for c in result['changes'] if c['path']=='previews/current.html')
        self.assertEqual(change['before']['sha'],d.blob(b'old preview'))
        self.assertEqual(change['after']['sha'],d.blob(primary.read_bytes()))
        self.assertNotIn('unrelated.html',[c['path'] for c in result['changes']])
        self.assertNotIn('index.html',[c['path'] for c in result['changes']])

    def test_primary_alias_collision_and_private_alias_refused(self):
        original=d.load(self.profile)
        for alias in ('releases/test-1/Lumen.html','releases/current.html','releases','releases/../outside.html','not-html.txt'):
            profile=json.loads(json.dumps(original)); profile['public']['primary_alias']=alias
            d.save(self.profile,d.encoded(profile))
            with self.assertRaises((d.DeliveryError,d.guard.GuardError)): self.prepare()
        profile=json.loads(json.dumps(original)); profile['private']['primary_alias']='private.html'
        d.save(self.profile,d.encoded(profile))
        with self.assertRaises(d.DeliveryError): self.prepare()

    def test_alias_does_not_make_release_files_mutable(self):
        profile=d.load(self.profile); profile['public']['primary_alias']='previews/current.html'
        d.save(self.profile,d.encoded(profile)); self.prepare()
        baseline=d.recursive_tree({'releases/test-1/Lumen.html':{'mode':'100644','type':'blob','sha':d.blob(b'different')}},40)
        path=self.root/'baseline.json'; d.save(path,d.encoded(baseline))
        args=argparse.Namespace(bundle=self.args.output,scope='public',baseline=str(path),baseline_tree_sha=baseline['sha'],baseline_commit='b'*40,output=str(self.root/'bad-alias-plan'))
        with self.assertRaises(d.DeliveryError): d.plan(args)

    def test_real_handoff_release_receipt_contract(self):
        frozen=self.root/'frozen'; d.reopen(self.checkpoint,frozen); output=self.root/'handoff'
        self.ship(['ship',str(output)],frozen,{'PYTHONDONTWRITEBYTECODE':'1'},True)
        handoff,rows=d.handoff_inventory(output)
        self.assertIn('RELEASE.json',[row['path'] for row in rows])
        release=d.load(output/'RELEASE.json'); release['source_fingerprint_sha256']='f'*64
        d.save(output/'RELEASE.json',d.encoded(release))
        with self.assertRaises(d.DeliveryError): d.handoff_inventory(output)

    def test_inventory_lexical_order_matches_restore_manifest(self):
        root=self.root/'lexical'; (root/'notes').mkdir(parents=True)
        d.save(root/'notes.html',b'index'); d.save(root/'notes/a.txt',b'note')
        rows=d.inventory(root)
        self.assertEqual([r['path'] for r in rows],['notes.html','notes/a.txt'])
        manifest={'members':[dict(path='Lumen/'+r['path'],bytes=r['bytes'],sha256=r['sha256'],mode='0644') for r in rows]}
        d.exact_restore(root,manifest)

    def test_supplied_handoff_default_clock_matches(self):
        frozen=self.root/'frozen'; d.reopen(self.checkpoint,frozen); output=self.root/'handoff'
        self.ship(['ship',str(output)],frozen,{'PYTHONDONTWRITEBYTECODE':'1'},True)
        self.args.handoff=str(output)
        with patch.dict(d.os.environ,{'SOURCE_DATE_EPOCH':'1800000000'}):
            self.assertEqual(self.prepare()['edition'],'test')

    def test_supplied_handoff_nondefault_epoch_matches(self):
        frozen=self.root/'frozen'; d.reopen(self.checkpoint,frozen); output=self.root/'handoff'
        epoch='1800000000'
        self.ship(['ship',str(output)],frozen,{'PYTHONDONTWRITEBYTECODE':'1','SOURCE_DATE_EPOCH':epoch},True)
        self.args.handoff=str(output)
        original=self.ship
        def checked(command,cwd,env,check):
            self.assertEqual(env['SOURCE_DATE_EPOCH'],epoch)
            original(command,cwd,env,check)
        with patch.object(d.subprocess,'run',side_effect=checked):
            self.assertEqual(d.prepare(self.args)['edition'],'test')


if __name__=='__main__': unittest.main()
