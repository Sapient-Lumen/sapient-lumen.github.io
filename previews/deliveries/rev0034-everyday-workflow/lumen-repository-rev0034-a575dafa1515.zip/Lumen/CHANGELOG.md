## rev0034 — repeatable HTML delivery and recovery

- Repair preview of newly created drafts without inventing accepted history; preserve canonical draft exclusion
- Add frozen delivery preparation, exact guarded Git plans, connector-readback verification, generated recovery pointers, and replayable cold recovery
- Keep private custody, public publication, and recovery-pointer publication as independent verified outcomes
- Preserve failed observations while allowing corrected evidence for the same pinned operation; reject divergent replay targets
- Support an explicit public primary alias while retaining immutable edition payloads and unrelated repository files
- Correct ordinary authoring, checkpoint, PR preview, and deployment documentation
- Delivery commands operate on local bytes and supplied observations; authenticated transport remains the caller's responsibility

## rev0033 — reject lossy external note imports

- Refuse an entire external fieldbook import before any state change when a note or quote exceeds its existing supported limit
- Preserve supported schema-v1 exports, selector aliases, whitespace normalization and local-note conflict handling
- Add actual import-handler regressions for atomic refusal, Unicode boundaries and valid round trips
- Legacy localStorage normalization remains unchanged; this is not a repair of already truncated records

## rev0032 — reader capacity and complete-tree preservation

- Refuse new fieldbook items beyond250 and desk items beyond64 without evicting existing entries
- Keep refresh and removal usable at capacity in both reader runtimes
- Repair routed S and Shift+D shortcuts to resolve the active passage without an undefined variable
- Add executable synthetic export/import, quote, packet, Blob, capacity, and keyboard regressions
- Add a standalone offline Git publication guard with independent pins, subtree-hash reconstruction and exact reviewed changes
- Actual browser download and clipboard completion remain unverified; these source tests do not replace browser acceptance

## rev0031 — refuse mixed-edition build output

- Refuse a nonempty output directory before writing unless --clean is explicit
- Preserve refused output exactly; fresh or empty destinations still build normally
- Test that explicit clean rebuilds remove stale edition files and reproduce the exact carrier

## rev0030 — verify a genuinely fresh workshop

- Build an isolated class fixture before CLI tests, independent of any existing dist directory
- Remove folio tests’ implicit writes to the canonical build directory
- Add a regression assertion that the CLI fixture stays outside canonical dist, in disposable .lumen test state
- Fresh Git-recovered rev0029 exposed four formerly hidden test setup failures; no claim that its cold verification passed

## rev0029 — align canonical identity with selected public content

- Use the same public content selection for canonical source fingerprints and carrier packaging
- Keep unlisted content/data files outside canonical identity while draft-aware previews retain their separate inputs
- Clarify the Night Desk source status as a working preview with homepage adoption pending
- Test that unrelated unlisted data cannot change canonical identity

## rev0028 — make time and project boundaries explicit

- Label the deterministic build reference clock separately from execution-time evidence; preserve the existing generated_at field for compatibility
- Record the reference-clock basis in build and inspection metadata
- Clarify that Night Desk contains local reading tools while the writing is public
- Reflect IoTox retirement in the current project overview while retaining earlier dated essays

## rev0027 — preserve reader notes during import

- Check fieldbook schema, distinct identities and file/entry limits before applying imports
- Keep divergent local notes and report conflicts instead of replacing them silently
- Bound entry normalization and return-marker input size
- Add routed/capsule parity tests for import merging
- Review the finite raw reader-script ceiling from 116,000 to 120,000 bytes for these safeguards; the 29,000-byte gzip ceiling remains unchanged

## rev0026 — reader navigation from live use

- Close the originating reader dialog when a local capsule link navigates, so clicked search results and saved passages are visible immediately
- Preserve ordinary external-link behavior and modified clicks
- Add a focused dialog-lifecycle regression check after observing the issue in the live customized preview

## rev0025 — use the workshop for current writing

- Import the three verified October 2 public essays into the existing note model without changing prose
- Add an offline, hash-pinned, plan-first importer that refuses replacement and records source commit provenance
- Compare corpus counts to accepted source instead of freezing the old four-note corpus
- Explicitly review finite corpus-size budgets for seven notes; executable-asset and custody limits stay bounded

## rev0024 — publication and comparison boundaries

- Share explicit public content selection between carrier and repository handoff; keep draft recovery separate
- Preserve full Git identifiers in reader edition comparison and report missing evidence as unknown
- Preserve plain homepage fragments in the capsule router
- Correct Night Desk labels and the distinction between desk entries and fieldbook quote slips
- Add focused selection and pure JavaScript regression checks

# Changelog

## rev0022 · exact portable reading-path folios

- Every authored reading path can now leave the site as one self-contained, no-JavaScript HTML folio assembled from exact accepted pages or exact passage slices.
- A quiet **Keep this path** control appears beside each curated route; the routed site serves static files and `Lumen.html` writes the same embedded bytes offline.
- `dist/meta/path-folios.json` binds each folio to its ordered steps, path digest, edition, source fingerprint, byte length, gzip measurement, and SHA-256.
- `./lumen pathfolio` lists, verifies, and atomically exports the same canonical objects in a cloudtainer.
- Distribution and capsule validators now enforce path identity, exact step counts, safe member paths, aggregate size ceilings, and routed/capsule parity.
- The public-source snapshot was rechecked at 2026-10-02 14:58 UTC; accepted public heads were unchanged and private recovery material remains outside the public carrier.

## rev0021 · exact portable page folios

- Adds one-click “Keep this page” controls to accepted notes and project pages without changing ordinary navigation, print, or no-JavaScript reading.
- Generates seven exact, self-contained HTML folios under `dist/folios/`; each opens directly from disk and carries accepted prose, stable page and passage identities, authored sources, declared related pages, reading-path membership, edition identity, and body SHA-256.
- Adds `meta/folios.json` as `lumen.portable-folios/v1`, binding every folio’s filename, bytes, gzip measurement, complete-file hash, body hash, and source fingerprint; distribution validation treats disagreement as a build failure.
- Embeds the identical folio bytes inside `Lumen.html`, where the existing page control downloads a local blob rather than depending on a web route.
- Adds `./lumen folio [PAGE]` for dependency-free listing, verification, and atomic export of the exact manifest-bound file from the cloudtainer.
- Keeps the feature deliberately bounded: folios contain no editor, search index, graph, private reading state, private workshop bytes, donor archive, or extraction payload. The full site and complete `Lumen.html` edition remain canonical.
- Removes a hidden test dependency on an already-built `dist/`: edition-comparison tests now construct their carrier in an isolated directory, so a freshly extracted GitHub/cloudtainer repository verifies from source exactly as documented.

## rev0020 · curated source-bound reading paths

- Adds three deliberately authored routes through the accepted publication: continuity and return, concern and authority, and evidence in practice.
- Binds all 12 steps to stable page identities and, where named, exact accepted passage fingerprints; canonical builds fail on missing pages, passages, duplicate path IDs, or invalid targets.
- Gives the Field Notes archive a compact “A few ways through” section and places a quiet expandable thread navigator after participating pages without recording reading history or displacing ordinary links.
- Adds path records to local search, page inspection, the hypertext ledger, build receipts, performance receipts, and the directly extractable `Lumen.html` manifest so Pages, offline reading, and custody agree.
- Adds `./lumen thread [QUERY]` with text, Markdown, and JSON output for dependency-free cloudtainer inspection of the same generated source-bound records.
- Keeps the Hyperepo inheritance subordinate to the blog: paths are static semantic HTML, complete without JavaScript, and explicitly editorial rather than inferred recommendations or proof that one text entails the next.

## rev0019 · exact private return point

- Adds one explicit private return point across the routed site and extractable `Lumen.html`, without creating passive reading history or another public destination.
- Binds the selected place to stable page/passage identity, accepted text SHA-256, edition fingerprint, optional exact prose-block hash, bounded excerpt, and a page-level scroll fallback.
- Reviews markers as exact, uniquely moved, changed, ambiguous, passage-missing, or page-missing; titles and approximate similarity never silently reattach old text.
- Adds `./lumen marker PAGE[#SECTION]` and `./lumen marker --check FILE` so exported markers can be created and verified against canonical cloudtainer context.
- Moves the routed-site return runtime and stylesheet behind content-addressed, on-demand assets instead of weakening the established homepage, JavaScript, CSS, or transfer budgets.
- Carries the same return behavior fully offline in the single-file edition and records the browser/cloudtainer capability in the capsule manifest.

## rev0018 · exact-quote commonplace slips

- Extends the private browser fieldbook from page and passage entries to exact selected-quote slips without adding a new public destination or interrupting ordinary reading.
- Binds each kept quote to stable page and passage identity, accepted passage fingerprint, edition, normalized offset, bounded before/after context, and quote SHA-256.
- Reuses the conservative exact-link resolver: a changed passage does not receive an approximate replacement quote, and an older entry remains visibly older rather than being silently reattached.
- Adds `./lumen packet --fieldbook lumen-fieldbook.json`, which re-resolves exported page, passage, and quote entries against canonical context and emits a source-bound `lumen.reading-packet/v2` only when every selected object still verifies.
- Carries explicitly exported private notes into that packet while keeping browser storage, private workshop repositories, and unexported reading state outside the public site and cloudtainer source tree.
- Adds exact-quote packet tests and raises the measured JavaScript ceiling narrowly to 116 KiB raw / 29 KiB gzip; the runtime remains dependency-free, framework-free, and loaded only from local authored assets.

## rev0017 · passage-aware edition comparison

- Extends the local custody-object comparator from page-level hashes to exact titled-passage records whenever both editions carry them.
- Emits `meta/edition-summary.json` as `lumen.edition-summary/v2`, carrying stable passage IDs, anchors, bounded excerpts, word counts, normalized-text SHA-256 values, and exact source-HTML SHA-256 values alongside the existing page and public-source identities.
- Reports text, markup-only, metadata, moved-identity, added, and removed passage states without fuzzy matching or semantic judgment; if an older edition lacks passage records, the result explicitly remains page-level.
- Enriches rev0016 and other compatible capsules from their carried context records without executing their scripts, so a reader can compare a kept single-file edition directly in the browser or with `./lumen compare`.
- Adds nested, collapsible passage differences to the quiet comparison dialog and emits the same `lumen.edition-comparison/v2` receipt from browser and cloudtainer paths.
- Makes passage-summary completeness, uniqueness, digests, counts, and capsule parity build failures rather than best-effort UI assumptions.

## rev0016 · local edition comparison

- Adds a quiet, entirely local comparison path for a reader who kept an older `Lumen.html` and wants to know exactly what a newer custody object carries differently.
- Emits `meta/edition-summary.json` as a bounded `lumen.edition-summary/v1` record of stable page IDs, authored-body hashes, routes, metadata, and accepted public-source heads.
- Loads comparator code and the current summary only when the routed-site dialog opens; the one-file edition embeds the same summary and comparison runtime for complete offline use.
- Adds `./lumen compare EDITION` with text, Markdown, and JSON output, including compatibility with earlier Lumen carriers without executing their scripts.
- Exports deterministic `lumen.edition-comparison/v1` receipts while preserving the boundary between exact byte identity and semantic judgment: changed prose is reported, never automatically declared better, true, or authoritative.
- Keeps private workshop history and checkpoints outside the public comparison surface, updates the accepted public-source observation without adopting private repository motion, and expands the dependency-free suite to 62 tests.

## rev0015 · source-bound correction packets

- Adds a quiet reader-to-maintainer correction path from any accepted page or passage.
- Creates deterministic `lumen.correction-packet/v1` JSON locally, with stable identities, exact source hashes, source offsets, privacy exclusions, and no automatic transmission.
- Adds `./lumen correction` for offline packet creation and verification, distinguishing exact, passage-stable, changed, and missing source states without auto-editing prose.
- Carries the same correction workflow inside the extractable one-file edition and adds a packet-aware GitHub issue template.
- Keeps the correction control subordinate to reading and raises the tightly measured JavaScript transfer budget only to 27 KiB gzip; the complete authored runtime remains framework-free and local.

## rev0014 · quiet source lens and review-only previews

- Bound every accepted external prose link to its stable local reference identity without changing normal navigation or no-JavaScript reading.
- Added a quiet source lens on precise-pointer hover and keyboard focus. It reports the authored label, domain, accepted-use count, and evidential boundary from local records only; touch devices keep ordinary link behavior.
- Added one small generated preview record per source under `meta/reference-previews/` and embedded the same behavior in the extractable `Lumen.html` edition without remote metadata calls.
- Added a read-only GitHub pull-request workflow that builds a draft-aware, noindex routed preview plus `Lumen.html`, records its checksum in the run summary, retains it for 14 days, and never deploys the branch.
- Extended distribution, capsule, and workflow tests so source-lens identities, per-source preview records, capsule parity, action pinning, permissions, and the review/deploy boundary remain checked.

## rev0013 · quiet reference room and source ledger

- Added a complete local Reference Room generated from the links Lumen actually published. Every source has a stable local identity, authored labels, exact URLs, domain grouping, and passage-level uses bound to accepted text and source-HTML fingerprints.
- Added collapsed per-note reference lists and a searchable, domain-filterable `/references/` route. The full ledger remains readable without JavaScript and is embedded in the offline, directly extractable `Lumen.html` edition.
- Added `./lumen references [QUERY] --format text|markdown|json --build` for cloudtainer inspection. It uses only the generated local ledger and performs no remote metadata lookup.
- Extended search, distribution validation, capsule receipts, and the capsule manifest so browser, GitHub Pages, and the extracted worktree agree on reference identities and counts.
- Preserved the editorial boundary: the ledger records where an accepted passage linked, not whether the linked source proves the claim or remains unchanged upstream.

## rev0012 · living editions and exact quote links

- Added a compact public editions ledger for the four published Field Notes. Stable note identity now survives accepted corrections, each current body is checked against an exact SHA-256/byte record, and the known earlier projection of “Continuity needs evidence” remains named without reconstructing retired text.
- Added `./lumen history --check` and `./lumen revise PAGE --summary "…"`; canonical builds now refuse an unrecorded change to published note prose. Publishing a new note creates its first accepted revision record.
- Added quiet selected-text tools. A reader can copy an exact quote link or quote-plus-citation carrying the page ID, passage ID, accepted passage fingerprint, edition, and bounded locator. Opening the link verifies the current passage before highlighting; a mismatched older edition opens the section and says that the old words were not reconstructed.
- Corrected homepage section tools so context, fieldbook, and reading-desk actions resolve against the note that owns a passage rather than the homepage container.
- Carried the revision ledger and exact-quote runtime into the extractable `Lumen.html` capsule while preserving complete no-JavaScript reading and the same public/private boundary.

## rev0011 · quiet archive, exact citation, private reopening

- Turned the replacement blog into a more complete long-lived publication without changing its visual thesis: added a real chronological archive, recurring-topic index, Atom, RSS 2.0, and JSON Feed 1.1 subscriptions generated from the accepted note set.
- Added `Blog` and `BlogPosting` JSON-LD to every relevant page, with the exact inline data block authorized by a generated CSP hash rather than weakening the script policy.
- Added quiet browser and single-file controls to copy a source-bound passage citation or an exact quote plus citation from the existing reading-tools disclosure.
- Added `./lumen cite PAGE[#SECTION]` with text, Markdown, and JSON formats, optional exact quoting, file output, and canonical source revalidation.
- Added deterministic private worktree checkpoints through `./lumen preserve`, using an explicit editable-tree allowlist rather than archiving the cloudtainer wholesale.
- Added guarded `./lumen reopen` verification and fresh-directory restoration: duplicate and unsafe paths, links, encrypted entries, mode/hash/member-set disagreement, and aggregate identity mismatch are rejected before atomic installation.
- Kept private recovery separate from public custody: checkpoints exclude generated `dist/`, `.git`, `.lumen`, research evidence, handoffs, credentials, arbitrary workspace data, and never enter GitHub Pages or `Lumen.html` automatically.
- Clarified that source sync observes public repositories only; private repositories and private recovery stores are not publication inputs merely because a token is present.
- Extended the public workbench, capsule manifest, handoff receipt, start guide, architecture, GitHub, cloudtainer, and release procedures around citation, subscription, and off-container recovery.
- Bound the default canonical build clock to the accepted source snapshot, so feeds, context hashes, build receipts, and the HTML/ZIP capsule no longer change merely because the same tree is rebuilt a second later. Explicit preview and `SOURCE_DATE_EPOCH` overrides remain available.
- Kept the extracted capsule worktree byte-identical to the ordinary repository projection instead of rewriting `START-HERE.txt` during packing; an extracted `Lumen.html` can now rebuild the same canonical site and capsule from the same source fingerprint.
- Expanded the dependency-free test suite to 51 tests before final revision stamping, including all three feed formats, CSP-bound JSON-LD, exact-quote citations, deterministic checkpoints, executable-mode preservation, clean reopening, and accepted-snapshot build-time selection.

## rev0010 · Night Index working surface

- Re-audited the original Hyperepo carrier and selected only the donor mechanics that improve Lumen without importing the donor runtime or private corpus.
- Deepened the optional dark candidate into **Night Index**, a genuinely different nocturnal editorial room rather than a palette swap.
- Added a browser-local ordered reading desk with stable page/passage identities, drag or button reordering, JSON export, and edition-mismatch warnings.
- Added a disposable focus sheet assembled from the current desk and a session-scoped focus-reading mode.
- Added plural local search intents for titles/aliases, tags, prose, exact phrases, and stable identities, including query prefixes.
- Added `./lumen packet --desk FILE` so an exported browser arrangement can become an ordered, source-bound cloudtainer packet without treating browser state as authority.
- Brought the same desk, focus sheet, plural search, and Night Index dock into the one-file `Lumen.html` edition.
- Updated the accepted source capture to Lumen checkpoint `e84f3b84a1ab` (398 reviewed tests and an exact 18-file recovery rehearsal) and W4R3Z checkpoint `ceb467a328dc` (the provenance-bound IoTox source seed).
- Added explicit donor-inheritance and reading-desk documentation; Field Notes remains the canonical default and unchanged editorial face.

## rev0009

- Kept Field Notes as the canonical default.
- Added Night Study as a fully optional dark editorial look.
- Added a local appearance picker and cloudtainer `look` command.
- Kept content identity, routes, source-bound passages, and the single-file carrier shared across looks.
- Added deterministic look bundling and capsule parity tests.

## rev0008 · Field Notes first

- Recast the public site as a direct, refined continuation of Lumen’s original blog rather than a showcase for the publication machinery.
- Restored the original visual grammar: warm paper, green ink, red accent, dotted texture, large Field Notes masthead, restrained navigation, and a narrow reading column.
- Put all published notes in full on the homepage, preserving the original scrollable journal form while keeping stable permalinks for individual pieces.
- Reduced the primary navigation to ordinary reader needs: Notes, About, Habitat log, and Search. Maintainer and custody surfaces moved to the quiet footer or optional routes.
- Collapsed article context and source controls into an unobtrusive “Reading tools” disclosure; the prose remains complete without JavaScript.
- Retained local search, stable section links, private reading trails, source receipts, the one-file edition, and the cloudtainer command deck without advertising them as the site’s subject.
- Updated GitHub-facing documentation to describe the repository as the replacement Field Notes blog first and the portable/cloudtainer system second.
- Preserved the accepted four-repository source capture, explicit Datacube retirement boundary, and approved Observer continuation without turning the homepage into a status dashboard.
- Passed 41 dependency-free tests, canonical distribution and capsule validation, and desktop/mobile visual review with no horizontal overflow.

## rev0007 · reader-owned fieldbook and explicit retirement boundaries

- Added a private browser fieldbook to the routed site and `Lumen.html`: save exact source-bound passages, attach local notes, adjust reading measure, import/export JSON, and export a standalone HTML reading packet without a server or account.
- Added `./lumen packet PAGE[#SECTION] ...` so the cloudtainer can produce the same quiet, source-bound reading packets with companion hashes directly from canonical context.
- Changed upstream acceptance so a repository missing from the public listing cannot disappear silently. `sync --accept` now requires exact `--confirm-retire OWNER/REPO` arguments and preserves the last accepted identity in `retired_sources`.
- Followed Lumen’s explicit Datacube retirement: removed its active project and museum routes, search records, graph nodes, source card, and capsule pages; retained only a compact retirement receipt.
- Updated the accepted source constellation to four active repositories, current Lumen checkpoint `7879eff01607`, 342 reviewed tests, the retired-source boundary, and the separately approved Observer continuation.
- Tightened the human reading surface around current-first navigation, Observer generations, retirement evidence, and locally owned reading trails while preserving semantic no-JavaScript documents.
- Extended the test suite to 41 dependency-free tests covering the fieldbook surface, packet hash fidelity, explicit retirement handling, current route counts, and retired-source exclusion.
- Kept the inherited Hyperepo machinery quiet: stable identity, exact source slices, typed links, point-in-time source state, portable custody, and honest deletion boundaries rather than a branded subsystem.

## rev0006 · quiet passage context and operator flow

- Added a source-bound passage ledger across every authored section: stable IDs, exact offsets, separate HTML/text fingerprints, citations, actual internal links, and typed incoming/outgoing context.
- Added optional passage-context panels to both the routed site and the single-file edition; normal reading remains complete HTML and the hash display explicitly refuses to certify truth.
- Upgraded local search to return section-level results and previews, and replaced the decorative graph with an accessible deterministic SVG plus a complete textual connection list.
- Kept actual authored links distinct from declared editorial relationships instead of collapsing them into an unexplained relevance score.
- Added `./lumen page`, `./lumen edit`, `./lumen context`, and `./lumen ship` so a cloudtainer maintainer can find, open, inspect, verify, and deliver work without remembering repository paths.
- Extended the capsule manifest and inspection receipts to bind the hypertext ledger and per-page context records to the accepted source fingerprint.
- Preserved the five accepted public repository heads; no upstream byte became an editorial claim automatically.
- Kept the recipient payload lean: no historic Hyperepo donor, private review bundle, screenshots, or outer revision archaeology enters the worktree or carrier.
- Passed 38 dependency-free tests, canonical distribution and capsule validation, and scripted desktop/mobile browser review with no console errors, page errors, or horizontal overflow.

## rev0005 · one-file custody, ordinary worktree

- Added `dist/Lumen.html`, a real HTML/ZIP polyglot that opens as the complete public site and extracts as a lean cloudtainer/GitHub worktree.
- Embedded every published route, local search, previews, page inspections, relationship data, source snapshot, and a no-JavaScript continuous reading archive.
- Added a capsule manifest binding the HTML prefix and every archive member by SHA-256, plus complete-file receipts outside the self-referential carrier.
- Added `./lumen capsule`, capsule validation, public download controls, cloudtainer extraction instructions, and handoff v2 with the carrier as the primary artifact.
- Separated the three operational contexts: single-file browser custody, ordinary cloudtainer editing, and a reviewable GitHub repository.
- Removed the historic donor archive, extracted carrier, private review evidence, screenshots, and outer revision workshop from the recipient payload. Prior revision packages retain that development history.
- Kept authored public references to collaboration and project provenance where they are part of Lumen’s own published work; tooling no longer requires the donor context.
- Qualified Datacube’s reader-lifetime rule with its six-pair count study: isolated reads showed little local benefit, while repeated batches favored finite caller-owned sessions; the frozen-plan pair-count defect remains visible.
- Added 33 dependency-free tests and exercised the carrier as browser HTML, Info-ZIP/Python-readable archive, executable cloudtainer extraction, deterministic rebuild, and source-fingerprint-preserving round trip.

## rev0004 · live edge, atomic cloudtainer handoff

- Added a public **Now** route that shows exact captured repository heads, changes since the preceding accepted snapshot, recent public activity, and the boundary between observed facts and editorial interpretation.
- Reviewed and represented Lumen’s closed 60-occurrence timer cohort alongside the separate 49-of-50 unresolved return-chain ending, without merging their claims.
- Reviewed Datacube’s bounded read-lifetime experiment and exposed its four-pair session-versus-one-shot measurements while retaining rev1183 and the stated limits.
- Added explicit page states: drafts are excluded from canonical builds, visible and noindexed in preview builds, and blocked from publication until source and interpretation metadata are completed.
- Replaced in-place development output with validated same-filesystem atomic preview swaps under `.lumen/preview-dist/`.
- Split source refresh into `sync --check`, `sync --stage`, and local `sync --accept`; acceptance archives the preceding snapshot and never edits authored prose.
- Added `start`, `drafts`, `publish`, `perf`, and `handoff` commands; the handoff emits deploy-only and executable toolkit archives with checksums and a machine-readable record.
- Added per-route raw and deterministic-gzip performance receipts, browser-loadable only on request.
- Added exact-commit-pinned GitHub Actions, CodeQL, Dependabot, CODEOWNERS, issue forms, release reproducibility, bounded workflow timeouts, and a GitHub operations guide.
- Added 31 dependency-free tests, cloudtainer smoke evidence, and a Chromium review across desktop, mobile dark mode, print, search, inspection, lazy performance, and no-JavaScript reading.
- Removed an off-screen rendering optimization after browser review showed it created misleading blank regions in full-page and mobile captures.

## rev0003 · field notes with visible machinery

- Established the source-aware static publication, 15 generated routes, local search and page inspection, relationship metadata, the cloudtainer command deck, GitHub Pages workflows, and deterministic deploy/toolkit archives.
- Captured five Sapient-Lumen repositories and integrated the Datacube Museum, W4R3Z, and Habitat Observer evidence into a coherent public reading surface.
