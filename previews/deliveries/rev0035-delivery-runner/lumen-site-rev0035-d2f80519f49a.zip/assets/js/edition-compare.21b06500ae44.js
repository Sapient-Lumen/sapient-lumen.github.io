/* Lumen local edition comparison. Loaded only when a reader asks for it. */
(() => {
  const MAX_FILE_BYTES = 32 * 1024 * 1024;
  const SUMMARY_BEGIN = "LUMEN_EDITION_SUMMARY_BEGIN";
  const SUMMARY_END = "LUMEN_EDITION_SUMMARY_END";
  let currentSummary = null;
  let currentLabel = "this edition";
  let currentComparison = null;
  let initialized = false;

  const byId = (id) => document.getElementById(id);

  function safeString(value, maximum = 4096) {
    return String(value ?? "").replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "").slice(0, maximum);
  }

  function normalizeHex(value) {
    const text = safeString(value, 128).toLowerCase();
    return /^[0-9a-f]{64}$/.test(text) ? text : "";
  }

  function normalizeGitOid(value) {
    const text = safeString(value, 128).toLowerCase();
    return /^(?:[0-9a-f]{40}|[0-9a-f]{64})$/.test(text) ? text : "";
  }

  function compareGitOids(left, right) {
    if (!left || !right) return "unknown";
    return left === right ? "same" : "changed";
  }

  function normalizeCount(value) {
    const number = Number(value);
    return Number.isInteger(number) && number >= 0 ? number : null;
  }

  function normalizePassage(passage = {}) {
    const id = safeString(passage.id || "", 512);
    if (!id) return null;
    return {
      id,
      anchor: safeString(passage.anchor || "", 512),
      url: safeString(passage.url || "", 2048),
      level: normalizeCount(passage.level),
      title: safeString(passage.title || id, 1024),
      order: normalizeCount(passage.order),
      excerpt: safeString(passage.excerpt || "", 600),
      word_count: normalizeCount(passage.word_count),
      text_sha256: normalizeHex(passage.text_sha256),
      source_html_sha256: normalizeHex(passage.source_html_sha256),
    };
  }

  function normalizePage(page = {}, fallbackId = "", sourceSchema = "") {
    const id = safeString(page.id || fallbackId, 256);
    if (!id) return null;
    const passages = (Array.isArray(page.passages) ? page.passages : [])
      .map((row) => normalizePassage(row))
      .filter(Boolean)
      .sort((a, b) => (a.order ?? 1e9) - (b.order ?? 1e9) || a.id.localeCompare(b.id));
    return {
      id,
      url: safeString(page.url || "/", 2048),
      kind: safeString(page.kind || "page", 64),
      title: safeString(page.title || id, 1024),
      status: safeString(page.status || "published", 64),
      date: safeString(page.date || "", 32),
      body_sha256: normalizeHex(page.body_sha256 || page.sha256),
      body_bytes: normalizeCount(page.body_bytes ?? page.bytes),
      word_count: normalizeCount(page.word_count),
      revision_count: normalizeCount(page.revision_count),
      latest_revision: page.latest_revision && typeof page.latest_revision === "object" ? {
        edition: safeString(page.latest_revision.edition || "", 64),
        date: safeString(page.latest_revision.date || "", 32),
        summary: safeString(page.latest_revision.summary || "", 2048),
        body_sha256: normalizeHex(page.latest_revision.body_sha256),
      } : null,
      passage_detail: Boolean(page.passage_detail),
      passages,
    };
  }

  function normalizeSources(value = {}) {
    const active = {};
    const retired = {};
    const activeRows = Array.isArray(value.active) ? value.active : value.active && typeof value.active === "object" ? Object.values(value.active) : Array.isArray(value.repositories) ? value.repositories : [];
    const retiredRows = Array.isArray(value.retired) ? value.retired : value.retired && typeof value.retired === "object" ? Object.values(value.retired) : Array.isArray(value.retired_sources) ? value.retired_sources : [];
    activeRows.forEach((row) => {
      const name = safeString(row?.name || "", 256);
      if (!name) return;
      active[name] = {
        name,
        head_sha: normalizeGitOid(row.head_sha || row.sha || ""),
        message: safeString(row.head_message || row.message || "", 1024),
        pushed_at: safeString(row.pushed_at || row.committed_at || "", 64),
      };
    });
    retiredRows.forEach((row) => {
      const name = safeString(row?.name || "", 256);
      if (!name) return;
      retired[name] = {
        name,
        last_observed_head: normalizeGitOid(row.last_observed_head || row.head_sha || ""),
        retired_at: safeString(row.retired_at || "", 64),
        reason: safeString(row.reason || "", 2048),
      };
    });
    return { active, retired };
  }

  function normalizeSummary(value) {
    if (!value || typeof value !== "object") throw new Error("The selected file does not contain a readable Lumen edition record.");
    if (value.schema === "lumen.editions/v1") {
      const pages = {};
      Object.entries(value.notes || {}).forEach(([id, record]) => {
        const revisions = Array.isArray(record?.revisions) ? record.revisions : [];
        const latest = revisions.at(-1) || {};
        const page = normalizePage({
          id,
          kind: "note",
          title: id,
          body_sha256: latest.body_sha256,
          body_bytes: latest.body_bytes,
          revision_count: revisions.length,
          latest_revision: latest,
          passage_detail: false,
          passages: [],
        }, id, "lumen.edition-summary/v1");
        if (page) pages[id] = page;
      });
      return {
        schema: "lumen.edition-summary/v2",
        source_schema: "lumen.editions/v1",
        scope: "notes-only",
        edition: safeString(value.edition || "unknown", 64),
        generated_at: safeString(value.generated_at || "", 64),
        source_fingerprint_sha256: normalizeHex(value.source_fingerprint_sha256),
        pages,
        sources: { active: {}, retired: {} },
      };
    }
    const sourceSchema = safeString(value.schema || "", 128);
    if (!["lumen.edition-summary/v1", "lumen.edition-summary/v2"].includes(sourceSchema)) {
      throw new Error(`Unsupported edition record: ${safeString(value.schema || "unknown", 128)}`);
    }
    const pages = {};
    const rows = Array.isArray(value.pages) ? value.pages : Object.values(value.pages || {});
    rows.forEach((row) => {
      const page = normalizePage(row, row?.id || "", sourceSchema);
      if (page) pages[page.id] = page;
    });
    return {
      schema: "lumen.edition-summary/v2",
      source_schema: safeString(value.source_schema || sourceSchema, 128),
      scope: safeString(value.scope || "complete", 64),
      edition: safeString(value.edition || "unknown", 64),
      generated_at: safeString(value.generated_at || "", 64),
      source_fingerprint_sha256: normalizeHex(value.source_fingerprint_sha256),
      pages,
      sources: normalizeSources(value.sources || value.source_snapshot || {}),
      counts: value.counts && typeof value.counts === "object" ? value.counts : {},
    };
  }

  function passagesFromContext(context = {}) {
    return (Array.isArray(context.passages) ? context.passages : [])
      .map((row) => normalizePassage(row))
      .filter(Boolean)
      .sort((a, b) => (a.order ?? 1e9) - (b.order ?? 1e9) || a.id.localeCompare(b.id));
  }

  function augmentSummaryWithContexts(summaryInput, contexts = {}) {
    const summary = normalizeSummary(summaryInput);
    Object.entries(contexts || {}).forEach(([fallbackId, context]) => {
      const pageId = safeString(context?.page?.id || fallbackId, 256);
      const page = summary.pages[pageId];
      if (!page) return;
      page.passages = passagesFromContext(context);
      page.passage_detail = true;
    });
    return summary;
  }

  function summaryFromCapsule(payload) {
    if (!payload || typeof payload !== "object") throw new Error("The selected HTML does not carry a readable Lumen capsule payload.");
    if (payload.editionSummary) return augmentSummaryWithContexts(payload.editionSummary, payload.contexts || {});
    const pages = {};
    Object.values(payload.inspections || {}).forEach((record) => {
      const page = record?.page || {};
      const revisions = Array.isArray(page.publication_history) ? page.publication_history : [];
      const context = payload.contexts?.[page.id] || {};
      const normalized = normalizePage({
        id: page.id,
        url: page.url,
        kind: page.kind,
        title: page.title,
        status: page.status,
        date: page.date,
        body_sha256: page.source_body?.sha256,
        body_bytes: page.source_body?.bytes,
        revision_count: revisions.length || null,
        latest_revision: revisions.at(-1) || null,
        passage_detail: Boolean(payload.contexts && Object.hasOwn(payload.contexts, page.id)),
        passages: passagesFromContext(context),
      }, page.id || "", "lumen.edition-summary/v2");
      if (normalized) pages[normalized.id] = normalized;
    });
    if (!Object.keys(pages).length) throw new Error("The selected capsule predates comparable page identities.");
    return normalizeSummary({
      schema: "lumen.edition-summary/v2",
      scope: "legacy-capsule",
      edition: payload.edition || "unknown",
      generated_at: payload.generatedAt || "",
      source_fingerprint_sha256: payload.sourceFingerprint || "",
      pages,
      sources: payload.sourceSnapshot || {},
    });
  }

  function decodeMarker(text) {
    const start = text.indexOf(SUMMARY_BEGIN);
    if (start < 0) return null;
    const end = text.indexOf(SUMMARY_END, start);
    if (end < 0) throw new Error("The Lumen edition marker is incomplete.");
    const body = text.slice(start + SUMMARY_BEGIN.length, end).replace(/[^A-Za-z0-9+/=]/g, "");
    if (!body) throw new Error("The Lumen edition marker is empty.");
    try {
      const binary = atob(body);
      const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
      return normalizeSummary(JSON.parse(new TextDecoder().decode(bytes)));
    } catch (error) {
      throw new Error(`The Lumen edition marker could not be decoded: ${error.message}`);
    }
  }

  function legacyCapsulePayload(text) {
    const token = "const CAPSULE = ";
    const start = text.indexOf(`${token}{`);
    if (start < 0) return null;
    const end = text.indexOf(";\nconst root", start + token.length);
    if (end < 0) return null;
    try {
      return JSON.parse(text.slice(start + token.length, end));
    } catch {
      return null;
    }
  }

  async function parseEditionFile(file) {
    if (!file) throw new Error("Choose a Lumen.html or edition-summary JSON file.");
    if (file.size > MAX_FILE_BYTES) throw new Error(`The selected file is ${(file.size / 1024 / 1024).toFixed(1)} MiB; the local comparison limit is 32 MiB.`);
    const text = await file.text();
    const trimmed = text.trimStart();
    if (trimmed.startsWith("{")) {
      try { return normalizeSummary(JSON.parse(trimmed)); }
      catch (error) { throw new Error(`The JSON edition record could not be read: ${error.message}`); }
    }
    const marked = decodeMarker(text);
    const legacy = legacyCapsulePayload(text);
    if (marked) return legacy ? augmentSummaryWithContexts(marked, legacy.contexts || {}) : marked;
    if (legacy) return summaryFromCapsule(legacy);
    throw new Error("This file is not a recognized Lumen.html edition or edition-summary JSON record.");
  }

  function revisionNumber(value) {
    const match = /^rev(\d+)$/i.exec(String(value || "").trim());
    return match ? Number(match[1]) : null;
  }

  function relation(current, other) {
    if (current.source_fingerprint_sha256 && current.source_fingerprint_sha256 === other.source_fingerprint_sha256) return "same";
    const a = revisionNumber(current.edition);
    const b = revisionNumber(other.edition);
    if (a !== null && b !== null) return b < a ? "older" : b > a ? "newer" : "parallel";
    return "parallel";
  }

  function compareSources(current, other) {
    const names = new Set([
      ...Object.keys(current.sources.active), ...Object.keys(other.sources.active),
      ...Object.keys(current.sources.retired), ...Object.keys(other.sources.retired),
    ]);
    const rows = [];
    [...names].sort().forEach((name) => {
      const currentActive = current.sources.active[name];
      const otherActive = other.sources.active[name];
      const currentRetired = current.sources.retired[name];
      const otherRetired = other.sources.retired[name];
      let state = "same";
      if (currentActive && otherActive) state = compareGitOids(currentActive.head_sha, otherActive.head_sha);
      else if (currentRetired && otherRetired) state = compareGitOids(currentRetired.last_observed_head, otherRetired.last_observed_head);
      else if (currentActive && otherRetired) state = "restored-current";
      else if (currentRetired && otherActive) state = "retired-current";
      else if (currentActive || currentRetired) state = "current-only";
      else state = "other-only";
      rows.push({
        name,
        state,
        current: currentActive || currentRetired || null,
        other: otherActive || otherRetired || null,
        current_status: currentActive ? "active" : currentRetired ? "retired" : "absent",
        other_status: otherActive ? "active" : otherRetired ? "retired" : "absent",
      });
    });
    return rows;
  }

  function comparePassages(currentPage, otherPage) {
    const states = ["same", "changed", "markup", "metadata", "moved", "current-only", "other-only"];
    const counts = Object.fromEntries(states.map((state) => [state, 0]));
    const available = Boolean(currentPage?.passage_detail && otherPage?.passage_detail);
    if (!available) return { available, counts, rows: [] };
    const current = Object.fromEntries((currentPage.passages || []).map((row) => [row.id, row]));
    const other = Object.fromEntries((otherPage.passages || []).map((row) => [row.id, row]));
    const currentUnmatched = new Set(Object.keys(current));
    const otherUnmatched = new Set(Object.keys(other));
    const rows = [];
    [...currentUnmatched].filter((id) => otherUnmatched.has(id)).sort().forEach((id) => {
      const here = current[id];
      const there = other[id];
      let state = "same";
      const changes = [];
      if (here.text_sha256 && there.text_sha256 && here.text_sha256 !== there.text_sha256) { state = "changed"; changes.push("text"); }
      else if (here.source_html_sha256 && there.source_html_sha256 && here.source_html_sha256 !== there.source_html_sha256) { state = "markup"; changes.push("markup"); }
      [["title", "title"], ["level", "level"], ["anchor", "anchor"]].forEach(([key, label]) => {
        if (here[key] !== there[key]) { if (state === "same") state = "metadata"; changes.push(label); }
      });
      rows.push({ id, state, changes, current: here, other: there });
      currentUnmatched.delete(id);
      otherUnmatched.delete(id);
    });
    const currentHashes = new Map();
    const otherHashes = new Map();
    currentUnmatched.forEach((id) => {
      const digest = current[id].text_sha256;
      if (!digest) return;
      currentHashes.set(digest, [...(currentHashes.get(digest) || []), id]);
    });
    otherUnmatched.forEach((id) => {
      const digest = other[id].text_sha256;
      if (!digest) return;
      otherHashes.set(digest, [...(otherHashes.get(digest) || []), id]);
    });
    [...currentHashes.keys()].filter((digest) => otherHashes.has(digest)).sort().forEach((digest) => {
      const currentIds = currentHashes.get(digest);
      const otherIds = otherHashes.get(digest);
      if (currentIds.length !== 1 || otherIds.length !== 1) return;
      const currentId = currentIds[0];
      const otherId = otherIds[0];
      const here = current[currentId];
      const there = other[otherId];
      const changes = ["stable passage id"];
      if (here.title !== there.title) changes.push("title");
      if (here.anchor !== there.anchor) changes.push("anchor");
      if (here.source_html_sha256 !== there.source_html_sha256) changes.push("markup");
      rows.push({ id: currentId, other_id: otherId, state: "moved", changes, current: here, other: there });
      currentUnmatched.delete(currentId);
      otherUnmatched.delete(otherId);
    });
    [...currentUnmatched].sort().forEach((id) => rows.push({ id, state: "current-only", changes: [], current: current[id], other: null }));
    [...otherUnmatched].sort().forEach((id) => rows.push({ id, state: "other-only", changes: [], current: null, other: other[id] }));
    rows.sort((a, b) => {
      const ao = a.current?.order ?? (100000 + (a.other?.order ?? 0));
      const bo = b.current?.order ?? (100000 + (b.other?.order ?? 0));
      return ao - bo || a.id.localeCompare(b.id);
    });
    rows.forEach((row) => { counts[row.state] += 1; });
    return { available: true, counts, rows };
  }

  function compareSummaries(currentInput, otherInput) {
    const current = normalizeSummary(currentInput);
    const other = normalizeSummary(otherInput);
    const ids = new Set([...Object.keys(current.pages), ...Object.keys(other.pages)]);
    const pages = [];
    [...ids].sort().forEach((id) => {
      const a = current.pages[id];
      const b = other.pages[id];
      let state = "same";
      const changes = [];
      let passageComparison = { available: false, counts: {}, rows: [] };
      if (a && !b) state = "current-only";
      else if (!a && b) state = "other-only";
      else if (a && b) {
        if (a.body_sha256 && b.body_sha256 && a.body_sha256 !== b.body_sha256) { state = "changed"; changes.push("body"); }
        if (a.url !== b.url) { if (state === "same") state = "metadata"; changes.push("route"); }
        if (a.title !== b.title) { if (state === "same") state = "metadata"; changes.push("title"); }
        if (a.kind !== b.kind) { if (state === "same") state = "metadata"; changes.push("kind"); }
        if (a.status !== b.status) { if (state === "same") state = "metadata"; changes.push("status"); }
        passageComparison = comparePassages(a, b);
      }
      const passageDifferences = Object.entries(passageComparison.counts || {})
        .filter(([label]) => label !== "same")
        .reduce((sum, [, value]) => sum + value, 0);
      pages.push({
        id, state, changes, current: a || null, other: b || null,
        passages: passageComparison.rows || [],
        passage_counts: passageComparison.counts || {},
        passage_detail_available: Boolean(passageComparison.available),
        unsectioned_body_change: Boolean(state === "changed" && passageComparison.available && passageDifferences === 0),
      });
    });
    const sources = compareSources(current, other);
    const count = (state) => pages.filter((row) => row.state === state).length;
    const sourceCount = (state) => sources.filter((row) => row.state === state).length;
    const passageStates = ["same", "changed", "markup", "metadata", "moved", "current-only", "other-only"];
    const counts = {
      pages_current: Object.keys(current.pages).length,
      pages_other: Object.keys(other.pages).length,
      same: count("same"),
      changed: count("changed"),
      metadata: count("metadata"),
      current_only: count("current-only"),
      other_only: count("other-only"),
      pages_with_passage_detail: pages.filter((row) => row.passage_detail_available).length,
      sources_changed: sources.filter((row) => row.state !== "same").length,
      sources_same: sourceCount("same"),
    };
    passageStates.forEach((state) => {
      counts[`passages_${state.replaceAll("-", "_")}`] = pages.reduce((sum, row) => sum + Number(row.passage_counts?.[state] || 0), 0);
    });
    counts.passage_differences = passageStates.filter((state) => state !== "same").reduce((sum, state) => sum + counts[`passages_${state.replaceAll("-", "_")}`], 0);
    return {
      schema: "lumen.edition-comparison/v2",
      generated_at: new Date().toISOString(),
      relation: relation(current, other),
      current: { edition: current.edition, generated_at: current.generated_at, source_fingerprint_sha256: current.source_fingerprint_sha256, scope: current.scope, source_schema: current.source_schema },
      other: { edition: other.edition, generated_at: other.generated_at, source_fingerprint_sha256: other.source_fingerprint_sha256, scope: other.scope, source_schema: other.source_schema },
      counts,
      pages,
      sources,
      boundary: "This local comparison reports edition identities, carried page bytes, and exact source-bound passage fingerprints when both editions provide them. It does not infer why text changed, prove a claim true, or upload either file.",
    };
  }

  function node(tag, value = "", className = "") {
    const item = document.createElement(tag);
    if (value) item.textContent = value;
    if (className) item.className = className;
    return item;
  }

  function shortHash(value) {
    return value ? value.slice(0, 12) : "unknown";
  }

  function stateLabel(state) {
    return ({
      same: "unchanged",
      changed: "prose changed",
      markup: "markup changed",
      metadata: "presentation changed",
      moved: "same words, new identity",
      "current-only": "only in this edition",
      "other-only": "only in the selected edition",
      "retired-current": "retired here",
      "restored-current": "active here",
    })[state] || state.replaceAll("-", " ");
  }

  function passageDetails(row) {
    const wrapper = node("div", "", "edition-passage-comparison");
    if (!row.passage_detail_available) {
      wrapper.append(node("p", "Passage-level records were not available in both editions. This difference remains page-level.", "edition-passage-boundary"));
      return wrapper;
    }
    const differences = (row.passages || []).filter((passage) => passage.state !== "same");
    if (!differences.length) {
      const message = row.unsectioned_body_change
        ? "The page bytes changed outside the comparable titled passages, or only in untitled or structural material."
        : "All comparable titled passages are unchanged.";
      wrapper.append(node("p", message, "edition-passage-boundary"));
      return wrapper;
    }
    const details = node("details", "", "edition-passage-details");
    const summary = node("summary", `${differences.length} source-bound passage difference${differences.length === 1 ? "" : "s"}`);
    details.append(summary);
    const list = node("ol", "", "edition-passage-list");
    differences.forEach((passage) => {
      const item = node("li");
      const head = node("div", "", "edition-passage-head");
      const badge = node("span", stateLabel(passage.state), `edition-state edition-state--${passage.state}`);
      const identity = node("div");
      const current = passage.current || null;
      const other = passage.other || null;
      const title = current?.title || other?.title || passage.id;
      identity.append(node("strong", title), node("code", passage.id));
      if (passage.state === "moved" && other?.title && other.title !== title) identity.append(node("p", `Selected edition: ${other.title}`, "edition-passage-previous"));
      head.append(badge, identity);
      item.append(head);
      const excerpts = node("div", "", "edition-passage-excerpts");
      if (other?.excerpt) {
        const block = node("div");
        block.append(node("span", "Selected edition"), node("blockquote", other.excerpt));
        excerpts.append(block);
      }
      if (current?.excerpt && (current.excerpt !== other?.excerpt || !other)) {
        const block = node("div");
        block.append(node("span", "This edition"), node("blockquote", current.excerpt));
        excerpts.append(block);
      }
      if (excerpts.childElementCount) item.append(excerpts);
      const facts = node("dl", "", "edition-passage-facts");
      const currentWords = current?.word_count ?? "—";
      const otherWords = other?.word_count ?? "—";
      facts.append(node("dt", "Words"), node("dd", `${otherWords} → ${currentWords}`));
      facts.append(node("dt", "Text identity"), node("dd", `${shortHash(other?.text_sha256)} → ${shortHash(current?.text_sha256)}`));
      item.append(facts);
      list.append(item);
    });
    details.append(list);
    wrapper.append(details);
    return wrapper;
  }

  function renderOverview(comparison, fileName) {
    const host = byId("edition-compare-results");
    const status = byId("edition-compare-status");
    if (!host || !status) return;
    host.replaceChildren();
    const intro = node("section", "", "edition-compare-overview");
    const eyebrow = node("p", `${comparison.other.edition} · ${fileName}`, "eyebrow");
    const title = node("h3", comparison.relation === "same" ? "These are the same accepted source edition." : `Selected edition is ${comparison.relation} relative to this one.`);
    const fingerprints = node("dl", "", "edition-compare-fingerprints");
    [["This edition", comparison.current], ["Selected", comparison.other]].forEach(([label, row]) => {
      fingerprints.append(node("dt", label), node("dd", `${row.edition} · ${shortHash(row.source_fingerprint_sha256)}`));
    });
    intro.append(eyebrow, title, fingerprints);
    const metrics = node("div", "", "edition-compare-metrics");
    [
      [comparison.counts.changed, "pages with prose change"],
      [comparison.counts.passage_differences || 0, "passages differ"],
      [comparison.counts.metadata, "metadata changed"],
      [comparison.counts.current_only + comparison.counts.other_only, "pages only on one side"],
      [comparison.counts.sources_changed, "source captures differ"],
    ].forEach(([number, label]) => {
      const card = node("div");
      card.append(node("strong", String(number)), node("span", label));
      metrics.append(card);
    });
    intro.append(metrics);
    host.append(intro);

    const changed = comparison.pages.filter((row) => row.state !== "same");
    const section = node("section", "", "edition-compare-section");
    section.append(node("h3", "Publication changes"));
    if (!changed.length) {
      section.append(node("p", "No page-body or public metadata differences were found in the comparable records."));
    } else {
      const list = node("ol", "", "edition-compare-list");
      changed.forEach((row) => {
        const item = node("li");
        const copy = node("div");
        const page = row.current || row.other;
        copy.append(node("strong", page.title || row.id), node("code", row.id));
        const detail = [];
        if (row.changes.length) detail.push(row.changes.join(", "));
        if (row.current?.url && row.other?.url && row.current.url !== row.other.url) detail.push(`${row.other.url} → ${row.current.url}`);
        copy.append(node("p", detail.join(" · ") || stateLabel(row.state)));
        copy.append(passageDetails(row));
        item.append(node("span", stateLabel(row.state), `edition-state edition-state--${row.state}`), copy);
        list.append(item);
      });
      section.append(list);
    }
    host.append(section);

    const sourceChanges = comparison.sources.filter((row) => row.state !== "same");
    const sourceSection = node("section", "", "edition-compare-section");
    sourceSection.append(node("h3", "Captured public sources"));
    if (!sourceChanges.length) sourceSection.append(node("p", "The comparable source heads and retirement boundaries match."));
    else {
      const list = node("ol", "", "edition-compare-list edition-compare-list--sources");
      sourceChanges.forEach((row) => {
        const item = node("li");
        const copy = node("div");
        copy.append(node("strong", row.name), node("p", `${row.other_status} ${shortHash(row.other?.head_sha || row.other?.last_observed_head)} → ${row.current_status} ${shortHash(row.current?.head_sha || row.current?.last_observed_head)}`));
        item.append(node("span", stateLabel(row.state), `edition-state edition-state--${row.state}`), copy);
        list.append(item);
      });
      sourceSection.append(list);
    }
    host.append(sourceSection, node("p", comparison.boundary, "edition-compare-boundary"));
    const passageCount = comparison.counts.passage_differences || 0;
    status.textContent = `Compared locally · ${changed.length} publication difference${changed.length === 1 ? "" : "s"} · ${passageCount} passage difference${passageCount === 1 ? "" : "s"} · ${sourceChanges.length} source-capture difference${sourceChanges.length === 1 ? "" : "s"}.`;
  }

  function download(name, value, type = "application/json") {
    const blob = new Blob([value], { type });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = name;
    link.hidden = true;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function filenameDate() {
    return new Date().toISOString().replace(/[:.]/g, "-");
  }

  function resetDialog() {
    currentComparison = null;
    const host = byId("edition-compare-results");
    const status = byId("edition-compare-status");
    const exportButton = document.querySelector("[data-edition-compare-export]");
    if (host) host.replaceChildren();
    if (status) status.textContent = `${currentLabel} · choose another Lumen.html or edition-summary JSON file. The file stays on this device.`;
    if (exportButton) exportButton.disabled = true;
  }

  function initialize() {
    if (initialized) return;
    initialized = true;
    const input = byId("edition-compare-file");
    const status = byId("edition-compare-status");
    const exportButton = document.querySelector("[data-edition-compare-export]");
    input?.addEventListener("change", async () => {
      const file = input.files?.[0];
      if (!file || !currentSummary) return;
      if (status) status.textContent = `Reading ${file.name} locally…`;
      try {
        const other = await parseEditionFile(file);
        currentComparison = compareSummaries(currentSummary, other);
        renderOverview(currentComparison, file.name);
        if (exportButton) exportButton.disabled = false;
      } catch (error) {
        currentComparison = null;
        if (status) status.textContent = error.message;
        byId("edition-compare-results")?.replaceChildren();
        if (exportButton) exportButton.disabled = true;
      } finally {
        input.value = "";
      }
    });
    exportButton?.addEventListener("click", () => {
      if (!currentComparison) return;
      download(`lumen-edition-comparison-${filenameDate()}.json`, `${JSON.stringify(currentComparison, null, 2)}\n`);
      if (status) status.textContent = "Comparison receipt exported. Neither edition was modified.";
    });
    document.querySelector("[data-edition-compare-reset]")?.addEventListener("click", resetDialog);
  }

  function open(options = {}) {
    initialize();
    currentSummary = normalizeSummary(options.currentSummary);
    currentLabel = safeString(options.currentLabel || `${currentSummary.edition} · ${shortHash(currentSummary.source_fingerprint_sha256)}`, 256);
    resetDialog();
    const dialog = byId("edition-compare-dialog");
    if (!dialog) throw new Error("Edition comparison dialog is missing from this build.");
    if (!dialog.open) dialog.showModal();
  }

  window.LumenEditionCompare = {
    open,
    parseEditionFile,
    compareSummaries,
    normalizeSummary,
    summaryFromCapsule,
  };
})();
