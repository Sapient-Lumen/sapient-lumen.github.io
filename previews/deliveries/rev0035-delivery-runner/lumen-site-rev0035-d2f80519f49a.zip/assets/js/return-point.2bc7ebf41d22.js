// Lumen return point — loaded only after explicit use, or when a marker already
// exists in this browser. The public page stays ordinary; stable page/passage
// identity and exact hashes remain available one layer deeper.
const host = window.LumenReturnHost;
if (!host) throw new Error("Lumen return-point host is unavailable.");
const {
  byId,
  safeField,
  normalizedQuoteText,
  fieldbookContextProvider,
  sha256Text,
  fieldbookEdition,
  fieldbookFingerprint,
  text,
  fieldbookRouteHref,
  downloadFieldbookFile,
  filenameDate,
  reducedMotion,
  getActivePassageAnchor,
} = host;

function ensureReturnDialog() {
  let dialog = byId("return-dialog");
  if (dialog) return dialog;
  dialog = document.createElement("dialog");
  dialog.className = "return-dialog";
  dialog.id = "return-dialog";
  dialog.setAttribute("aria-labelledby", "return-title");
  dialog.innerHTML = `
    <form method="dialog" class="dialog-bar"><div><p class="eyebrow">Private · explicit · source-bound</p><h2 id="return-title">Return point</h2></div><button class="icon-button" value="close" aria-label="Close return point">×</button></form>
    <p class="return-intro">Keep one place to resume. It is recorded only when you ask and checked against the accepted page or passage before Lumen calls it the same text.</p>
    <p class="return-status" id="return-status" role="status">No return point is stored in this browser.</p>
    <div class="return-receipt" id="return-receipt"><p>Mark the current place explicitly; Lumen does not track reading automatically.</p></div>
    <div class="return-actions">
      <button class="button-link" type="button" data-return-go disabled>Return to my place</button>
      <button class="button-link button-link--quiet" type="button" data-return-mark>Mark current place</button>
      <button class="button-link button-link--quiet" type="button" data-return-export disabled>Export marker</button>
      <label class="button-link button-link--quiet" for="return-import">Import marker</label><input id="return-import" type="file" accept="application/json,.json" hidden>
      <button class="text-button" type="button" data-return-clear disabled>Clear</button>
    </div>
    <p class="return-boundary">Exact matching may follow unchanged text to a renamed section. Changed, missing, or ambiguous text is reported rather than reattached by guesswork.</p>`;
  document.body.append(dialog);
  return dialog;
}

const returnDialog = ensureReturnDialog();
const returnStrip = byId("return-strip");
const returnStripTitle = byId("return-strip-title");
const returnStripMeta = byId("return-strip-meta");
const returnStatus = byId("return-status");
const returnReceipt = byId("return-receipt");
const returnGoButton = document.querySelector("[data-return-go]");
const returnExportButton = document.querySelector("[data-return-export]");
const returnClearButton = document.querySelector("[data-return-clear]");
const returnImport = byId("return-import");
const RETURN_MARKER_KEY = "lumen-return-marker/v1";
const RETURN_PENDING_KEY = "lumen-return-pending/v1";
let returnStorageAvailable = true;
let returnMarker = null;
let returnReview = null;
let returnReviewGeneration = 0;

function normalizeReturnMarker(value) {
  if (!value || typeof value !== "object") return null;
  const pageId = safeField(value.page_id, 180);
  const textSha = safeField(value.text_sha256 || value.passage_text_sha256 || value.page_body_sha256, 128);
  if (!pageId || !/^[0-9a-f]{64}$/.test(textSha)) return null;
  const blockIndex = Number(value.block_index);
  const scrollPercent = Number(value.scroll_percent);
  return {
    schema: "lumen.return-marker/v1",
    page_id: pageId,
    page_title: safeField(value.page_title, 500),
    page_url: safeField(value.page_url || value.url || "/", 1200),
    scope: value.scope === "passage" ? "passage" : "page",
    anchor: safeField(value.anchor, 300),
    passage_id: safeField(value.passage_id, 300),
    passage_title: safeField(value.passage_title || value.title, 500),
    text_sha256: textSha,
    page_body_sha256: safeField(value.page_body_sha256, 128),
    block_index: Number.isInteger(blockIndex) && blockIndex >= 0 ? blockIndex : null,
    block_text_sha256: /^[0-9a-f]{64}$/.test(String(value.block_text_sha256 || "")) ? String(value.block_text_sha256) : "",
    block_excerpt: safeField(value.block_excerpt, 480),
    scroll_percent: Number.isFinite(scrollPercent) ? Math.max(0, Math.min(100, Math.round(scrollPercent))) : 0,
    edition: safeField(value.edition, 100),
    source_fingerprint_sha256: safeField(value.source_fingerprint_sha256, 128),
    recorded_at: safeField(value.recorded_at || value.saved_at, 100) || new Date().toISOString(),
  };
}

function loadReturnMarker() {
  try {
    const raw = localStorage.getItem(RETURN_MARKER_KEY);
    return raw ? normalizeReturnMarker(JSON.parse(raw)) : null;
  } catch {
    returnStorageAvailable = false;
    return null;
  }
}

function persistReturnMarker(marker, message = "") {
  returnMarker = normalizeReturnMarker(marker);
  try {
    if (returnMarker) localStorage.setItem(RETURN_MARKER_KEY, JSON.stringify(returnMarker));
    else localStorage.removeItem(RETURN_MARKER_KEY);
    returnStorageAvailable = true;
  } catch {
    returnStorageAvailable = false;
  }
  if (message && returnStatus) {
    returnStatus.textContent = returnStorageAvailable
      ? message
      : `${message} Browser storage is unavailable, so this return point lasts only for this page session.`;
  }
  refreshReturnPointUi();
}

function returnPassageAnchorForBlock(block) {
  const prose = block?.closest?.("[data-prose]");
  if (!prose) return "";
  let anchor = "";
  for (const heading of prose.querySelectorAll("h2[id][data-passage-id],h3[id][data-passage-id]")) {
    if (heading === block || (heading.compareDocumentPosition(block) & Node.DOCUMENT_POSITION_FOLLOWING)) anchor = heading.id;
    else break;
  }
  return anchor;
}

function returnBlocks(anchor = "") {
  const prose = document.querySelector("[data-prose]");
  if (!prose) return [];
  return [...prose.querySelectorAll("p,blockquote,li,pre,figcaption")]
    .filter((block) => normalizedQuoteText(block.textContent || "").length >= 3)
    .filter((block) => !anchor || returnPassageAnchorForBlock(block) === anchor);
}

function nearestReturnBlock() {
  const blocks = returnBlocks();
  if (!blocks.length) return null;
  const target = window.innerHeight * 0.38;
  const visible = blocks.filter((block) => {
    const rect = block.getBoundingClientRect();
    return rect.bottom > 0 && rect.top < window.innerHeight;
  });
  const pool = visible.length ? visible : blocks;
  return pool.sort((a, b) => {
    const ar = a.getBoundingClientRect();
    const br = b.getBoundingClientRect();
    return Math.abs((ar.top + ar.bottom) / 2 - target) - Math.abs((br.top + br.bottom) / 2 - target);
  })[0];
}

async function createReturnMarker() {
  const pageId = document.body.dataset.pageId || "";
  const payload = await fieldbookContextProvider(pageId);
  if (!payload?.page?.id) throw new Error("This route has no accepted page identity.");
  const block = nearestReturnBlock();
  const anchor = block ? returnPassageAnchorForBlock(block) : (getActivePassageAnchor() || "");
  const passage = anchor
    ? (payload.passages || []).find((row) => row.anchor === anchor || row.id === anchor)
    : null;
  const blocks = returnBlocks(passage?.anchor || "");
  const blockText = block ? normalizedQuoteText(block.textContent || "") : "";
  const maximum = document.documentElement.scrollHeight - window.innerHeight;
  const scrollPercent = maximum > 0 ? (window.scrollY / maximum) * 100 : 0;
  return normalizeReturnMarker({
    schema: "lumen.return-marker/v1",
    page_id: payload.page.id,
    page_title: payload.page.title,
    page_url: payload.page.url,
    scope: passage ? "passage" : "page",
    anchor: passage?.anchor || "",
    passage_id: passage?.id || "",
    passage_title: passage?.title || "",
    text_sha256: passage?.text_sha256 || payload.page.body_sha256,
    page_body_sha256: payload.page.body_sha256,
    block_index: block ? blocks.indexOf(block) : null,
    block_text_sha256: blockText ? await sha256Text(blockText) : "",
    block_excerpt: blockText.length > 360 ? `${blockText.slice(0, 357)}…` : blockText,
    scroll_percent: scrollPercent,
    edition: fieldbookEdition,
    source_fingerprint_sha256: fieldbookFingerprint,
    recorded_at: new Date().toISOString(),
  });
}

async function reviewReturnMarker(marker = returnMarker) {
  marker = normalizeReturnMarker(marker);
  if (!marker) return { status: "empty", marker: null, target: null };
  let payload;
  try {
    payload = await fieldbookContextProvider(marker.page_id);
  } catch (error) {
    return { status: "page-missing", marker, target: null, message: error.message };
  }
  if (!payload?.page?.id) return { status: "page-missing", marker, target: null };
  const page = payload.page;
  const passages = payload.passages || [];
  if (marker.scope === "page") {
    const exact = page.body_sha256 === marker.text_sha256;
    return {
      status: exact ? "exact" : "changed",
      marker,
      target: { page_id: page.id, page_url: page.url, page_title: page.title, anchor: "", title: page.title, text_sha256: page.body_sha256, excerpt: "" },
      current_source_fingerprint_sha256: payload.source_fingerprint_sha256 || fieldbookFingerprint,
    };
  }
  const direct = passages.find((row) => row.id === marker.passage_id || row.anchor === marker.anchor);
  if (direct?.text_sha256 === marker.text_sha256) {
    return {
      status: "exact",
      marker,
      target: { page_id: page.id, page_url: page.url, page_title: page.title, anchor: direct.anchor, title: direct.title, text_sha256: direct.text_sha256, excerpt: direct.excerpt || direct.text },
      current_source_fingerprint_sha256: payload.source_fingerprint_sha256 || fieldbookFingerprint,
    };
  }
  const exactElsewhere = passages.filter((row) => row.text_sha256 === marker.text_sha256);
  if (exactElsewhere.length === 1) {
    const moved = exactElsewhere[0];
    return {
      status: "moved",
      marker,
      target: { page_id: page.id, page_url: page.url, page_title: page.title, anchor: moved.anchor, title: moved.title, text_sha256: moved.text_sha256, excerpt: moved.excerpt || moved.text },
      current_source_fingerprint_sha256: payload.source_fingerprint_sha256 || fieldbookFingerprint,
    };
  }
  if (exactElsewhere.length > 1) {
    return { status: "ambiguous", marker, target: null, matches: exactElsewhere.length, current_source_fingerprint_sha256: payload.source_fingerprint_sha256 || fieldbookFingerprint };
  }
  if (direct) {
    return {
      status: "changed",
      marker,
      target: { page_id: page.id, page_url: page.url, page_title: page.title, anchor: direct.anchor, title: direct.title, text_sha256: direct.text_sha256, excerpt: direct.excerpt || direct.text },
      current_source_fingerprint_sha256: payload.source_fingerprint_sha256 || fieldbookFingerprint,
    };
  }
  return { status: "passage-missing", marker, target: null, current_source_fingerprint_sha256: payload.source_fingerprint_sha256 || fieldbookFingerprint };
}

function returnStatusCopy(review) {
  const copies = {
    empty: "No return point is stored in this browser.",
    exact: "The marked text is byte-for-byte the same in this edition.",
    moved: "The exact marked text survives under a different section identity in this edition.",
    changed: "The marked page or passage still exists, but its accepted text changed.",
    ambiguous: "The old accepted text appears more than once, so no new location was chosen.",
    "passage-missing": "The marked passage is not present in this edition.",
    "page-missing": "The marked page is not present in this edition.",
  };
  return copies[review?.status] || "The return point could not be reviewed.";
}

function returnRecordedLabel(value) {
  const date = new Date(value || "");
  return Number.isNaN(date.getTime()) ? "date unknown" : date.toLocaleString();
}

function receiptRow(dl, label, value, code = false) {
  dl.append(text("dt", label));
  const dd = text("dd", value || "Not recorded");
  if (code) dd.className = "return-code";
  dl.append(dd);
}

function renderReturnReceipt(review) {
  if (!returnReceipt) return;
  returnReceipt.replaceChildren();
  if (!review?.marker) {
    returnReceipt.append(text("p", "Mark the current place explicitly; Lumen does not track reading automatically."));
    if (returnGoButton) returnGoButton.disabled = true;
    if (returnExportButton) returnExportButton.disabled = true;
    if (returnClearButton) returnClearButton.disabled = true;
    return;
  }
  const marker = review.marker;
  const title = review.target?.title || marker.passage_title || marker.page_title || marker.page_id;
  returnReceipt.append(text("h3", title));
  if (marker.block_excerpt) returnReceipt.append(text("blockquote", marker.block_excerpt, "return-excerpt"));
  if (review.status === "changed" && review.target?.excerpt) {
    const current = document.createElement("details");
    current.append(text("summary", "Read the current accepted excerpt"), text("p", review.target.excerpt, "return-current-excerpt"));
    returnReceipt.append(current);
  }
  const dl = document.createElement("dl");
  dl.className = "return-receipt-list";
  receiptRow(dl, "Review", returnStatusCopy(review));
  receiptRow(dl, "Marked", returnRecordedLabel(marker.recorded_at));
  receiptRow(dl, "Edition", marker.edition || "unknown");
  receiptRow(dl, "Identity", marker.passage_id || marker.page_id, true);
  receiptRow(dl, "Accepted text", marker.text_sha256, true);
  if (marker.block_text_sha256) receiptRow(dl, "Exact block", marker.block_text_sha256, true);
  receiptRow(dl, "Source edition", marker.source_fingerprint_sha256, true);
  returnReceipt.append(dl);
  if (returnGoButton) {
    returnGoButton.disabled = !review.target || ["ambiguous", "passage-missing", "page-missing"].includes(review.status);
    returnGoButton.textContent = review.status === "changed" ? "Open current passage" : review.status === "moved" ? "Return to exact text" : "Return to my place";
  }
  if (returnExportButton) returnExportButton.disabled = false;
  if (returnClearButton) returnClearButton.disabled = false;
}

async function refreshReturnPointUi() {
  const generation = ++returnReviewGeneration;
  if (!returnMarker) returnMarker = loadReturnMarker();
  if (!returnMarker) {
    returnReview = { status: "empty", marker: null, target: null };
    if (returnStrip) returnStrip.hidden = true;
    if (returnStatus) returnStatus.textContent = returnStatusCopy(returnReview);
    renderReturnReceipt(returnReview);
    return;
  }
  if (returnStrip) returnStrip.hidden = false;
  if (returnStripTitle) returnStripTitle.textContent = returnMarker.passage_title || returnMarker.page_title || "Saved return point";
  if (returnStripMeta) returnStripMeta.textContent = `Reviewing ${returnMarker.edition || "saved edition"}…`;
  const review = await reviewReturnMarker(returnMarker);
  if (generation !== returnReviewGeneration) return;
  returnReview = review;
  if (returnStatus) returnStatus.textContent = `${returnStatusCopy(review)} Nothing is transmitted.`;
  if (returnStripMeta) returnStripMeta.textContent = `${review.status.replace(/-/g, " ")} · marked ${returnRecordedLabel(returnMarker.recorded_at)}`;
  renderReturnReceipt(review);
}

function openReturnPoint() {
  refreshReturnPointUi();
  if (returnDialog && !returnDialog.open) returnDialog.showModal();
}

async function markCurrentReturnPoint() {
  const marker = await createReturnMarker();
  if (!marker) throw new Error("The current place could not be bound to accepted text.");
  persistReturnMarker(marker, `Marked “${marker.passage_title || marker.page_title}” as the private return point.`);
  return marker;
}

async function exactReturnBlock(marker, anchor) {
  if (!marker?.block_text_sha256) return null;
  const blocks = returnBlocks(anchor);
  const preferred = Number.isInteger(marker.block_index) ? blocks[marker.block_index] : null;
  if (preferred && await sha256Text(normalizedQuoteText(preferred.textContent || "")) === marker.block_text_sha256) return preferred;
  const matches = [];
  for (const block of blocks) {
    if (await sha256Text(normalizedQuoteText(block.textContent || "")) === marker.block_text_sha256) matches.push(block);
  }
  return matches.length === 1 ? matches[0] : null;
}

function highlightReturnTarget(node) {
  if (!node) return;
  node.classList.add("return-point-highlight");
  window.setTimeout(() => node.classList.remove("return-point-highlight"), reducedMotion ? 800 : 2600);
}

async function restorePendingReturnPoint() {
  if (!returnMarker) returnMarker = loadReturnMarker();
  if (!returnMarker || document.body.dataset.pageId !== returnMarker.page_id) return;
  let pending = "";
  try { pending = sessionStorage.getItem(RETURN_PENDING_KEY) || ""; } catch { pending = ""; }
  if (pending && pending !== returnMarker.recorded_at) return;
  const review = await reviewReturnMarker(returnMarker);
  if (!["exact", "moved"].includes(review.status) || !review.target) return;
  const anchor = review.target.anchor || "";
  const heading = anchor ? document.getElementById(anchor) : null;
  const block = await exactReturnBlock(returnMarker, anchor);
  const target = block || heading;
  if (target) {
    target.scrollIntoView({ behavior: reducedMotion ? "auto" : "smooth", block: block ? "center" : "start" });
    highlightReturnTarget(target);
  } else if (!anchor && returnMarker.scroll_percent > 0) {
    const maximum = document.documentElement.scrollHeight - window.innerHeight;
    window.scrollTo({ top: maximum * (returnMarker.scroll_percent / 100), behavior: reducedMotion ? "auto" : "smooth" });
  }
  try { sessionStorage.removeItem(RETURN_PENDING_KEY); } catch { /* Session storage is optional. */ }
}

async function goToReturnPoint() {
  const review = returnReview?.marker === returnMarker ? returnReview : await reviewReturnMarker(returnMarker);
  if (!review?.target || ["ambiguous", "passage-missing", "page-missing"].includes(review.status)) return;
  try { sessionStorage.setItem(RETURN_PENDING_KEY, returnMarker.recorded_at); } catch { /* Session storage is optional. */ }
  if (returnDialog?.open) returnDialog.close();
  const href = fieldbookRouteHref(review.target.page_url || returnMarker.page_url || "/", review.target.anchor || "");
  if (href.startsWith("#/")) {
    const previous = location.hash;
    location.hash = href.slice(1);
    if (previous === location.hash) window.dispatchEvent(new HashChangeEvent("hashchange"));
  } else if (document.body.dataset.pageId === review.target.page_id) {
    if (review.target.anchor) history.replaceState(null, "", `#${review.target.anchor}`);
    await restorePendingReturnPoint();
  } else {
    window.location.href = href;
  }
}

returnGoButton?.addEventListener("click", () => goToReturnPoint());
returnExportButton?.addEventListener("click", () => {
  if (!returnMarker) return;
  downloadFieldbookFile(`lumen-return-marker-${filenameDate()}.json`, JSON.stringify(returnMarker, null, 2) + "\n", "application/json");
  if (returnStatus) returnStatus.textContent = "Return marker exported. It contains source identity and reading position, not browser history.";
});
returnClearButton?.addEventListener("click", () => {
  if (!returnMarker || window.confirm("Remove the private return point from this browser?")) {
    persistReturnMarker(null, "Return point cleared.");
  }
});
returnImport?.addEventListener("change", async () => {
  const file = returnImport.files?.[0];
  if (!file) return;
  try {
    if (file.size > 256 * 1024) throw new Error("The return-marker import limit is 256 KiB.");
    const marker = normalizeReturnMarker(JSON.parse(await file.text()));
    if (!marker) throw new Error("the file is not a valid lumen.return-marker/v1 record");
    persistReturnMarker(marker, `Imported a return point from ${marker.edition || "another edition"}.`);
  } catch (error) {
    if (returnStatus) returnStatus.textContent = `Import refused: ${error.message}`;
  } finally {
    returnImport.value = "";
  }
});

returnMarker = loadReturnMarker();
refreshReturnPointUi();
window.setTimeout(() => restorePendingReturnPoint(), 80);

const api = Object.freeze({
  open() { openReturnPoint(); },
  async mark({ openAfter = false } = {}) {
    const marker = await markCurrentReturnPoint();
    if (openAfter && returnDialog && !returnDialog.open) returnDialog.showModal();
    return marker;
  },
  async review() { return reviewReturnMarker(returnMarker); },
  close() { if (returnDialog?.open) returnDialog.close(); },
});
window.LumenReturnPoint = api;
export default api;

