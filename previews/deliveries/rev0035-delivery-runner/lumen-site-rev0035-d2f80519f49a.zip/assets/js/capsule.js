/* Lumen portable edition runtime. The builder replaces the data token below. */
const CAPSULE = __LUMEN_CAPSULE_DATA__;
const root = document.documentElement;
root.classList.add("js", "capsule-runtime");

const byId = (id) => document.getElementById(id);
const main = byId("main");
const searchDialog = byId("search-dialog");
const inspectDialog = byId("inspect-dialog");
const contextDialog = byId("context-dialog");
const correctionDialog = byId("correction-dialog");
const correctionForm = byId("correction-form");
const correctionSource = byId("correction-source");
const correctionType = byId("correction-type");
const correctionIssue = byId("correction-issue");
const correctionEvidence = byId("correction-evidence");
const correctionBoundary = byId("correction-boundary");
const correctionIncludeQuote = byId("correction-include-quote");
const correctionStatus = byId("correction-status");
const capsuleDialog = byId("capsule-dialog");
const appearanceDialog = byId("appearance-dialog");
const editionCompareDialog = byId("edition-compare-dialog");
const appearanceStatus = byId("appearance-status");
const searchInput = byId("search-input");
const searchResults = byId("search-results");
const searchStatus = byId("search-status");
const inspectContent = byId("inspect-content");
const contextContent = byId("context-content");
const preview = byId("link-preview");
const selectionTools = byId("selection-tools");
const quoteStatus = byId("quote-status");
let pendingSelection = null;
let quoteStatusTimer = 0;
const progress = document.querySelector(".reading-progress span");
const readingPosition = document.querySelector("[data-reading-position]");
const coarsePointer = window.matchMedia("(pointer: coarse)").matches || navigator.maxTouchPoints > 0;
const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const routes = new Map(Object.entries(CAPSULE.pages));
const previews = CAPSULE.previews || {};
const inspections = CAPSULE.inspections || {};
const contexts = CAPSULE.contexts || {};
const searchRecords = CAPSULE.search?.records || [];
const graph = CAPSULE.graph || { nodes: [], edges: [] };
const referenceLedger = CAPSULE.references || { schema: "lumen.references/v1", sources: [], counts: {} };
const referenceById = new Map((referenceLedger.sources || []).map((source) => [source.id, source]));
const portableFolios = CAPSULE.portableFolios?.items || {};
const portablePathFolios = CAPSULE.portablePathFolios?.items || {};
let currentRoute = "/";
let tocObserver = null;
let previewTimer = 0;
let previewOwner = null;
let activePassageAnchor = "";
let correctionContext = null;

function text(tag, value, className = "") {
  const node = document.createElement(tag);
  node.textContent = value ?? "";
  if (className) node.className = className;
  return node;
}

function normalizeRoute(value) {
  let route = value || "/";
  if (!route.startsWith("/")) route = `/${route}`;
  route = route.replace(/\/+/g, "/");
  if (!route.endsWith("/") && !route.split("/").pop().includes(".")) route += "/";
  return route;
}

function routeState() {
  if (location.hash.startsWith("#") && !location.hash.startsWith("#/")) {
    let anchor = location.hash.slice(1);
    try { anchor = decodeURIComponent(anchor); } catch { /* Keep the literal fragment. */ }
    return { route: "/", anchor, quote: "" };
  }
  const raw = location.hash.startsWith("#/") ? location.hash.slice(1) : "/";
  const queryAt = raw.indexOf("?");
  const path = queryAt >= 0 ? raw.slice(0, queryAt) : raw;
  const params = new URLSearchParams(queryAt >= 0 ? raw.slice(queryAt + 1) : "");
  return {
    route: normalizeRoute(decodeURI(path || "/")),
    anchor: params.get("anchor") || "",
    quote: params.get("lq") || "",
  };
}

function capsuleHref(route, anchor = "", quote = "") {
  const [routePart, inlineAnchor = ""] = String(route || "/").split("#", 2);
  const path = normalizeRoute(routePart);
  const params = new URLSearchParams();
  const targetAnchor = anchor || inlineAnchor;
  if (targetAnchor) params.set("anchor", targetAnchor);
  if (quote) params.set("lq", quote);
  const query = params.toString();
  return `#${path}${query ? `?${query}` : ""}`;
}

function activeKey(page) {
  if (["note", "listing"].includes(page.kind)) return "notes";
  if (["project", "collection"].includes(page.kind)) return "projects";
  return page.kind;
}

function updateNav(page) {
  const key = activeKey(page);
  document.querySelectorAll(".site-nav a").forEach((link) => {
    const navKey = link.dataset.navKey || "";
    if (navKey === key) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  });
}

function renderRoute(route, anchor = "", { focus = true, quote = "" } = {}) {
  const normalized = normalizeRoute(route);
  const page = routes.get(normalized) || CAPSULE.notFound;
  currentRoute = routes.has(normalized) ? normalized : "/404.html";
  activePassageAnchor = anchor || "";
  main.innerHTML = page.main;
  document.body.dataset.pageId = page.id;
  root.dataset.pageKind = page.kind;
  applyRouteAppearance(page);
  document.title = `${page.title} · Lumen`;
  const description = document.querySelector('meta[name="description"]');
  if (description) description.content = page.description;
  updateNav(page);
  bindPageFeatures();
  refreshReturnPointUi();
  window.setTimeout(() => restorePendingReturnPoint(), 80);
  if (quote) window.setTimeout(() => restoreExactQuote(quote), 0);
  if (anchor) {
    requestAnimationFrame(() => document.getElementById(anchor)?.scrollIntoView({ block: "start" }));
  } else {
    scrollTo({ top: 0, behavior: "instant" });
  }
  if (focus) main.focus({ preventScroll: true });
  updateProgress();
}

function navigate(route, anchor = "", quote = "") {
  const target = capsuleHref(route, anchor, quote);
  if (location.hash === target) renderRoute(route, anchor, { quote });
  else location.hash = target;
}

window.addEventListener("hashchange", () => {
  const state = routeState();
  renderRoute(state.route, state.anchor, { quote: state.quote });
});

function closeReaderDialogForLink(link) {
  const dialog = link.closest("dialog[open]");
  if (dialog) dialog.close();
}

document.addEventListener("click", (event) => {
  const link = event.target.closest("a[href]");
  if (!link || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
  const href = link.getAttribute("href") || "";
  if (href === "/Lumen.html" || link.hasAttribute("data-capsule-download")) {
    event.preventDefault();
    openCapsuleDialog();
    return;
  }
  if (link.hasAttribute("data-reference-download")) {
    event.preventDefault();
    downloadFieldbookFile("lumen-references.json", JSON.stringify(referenceLedger, null, 2) + "\n", "application/json");
    return;
  }
  if (link.hasAttribute("data-folio-download")) {
    event.preventDefault();
    const pageId = link.dataset.folioDownload || document.body.dataset.pageId || "";
    const folio = portableFolios[pageId];
    if (!folio?.html || !folio?.record) {
      setQuoteStatus("This edition does not carry a portable folio for the current page.");
      return;
    }
    downloadFieldbookFile(
      folio.record.download_name || `Lumen-${pageId}.html`,
      folio.html,
      "text/html",
    );
    setQuoteStatus("Portable page downloaded from this exact edition.");
    return;
  }
  if (link.hasAttribute("data-path-folio-download")) {
    event.preventDefault();
    const pathId = link.dataset.pathFolioDownload || "";
    const folio = portablePathFolios[pathId];
    if (!folio?.html || !folio?.record) {
      setQuoteStatus("This edition does not carry a portable folio for that reading path.");
      return;
    }
    downloadFieldbookFile(
      folio.record.download_name || `Lumen-path-${pathId}.html`,
      folio.html,
      "text/html",
    );
    setQuoteStatus("Portable reading path downloaded from this exact edition.");
    return;
  }
  if (href.startsWith("#/")) { closeReaderDialogForLink(link); return; }
  if (href.startsWith("#") && href.length > 1) {
    const id = href.slice(1);
    const target = document.getElementById(id);
    if (target) {
      event.preventDefault();
      closeReaderDialogForLink(link);
      target.scrollIntoView({ behavior: reducedMotion ? "auto" : "smooth", block: "start" });
    }
    return;
  }
  if (href.startsWith("/")) {
    const url = new URL(href, "https://lumen.invalid");
    if (routes.has(normalizeRoute(url.pathname))) {
      event.preventDefault();
      closeReaderDialogForLink(link);
      navigate(url.pathname, url.hash.slice(1));
    }
  }
});

// Appearance. The capsule carries both presentation layers without changing its content receipts.
const themes = ["system", "light", "dark"];
const themeIcons = { system: "◐", light: "☼", dark: "☾" };
const looks = ["field-notes", "night-study"];
const lookLabels = { "field-notes": "Field Notes", "night-study": "Night Desk" };
let storedLook = null;
let storedTheme = null;
try {
  storedLook = localStorage.getItem("lumen-look/v1");
  storedTheme = localStorage.getItem("lumen-theme");
} catch {}
let look = looks.includes(storedLook) ? storedLook : "field-notes";
let theme = themes.includes(storedTheme) ? storedTheme : "system";

function refreshAppearanceControls() {
  document.querySelectorAll("[data-theme-icon]").forEach((node) => { node.textContent = themeIcons[theme]; });
  document.querySelectorAll("[data-theme-toggle]").forEach((button) => button.setAttribute("aria-label", `Color theme: ${theme}. Activate to change.`));
  document.querySelectorAll("[data-theme-choice]").forEach((button) => button.setAttribute("aria-pressed", String(button.dataset.themeChoice === theme)));
  document.querySelectorAll("[data-look-choice]").forEach((button) => button.setAttribute("aria-pressed", String(button.dataset.lookChoice === look)));
  if (appearanceStatus) appearanceStatus.textContent = `${lookLabels[look]} · ${theme} tone. Saved only in this browser.`;
}
function applyTheme(next, { persist = true } = {}) {
  if (!themes.includes(next)) return;
  theme = next; root.dataset.theme = next;
  if (persist) { try { localStorage.setItem("lumen-theme", next); storedTheme = next; } catch {} }
  refreshAppearanceControls();
}
function applyLook(next, { persist = true, preferredTone = "" } = {}) {
  if (!looks.includes(next)) return;
  look = next; root.dataset.look = next; root.dataset.lookPreview = "false";
  if (persist) { try { localStorage.setItem("lumen-look/v1", next); storedLook = next; } catch {} }
  if (preferredTone && themes.includes(preferredTone)) applyTheme(preferredTone, { persist });
  refreshAppearanceControls();
}
function applyRouteAppearance(page) {
  if (!storedLook && page?.lookPreview && looks.includes(page.look)) {
    look = page.look; root.dataset.look = look; root.dataset.lookPreview = "true";
  } else {
    look = looks.includes(storedLook) ? storedLook : "field-notes"; root.dataset.look = look; root.dataset.lookPreview = "false";
  }
  if (!storedTheme && page?.lookPreview && themes.includes(page.theme)) {
    theme = page.theme; root.dataset.theme = theme;
  } else {
    theme = themes.includes(storedTheme) ? storedTheme : "system"; root.dataset.theme = theme;
  }
  refreshAppearanceControls();
}
applyTheme(theme, { persist: false });
applyLook(look, { persist: false });
document.querySelectorAll("[data-theme-toggle]").forEach((button) => button.addEventListener("click", () => applyTheme(themes[(themes.indexOf(theme) + 1) % themes.length])));
document.querySelectorAll("[data-theme-choice]").forEach((button) => button.addEventListener("click", () => applyTheme(button.dataset.themeChoice)));
document.querySelectorAll("[data-look-choice]").forEach((button) => button.addEventListener("click", () => applyLook(button.dataset.lookChoice, { preferredTone: button.dataset.lookTone || "" })));
document.querySelectorAll("[data-open-appearance]").forEach((button) => button.addEventListener("click", () => { if (appearanceDialog && !appearanceDialog.open) appearanceDialog.showModal(); }));

// Progress
let progressQueued = false;
function updateProgress() {
  progressQueued = false;
  if (!progress) return;
  const max = document.documentElement.scrollHeight - innerHeight;
  const value = max > 0 ? Math.min(1, Math.max(0, scrollY / max)) : 0;
  progress.style.transform = `scaleX(${value})`;
  if (readingPosition) readingPosition.textContent = String(Math.round(value * 100)).padStart(3, "0");
}
addEventListener("scroll", () => {
  if (!progressQueued) {
    progressQueued = true;
    requestAnimationFrame(updateProgress);
  }
}, { passive: true });
addEventListener("resize", updateProgress, { passive: true });

// Search: one embedded index, several explicit intents.
function normalizeQuery(value) {
  return value.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").trim();
}
const validSearchModes = new Set(["all", "title", "tag", "text", "exact", "alias", "id"]);
const searchModeLabels = { all: "All fields", title: "Titles + aliases", tag: "Tags", text: "Prose", exact: "Exact phrase", alias: "Aliases", id: "Stable identity" };
let searchMode = "all";
function parseSearchQuery(value) {
  const normalized = normalizeQuery(value);
  const match = normalized.match(/^(title|tag|text|exact|alias|id):\s*(.+)$/);
  if (match && validSearchModes.has(match[1])) return { query: match[2].trim(), mode: match[1] };
  return { query: normalized, mode: searchMode };
}
function recordFields(record) {
  return {
    title: normalizeQuery(`${record.title || ""} ${record.page_title || ""}`),
    description: normalizeQuery(record.description || ""),
    aliases: normalizeQuery((record.aliases || []).join(" ")),
    tags: normalizeQuery((record.tags || []).join(" ")),
    body: normalizeQuery(record.text || ""),
    identity: normalizeQuery(`${record.id || ""} ${record.url || ""}`),
  };
}
function allTermsPresent(haystack, terms) { return terms.every((term) => haystack.includes(term)); }
function scoreRecord(record, query, mode) {
  const terms = query.split(/\s+/).filter(Boolean);
  if (!terms.length) return 0;
  const fields = recordFields(record);
  if (mode === "exact") {
    const joined = `${fields.title} ${fields.aliases} ${fields.tags} ${fields.description} ${fields.body}`;
    if (!joined.includes(query)) return 0;
    return 100 + (fields.title.includes(query) ? 40 : 0) + (fields.aliases.includes(query) ? 30 : 0);
  }
  if (mode === "title") return allTermsPresent(`${fields.title} ${fields.aliases}`, terms) ? 80 + (fields.title.includes(query) ? 20 : 0) : 0;
  if (mode === "alias") return allTermsPresent(fields.aliases, terms) ? 85 : 0;
  if (mode === "tag") return allTermsPresent(fields.tags, terms) ? 75 : 0;
  if (mode === "text") return allTermsPresent(`${fields.description} ${fields.body}`, terms) ? 55 + (fields.description.includes(query) ? 12 : 0) : 0;
  if (mode === "id") return allTermsPresent(fields.identity, terms) ? 90 : 0;
  let score = 0;
  for (const term of terms) {
    let part = 0;
    if (fields.title === term) part += 60;
    if (fields.title.includes(term)) part += 24;
    if (fields.aliases.includes(term)) part += 18;
    if (fields.description.includes(term)) part += 10;
    if (fields.tags.includes(term)) part += 12;
    if (fields.identity.includes(term)) part += 7;
    const index = fields.body.indexOf(term);
    if (index >= 0) part += 3 + Math.max(0, 3 - index / 1200);
    if (!part) return 0;
    score += part;
  }
  return score + (fields.title.includes(query) ? 28 : 0) + (fields.aliases.includes(query) ? 20 : 0) + (fields.description.includes(query) ? 10 : 0);
}
function setSearchMode(next, { focus = true } = {}) {
  if (!validSearchModes.has(next) || ["alias", "id"].includes(next)) return;
  searchMode = next;
  document.querySelectorAll("[data-search-mode]").forEach((button) => button.setAttribute("aria-pressed", String(button.dataset.searchMode === next)));
  renderSearch(searchInput?.value || "");
  if (focus) searchInput?.focus();
}
function renderSearch(rawQuery) {
  const parsed = parseSearchQuery(rawQuery);
  const q = parsed.query;
  const mode = parsed.mode;
  searchResults.replaceChildren();
  if (!q) {
    searchStatus.textContent = `${CAPSULE.search?.page_count || 0} pages, ${CAPSULE.search?.passage_count || 0} passages, and ${CAPSULE.search?.reference_count || 0} references are embedded · ${searchModeLabels[searchMode]}.`;
    return;
  }
  const ranked = searchRecords.map((record) => ({ record, score: scoreRecord(record, q, mode) }))
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score || a.record.title.localeCompare(b.record.title))
    .slice(0, 18);
  searchStatus.textContent = ranked.length ? `${searchModeLabels[mode]} · ${ranked.length} result${ranked.length === 1 ? "" : "s"}.` : `${searchModeLabels[mode]} · no embedded page, passage, or reference matched.`;
  for (const { record } of ranked) {
    const li = document.createElement("li");
    const link = document.createElement("a");
    link.className = `search-result search-result--${record.scope || "page"}`;
    link.href = capsuleHref(record.url);
    const titleValue = record.scope === "passage" ? `${record.page_title} › ${record.title}` : record.title;
    const scope = record.scope === "passage" ? "passage" : record.kind;
    const aliases = (record.aliases || []).length && mode === "title" ? ` · aka ${(record.aliases || []).slice(0, 2).join(", ")}` : "";
    link.append(text("strong", titleValue), text("span", `${scope} · ${record.date || "undated"} · ${record.description}${aliases}`));
    li.append(link);
    searchResults.append(li);
  }
}
function openSearch() {
  if (!searchDialog.open) searchDialog.showModal();
  searchInput.focus();
  renderSearch(searchInput.value);
}
document.querySelectorAll("[data-search-mode]").forEach((button) => button.addEventListener("click", () => setSearchMode(button.dataset.searchMode || "all")));
document.querySelectorAll("[data-open-search]").forEach((button) => button.addEventListener("click", openSearch));
searchInput.addEventListener("input", () => renderSearch(searchInput.value));
searchInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    const first = searchResults.querySelector("a");
    if (first) { event.preventDefault(); first.click(); searchDialog.close(); }
  }
});

// Inspector
function inspectRow(dl, label, value) {
  dl.append(text("dt", label), text("dd", value || "Not declared"));
}
function inspectLinkRow(dl, label, href, value) {
  if (!href) return;
  dl.append(text("dt", label));
  const dd = document.createElement("dd");
  const link = document.createElement("a");
  link.href = href;
  link.textContent = value || href;
  dd.append(link);
  dl.append(dd);
}
function renderInspector(payload) {
  inspectContent.replaceChildren();
  const page = payload?.page || {};
  const build = payload?.build || {};
  const dl = document.createElement("dl");
  dl.className = "inspect-grid";
  inspectRow(dl, "Page", page.title);
  inspectRow(dl, "Kind", page.kind);
  inspectRow(dl, "Published", page.date || "Undated");
  inspectRow(dl, "Author", page.author);
  if (page.aliases?.length) inspectRow(dl, "Aliases", page.aliases.join(", "));
  inspectRow(dl, "Source repository", page.source?.repository);
  inspectRow(dl, "Source path", page.source?.path);
  inspectLinkRow(dl, "Public source", page.source?.url, "Open captured public source ↗");
  inspectRow(dl, "Captured source", page.source?.sha);
  inspectRow(dl, "Source status", page.source?.status);
  inspectRow(dl, "Build reference clock", build.generated_at);
  inspectRow(dl, "Clock basis", build.generated_at_basis || "fixed source clock");
  inspectRow(dl, "Build fingerprint", build.source_fingerprint);
  inspectRow(dl, "Edition", CAPSULE.edition);
  inspectRow(dl, "Carrier", "Single HTML + extractable ZIP payload");
  if (page.hypertext) {
    inspectRow(dl, "Source-bound passages", String(page.hypertext.passages ?? 0));
    inspectRow(dl, "External citations", String(page.hypertext.external_citations ?? 0));
    inspectRow(dl, "Incoming contexts", String(page.hypertext.incoming_contexts ?? 0));
    inspectRow(dl, "Outgoing contexts", String(page.hypertext.outgoing_contexts ?? 0));
  }
  inspectContent.append(dl);
  if (page.limits?.length) {
    const section = document.createElement("section");
    section.className = "inspect-limits";
    section.append(text("p", "Declared limits", "eyebrow"));
    const list = document.createElement("ul");
    page.limits.forEach((item) => list.append(text("li", item)));
    section.append(list);
    inspectContent.append(section);
  }
}
function openInspector() {
  if (!inspectDialog.open) inspectDialog.showModal();
  renderInspector(inspections[document.body.dataset.pageId]);
}
document.addEventListener("click", (event) => {
  if (event.target.closest("[data-open-inspector]")) openInspector();
});

// Passage context is carried entirely inside the capsule.
function shortHash(value) {
  return value ? `${String(value).slice(0, 12)}…` : "Not declared";
}
function contextLink(href, label, { external = false } = {}) {
  const link = document.createElement("a");
  link.href = !external && String(href).startsWith("/") ? capsuleHref(href) : href;
  link.textContent = label || href;
  if (external) { link.target = "_blank"; link.rel = "noopener noreferrer"; }
  return link;
}
function contextList(title, rows, renderRow) {
  if (!rows?.length) return null;
  const section = document.createElement("section");
  section.className = "context-section";
  section.append(text("h3", title));
  const list = document.createElement("ul");
  rows.forEach((row) => { const item = document.createElement("li"); renderRow(item, row); list.append(item); });
  section.append(list);
  return section;
}

function sourceBoundCitation(page, passage, url) {
  const title = passage?.title || page?.title || "Untitled passage";
  const container = passage ? ` In “${page?.title || "Lumen’s Field Notes"},”` : "";
  const date = page?.date ? ` ${page.date}.` : "";
  const edition = root.dataset.edition || CAPSULE.edition || "unknown";
  const hash = passage?.text_sha256 || page?.body_sha256 || "";
  return `Lumen. “${title}.”${container} Lumen’s Field Notes.${date} ${url} (edition ${edition}${hash ? `; text SHA-256 ${hash}` : ""}).`;
}

function quotedPassage(passage, citation) {
  const body = String(passage?.text || passage?.excerpt || "").trim();
  return `${body.replace(/^/gm, "> ")}

— ${citation}`;
}


function normalizedQuoteText(value) {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

function pageIdForAnchor(anchor = "", origin = null) {
  const owner = origin instanceof Element ? origin.closest("[data-page-id]") : null;
  if (owner?.dataset.pageId) return owner.dataset.pageId;
  const heading = anchor ? document.getElementById(anchor) : null;
  const article = heading?.closest("[data-page-id]");
  return article?.dataset.pageId || document.body.dataset.pageId || "";
}

function passageHeadingForNode(node) {
  const element = node instanceof Element ? node : node?.parentElement;
  const prose = element?.closest?.("[data-prose]");
  if (!prose) return null;
  let top = element;
  while (top?.parentElement && top.parentElement !== prose) top = top.parentElement;
  if (!top) return null;
  if (top.matches?.("h2[id][data-passage-id],h3[id][data-passage-id]")) return top;
  let cursor = top.previousElementSibling;
  while (cursor) {
    if (cursor.matches("h2[id][data-passage-id],h3[id][data-passage-id]")) return cursor;
    cursor = cursor.previousElementSibling;
  }
  return null;
}

function selectionSnapshot() {
  const selection = window.getSelection();
  if (!selection || selection.rangeCount !== 1 || selection.isCollapsed) return null;
  const range = selection.getRangeAt(0);
  const startHeading = passageHeadingForNode(range.startContainer);
  const endHeading = passageHeadingForNode(range.endContainer);
  if (!startHeading || startHeading !== endHeading) return null;
  const quote = normalizedQuoteText(selection.toString());
  if (quote.length < 3 || quote.length > 700) return null;
  const rect = range.getBoundingClientRect();
  if (!rect || (!rect.width && !rect.height)) return null;
  return { pageId: pageIdForAnchor(startHeading.id, startHeading), anchor: startHeading.id, quote, range: range.cloneRange(), rect };
}

function encodeQuotePayload(value) {
  const bytes = new TextEncoder().encode(JSON.stringify(value));
  let binary = "";
  bytes.forEach((byte) => { binary += String.fromCharCode(byte); });
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function decodeQuotePayload(value) {
  try {
    const source = String(value || "");
    const padded = source.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(source.length / 4) * 4, "=");
    const binary = atob(padded);
    const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
    const payload = JSON.parse(new TextDecoder().decode(bytes));
    return payload?.v === 1 ? payload : null;
  } catch { return null; }
}

function quoteOffsets(haystack, needle) {
  const rows = [];
  let index = haystack.indexOf(needle);
  while (index >= 0 && rows.length < 64) {
    rows.push(index);
    index = haystack.indexOf(needle, index + Math.max(1, needle.length));
  }
  return rows;
}

function domPrefixLength(heading, range) {
  try {
    const before = document.createRange();
    before.setStartAfter(heading);
    before.setEnd(range.startContainer, range.startOffset);
    return normalizedQuoteText(before.toString()).length;
  } catch { return 0; }
}

async function quotePayloadFromSelection(snapshot = pendingSelection) {
  if (!snapshot) throw new Error("Select text inside a titled section first.");
  const context = contexts[snapshot.pageId];
  const page = context?.page || {};
  const passage = (context?.passages || []).find((row) => row.anchor === snapshot.anchor);
  if (!passage) throw new Error("This section has no accepted passage record.");
  const passageText = normalizedQuoteText(passage.text || "");
  const quote = normalizedQuoteText(snapshot.quote);
  const offsets = quoteOffsets(passageText, quote);
  if (!offsets.length) throw new Error("The selected text does not match the accepted passage record.");
  const heading = document.getElementById(snapshot.anchor);
  const expected = heading ? domPrefixLength(heading, snapshot.range) : offsets[0];
  const index = offsets.reduce((best, row) => Math.abs(row - expected) < Math.abs(best - expected) ? row : best, offsets[0]);
  return {
    page,
    passage,
    value: {
      v: 1, p: page.id, a: passage.anchor, q: quote, i: index,
      b: passageText.slice(Math.max(0, index - 48), index),
      n: passageText.slice(index + quote.length, index + quote.length + 48),
      h: passage.text_sha256 || "", e: root.dataset.edition || CAPSULE.edition || "unknown",
    },
  };
}

function exactQuoteCapsuleUrl(page, encoded, anchor) {
  return `${location.href.split("#")[0]}${capsuleHref(page.url || currentRoute, anchor, encoded)}`;
}

function exactQuoteCanonicalUrl(page, encoded, anchor) {
  const base = String(CAPSULE.origin || "https://sapient-lumen.github.io").replace(/\/$/, "");
  const url = new URL(page.url || "/", `${base}/`);
  url.searchParams.set("lq", encoded);
  url.hash = anchor;
  return url.href;
}

function selectedQuoteCitation(page, passage, quote, url) {
  return `${String(quote).replace(/^/gm, "> ")}\n\n— ${sourceBoundCitation(page, passage, url)}`;
}

function setQuoteStatus(message, { persist = false } = {}) {
  if (!quoteStatus) return;
  clearTimeout(quoteStatusTimer);
  quoteStatus.textContent = message;
  quoteStatus.hidden = false;
  if (!persist) quoteStatusTimer = setTimeout(() => { quoteStatus.hidden = true; }, 5200);
}

function hideSelectionTools() {
  if (selectionTools) selectionTools.hidden = true;
  pendingSelection = null;
}

function positionSelectionTools(snapshot) {
  if (!selectionTools) return;
  const width = selectionTools.offsetWidth || 270;
  selectionTools.style.left = `${Math.max(12, Math.min(innerWidth - width - 12, snapshot.rect.left + snapshot.rect.width / 2 - width / 2))}px`;
  selectionTools.style.top = `${Math.max(12, snapshot.rect.top - (selectionTools.offsetHeight || 42) - 10)}px`;
}

function refreshSelectionTools() {
  const snapshot = selectionSnapshot();
  if (!snapshot || !selectionTools) { hideSelectionTools(); return; }
  pendingSelection = snapshot;
  selectionTools.hidden = false;
  requestAnimationFrame(() => positionSelectionTools(snapshot));
}

function passageTextMap(heading) {
  const textNodes = [];
  let node = heading.nextSibling;
  while (node) {
    if (node.nodeType === Node.ELEMENT_NODE && node.matches?.("h2[id][data-passage-id],h3[id][data-passage-id]")) break;
    const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT, {
      acceptNode(textNode) {
        const parent = textNode.parentElement;
        if (!parent || parent.closest(".heading-tools,button,script,style,[hidden]")) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      },
    });
    if (node.nodeType === Node.TEXT_NODE) textNodes.push(node);
    else while (walker.nextNode()) textNodes.push(walker.currentNode);
    node = node.nextSibling;
  }
  let rendered = "";
  const starts = [], ends = [];
  let whitespace = null;
  const append = (char, start, end) => { rendered += char; starts.push(start); ends.push(end); };
  for (const textNode of textNodes) {
    const value = textNode.nodeValue || "";
    for (let offset = 0; offset < value.length; offset += 1) {
      const char = value[offset];
      if (/\s/.test(char)) {
        if (!whitespace) whitespace = { start: { node: textNode, offset }, end: { node: textNode, offset: offset + 1 } };
        else whitespace.end = { node: textNode, offset: offset + 1 };
        continue;
      }
      if (whitespace && rendered && !rendered.endsWith(" ")) append(" ", whitespace.start, whitespace.end);
      whitespace = null;
      append(char, { node: textNode, offset }, { node: textNode, offset: offset + 1 });
    }
  }
  return { text: rendered, starts, ends };
}

function quoteIndexForPayload(textValue, payload) {
  const quote = normalizedQuoteText(payload.q || "");
  if (!quote) return -1;
  const declared = Number(payload.i);
  if (Number.isInteger(declared) && declared >= 0 && textValue.slice(declared, declared + quote.length) === quote) return declared;
  const offsets = quoteOffsets(textValue, quote);
  if (offsets.length === 1) return offsets[0];
  return offsets.find((index) => textValue.slice(Math.max(0, index - String(payload.b || "").length), index) === String(payload.b || "")
    && textValue.slice(index + quote.length, index + quote.length + String(payload.n || "").length) === String(payload.n || "")) ?? -1;
}

function restoreExactQuote(encoded = "") {
  if (!encoded) return;
  const payload = decodeQuotePayload(encoded);
  if (!payload?.p || !payload?.a) { setQuoteStatus("This exact-quote link is malformed.", { persist: true }); return; }
  try {
    const context = contexts[payload.p];
    const passage = (context?.passages || []).find((row) => row.anchor === payload.a);
    const heading = document.getElementById(payload.a);
    if (!passage || !heading) throw new Error("The linked passage is not present in this projection.");
    heading.scrollIntoView({ block: "center", behavior: reducedMotion ? "auto" : "smooth" });
    if (payload.h && passage.text_sha256 && payload.h !== passage.text_sha256) {
      heading.dataset.quoteFallback = "true";
      setQuoteStatus("This quote belongs to another accepted edition. The matching section is open, but the old words were not reconstructed.", { persist: true });
      return;
    }
    const map = passageTextMap(heading);
    const quote = normalizedQuoteText(payload.q || "");
    const index = quoteIndexForPayload(map.text, payload);
    if (index < 0 || !map.starts[index] || !map.ends[index + quote.length - 1]) throw new Error("The exact selected words are not present in this edition.");
    const range = document.createRange();
    range.setStart(map.starts[index].node, map.starts[index].offset);
    range.setEnd(map.ends[index + quote.length - 1].node, map.ends[index + quote.length - 1].offset);
    if (globalThis.CSS?.highlights && typeof globalThis.Highlight === "function") {
      CSS.highlights.set("lumen-exact-quote", new Highlight(range));
      range.startContainer.parentElement?.scrollIntoView({ block: "center", behavior: reducedMotion ? "auto" : "smooth" });
      setQuoteStatus(`Exact quote verified against ${String(passage.text_sha256 || "").slice(0, 12)}…`);
    } else {
      heading.dataset.quoteFallback = "true";
      setQuoteStatus("Exact quote verified. This browser opened the section but cannot paint custom quote highlights.");
    }
  } catch (error) { setQuoteStatus(`Exact quote unavailable: ${error.message}`, { persist: true }); }
}

function bindExactQuoteLinks() {
  if (!selectionTools || selectionTools.dataset.bound === "true") return;
  selectionTools.dataset.bound = "true";
  selectionTools.addEventListener("pointerdown", (event) => event.preventDefault());
  document.addEventListener("selectionchange", () => setTimeout(refreshSelectionTools, 0));
  addEventListener("scroll", hideSelectionTools, { passive: true });
  addEventListener("resize", hideSelectionTools, { passive: true });
  selectionTools.querySelector("[data-selection-copy-link]")?.addEventListener("click", async () => {
    try {
      const result = await quotePayloadFromSelection();
      const encoded = encodeQuotePayload(result.value);
      await copyText(exactQuoteCapsuleUrl(result.page, encoded, result.passage.anchor));
      setQuoteStatus("Exact quote link copied. It stays inside this portable edition.");
    } catch (error) { setQuoteStatus(error.message, { persist: true }); }
    hideSelectionTools();
  });
  selectionTools.querySelector("[data-selection-copy-quote]")?.addEventListener("click", async () => {
    try {
      const result = await quotePayloadFromSelection();
      const encoded = encodeQuotePayload(result.value);
      await copyText(selectedQuoteCitation(result.page, result.passage, result.value.q, exactQuoteCanonicalUrl(result.page, encoded, result.passage.anchor)));
      setQuoteStatus("Quote and source-bound citation copied.");
    } catch (error) { setQuoteStatus(error.message, { persist: true }); }
    hideSelectionTools();
  });
  selectionTools.querySelector("[data-selection-save-quote]")?.addEventListener("click", async () => {
    try {
      const entry = await saveFieldbookQuoteFromSelection();
      setQuoteStatus(`Kept exact quote in the private reading trail · ${entry.quote_sha256.slice(0, 12)}…`);
    } catch (error) { setQuoteStatus(error.message, { persist: true }); }
    hideSelectionTools();
  });
}

function renderContext(payload, requestedAnchor = "") {
  contextContent.replaceChildren();
  const passages = payload?.passages || [];
  const passage = passages.find((row) => row.anchor === requestedAnchor) || passages[0] || null;
  const page = payload?.page || {};
  const anchor = passage?.anchor || "";
  const intro = document.createElement("header");
  intro.className = "context-intro";
  intro.append(text("p", page.title || "Current page", "eyebrow"), text("h2", passage?.title || "Page context"), text("p", passage?.excerpt || "This page has no section passage record.", "context-excerpt"));
  contextContent.append(intro);
  const facts = document.createElement("dl");
  facts.className = "context-facts";
  inspectRow(facts, "Stable identity", passage?.id || page.id);
  inspectRow(facts, "Words", String(passage?.word_count ?? page.word_count ?? 0));
  inspectRow(facts, "Text fingerprint", shortHash(passage?.text_sha256 || page.body_sha256));
  inspectRow(facts, "Exact HTML fingerprint", shortHash(passage?.source_html_sha256));
  if (passage?.source_offsets) inspectRow(facts, "Source slice", `${passage.source_offsets.start}–${passage.source_offsets.end}`);
  contextContent.append(facts);
  if (anchor) {
    const actions = document.createElement("div");
    actions.className = "context-actions";
    actions.append(contextLink(`${page.url}#${anchor}`, "Open this passage"));
    const copy = document.createElement("button");
    copy.type = "button"; copy.className = "text-button"; copy.textContent = "Copy passage link";
    copy.addEventListener("click", async () => {
      const url = `${location.href.split("#")[0]}${capsuleHref(page.url, anchor)}`;
      try { await copyText(url); copy.textContent = "Copied ✓"; } catch { copy.textContent = "Copy unavailable"; }
      setTimeout(() => { copy.textContent = "Copy passage link"; }, 1400);
    });
    const canonicalBase = String(CAPSULE.origin || "https://sapient-lumen.github.io").replace(/\/$/, "");
    const canonicalUrl = `${canonicalBase}${page.url}#${anchor}`;
    const citation = sourceBoundCitation(page, passage, canonicalUrl);
    const cite = document.createElement("button");
    cite.type = "button"; cite.className = "text-button"; cite.textContent = "Copy citation";
    cite.addEventListener("click", async () => {
      try { await copyText(citation); cite.textContent = "Copied ✓"; } catch { cite.textContent = "Copy unavailable"; }
      setTimeout(() => { cite.textContent = "Copy citation"; }, 1400);
    });
    const quote = document.createElement("button");
    quote.type = "button"; quote.className = "text-button"; quote.textContent = "Copy quote + citation";
    quote.addEventListener("click", async () => {
      try { await copyText(quotedPassage(passage, citation)); quote.textContent = "Copied ✓"; } catch { quote.textContent = "Copy unavailable"; }
      setTimeout(() => { quote.textContent = "Copy quote + citation"; }, 1400);
    });
    actions.append(copy, cite, quote, makeFieldbookSaveButton(payload, anchor), makeDeskSaveButton(payload, anchor), makeCorrectionButton(payload, anchor)); contextContent.append(actions);
  }
  const citations = contextList("Citations in this passage", passage?.external_links || [], (item, row) => { item.append(contextLink(row.url, row.label || row.host || row.url, { external: true })); if (row.host) item.append(text("small", row.host)); });
  if (citations) contextContent.append(citations);
  const internal = contextList("Links from this passage", passage?.internal_links || [], (item, row) => { item.append(contextLink(`${row.url}${row.anchor ? `#${row.anchor}` : ""}`, row.label || row.title)); if (row.title && row.label !== row.title) item.append(text("small", row.title)); });
  if (internal) contextContent.append(internal);
  const incomingRows = (payload?.incoming || []).filter((row) => !row.target_anchor || !anchor || row.target_anchor === anchor);
  const incoming = contextList("Incoming context", incomingRows, (item, row) => { const source = row.from_passage; item.append(contextLink(source?.url || row.from_url, source?.title || row.from_title)); item.append(text("small", row.type === "links-to" ? "Authored link" : "Declared reading relationship")); if (source?.excerpt) item.append(text("p", source.excerpt)); });
  if (incoming) contextContent.append(incoming);
  const outgoingRows = (payload?.outgoing || []).filter((row) => !row.passage_id || !passage || row.passage_id === passage.id);
  const outgoing = contextList("Related destinations", outgoingRows, (item, row) => { item.append(contextLink(row.to_url, row.to_title)); item.append(text("small", row.type === "links-to" ? "Authored link" : "Declared reading relationship")); });
  if (outgoing) contextContent.append(outgoing);
  contextContent.append(text("p", "Fingerprints establish the identity of this source slice. They do not certify the truth of its claims.", "context-limit"));
}
function openContext(anchor = "", pageId = "") {
  const payload = contexts[pageId || pageIdForAnchor(anchor)];
  if (!payload || !contextDialog) return;
  if (!contextDialog.open) contextDialog.showModal();
  renderContext(payload, anchor || activePassageAnchor);
}


// Source-bound correction packets. Nothing leaves the local carrier unless the
// reader explicitly copies, downloads, or opens a GitHub draft.
function stableJson(value) {
  if (Array.isArray(value)) return `[${value.map(stableJson).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stableJson(value[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}
function sha256Fallback(value) {
  const input = new TextEncoder().encode(value);
  const length = Math.ceil((input.length + 9) / 64) * 64;
  const data = new Uint8Array(length);
  data.set(input);
  data[input.length] = 0x80;
  const view = new DataView(data.buffer);
  const bitLength = input.length * 8;
  view.setUint32(length - 8, Math.floor(bitLength / 0x100000000), false);
  view.setUint32(length - 4, bitLength >>> 0, false);
  const k = [
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2,
  ];
  const rotr = (x, n) => (x >>> n) | (x << (32 - n));
  const w = new Uint32Array(64);
  let h = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
  for (let offset = 0; offset < data.length; offset += 64) {
    for (let i = 0; i < 16; i += 1) w[i] = view.getUint32(offset + i * 4, false);
    for (let i = 16; i < 64; i += 1) {
      const s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >>> 3);
      const s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
    }
    let [a,b,c,d,e,f,g,hh] = h;
    for (let i = 0; i < 64; i += 1) {
      const s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
      const ch = (e & f) ^ (~e & g);
      const t1 = (hh + s1 + ch + k[i] + w[i]) >>> 0;
      const s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const t2 = (s0 + maj) >>> 0;
      hh = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
    }
    h = h.map((value, i) => (value + [a,b,c,d,e,f,g,hh][i]) >>> 0);
  }
  return h.map((value) => value.toString(16).padStart(8, "0")).join("");
}

async function sha256Text(value) {
  if (globalThis.crypto?.subtle) {
    try {
      const digest = await globalThis.crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
      return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
    } catch { /* local fallback below */ }
  }
  return sha256Fallback(value);
}
function setCorrectionStatus(message) { if (correctionStatus) correctionStatus.textContent = message; }
function correctionCanonicalUrl(page, passage = null) {
  const origin = String(CAPSULE.origin || root.dataset.origin || "https://sapient-lumen.github.io").replace(/\/$/, "");
  return `${origin}${page.url || "/"}${passage?.anchor ? `#${passage.anchor}` : ""}`;
}
function correctionPassage(payload, anchor = "") {
  if (!anchor) return null;
  return (payload?.passages || []).find((row) => row.anchor === anchor || row.id === anchor) || null;
}
function renderCorrectionSource(payload, passage) {
  if (!correctionSource) return;
  const page = payload?.page || {};
  correctionSource.replaceChildren();
  correctionSource.append(text("p", page.title || "Current page", "eyebrow"), text("strong", passage?.title || "Whole page"));
  correctionSource.append(text("code", `${passage?.id || page.id || "unknown"} · ${String(passage?.text_sha256 || page.body_sha256 || "unavailable").slice(0, 16)}… · ${CAPSULE.edition || "development"}`));
}
function openCorrectionFromPayload(payload, anchor = "") {
  if (!correctionDialog || !correctionForm || !payload) return;
  const passage = correctionPassage(payload, anchor);
  const key = passage?.id || payload?.page?.id || "unknown";
  if (correctionContext?.key !== key) {
    correctionForm.reset();
    if (correctionIncludeQuote) correctionIncludeQuote.checked = true;
  }
  correctionContext = { key, payload, passage };
  renderCorrectionSource(payload, passage);
  setCorrectionStatus("Nothing is sent automatically. Review the packet before copying, downloading, or opening GitHub.");
  if (contextDialog?.open) contextDialog.close();
  if (!correctionDialog.open) correctionDialog.showModal();
  correctionIssue?.focus();
}
function openCorrection(anchor = "", pageId = "") {
  const payload = contexts[pageId || pageIdForAnchor(anchor)];
  if (!payload) { setCorrectionStatus("Correction context is unavailable in this edition."); return; }
  openCorrectionFromPayload(payload, anchor || activePassageAnchor);
}
function makeCorrectionButton(payload, anchor = "") {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "text-button";
  button.dataset.openCorrection = "true";
  button.textContent = "Suggest a correction";
  button.addEventListener("click", () => openCorrectionFromPayload(payload, anchor));
  return button;
}
async function correctionPacket() {
  if (!correctionContext) throw new Error("Choose a page or passage first.");
  const issue = String(correctionIssue?.value || "").trim();
  if (!issue) { correctionIssue?.focus(); throw new Error("Describe the concrete problem before preparing a packet."); }
  const { payload, passage } = correctionContext;
  const page = payload.page || {};
  const packet = {
    schema: "lumen.correction-packet/v1",
    created_at: new Date().toISOString(),
    edition: CAPSULE.edition || root.dataset.edition || "development",
    source_fingerprint_sha256: CAPSULE.sourceFingerprint || root.dataset.sourceFingerprint || "",
    repository: CAPSULE.sourceRepository || root.dataset.correctionRepository || "Sapient-Lumen/sapient-lumen.github.io",
    location: {
      page_id: page.id || "", page_title: page.title || "", page_url: page.url || "/", page_kind: page.kind || "", page_date: page.date || null,
      page_body_sha256: page.body_sha256 || "", passage_id: passage?.id || null, passage_title: passage?.title || null, anchor: passage?.anchor || null,
      passage_text_sha256: passage?.text_sha256 || null, source_html_sha256: passage?.source_html_sha256 || null,
      source_offsets: passage?.source_offsets || null, exact_url: correctionCanonicalUrl(page, passage),
    },
    report: {
      type: String(correctionType?.value || "other"), issue,
      evidence_or_suggested_change: String(correctionEvidence?.value || "").trim(), boundary: String(correctionBoundary?.value || "").trim(),
    },
    carried_quote: correctionIncludeQuote?.checked ? (passage?.text || null) : null,
    privacy: { included: ["source identity", "accepted fingerprints", "reader-entered report"], excluded: ["browser history", "reading trail", "reading desk", "local notes", "credentials"], automatic_transmission: false },
    packet_content_sha256_scope: "UTF-8 stable JSON of every field except packet_content_sha256",
  };
  packet.packet_content_sha256 = await sha256Text(stableJson(packet));
  return packet;
}
function correctionMarkdown(packet, { issueBody = false } = {}) {
  const location = packet.location || {}; const report = packet.report || {};
  const offsets = location.source_offsets ? `${location.source_offsets.start}–${location.source_offsets.end}` : "whole page";
  const quote = packet.carried_quote ? String(packet.carried_quote) : "";
  const shownQuote = issueBody && quote.length > 900 ? `${quote.slice(0, 900).trim()}…` : quote;
  const rows = ["<!-- lumen.correction-packet/v1 -->", "## Source-bound location", `- Page: [${location.page_title || location.page_id}](${location.exact_url || location.page_url})`, `- Page identity: \`${location.page_id || "unknown"}\``, `- Passage identity: \`${location.passage_id || "whole page"}\``, `- Edition: \`${packet.edition || "unknown"}\``, `- Source fingerprint: \`${packet.source_fingerprint_sha256 || "unavailable"}\``, `- Text SHA-256: \`${location.passage_text_sha256 || location.page_body_sha256 || "unavailable"}\``, `- Exact HTML SHA-256: \`${location.source_html_sha256 || "not passage-bound"}\``, `- Source slice: \`${offsets}\``, `- Packet SHA-256: \`${packet.packet_content_sha256 || "unavailable"}\``, "", "## Report", `**Type:** ${report.type || "other"}`, "", report.issue || ""];
  if (report.evidence_or_suggested_change) rows.push("", "## Evidence or suggested change", report.evidence_or_suggested_change);
  if (report.boundary) rows.push("", "## Boundary", report.boundary);
  if (shownQuote) rows.push("", "<details><summary>Accepted passage carried by the packet</summary>", "", shownQuote.replace(/^/gm, "> "), "", "</details>");
  rows.push("", "_This report identifies accepted bytes and a reader concern. It does not automatically change the publication or establish that the concern is correct._");
  return rows.join("\n");
}
function correctionFilename(packet) {
  const page = String(packet.location?.page_id || "page").replace(/[^a-z0-9-]+/gi, "-").toLowerCase();
  const anchor = String(packet.location?.anchor || "whole-page").replace(/[^a-z0-9-]+/gi, "-").toLowerCase();
  return `lumen-correction-${page}-${anchor}-${new Date().toISOString().slice(0, 10)}.json`;
}
function githubCorrectionUrl(packet) {
  const repository = packet.repository || "Sapient-Lumen/sapient-lumen.github.io";
  const title = `Correction: ${packet.location?.passage_title || packet.location?.page_title || packet.location?.page_id || "Field Notes"}`;
  const body = correctionMarkdown(packet, { issueBody: true });
  return `https://github.com/${repository}/issues/new?${new URLSearchParams({ title: title.slice(0, 240), body: body.slice(0, 7600), labels: "correction" })}`;
}
correctionForm?.addEventListener("submit", (event) => event.preventDefault());
document.querySelector("[data-correction-copy]")?.addEventListener("click", async () => { try { const packet = await correctionPacket(); await copyText(correctionMarkdown(packet)); setCorrectionStatus("Source-bound review note copied. Nothing was submitted."); } catch (error) { setCorrectionStatus(error.message); } });
document.querySelector("[data-correction-download]")?.addEventListener("click", async () => { try { const packet = await correctionPacket(); downloadFieldbookFile(correctionFilename(packet), `${JSON.stringify(packet, null, 2)}\n`, "application/json"); setCorrectionStatus("Correction packet downloaded. It can be checked with ./lumen correction PACKET.json."); } catch (error) { setCorrectionStatus(error.message); } });
document.querySelector("[data-correction-github]")?.addEventListener("click", async () => { try { const packet = await correctionPacket(); const opened = window.open(githubCorrectionUrl(packet), "_blank", "noopener,noreferrer"); setCorrectionStatus(opened ? "GitHub opened with a reviewable draft. You still choose whether to submit it." : "The browser blocked the new tab. Copy the review note or download the packet instead."); } catch (error) { setCorrectionStatus(error.message); } });

// Capsule help
function openCapsuleDialog() {
  if (!capsuleDialog.open) capsuleDialog.showModal();
}

function openEditionCompare() {
  if (capsuleDialog?.open) capsuleDialog.close();
  if (!window.LumenEditionCompare) {
    if (editionCompareDialog && !editionCompareDialog.open) editionCompareDialog.showModal();
    const status = byId("edition-compare-status");
    if (status) status.textContent = "Edition comparison runtime is unavailable in this file.";
    return;
  }
  window.LumenEditionCompare.open({
    currentSummary: CAPSULE.editionSummary,
    currentLabel: `${CAPSULE.edition} · ${(CAPSULE.sourceFingerprint || "").slice(0, 12)}`,
  });
}

document.addEventListener("click", (event) => {
  const button = event.target.closest("[data-open-edition-compare]");
  if (!button) return;
  event.preventDefault();
  openEditionCompare();
});
document.querySelectorAll("[data-open-capsule]").forEach((button) => button.addEventListener("click", openCapsuleDialog));

// Preview
function positionPreview(owner) {
  const rect = owner.getBoundingClientRect();
  const width = Math.min(400, innerWidth - 32);
  const left = Math.min(innerWidth - width - 16, Math.max(16, rect.left));
  const height = preview.offsetHeight || 180;
  let top = rect.bottom + 12;
  if (top + height > innerHeight - 16) top = Math.max(16, rect.top - height - 12);
  preview.style.width = `${width}px`;
  preview.style.left = `${left}px`;
  preview.style.top = `${top}px`;
}
function showPreview(owner) {
  if (coarsePointer || !owner) return;
  previewOwner = owner;
  if (owner.dataset.referenceId) {
    const source = referenceById.get(owner.dataset.referenceId);
    if (!source) return;
    preview.dataset.previewKind = "reference";
    preview.replaceChildren(
      text("p", `Source record · ${source.host || "external source"}`, "eyebrow"),
      text("h3", source.display_label || source.host || source.url),
      text("p", `Linked from ${source.citation_count || 0} accepted passage${Number(source.citation_count) === 1 ? "" : "s"} across ${source.page_count || 0} page${Number(source.page_count) === 1 ? "" : "s"}.`),
      text("p", "This local record identifies where accepted text linked. It does not certify support, truth, or current remote content.", "preview-boundary"),
    );
    preview.hidden = false;
    positionPreview(owner);
    return;
  }
  if (!owner.dataset.previewId) return;
  const data = previews[owner.dataset.previewId];
  if (!data) return;
  preview.dataset.previewKind = "page";
  const passage = owner.dataset.previewAnchor ? (data.passages || []).find((row) => row.anchor === owner.dataset.previewAnchor) : null;
  preview.replaceChildren(
    text("p", `${data.label || data.kind}${data.date ? ` · ${data.date}` : ""}`, "eyebrow"),
    text("h2", passage ? `${data.title} › ${passage.title}` : data.title),
    text("p", passage?.excerpt || data.description),
  );
  preview.hidden = false;
  positionPreview(owner);
}
function hidePreview(owner) {
  clearTimeout(previewTimer);
  if (owner && previewOwner && owner !== previewOwner) return;
  previewOwner = null;
  preview.hidden = true;
}
function bindPreviews() {
  document.querySelectorAll("a[data-preview-id], a[data-reference-id]").forEach((link) => {
    link.addEventListener("mouseenter", () => { clearTimeout(previewTimer); previewTimer = setTimeout(() => showPreview(link), 160); });
    link.addEventListener("mouseleave", () => hidePreview(link));
    link.addEventListener("focus", () => { clearTimeout(previewTimer); previewTimer = setTimeout(() => showPreview(link), 160); });
    link.addEventListener("blur", () => hidePreview(link));
  });
}
addEventListener("scroll", () => hidePreview(), { passive: true });
addEventListener("resize", () => hidePreview(), { passive: true });

// Page enhancements
async function copyText(value) {
  if (navigator.clipboard?.writeText) return navigator.clipboard.writeText(value);
  const area = document.createElement("textarea");
  area.value = value;
  area.readOnly = true;
  area.className = "clipboard-fallback";
  document.body.append(area);
  area.select();
  const ok = document.execCommand("copy");
  area.remove();
  if (!ok) throw new Error("Clipboard unavailable");
}
function bindCopyCommands() {
  document.querySelectorAll("[data-copy-command]").forEach((button) => button.addEventListener("click", async () => {
    const original = button.textContent;
    try { await copyText(button.dataset.copyCommand || ""); button.textContent = "Copied ✓"; }
    catch { button.textContent = "Select the command above"; }
    setTimeout(() => { button.textContent = original; }, 1500);
  }));
  document.querySelectorAll("[data-copy-anchor]").forEach((button) => button.addEventListener("click", async () => {
    const id = button.dataset.copyAnchor;
    const url = `${location.href.split("#")[0]}${capsuleHref(currentRoute, id)}`;
    try { await copyText(url); button.textContent = "✓"; setTimeout(() => { button.textContent = "#"; }, 1000); }
    catch { navigate(currentRoute, id); }
  }));
}
function bindContext() {
  document.querySelectorAll("[data-context-anchor]").forEach((button) => button.addEventListener("click", () => openContext(button.dataset.contextAnchor || "", pageIdForAnchor(button.dataset.contextAnchor || "", button))));
  document.querySelectorAll("[data-context-current]").forEach((button) => button.addEventListener("click", () => openContext(activePassageAnchor)));
}
function bindToc() {
  tocObserver?.disconnect();
  const links = [...document.querySelectorAll(".toc a[href^='#']")];
  if (!activePassageAnchor && links.length) activePassageAnchor = links[0].getAttribute("href")?.slice(1) || "";
  if (!links.length || !("IntersectionObserver" in window)) return;
  const byHash = new Map(links.map((link) => [link.getAttribute("href").slice(1), link]));
  tocObserver = new IntersectionObserver((entries) => {
    const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
    if (!visible.length) return;
    links.forEach((link) => link.removeAttribute("aria-current"));
    activePassageAnchor = visible[0].target.id;
    byHash.get(activePassageAnchor)?.setAttribute("aria-current", "true");
    refreshFieldbookMarkers();
  }, { rootMargin: "-15% 0px -70% 0px", threshold: [0, 1] });
  byHash.forEach((_, id) => { const heading = byId(id); if (heading) tocObserver.observe(heading); });
}
function renderRelationshipGraph(output) {
  const nodes = [...(graph.nodes || [])].sort((a, b) => a.title.localeCompare(b.title));
  const edges = graph.edges || [];
  const nodeMap = new Map(nodes.map((node) => [node.id, node]));
  const figure = document.createElement("figure");
  figure.className = "relationship-figure";
  const caption = document.createElement("figcaption");
  caption.append(text("strong", `${nodes.length} pages · ${edges.length} typed connections`), text("span", "Solid lines are authored links. Dashed lines are declared reading relationships."));
  figure.append(caption);
  const ns = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(ns, "svg");
  svg.setAttribute("viewBox", "0 0 920 560");
  svg.setAttribute("role", "img");
  svg.setAttribute("aria-label", "Relationship map of the embedded Lumen pages");
  svg.classList.add("relationship-svg");
  const titleNode = document.createElementNS(ns, "title");
  titleNode.textContent = "Lumen source constellation"; svg.append(titleNode);
  const positions = new Map();
  const home = nodes.find((node) => node.id === "home");
  const ring = nodes.filter((node) => node !== home);
  if (home) positions.set(home.id, { x: 460, y: 280 });
  ring.forEach((node, index) => {
    const angle = -Math.PI / 2 + (Math.PI * 2 * index) / Math.max(1, ring.length);
    const radius = index % 2 ? 225 : 195;
    positions.set(node.id, { x: 460 + Math.cos(angle) * radius, y: 280 + Math.sin(angle) * radius });
  });
  const edgeLayer = document.createElementNS(ns, "g");
  for (const edge of edges) {
    const start = positions.get(edge.from), end = positions.get(edge.to);
    if (!start || !end) continue;
    const line = document.createElementNS(ns, "line");
    line.setAttribute("x1", String(start.x)); line.setAttribute("y1", String(start.y)); line.setAttribute("x2", String(end.x)); line.setAttribute("y2", String(end.y));
    line.setAttribute("class", `graph-edge graph-edge--${edge.type}`);
    const title = document.createElementNS(ns, "title");
    title.textContent = `${nodeMap.get(edge.from)?.title || edge.from} → ${nodeMap.get(edge.to)?.title || edge.to}: ${graph.legend?.[edge.type] || edge.type}`;
    line.append(title); edgeLayer.append(line);
  }
  svg.append(edgeLayer);
  const nodeLayer = document.createElementNS(ns, "g");
  for (const node of nodes) {
    const point = positions.get(node.id); if (!point) continue;
    const link = document.createElementNS(ns, "a");
    link.setAttribute("href", capsuleHref(node.url)); link.setAttribute("class", `graph-node graph-node--${node.kind || "page"}`);
    const circle = document.createElementNS(ns, "circle");
    circle.setAttribute("cx", String(point.x)); circle.setAttribute("cy", String(point.y)); circle.setAttribute("r", node.id === "home" ? "24" : "17");
    const title = document.createElementNS(ns, "title"); title.textContent = `${node.title} · ${node.kind || "page"}`; circle.append(title); link.append(circle);
    const label = document.createElementNS(ns, "text");
    const right = point.x >= 460;
    label.setAttribute("x", String(point.x + (node.id === "home" ? 0 : right ? 24 : -24))); label.setAttribute("y", String(point.y + (node.id === "home" ? 39 : 4)));
    label.setAttribute("text-anchor", node.id === "home" ? "middle" : right ? "start" : "end");
    label.textContent = node.title.length > 24 ? `${node.title.slice(0, 23)}…` : node.title; link.append(label); nodeLayer.append(link);
  }
  svg.append(nodeLayer); figure.append(svg);
  const details = document.createElement("details"); details.className = "relationship-edges"; details.append(text("summary", "Read the complete connection list"));
  const list = document.createElement("ol");
  for (const edge of edges) {
    const from = nodeMap.get(edge.from), to = nodeMap.get(edge.to); if (!from || !to) continue;
    const item = document.createElement("li"); item.append(contextLink(from.url, from.title), document.createTextNode(" → "), contextLink(to.url, to.title), text("small", `${graph.legend?.[edge.type] || edge.type}${edge.count > 1 ? ` · ${edge.count} links` : ""}`)); list.append(item);
  }
  details.append(list); figure.append(details); output.replaceChildren(figure);
}
function bindGraph() {
  const button = document.querySelector("[data-load-graph]");
  const output = byId("relationship-graph");
  if (!button || !output) return;
  button.addEventListener("click", () => {
    button.disabled = true; renderRelationshipGraph(output); button.textContent = "Relationship graph loaded";
  }, { once: true });
}
function bindOfflineControls() {
  const controls = document.querySelector("[data-offline-controls]");
  if (!controls) return;
  controls.dataset.state = "capsule";
  controls.querySelectorAll("button").forEach((button) => { button.disabled = true; });
  const status = byId("offline-status");
  if (status) status.textContent = "This portable file is already complete and offline. Extract it to enter the cloudtainer workshop.";
}
function bindMotion() {
  if (reducedMotion || coarsePointer) return;
  document.querySelectorAll(".work-card").forEach((card) => card.addEventListener("pointermove", (event) => {
    const rect = card.getBoundingClientRect();
    card.style.setProperty("--pointer-x", `${event.clientX - rect.left}px`);
    card.style.setProperty("--pointer-y", `${event.clientY - rect.top}px`);
  }));
}

async function fieldbookContextProvider(pageId = "") {
  return contexts[pageId || document.body.dataset.pageId] || null;
}
function fieldbookRouteHref(pageUrl, anchor = "") {
  return capsuleHref(pageUrl, anchor);
}

// Local fieldbook: a private, source-bound reading trail. Nothing is sent to a
// server. Entries carry enough identity to survive route redesigns and to show
// when an imported passage came from another accepted edition.
const fieldbookDialog = byId("fieldbook-dialog");
const fieldbookList = byId("fieldbook-list");
const fieldbookEmpty = byId("fieldbook-empty");
const fieldbookStatus = byId("fieldbook-status");
const fieldbookImport = byId("fieldbook-import");
const FIELDBOOK_KEY = "lumen-fieldbook/v1";
const fieldbookFingerprint = root.dataset.sourceFingerprint
  || document.querySelector('meta[name="lumen-source-fingerprint"]')?.content
  || "unidentified-edition";
const fieldbookEdition = root.dataset.edition || "development";
const allowedReadingSizes = new Set(["compact", "standard", "large"]);
const allowedReadingMeasures = new Set(["narrow", "standard", "wide"]);
let fieldbookStorageAvailable = true;
let fieldbookNoteTimer = 0;

function emptyFieldbook() {
  return {
    schema: "lumen.fieldbook/v1",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    source_fingerprint_sha256: fieldbookFingerprint,
    entries: [],
    preferences: { size: "standard", measure: "standard" },
  };
}

function safeField(value, limit = 4000) {
  return String(value ?? "").slice(0, limit);
}

function normalizeQuoteSelector(value) {
  if (!value || typeof value !== "object") return null;
  const quote = normalizedQuoteText(value.q || value.quote || "").slice(0, 700);
  if (!quote) return null;
  const index = Number(value.i ?? value.index);
  return {
    v: 1,
    p: safeField(value.p || value.page_id, 180),
    a: safeField(value.a || value.anchor, 300),
    q: quote,
    i: Number.isInteger(index) && index >= 0 ? index : 0,
    b: safeField(value.b || value.before, 96),
    n: safeField(value.n || value.after, 96),
    h: safeField(value.h || value.passage_text_sha256, 128),
    e: safeField(value.e || value.edition, 100),
  };
}

function normalizeFieldbookEntry(value) {
  if (!value || typeof value !== "object") return null;
  const stableId = safeField(value.stable_id || value.id, 300);
  if (!stableId) return null;
  const sourceOffsets = value.source_offsets && typeof value.source_offsets === "object"
    ? { start: Number(value.source_offsets.start || 0), end: Number(value.source_offsets.end || 0) }
    : null;
  const requestedScope = safeField(value.scope, 24);
  const scope = ["page", "passage", "quote"].includes(requestedScope) ? requestedScope : "passage";
  const quoteSelector = normalizeQuoteSelector(value.quote_selector || value.quote);
  if (scope === "quote" && !quoteSelector) return null;
  return {
    stable_id: stableId,
    scope,
    page_id: safeField(value.page_id, 180),
    page_title: safeField(value.page_title, 500),
    page_url: safeField(value.page_url || value.url || "/", 1200),
    anchor: safeField(value.anchor, 300),
    title: safeField(value.title || value.page_title || stableId, 500),
    excerpt: safeField(value.excerpt || value.text, 6000),
    word_count: Number(value.word_count || 0),
    text_sha256: safeField(value.text_sha256 || value.body_sha256, 128),
    source_html_sha256: safeField(value.source_html_sha256, 128),
    source_offsets: sourceOffsets,
    source_fingerprint_sha256: safeField(value.source_fingerprint_sha256, 128),
    edition: safeField(value.edition, 100),
    quote_selector: quoteSelector,
    quote_sha256: safeField(value.quote_sha256, 128),
    saved_at: safeField(value.saved_at, 100) || new Date().toISOString(),
    note: safeField(value.note, 4000),
  };
}

function validateFieldbookImport(value) {
  if (!value || value.schema !== "lumen.fieldbook/v1" || !Array.isArray(value.entries)) {
    throw new Error("Expected a lumen.fieldbook/v1 export with an entries array.");
  }
  if (value.entries.length > 250) throw new Error("This export exceeds the 250-item fieldbook limit; no items were imported.");
  const ids = new Set();
  for (const entry of value.entries) {
    const id = entry?.stable_id || entry?.id;
    if (typeof id !== "string" || !id || ids.has(id)) throw new Error("Entries must have distinct, nonempty stable identities.");
    ids.add(id);
    if (String(entry.note ?? "").length > 4000) {
      throw new Error("A note exceeds the 4000-character limit; no items were imported.");
    }
    const selector = entry.quote_selector || entry.quote;
    if (selector && typeof selector === "object"
        && normalizedQuoteText(selector.q || selector.quote || "").length > 700) {
      throw new Error("A quote exceeds the 700-character limit after whitespace normalization; no items were imported.");
    }
  }
  return value;
}

function mergeFieldbookEntries(current, incoming, limit = 250) {
  const merged = new Map(current.map((entry) => [entry.stable_id, entry]));
  let added = 0, conflicts = 0, unchanged = 0, full = 0;
  for (const entry of incoming) {
    const existing = merged.get(entry.stable_id);
    if (existing) {
      if (JSON.stringify(existing) === JSON.stringify(entry)) unchanged += 1;
      else conflicts += 1;
    } else if (merged.size >= limit) full += 1;
    else { merged.set(entry.stable_id, entry); added += 1; }
  }
  return { entries: [...merged.values()], added, conflicts, unchanged, full };
}

function normalizeFieldbook(value) {
  const state = emptyFieldbook();
  if (!value || typeof value !== "object") return state;
  const entries = Array.isArray(value.entries)
    ? value.entries.slice(0, 250).map(normalizeFieldbookEntry).filter(Boolean)
    : [];
  const deduped = new Map();
  for (const entry of entries) deduped.set(entry.stable_id, entry);
  const preferences = value.preferences && typeof value.preferences === "object" ? value.preferences : {};
  state.created_at = safeField(value.created_at, 100) || state.created_at;
  state.updated_at = safeField(value.updated_at, 100) || state.updated_at;
  state.source_fingerprint_sha256 = safeField(value.source_fingerprint_sha256, 128) || fieldbookFingerprint;
  state.entries = [...deduped.values()];
  state.preferences = {
    size: allowedReadingSizes.has(preferences.size) ? preferences.size : "standard",
    measure: allowedReadingMeasures.has(preferences.measure) ? preferences.measure : "standard",
  };
  return state;
}

function loadFieldbook() {
  try {
    const raw = localStorage.getItem(FIELDBOOK_KEY);
    return raw ? normalizeFieldbook(JSON.parse(raw)) : emptyFieldbook();
  } catch {
    fieldbookStorageAvailable = false;
    return emptyFieldbook();
  }
}

let fieldbookState = loadFieldbook();

function persistFieldbook(message = "") {
  fieldbookState.updated_at = new Date().toISOString();
  fieldbookState.source_fingerprint_sha256 = fieldbookFingerprint;
  try {
    localStorage.setItem(FIELDBOOK_KEY, JSON.stringify(fieldbookState));
    fieldbookStorageAvailable = true;
  } catch {
    fieldbookStorageAvailable = false;
  }
  if (message && fieldbookStatus) {
    fieldbookStatus.textContent = fieldbookStorageAvailable
      ? message
      : `${message} Browser storage is unavailable, so this trail lasts only for the current page session.`;
  }
  refreshFieldbookMarkers();
}

function fieldbookEntryKey(pageId, anchor = "") {
  return anchor ? `${pageId}::${anchor}` : pageId;
}

function findFieldbookEntry(key) {
  return fieldbookState.entries.find((entry) => entry.stable_id === key) || null;
}

function entryFromContext(payload, requestedAnchor = "") {
  const page = payload?.page || {};
  const passages = payload?.passages || [];
  const passage = requestedAnchor
    ? passages.find((row) => row.anchor === requestedAnchor || row.id === requestedAnchor)
    : null;
  if (passage) {
    return normalizeFieldbookEntry({
      stable_id: passage.id,
      scope: "passage",
      page_id: page.id,
      page_title: page.title,
      page_url: page.url,
      anchor: passage.anchor,
      title: passage.title,
      excerpt: passage.excerpt || passage.text,
      word_count: passage.word_count,
      text_sha256: passage.text_sha256,
      source_html_sha256: passage.source_html_sha256,
      source_offsets: passage.source_offsets,
      source_fingerprint_sha256: payload.source_fingerprint_sha256 || fieldbookFingerprint,
      edition: fieldbookEdition,
      saved_at: new Date().toISOString(),
    });
  }
  return normalizeFieldbookEntry({
    stable_id: page.id,
    scope: "page",
    page_id: page.id,
    page_title: page.title,
    page_url: page.url,
    title: page.title,
    excerpt: page.description || `${page.word_count || 0} words in this page.`,
    word_count: page.word_count,
    text_sha256: page.body_sha256,
    source_fingerprint_sha256: payload.source_fingerprint_sha256 || fieldbookFingerprint,
    edition: fieldbookEdition,
    saved_at: new Date().toISOString(),
  });
}

async function toggleFieldbookPassage(anchor = "", { forceSave = false, pageId = "" } = {}) {
  const payload = await fieldbookContextProvider(pageId || pageIdForAnchor(anchor));
  if (!payload) throw new Error("No passage context exists for this route.");
  const entry = entryFromContext(payload, anchor);
  if (!entry) throw new Error("The requested passage has no stable identity.");
  const index = fieldbookState.entries.findIndex((row) => row.stable_id === entry.stable_id);
  if (index >= 0 && !forceSave) {
    fieldbookState.entries.splice(index, 1);
    persistFieldbook(`Removed “${entry.title}” from the reading trail.`);
  } else if (index >= 0) {
    const note = fieldbookState.entries[index].note;
    fieldbookState.entries[index] = { ...entry, note };
    persistFieldbook(`Refreshed “${entry.title}” from this edition.`);
  } else {
    if (fieldbookState.entries.length >= 250) throw new Error("The reading trail is full (250 items). Export a backup and remove an item before saving another.");
    fieldbookState.entries.push(entry);
    persistFieldbook(`Saved “${entry.title}” to the reading trail.`);
  }
  renderFieldbook();
  return entry;
}


async function fieldbookQuoteEntryFromSelection(snapshot = pendingSelection) {
  const result = await quotePayloadFromSelection(snapshot);
  const quoteSha256 = await sha256Text(result.value.q);
  const stableId = `${result.passage.id}::q:${quoteSha256.slice(0, 24)}:${result.value.i}`;
  return normalizeFieldbookEntry({
    stable_id: stableId,
    scope: "quote",
    page_id: result.page.id,
    page_title: result.page.title,
    page_url: result.page.url,
    anchor: result.passage.anchor,
    title: result.passage.title,
    excerpt: result.value.q,
    word_count: result.value.q.split(/\s+/).filter(Boolean).length,
    text_sha256: result.passage.text_sha256,
    source_html_sha256: result.passage.source_html_sha256,
    source_offsets: result.passage.source_offsets,
    source_fingerprint_sha256: fieldbookFingerprint,
    edition: fieldbookEdition,
    quote_selector: result.value,
    quote_sha256: quoteSha256,
    saved_at: new Date().toISOString(),
  });
}

async function saveFieldbookQuoteFromSelection(snapshot = pendingSelection) {
  const entry = await fieldbookQuoteEntryFromSelection(snapshot);
  if (!entry) throw new Error("The selected quote could not be bound to this edition.");
  const index = fieldbookState.entries.findIndex((row) => row.stable_id === entry.stable_id);
  if (index >= 0) {
    const note = fieldbookState.entries[index].note;
    fieldbookState.entries[index] = { ...entry, note };
    persistFieldbook(`Exact quote already kept; its source receipt was refreshed from this edition.`);
  } else {
    if (fieldbookState.entries.length >= 250) throw new Error("The reading trail is full (250 items). Export a backup and remove an item before saving another.");
    fieldbookState.entries.push(entry);
    persistFieldbook(`Kept an exact quote from “${entry.title}” in the private reading trail.`);
  }
  renderFieldbook();
  return entry;
}

function fieldbookEntryHref(entry) {
  if (entry.scope === "quote" && entry.quote_selector) {
    const encoded = encodeQuotePayload(entry.quote_selector);
    return `${location.href.split("#")[0]}${capsuleHref(entry.page_url || "/", entry.anchor || entry.quote_selector.a || "", encoded)}`;
  }
  return fieldbookRouteHref(entry.page_url || "/", entry.anchor || "");
}

function fieldbookCitation(entry) {
  const locator = entry.scope === "quote" && entry.quote_selector
    ? exactQuoteCanonicalUrl({ url: entry.page_url }, encodeQuotePayload(entry.quote_selector), entry.anchor || entry.quote_selector.a || "")
    : (entry.anchor ? `${CAPSULE.origin}${entry.page_url}#${entry.anchor}` : `${CAPSULE.origin}${entry.page_url}`);
  const hash = entry.text_sha256 ? entry.text_sha256.slice(0, 16) : "unhashed";
  if (entry.scope === "quote" && entry.quote_selector) {
    const quoteHash = entry.quote_sha256 ? entry.quote_sha256.slice(0, 16) : "unhashed";
    return `${entry.quote_selector.q}

— Lumen, “${entry.title},” ${entry.page_title || "Field Notes"}, ${locator}, quote ${quoteHash}, passage ${hash}, edition ${entry.edition || "unknown"}.`;
  }
  return `Lumen, “${entry.title},” ${entry.page_title || "Field Notes"}, ${locator}, text ${hash}, edition ${entry.edition || "unknown"}.`;
}

function setFieldbookStatus(message) {
  if (fieldbookStatus) fieldbookStatus.textContent = message;
}

function updateReadingPreferences() {
  const size = allowedReadingSizes.has(fieldbookState.preferences.size) ? fieldbookState.preferences.size : "standard";
  const measure = allowedReadingMeasures.has(fieldbookState.preferences.measure) ? fieldbookState.preferences.measure : "standard";
  root.dataset.readingSize = size;
  root.dataset.readingMeasure = measure;
  document.querySelectorAll("[data-reading-size]").forEach((button) => {
    const active = button.dataset.readingSize === size;
    button.setAttribute("aria-pressed", String(active));
  });
  document.querySelectorAll("[data-reading-measure]").forEach((button) => {
    const active = button.dataset.readingMeasure === measure;
    button.setAttribute("aria-pressed", String(active));
  });
}

function refreshFieldbookMarkers() {
  const count = fieldbookState.entries.length;
  document.querySelectorAll("[data-fieldbook-count]").forEach((node) => {
    node.textContent = String(count);
    node.hidden = count === 0;
  });
  const pageId = document.body.dataset.pageId || "";
  document.querySelectorAll("[data-fieldbook-anchor]").forEach((button) => {
    const key = fieldbookEntryKey(pageId, button.dataset.fieldbookAnchor || "");
    const saved = Boolean(findFieldbookEntry(key));
    button.setAttribute("aria-pressed", String(saved));
    button.textContent = saved ? "★" : "☆";
    button.title = saved ? "Remove from reading trail" : "Save to reading trail";
  });
  document.querySelectorAll("[data-fieldbook-current]").forEach((button) => {
    const key = fieldbookEntryKey(pageId, activePassageAnchor || "");
    const saved = Boolean(findFieldbookEntry(key));
    button.setAttribute("aria-pressed", String(saved));
    button.classList.toggle("is-saved", saved);
    const label = button.querySelector("span");
    if (label) label.textContent = saved ? "Remove current passage" : "Save current passage";
  });
  updateReadingPreferences();
}

function fieldbookReceipt(entry) {
  const details = document.createElement("details");
  details.className = "fieldbook-receipt";
  details.append(text("summary", "Source receipt"));
  const dl = document.createElement("dl");
  inspectRow(dl, "Stable identity", entry.stable_id);
  inspectRow(dl, "Edition", entry.edition || "Unknown");
  inspectRow(dl, "Text fingerprint", shortHash(entry.text_sha256));
  inspectRow(dl, "Exact HTML fingerprint", shortHash(entry.source_html_sha256));
  if (entry.scope === "quote" && entry.quote_selector) {
    inspectRow(dl, "Exact quote", shortHash(entry.quote_sha256));
    inspectRow(dl, "Quote offset", String(entry.quote_selector.i));
  }
  if (entry.source_offsets) inspectRow(dl, "Source slice", `${entry.source_offsets.start}–${entry.source_offsets.end}`);
  if (entry.source_fingerprint_sha256 && entry.source_fingerprint_sha256 !== fieldbookFingerprint) {
    inspectRow(dl, "Edition mismatch", `Imported from ${shortHash(entry.source_fingerprint_sha256)}`);
  }
  details.append(dl);
  return details;
}

function renderFieldbook() {
  if (!fieldbookList || !fieldbookEmpty) return;
  fieldbookList.replaceChildren();
  fieldbookEmpty.hidden = fieldbookState.entries.length > 0;
  fieldbookState.entries.forEach((entry, index) => {
    const item = document.createElement("li");
    item.className = `fieldbook-entry${entry.scope === "quote" ? " fieldbook-entry--quote" : ""}`;
    item.dataset.fieldbookId = entry.stable_id;
    const head = document.createElement("header");
    const labels = document.createElement("div");
    labels.append(text("p", `${entry.page_title || "Lumen"}${entry.scope === "quote" ? " · exact quote" : ""}`, "eyebrow"));
    labels.append(text("h3", entry.title));
    head.append(labels);
    if (entry.source_fingerprint_sha256 && entry.source_fingerprint_sha256 !== fieldbookFingerprint) {
      head.append(text("span", "other edition", "fieldbook-edition-badge"));
    }
    item.append(head);
    if (entry.excerpt) {
      const excerpt = text(entry.scope === "quote" ? "blockquote" : "p", entry.excerpt, "fieldbook-excerpt");
      item.append(excerpt);
    }
    const note = document.createElement("label");
    note.className = "fieldbook-note";
    note.append(text("span", "Private note"));
    const area = document.createElement("textarea");
    area.rows = 3;
    area.maxLength = 4000;
    area.placeholder = "What changed, what remains open, or why this passage matters…";
    area.value = entry.note || "";
    area.addEventListener("input", () => {
      entry.note = area.value.slice(0, 4000);
      clearTimeout(fieldbookNoteTimer);
      fieldbookNoteTimer = window.setTimeout(() => persistFieldbook("Reading-trail note saved locally."), 240);
    });
    note.append(area);
    item.append(note);
    const actions = document.createElement("div");
    actions.className = "fieldbook-entry-actions";
    const open = document.createElement("a");
    open.className = "text-button";
    open.href = fieldbookEntryHref(entry);
    open.textContent = entry.scope === "quote" ? "Open exact quote" : "Open passage";
    const copy = document.createElement("button");
    copy.type = "button";
    copy.className = "text-button";
    copy.textContent = entry.scope === "quote" ? "Copy quote + citation" : "Copy citation";
    copy.addEventListener("click", async () => {
      try { await copyText(fieldbookCitation(entry)); copy.textContent = "Copied ✓"; }
      catch { copy.textContent = "Copy unavailable"; }
      setTimeout(() => { copy.textContent = entry.scope === "quote" ? "Copy quote + citation" : "Copy citation"; }, 1300);
    });
    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "text-button fieldbook-remove";
    remove.textContent = "Remove";
    remove.addEventListener("click", () => {
      fieldbookState.entries.splice(index, 1);
      persistFieldbook(`Removed “${entry.title}” from the reading trail.`);
      renderFieldbook();
    });
    actions.append(open, copy, remove);
    item.append(actions, fieldbookReceipt(entry));
    fieldbookList.append(item);
  });
  const persistence = fieldbookStorageAvailable ? "saved in this browser" : "held for this page session";
  setFieldbookStatus(`${fieldbookState.entries.length} saved item${fieldbookState.entries.length === 1 ? "" : "s"} · ${persistence} · source ${fieldbookFingerprint.slice(0, 12)}`);
  refreshFieldbookMarkers();
}

function openFieldbook() {
  renderFieldbook();
  if (fieldbookDialog && !fieldbookDialog.open) fieldbookDialog.showModal();
}

function makeFieldbookSaveButton(payload, anchor = "") {
  const entry = entryFromContext(payload, anchor);
  const button = document.createElement("button");
  button.type = "button";
  button.className = "text-button context-save";
  const setLabel = () => {
    const saved = entry && Boolean(findFieldbookEntry(entry.stable_id));
    button.textContent = saved ? "Remove from reading trail" : "Save to reading trail";
    button.setAttribute("aria-pressed", String(saved));
  };
  setLabel();
  button.addEventListener("click", async () => {
    try { await toggleFieldbookPassage(anchor, { pageId: payload?.page?.id || "" }); setLabel(); }
    catch (error) { setFieldbookStatus(`Could not update reading trail: ${error.message}`); button.textContent = error.message; }
  });
  return button;
}

function downloadFieldbookFile(filename, body, type) {
  const blob = new Blob([body], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function fieldbookExportPayload() {
  return {
    ...fieldbookState,
    schema: "lumen.fieldbook/v1",
    exported_at: new Date().toISOString(),
    exported_from: {
      edition: fieldbookEdition,
      source_fingerprint_sha256: fieldbookFingerprint,
      location: location.protocol === "file:" ? "local Lumen.html" : location.origin,
    },
  };
}

function escapeFieldbookHtml(value) {
  return String(value ?? "").replace(/[&<>\"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[char]));
}

function fieldbookPacketHtml() {
  const cards = fieldbookState.entries.map((entry, index) => {
    const note = entry.note ? `<section class="note"><h3>Reader note</h3><p>${escapeFieldbookHtml(entry.note).replace(/\n/g, "<br>")}</p></section>` : "";
    const locator = fieldbookEntryHref(entry);
    const quoteReceipt = entry.scope === "quote" && entry.quote_selector
      ? `<dt>Exact quote</dt><dd><code>${escapeFieldbookHtml(entry.quote_sha256 || "not recorded")}</code></dd><dt>Quote offset</dt><dd>${escapeFieldbookHtml(entry.quote_selector.i)}</dd>`
      : "";
    return `<article id="entry-${index + 1}"><p class="kicker">${escapeFieldbookHtml(entry.page_title)}${entry.scope === "quote" ? " · EXACT QUOTE" : ""}</p><h2>${escapeFieldbookHtml(entry.title)}</h2><blockquote>${escapeFieldbookHtml(entry.excerpt)}</blockquote>${note}<dl><dt>Stable identity</dt><dd><code>${escapeFieldbookHtml(entry.stable_id)}</code></dd>${quoteReceipt}<dt>Text fingerprint</dt><dd><code>${escapeFieldbookHtml(entry.text_sha256 || "not recorded")}</code></dd><dt>Source edition</dt><dd><code>${escapeFieldbookHtml(entry.source_fingerprint_sha256 || "not recorded")}</code></dd><dt>Locator</dt><dd>${escapeFieldbookHtml(locator)}</dd></dl></article>`;
  }).join("\n");
  const generated = new Date().toISOString();
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Lumen reading trail · reading packet</title><style>:root{color-scheme:light dark;--paper:#f3efe4;--ink:#14231c;--line:#b9b2a5;--accent:#b8472a}@media(prefers-color-scheme:dark){:root{--paper:#111713;--ink:#edf0e5;--line:#455148;--accent:#ff8059}}*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:18px/1.65 Georgia,serif}main{max-width:820px;margin:auto;padding:8vw 6vw}header{padding-bottom:2rem;border-bottom:2px solid var(--ink)}h1{font-size:clamp(2.6rem,8vw,5.6rem);line-height:.95;font-weight:400;margin:.5rem 0 1rem}header p,.kicker,dt{font:12px/1.5 ui-monospace,monospace;letter-spacing:.08em;text-transform:uppercase}article{padding:3rem 0;border-bottom:1px solid var(--line)}h2{font-size:2rem;line-height:1.15;font-weight:400}blockquote{margin:1.4rem 0;padding-left:1.2rem;border-left:3px solid var(--accent);font-size:1.12em}dl{display:grid;grid-template-columns:10rem 1fr;gap:.35rem 1rem;font-size:.78rem}dd{margin:0;overflow-wrap:anywhere}.note{padding:1rem 1.2rem;border:1px solid var(--line)}.note h3{font:12px ui-monospace,monospace;text-transform:uppercase}code{font-family:ui-monospace,monospace}@media(max-width:620px){dl{grid-template-columns:1fr}main{padding:3rem 1.25rem}}</style></head><body><main><header><p>Private reading trail · ${escapeFieldbookHtml(fieldbookEdition)}</p><h1>Lumen reading trail</h1><p>${fieldbookState.entries.length} source-bound item${fieldbookState.entries.length === 1 ? "" : "s"} · exported ${escapeFieldbookHtml(generated)} · source ${escapeFieldbookHtml(fieldbookFingerprint)}</p></header>${cards || "<p>No saved passages.</p>"}</main></body></html>`;
}

function filenameDate() {
  return new Date().toISOString().slice(0, 10);
}

document.addEventListener("click", (event) => {
  const open = event.target.closest("[data-open-fieldbook]");
  if (open) { event.preventDefault(); openFieldbook(); return; }
  const passage = event.target.closest("[data-fieldbook-anchor]");
  if (passage) {
    event.preventDefault();
    toggleFieldbookPassage(passage.dataset.fieldbookAnchor || "", { pageId: pageIdForAnchor(passage.dataset.fieldbookAnchor || "", passage) }).catch((error) => setFieldbookStatus(`Could not update reading trail: ${error.message}`));
    return;
  }
  const current = event.target.closest("[data-fieldbook-current]");
  if (current) {
    event.preventDefault();
    toggleFieldbookPassage(activePassageAnchor || "", { pageId: pageIdForAnchor(activePassageAnchor || "", current) }).catch((error) => setFieldbookStatus(`Could not update reading trail: ${error.message}`));
  }
});

document.querySelectorAll("[data-reading-size]").forEach((button) => button.addEventListener("click", () => {
  fieldbookState.preferences.size = button.dataset.readingSize;
  persistFieldbook(`Reading size set to ${button.dataset.readingSize}.`);
}));
document.querySelectorAll("[data-reading-measure]").forEach((button) => button.addEventListener("click", () => {
  fieldbookState.preferences.measure = button.dataset.readingMeasure;
  persistFieldbook(`Line measure set to ${button.dataset.readingMeasure}.`);
}));
document.querySelector("[data-fieldbook-export-json]")?.addEventListener("click", () => {
  downloadFieldbookFile(`lumen-fieldbook-${filenameDate()}.json`, JSON.stringify(fieldbookExportPayload(), null, 2) + "\n", "application/json");
  setFieldbookStatus("Reading-trail JSON exported.");
});
document.querySelector("[data-fieldbook-export-html]")?.addEventListener("click", () => {
  downloadFieldbookFile(`lumen-reading-packet-${filenameDate()}.html`, fieldbookPacketHtml(), "text/html");
  setFieldbookStatus("Standalone reading packet exported.");
});
document.querySelector("[data-fieldbook-clear]")?.addEventListener("click", () => {
  if (!fieldbookState.entries.length || window.confirm("Remove every saved reading-trail item from this browser?")) {
    fieldbookState.entries = [];
    persistFieldbook("Reading trail cleared.");
    renderFieldbook();
  }
});
fieldbookImport?.addEventListener("change", async () => {
  const file = fieldbookImport.files?.[0];
  if (!file) return;
  try {
    if (file.size > 32 * 1024 * 1024) throw new Error("The fieldbook import limit is 32 MiB; no items were imported.");
    const parsed = validateFieldbookImport(JSON.parse(await file.text()));
    const imported = normalizeFieldbook(parsed);
    if (imported.entries.length !== parsed.entries.length) throw new Error("Some entries have invalid or colliding identities; no items were imported.");
    const merged = mergeFieldbookEntries(fieldbookState.entries, imported.entries);
    fieldbookState.entries = merged.entries;
    persistFieldbook(`Added ${merged.added}; unchanged ${merged.unchanged}; kept ${merged.conflicts} conflicting local item(s); ${merged.full} could not fit. Existing notes were not overwritten.`);
    renderFieldbook();
  } catch (error) {
    setFieldbookStatus(`Import refused: ${error.message}`);
  } finally {
    fieldbookImport.value = "";
  }
});

updateReadingPreferences();
refreshFieldbookMarkers();

// Return point: one explicit, private place to resume. It is deliberately
// separate from the longer-lived fieldbook and the multi-item reading desk.
// The marker carries stable page/passage identity, exact accepted text hashes,
// and an optional exact block hash. A later edition may confirm the same bytes
// or report that the place changed; it never guesses a new attachment.
const returnStrip = byId("return-strip");
const returnStripTitle = byId("return-strip-title");
const returnStripMeta = byId("return-strip-meta");
const returnDialog = byId("return-dialog");
const returnStatus = byId("return-status");
const returnReceipt = byId("return-receipt");
const returnGoButton = document.querySelector("[data-return-go]");
const returnExportButton = document.querySelector("[data-return-export]");
const returnClearButton = document.querySelector("[data-return-clear]");
const returnImport = byId("return-import");
const RETURN_MARKER_KEY = "lumen-return-marker/v1";
const RETURN_PENDING_KEY = "lumen-return-pending/v1";
let returnStorageAvailable = true;
let returnMarker = null;
let returnReview = null;
let returnReviewGeneration = 0;

function normalizeReturnMarker(value) {
  if (!value || typeof value !== "object") return null;
  const pageId = safeField(value.page_id, 180);
  const textSha = safeField(value.text_sha256 || value.passage_text_sha256 || value.page_body_sha256, 128);
  if (!pageId || !/^[0-9a-f]{64}$/.test(textSha)) return null;
  const blockIndex = Number(value.block_index);
  const scrollPercent = Number(value.scroll_percent);
  return {
    schema: "lumen.return-marker/v1",
    page_id: pageId,
    page_title: safeField(value.page_title, 500),
    page_url: safeField(value.page_url || value.url || "/", 1200),
    scope: value.scope === "passage" ? "passage" : "page",
    anchor: safeField(value.anchor, 300),
    passage_id: safeField(value.passage_id, 300),
    passage_title: safeField(value.passage_title || value.title, 500),
    text_sha256: textSha,
    page_body_sha256: safeField(value.page_body_sha256, 128),
    block_index: Number.isInteger(blockIndex) && blockIndex >= 0 ? blockIndex : null,
    block_text_sha256: /^[0-9a-f]{64}$/.test(String(value.block_text_sha256 || "")) ? String(value.block_text_sha256) : "",
    block_excerpt: safeField(value.block_excerpt, 480),
    scroll_percent: Number.isFinite(scrollPercent) ? Math.max(0, Math.min(100, Math.round(scrollPercent))) : 0,
    edition: safeField(value.edition, 100),
    source_fingerprint_sha256: safeField(value.source_fingerprint_sha256, 128),
    recorded_at: safeField(value.recorded_at || value.saved_at, 100) || new Date().toISOString(),
  };
}

function loadReturnMarker() {
  try {
    const raw = localStorage.getItem(RETURN_MARKER_KEY);
    return raw ? normalizeReturnMarker(JSON.parse(raw)) : null;
  } catch {
    returnStorageAvailable = false;
    return null;
  }
}

function persistReturnMarker(marker, message = "") {
  returnMarker = normalizeReturnMarker(marker);
  try {
    if (returnMarker) localStorage.setItem(RETURN_MARKER_KEY, JSON.stringify(returnMarker));
    else localStorage.removeItem(RETURN_MARKER_KEY);
    returnStorageAvailable = true;
  } catch {
    returnStorageAvailable = false;
  }
  if (message && returnStatus) {
    returnStatus.textContent = returnStorageAvailable
      ? message
      : `${message} Browser storage is unavailable, so this return point lasts only for this page session.`;
  }
  refreshReturnPointUi();
}

function returnPassageAnchorForBlock(block) {
  const prose = block?.closest?.("[data-prose]");
  if (!prose) return "";
  let anchor = "";
  for (const heading of prose.querySelectorAll("h2[id][data-passage-id],h3[id][data-passage-id]")) {
    if (heading === block || (heading.compareDocumentPosition(block) & Node.DOCUMENT_POSITION_FOLLOWING)) anchor = heading.id;
    else break;
  }
  return anchor;
}

function returnBlocks(anchor = "") {
  const prose = document.querySelector("[data-prose]");
  if (!prose) return [];
  return [...prose.querySelectorAll("p,blockquote,li,pre,figcaption")]
    .filter((block) => normalizedQuoteText(block.textContent || "").length >= 3)
    .filter((block) => !anchor || returnPassageAnchorForBlock(block) === anchor);
}

function nearestReturnBlock() {
  const blocks = returnBlocks();
  if (!blocks.length) return null;
  const target = window.innerHeight * 0.38;
  const visible = blocks.filter((block) => {
    const rect = block.getBoundingClientRect();
    return rect.bottom > 0 && rect.top < window.innerHeight;
  });
  const pool = visible.length ? visible : blocks;
  return pool.sort((a, b) => {
    const ar = a.getBoundingClientRect();
    const br = b.getBoundingClientRect();
    return Math.abs((ar.top + ar.bottom) / 2 - target) - Math.abs((br.top + br.bottom) / 2 - target);
  })[0];
}

async function createReturnMarker() {
  const pageId = document.body.dataset.pageId || "";
  const payload = await fieldbookContextProvider(pageId);
  if (!payload?.page?.id) throw new Error("This route has no accepted page identity.");
  const block = nearestReturnBlock();
  const anchor = block ? returnPassageAnchorForBlock(block) : (activePassageAnchor || "");
  const passage = anchor
    ? (payload.passages || []).find((row) => row.anchor === anchor || row.id === anchor)
    : null;
  const blocks = returnBlocks(passage?.anchor || "");
  const blockText = block ? normalizedQuoteText(block.textContent || "") : "";
  const maximum = document.documentElement.scrollHeight - window.innerHeight;
  const scrollPercent = maximum > 0 ? (window.scrollY / maximum) * 100 : 0;
  return normalizeReturnMarker({
    schema: "lumen.return-marker/v1",
    page_id: payload.page.id,
    page_title: payload.page.title,
    page_url: payload.page.url,
    scope: passage ? "passage" : "page",
    anchor: passage?.anchor || "",
    passage_id: passage?.id || "",
    passage_title: passage?.title || "",
    text_sha256: passage?.text_sha256 || payload.page.body_sha256,
    page_body_sha256: payload.page.body_sha256,
    block_index: block ? blocks.indexOf(block) : null,
    block_text_sha256: blockText ? await sha256Text(blockText) : "",
    block_excerpt: blockText.length > 360 ? `${blockText.slice(0, 357)}…` : blockText,
    scroll_percent: scrollPercent,
    edition: fieldbookEdition,
    source_fingerprint_sha256: fieldbookFingerprint,
    recorded_at: new Date().toISOString(),
  });
}

async function reviewReturnMarker(marker = returnMarker) {
  marker = normalizeReturnMarker(marker);
  if (!marker) return { status: "empty", marker: null, target: null };
  let payload;
  try {
    payload = await fieldbookContextProvider(marker.page_id);
  } catch (error) {
    return { status: "page-missing", marker, target: null, message: error.message };
  }
  if (!payload?.page?.id) return { status: "page-missing", marker, target: null };
  const page = payload.page;
  const passages = payload.passages || [];
  if (marker.scope === "page") {
    const exact = page.body_sha256 === marker.text_sha256;
    return {
      status: exact ? "exact" : "changed",
      marker,
      target: { page_id: page.id, page_url: page.url, page_title: page.title, anchor: "", title: page.title, text_sha256: page.body_sha256, excerpt: "" },
      current_source_fingerprint_sha256: payload.source_fingerprint_sha256 || fieldbookFingerprint,
    };
  }
  const direct = passages.find((row) => row.id === marker.passage_id || row.anchor === marker.anchor);
  if (direct?.text_sha256 === marker.text_sha256) {
    return {
      status: "exact",
      marker,
      target: { page_id: page.id, page_url: page.url, page_title: page.title, anchor: direct.anchor, title: direct.title, text_sha256: direct.text_sha256, excerpt: direct.excerpt || direct.text },
      current_source_fingerprint_sha256: payload.source_fingerprint_sha256 || fieldbookFingerprint,
    };
  }
  const exactElsewhere = passages.filter((row) => row.text_sha256 === marker.text_sha256);
  if (exactElsewhere.length === 1) {
    const moved = exactElsewhere[0];
    return {
      status: "moved",
      marker,
      target: { page_id: page.id, page_url: page.url, page_title: page.title, anchor: moved.anchor, title: moved.title, text_sha256: moved.text_sha256, excerpt: moved.excerpt || moved.text },
      current_source_fingerprint_sha256: payload.source_fingerprint_sha256 || fieldbookFingerprint,
    };
  }
  if (exactElsewhere.length > 1) {
    return { status: "ambiguous", marker, target: null, matches: exactElsewhere.length, current_source_fingerprint_sha256: payload.source_fingerprint_sha256 || fieldbookFingerprint };
  }
  if (direct) {
    return {
      status: "changed",
      marker,
      target: { page_id: page.id, page_url: page.url, page_title: page.title, anchor: direct.anchor, title: direct.title, text_sha256: direct.text_sha256, excerpt: direct.excerpt || direct.text },
      current_source_fingerprint_sha256: payload.source_fingerprint_sha256 || fieldbookFingerprint,
    };
  }
  return { status: "passage-missing", marker, target: null, current_source_fingerprint_sha256: payload.source_fingerprint_sha256 || fieldbookFingerprint };
}

function returnStatusCopy(review) {
  const copies = {
    empty: "No return point is stored in this browser.",
    exact: "The marked text is byte-for-byte the same in this edition.",
    moved: "The exact marked text survives under a different section identity in this edition.",
    changed: "The marked page or passage still exists, but its accepted text changed.",
    ambiguous: "The old accepted text appears more than once, so no new location was chosen.",
    "passage-missing": "The marked passage is not present in this edition.",
    "page-missing": "The marked page is not present in this edition.",
  };
  return copies[review?.status] || "The return point could not be reviewed.";
}

function returnRecordedLabel(value) {
  const date = new Date(value || "");
  return Number.isNaN(date.getTime()) ? "date unknown" : date.toLocaleString();
}

function receiptRow(dl, label, value, code = false) {
  dl.append(text("dt", label));
  const dd = text("dd", value || "Not recorded");
  if (code) dd.className = "return-code";
  dl.append(dd);
}

function renderReturnReceipt(review) {
  if (!returnReceipt) return;
  returnReceipt.replaceChildren();
  if (!review?.marker) {
    returnReceipt.append(text("p", "Mark the current place explicitly; Lumen does not track reading automatically."));
    if (returnGoButton) returnGoButton.disabled = true;
    if (returnExportButton) returnExportButton.disabled = true;
    if (returnClearButton) returnClearButton.disabled = true;
    return;
  }
  const marker = review.marker;
  const title = review.target?.title || marker.passage_title || marker.page_title || marker.page_id;
  returnReceipt.append(text("h3", title));
  if (marker.block_excerpt) returnReceipt.append(text("blockquote", marker.block_excerpt, "return-excerpt"));
  if (review.status === "changed" && review.target?.excerpt) {
    const current = document.createElement("details");
    current.append(text("summary", "Read the current accepted excerpt"), text("p", review.target.excerpt, "return-current-excerpt"));
    returnReceipt.append(current);
  }
  const dl = document.createElement("dl");
  dl.className = "return-receipt-list";
  receiptRow(dl, "Review", returnStatusCopy(review));
  receiptRow(dl, "Marked", returnRecordedLabel(marker.recorded_at));
  receiptRow(dl, "Edition", marker.edition || "unknown");
  receiptRow(dl, "Identity", marker.passage_id || marker.page_id, true);
  receiptRow(dl, "Accepted text", marker.text_sha256, true);
  if (marker.block_text_sha256) receiptRow(dl, "Exact block", marker.block_text_sha256, true);
  receiptRow(dl, "Source edition", marker.source_fingerprint_sha256, true);
  returnReceipt.append(dl);
  if (returnGoButton) {
    returnGoButton.disabled = !review.target || ["ambiguous", "passage-missing", "page-missing"].includes(review.status);
    returnGoButton.textContent = review.status === "changed" ? "Open current passage" : review.status === "moved" ? "Return to exact text" : "Return to my place";
  }
  if (returnExportButton) returnExportButton.disabled = false;
  if (returnClearButton) returnClearButton.disabled = false;
}

async function refreshReturnPointUi() {
  const generation = ++returnReviewGeneration;
  if (!returnMarker) returnMarker = loadReturnMarker();
  if (!returnMarker) {
    returnReview = { status: "empty", marker: null, target: null };
    if (returnStrip) returnStrip.hidden = true;
    if (returnStatus) returnStatus.textContent = returnStatusCopy(returnReview);
    renderReturnReceipt(returnReview);
    return;
  }
  if (returnStrip) returnStrip.hidden = false;
  if (returnStripTitle) returnStripTitle.textContent = returnMarker.passage_title || returnMarker.page_title || "Saved return point";
  if (returnStripMeta) returnStripMeta.textContent = `Reviewing ${returnMarker.edition || "saved edition"}…`;
  const review = await reviewReturnMarker(returnMarker);
  if (generation !== returnReviewGeneration) return;
  returnReview = review;
  if (returnStatus) returnStatus.textContent = `${returnStatusCopy(review)} Nothing is transmitted.`;
  if (returnStripMeta) returnStripMeta.textContent = `${review.status.replace(/-/g, " ")} · marked ${returnRecordedLabel(returnMarker.recorded_at)}`;
  renderReturnReceipt(review);
}

function openReturnPoint() {
  refreshReturnPointUi();
  if (returnDialog && !returnDialog.open) returnDialog.showModal();
}

async function markCurrentReturnPoint() {
  const marker = await createReturnMarker();
  if (!marker) throw new Error("The current place could not be bound to accepted text.");
  persistReturnMarker(marker, `Marked “${marker.passage_title || marker.page_title}” as the private return point.`);
  return marker;
}

async function exactReturnBlock(marker, anchor) {
  if (!marker?.block_text_sha256) return null;
  const blocks = returnBlocks(anchor);
  const preferred = Number.isInteger(marker.block_index) ? blocks[marker.block_index] : null;
  if (preferred && await sha256Text(normalizedQuoteText(preferred.textContent || "")) === marker.block_text_sha256) return preferred;
  const matches = [];
  for (const block of blocks) {
    if (await sha256Text(normalizedQuoteText(block.textContent || "")) === marker.block_text_sha256) matches.push(block);
  }
  return matches.length === 1 ? matches[0] : null;
}

function highlightReturnTarget(node) {
  if (!node) return;
  node.classList.add("return-point-highlight");
  window.setTimeout(() => node.classList.remove("return-point-highlight"), reducedMotion ? 800 : 2600);
}

async function restorePendingReturnPoint() {
  if (!returnMarker) returnMarker = loadReturnMarker();
  if (!returnMarker || document.body.dataset.pageId !== returnMarker.page_id) return;
  let pending = "";
  try { pending = sessionStorage.getItem(RETURN_PENDING_KEY) || ""; } catch { pending = ""; }
  if (pending && pending !== returnMarker.recorded_at) return;
  const review = await reviewReturnMarker(returnMarker);
  if (!["exact", "moved"].includes(review.status) || !review.target) return;
  const anchor = review.target.anchor || "";
  const heading = anchor ? document.getElementById(anchor) : null;
  const block = await exactReturnBlock(returnMarker, anchor);
  const target = block || heading;
  if (target) {
    target.scrollIntoView({ behavior: reducedMotion ? "auto" : "smooth", block: block ? "center" : "start" });
    highlightReturnTarget(target);
  } else if (!anchor && returnMarker.scroll_percent > 0) {
    const maximum = document.documentElement.scrollHeight - window.innerHeight;
    window.scrollTo({ top: maximum * (returnMarker.scroll_percent / 100), behavior: reducedMotion ? "auto" : "smooth" });
  }
  try { sessionStorage.removeItem(RETURN_PENDING_KEY); } catch { /* Session storage is optional. */ }
}

async function goToReturnPoint() {
  const review = returnReview?.marker === returnMarker ? returnReview : await reviewReturnMarker(returnMarker);
  if (!review?.target || ["ambiguous", "passage-missing", "page-missing"].includes(review.status)) return;
  try { sessionStorage.setItem(RETURN_PENDING_KEY, returnMarker.recorded_at); } catch { /* Session storage is optional. */ }
  if (returnDialog?.open) returnDialog.close();
  const href = fieldbookRouteHref(review.target.page_url || returnMarker.page_url || "/", review.target.anchor || "");
  if (href.startsWith("#/")) {
    const previous = location.hash;
    location.hash = href.slice(1);
    if (previous === location.hash) window.dispatchEvent(new HashChangeEvent("hashchange"));
  } else if (document.body.dataset.pageId === review.target.page_id) {
    if (review.target.anchor) history.replaceState(null, "", `#${review.target.anchor}`);
    await restorePendingReturnPoint();
  } else {
    window.location.href = href;
  }
}

document.addEventListener("click", (event) => {
  const open = event.target.closest("[data-open-return]");
  if (open) { event.preventDefault(); openReturnPoint(); return; }
  const mark = event.target.closest("[data-return-mark]");
  if (mark) {
    event.preventDefault();
    markCurrentReturnPoint().then(() => {
      if (returnDialog && !returnDialog.open && mark.dataset.returnOpenAfter === "true") returnDialog.showModal();
    }).catch((error) => { if (returnStatus) returnStatus.textContent = `Could not mark this place: ${error.message}`; });
  }
});

returnGoButton?.addEventListener("click", () => goToReturnPoint());
returnExportButton?.addEventListener("click", () => {
  if (!returnMarker) return;
  downloadFieldbookFile(`lumen-return-marker-${filenameDate()}.json`, JSON.stringify(returnMarker, null, 2) + "\n", "application/json");
  if (returnStatus) returnStatus.textContent = "Return marker exported. It contains source identity and reading position, not browser history.";
});
returnClearButton?.addEventListener("click", () => {
  if (!returnMarker || window.confirm("Remove the private return point from this browser?")) {
    persistReturnMarker(null, "Return point cleared.");
  }
});
returnImport?.addEventListener("change", async () => {
  const file = returnImport.files?.[0];
  if (!file) return;
  try {
    if (file.size > 256 * 1024) throw new Error("The return-marker import limit is 256 KiB.");
    const marker = normalizeReturnMarker(JSON.parse(await file.text()));
    if (!marker) throw new Error("the file is not a valid lumen.return-marker/v1 record");
    persistReturnMarker(marker, `Imported a return point from ${marker.edition || "another edition"}.`);
  } catch (error) {
    if (returnStatus) returnStatus.textContent = `Import refused: ${error.message}`;
  } finally {
    returnImport.value = "";
  }
});

returnMarker = loadReturnMarker();
refreshReturnPointUi();
window.setTimeout(() => restorePendingReturnPoint(), 80);


// Reading desk: a small ordered open set inspired by the donor's StoryList,
// rebuilt for stable page/passage identities and browser-local custody. It is
// deliberately separate from the longer-lived annotated fieldbook.
const deskDialog = byId("desk-dialog");
const deskList = byId("desk-list");
const deskEmpty = byId("desk-empty");
const deskStatus = byId("desk-status");
const focusSheetDialog = byId("focus-sheet-dialog");
const focusSheet = byId("focus-sheet");
const focusSheetMeta = byId("focus-sheet-meta");
const DESK_KEY = "lumen-reading-desk/v1";
let deskStorageAvailable = true;
let draggedDeskIndex = -1;

function emptyDesk() {
  return { schema: "lumen.reading-desk/v1", updated_at: new Date().toISOString(), source_fingerprint_sha256: fieldbookFingerprint, entries: [] };
}

function normalizeDeskEntry(value) {
  if (!value || typeof value !== "object") return null;
  const stableId = safeField(value.stable_id || value.id, 300);
  if (!stableId) return null;
  return {
    stable_id: stableId,
    scope: value.scope === "page" ? "page" : "passage",
    page_id: safeField(value.page_id, 180),
    page_title: safeField(value.page_title, 500),
    page_url: safeField(value.page_url || value.url || "/", 1200),
    anchor: safeField(value.anchor, 300),
    title: safeField(value.title || value.page_title || stableId, 500),
    text: safeField(value.text || value.excerpt, 24000),
    excerpt: safeField(value.excerpt || value.text, 1400),
    text_sha256: safeField(value.text_sha256 || value.body_sha256, 128),
    source_html_sha256: safeField(value.source_html_sha256, 128),
    source_fingerprint_sha256: safeField(value.source_fingerprint_sha256, 128),
    edition: safeField(value.edition, 100),
    opened_at: safeField(value.opened_at, 100) || new Date().toISOString(),
  };
}

function loadDesk() {
  try {
    const raw = localStorage.getItem(DESK_KEY);
    if (!raw) return emptyDesk();
    const value = JSON.parse(raw);
    const entries = Array.isArray(value.entries) ? value.entries.slice(0, 64).map(normalizeDeskEntry).filter(Boolean) : [];
    const deduped = new Map();
    for (const entry of entries) deduped.set(entry.stable_id, entry);
    return { schema: "lumen.reading-desk/v1", updated_at: safeField(value.updated_at, 100), source_fingerprint_sha256: safeField(value.source_fingerprint_sha256, 128), entries: [...deduped.values()] };
  } catch {
    deskStorageAvailable = false;
    return emptyDesk();
  }
}

let deskState = loadDesk();

function setDeskStatus(message) {
  if (deskStatus) deskStatus.textContent = message;
}

function persistDesk(message = "") {
  deskState.updated_at = new Date().toISOString();
  deskState.source_fingerprint_sha256 = fieldbookFingerprint;
  try {
    localStorage.setItem(DESK_KEY, JSON.stringify(deskState));
    deskStorageAvailable = true;
  } catch {
    deskStorageAvailable = false;
  }
  if (message) setDeskStatus(deskStorageAvailable ? message : `${message} Storage is unavailable; the desk lasts only for this page session.`);
  refreshDeskMarkers();
}

function deskEntryFromContext(payload, anchor = "") {
  const page = payload?.page || {};
  const passage = anchor ? (payload?.passages || []).find((row) => row.anchor === anchor || row.id === anchor) : null;
  if (passage) return normalizeDeskEntry({
    stable_id: passage.id,
    scope: "passage",
    page_id: page.id,
    page_title: page.title,
    page_url: page.url,
    anchor: passage.anchor,
    title: passage.title,
    text: passage.text,
    excerpt: passage.excerpt,
    text_sha256: passage.text_sha256,
    source_html_sha256: passage.source_html_sha256,
    source_fingerprint_sha256: payload.source_fingerprint_sha256 || fieldbookFingerprint,
    edition: fieldbookEdition,
    opened_at: new Date().toISOString(),
  });
  const description = document.querySelector('meta[name="description"]')?.content || `${page.word_count || 0} words in this page.`;
  return normalizeDeskEntry({
    stable_id: page.id,
    scope: "page",
    page_id: page.id,
    page_title: page.title,
    page_url: page.url,
    title: page.title,
    text: description,
    excerpt: description,
    text_sha256: page.body_sha256,
    source_fingerprint_sha256: payload.source_fingerprint_sha256 || fieldbookFingerprint,
    edition: fieldbookEdition,
    opened_at: new Date().toISOString(),
  });
}

function findDeskEntry(key) {
  return deskState.entries.find((entry) => entry.stable_id === key) || null;
}

async function toggleDeskPassage(anchor = "", { forceAdd = false, pageId = "" } = {}) {
  const payload = await fieldbookContextProvider(pageId || pageIdForAnchor(anchor));
  if (!payload) throw new Error("No source-bound context exists for this route.");
  const entry = deskEntryFromContext(payload, anchor);
  if (!entry) throw new Error("The requested item has no stable identity.");
  const index = deskState.entries.findIndex((row) => row.stable_id === entry.stable_id);
  if (index >= 0 && !forceAdd) {
    deskState.entries.splice(index, 1);
    persistDesk(`Closed “${entry.title}” on the reading desk.`);
  } else if (index >= 0) {
    deskState.entries[index] = entry;
    persistDesk(`Refreshed “${entry.title}” from this edition.`);
  } else {
    if (deskState.entries.length >= 64) throw new Error("The reading desk is full (64 items). Close an item before opening another.");
    deskState.entries.push(entry);
    persistDesk(`Opened “${entry.title}” on the reading desk.`);
  }
  renderDesk();
  return entry;
}

function moveDeskEntry(from, to) {
  if (from < 0 || to < 0 || from >= deskState.entries.length || to >= deskState.entries.length || from === to) return;
  const [entry] = deskState.entries.splice(from, 1);
  deskState.entries.splice(to, 0, entry);
  persistDesk(`Moved “${entry.title}” to position ${to + 1}.`);
  renderDesk();
}

function refreshDeskMarkers() {
  const keys = new Set(deskState.entries.map((entry) => entry.stable_id));
  document.querySelectorAll("[data-desk-count]").forEach((node) => { node.textContent = String(deskState.entries.length); });
  document.querySelectorAll("[data-desk-anchor]").forEach((button) => {
    const pageId = document.body.dataset.pageId || "";
    const key = fieldbookEntryKey(pageId, button.dataset.deskAnchor || "");
    const active = keys.has(key);
    button.setAttribute("aria-pressed", String(active));
    button.textContent = active ? "◆" : "◇";
  });
  document.querySelectorAll("[data-desk-current]").forEach((button) => {
    const pageId = document.body.dataset.pageId || "";
    const key = fieldbookEntryKey(pageId, activePassageAnchor || "");
    const active = keys.has(key) || (!activePassageAnchor && keys.has(pageId));
    button.setAttribute("aria-pressed", String(active));
    button.textContent = active ? "Remove current passage from desk" : "Add current passage to desk";
  });
}

function deskButton(label, action, disabled = false) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "text-button";
  button.textContent = label;
  button.disabled = disabled;
  button.addEventListener("click", action);
  return button;
}

function renderDesk() {
  if (!deskList || !deskEmpty) return;
  deskList.replaceChildren();
  deskEmpty.hidden = deskState.entries.length > 0;
  deskState.entries.forEach((entry, index) => {
    const item = document.createElement("li");
    item.className = "desk-item";
    item.draggable = true;
    item.dataset.deskIndex = String(index);
    const handle = text("span", "⠿", "desk-handle");
    handle.title = "Drag to reorder";
    const order = text("span", String(index + 1).padStart(2, "0"), "desk-order");
    const copy = document.createElement("div");
    copy.className = "desk-copy";
    copy.append(text("p", entry.scope === "passage" ? entry.page_title : "Page", "eyebrow"));
    const titleNode = document.createElement("h3");
    const link = document.createElement("a");
    link.href = fieldbookEntryHref(entry);
    link.textContent = entry.title;
    titleNode.append(link);
    copy.append(titleNode, text("p", entry.excerpt || entry.text, "desk-excerpt"));
    if (entry.source_fingerprint_sha256 && entry.source_fingerprint_sha256 !== fieldbookFingerprint) {
      copy.append(text("p", `Saved from ${entry.edition || "another edition"}; verify before relying on exact text.`, "desk-mismatch"));
    }
    const actions = document.createElement("div");
    actions.className = "desk-item-actions";
    actions.append(
      deskButton("↑", () => moveDeskEntry(index, index - 1), index === 0),
      deskButton("↓", () => moveDeskEntry(index, index + 1), index === deskState.entries.length - 1),
      deskButton("Close", () => { deskState.entries.splice(index, 1); persistDesk(`Closed “${entry.title}”.`); renderDesk(); })
    );
    item.append(handle, order, copy, actions);
    item.addEventListener("dragstart", () => { draggedDeskIndex = index; item.classList.add("is-dragging"); });
    item.addEventListener("dragend", () => { draggedDeskIndex = -1; item.classList.remove("is-dragging"); });
    item.addEventListener("dragover", (event) => { event.preventDefault(); item.classList.add("is-drop-target"); });
    item.addEventListener("dragleave", () => item.classList.remove("is-drop-target"));
    item.addEventListener("drop", (event) => { event.preventDefault(); item.classList.remove("is-drop-target"); moveDeskEntry(draggedDeskIndex, index); });
    deskList.append(item);
  });
  const storage = deskStorageAvailable ? "stored in this browser" : "held for this page session";
  setDeskStatus(`${deskState.entries.length} open item${deskState.entries.length === 1 ? "" : "s"} · ${storage} · source ${fieldbookFingerprint.slice(0, 12)}`);
  refreshDeskMarkers();
}

function openDesk() {
  renderDesk();
  if (deskDialog && !deskDialog.open) deskDialog.showModal();
}

function renderFocusSheet() {
  if (!focusSheet || !focusSheetMeta) return;
  focusSheet.replaceChildren();
  if (!deskState.entries.length) {
    focusSheet.append(text("p", "The reading desk is empty. Add a page or passage first."));
    focusSheetMeta.textContent = "No local projection generated.";
    return;
  }
  focusSheetMeta.textContent = `${deskState.entries.length} item${deskState.entries.length === 1 ? "" : "s"} · source ${fieldbookFingerprint.slice(0, 12)} · assembled ${new Date().toLocaleString()}`;
  deskState.entries.forEach((entry, index) => {
    const article = document.createElement("article");
    article.className = "focus-sheet-item";
    article.append(text("p", `${String(index + 1).padStart(2, "0")} · ${entry.page_title || entry.scope}`, "eyebrow"));
    article.append(text("h2", entry.title));
    const body = text("p", entry.text || entry.excerpt || "No local text projection is available.");
    body.className = "focus-sheet-text";
    article.append(body);
    const source = document.createElement("a");
    source.href = fieldbookEntryHref(entry);
    source.textContent = "Open source location";
    article.append(source);
    focusSheet.append(article);
  });
}

function openFocusSheet() {
  renderFocusSheet();
  if (deskDialog?.open) deskDialog.close();
  if (focusSheetDialog && !focusSheetDialog.open) focusSheetDialog.showModal();
}

function makeDeskSaveButton(payload, anchor = "") {
  const entry = deskEntryFromContext(payload, anchor);
  const button = document.createElement("button");
  button.type = "button";
  button.className = "text-button context-save";
  const update = () => {
    const active = entry && Boolean(findDeskEntry(entry.stable_id));
    button.textContent = active ? "Remove from reading desk" : "Add to reading desk";
    button.setAttribute("aria-pressed", String(active));
  };
  update();
  button.addEventListener("click", async () => {
    try { await toggleDeskPassage(anchor, { pageId: payload?.page?.id || "" }); update(); }
    catch (error) { setDeskStatus(error.message); button.textContent = error.message; }
  });
  return button;
}

function deskExportPayload() {
  return { ...deskState, schema: "lumen.reading-desk/v1", exported_at: new Date().toISOString(), exported_from: { edition: fieldbookEdition, source_fingerprint_sha256: fieldbookFingerprint } };
}

document.addEventListener("click", (event) => {
  const open = event.target.closest("[data-open-desk]");
  if (open) { event.preventDefault(); openDesk(); return; }
  const passage = event.target.closest("[data-desk-anchor]");
  if (passage) { event.preventDefault(); toggleDeskPassage(passage.dataset.deskAnchor || "", { pageId: pageIdForAnchor(passage.dataset.deskAnchor || "", passage) }).catch((error) => setDeskStatus(error.message)); return; }
  const current = event.target.closest("[data-desk-current]");
  if (current) { event.preventDefault(); toggleDeskPassage(activePassageAnchor || "", { pageId: pageIdForAnchor(activePassageAnchor || "", current) }).catch((error) => setDeskStatus(error.message)); }
});

document.querySelector("[data-desk-add-current]")?.addEventListener("click", () => toggleDeskPassage(activePassageAnchor || "", { forceAdd: true, pageId: pageIdForAnchor(activePassageAnchor || "") }).catch((error) => setDeskStatus(error.message)));
document.querySelector("[data-desk-focus]")?.addEventListener("click", openFocusSheet);
document.querySelector("[data-desk-export]")?.addEventListener("click", () => {
  downloadFieldbookFile(`lumen-reading-desk-${filenameDate()}.json`, JSON.stringify(deskExportPayload(), null, 2) + "\n", "application/json");
  setDeskStatus("Reading desk exported.");
});
document.querySelector("[data-desk-clear]")?.addEventListener("click", () => {
  if (!deskState.entries.length || window.confirm("Close every item on this browser's reading desk?")) {
    deskState.entries = [];
    persistDesk("Reading desk cleared.");
    renderDesk();
  }
});

// Focus mode hides publication chrome without changing the document or URL.
// It is session-scoped so a reader is not surprised on a later visit.
const FOCUS_KEY = "lumen-focus/v1";
let focusMode = false;
try { focusMode = sessionStorage.getItem(FOCUS_KEY) === "true"; } catch { focusMode = false; }

function applyFocusMode(next) {
  focusMode = Boolean(next);
  root.dataset.focus = String(focusMode);
  document.querySelectorAll("[data-focus-toggle]").forEach((button) => button.setAttribute("aria-pressed", String(focusMode)));
  try { sessionStorage.setItem(FOCUS_KEY, String(focusMode)); } catch { /* Session state is optional. */ }
}
function toggleFocusMode() { applyFocusMode(!focusMode); }
document.querySelectorAll("[data-focus-toggle]").forEach((button) => { button.dataset.boundFocus = "true"; button.addEventListener("click", toggleFocusMode); });

applyFocusMode(focusMode);
renderDesk();


function bindReferenceRoom(scope = document) {
  const filter = scope.querySelector("[data-reference-filter]");
  const host = scope.querySelector("[data-reference-host]");
  const status = scope.querySelector("[data-reference-status]");
  const entries = Array.from(scope.querySelectorAll("[data-reference-entry]"));
  if (!filter || !entries.length || filter.dataset.referenceBound) return;
  filter.dataset.referenceBound = "true";
  const apply = () => {
    const query = normalizeQuery(filter.value || "");
    const selectedHost = normalizeQuery(host?.value || "");
    let visible = 0;
    entries.forEach((entry) => {
      const textValue = normalizeQuery(entry.dataset.referenceSearch || "");
      const entryHost = normalizeQuery(entry.dataset.referenceHost || "");
      const show = (!query || textValue.includes(query)) && (!selectedHost || entryHost === selectedHost);
      entry.hidden = !show;
      if (show) visible += 1;
    });
    if (status) status.textContent = `${visible} of ${entries.length} source${entries.length === 1 ? "" : "s"} shown locally.`;
  };
  filter.addEventListener("input", apply);
  host?.addEventListener("change", apply);
  apply();
}


function bindPageFeatures() {
  document.querySelectorAll("[data-open-appearance]").forEach((button) => { if (!button.dataset.boundAppearance) { button.dataset.boundAppearance = "true"; button.addEventListener("click", () => { if (appearanceDialog && !appearanceDialog.open) appearanceDialog.showModal(); }); } });
  document.querySelectorAll("[data-look-choice]").forEach((button) => { if (!button.dataset.boundLook) { button.dataset.boundLook = "true"; button.addEventListener("click", () => applyLook(button.dataset.lookChoice, { preferredTone: button.dataset.lookTone || "" })); } });
  refreshFieldbookMarkers();
  refreshDeskMarkers();
  document.querySelectorAll("[data-focus-toggle]").forEach((button) => {
    if (!button.dataset.boundFocus) {
      button.dataset.boundFocus = "true";
      button.addEventListener("click", toggleFocusMode);
    }
    button.setAttribute("aria-pressed", String(focusMode));
  });
  bindPreviews();
  bindCopyCommands();
  bindContext();
  bindToc();
  bindGraph();
  bindOfflineControls();
  bindMotion();
  bindExactQuoteLinks();
  refreshReturnPointUi();
  document.querySelectorAll("[data-correction-current]").forEach((button) => { if (!button.dataset.boundCorrection) { button.dataset.boundCorrection = "true"; button.addEventListener("click", () => openCorrection(activePassageAnchor)); } });
  bindReferenceRoom(main);
}

// Keyboard
addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    [focusSheetDialog, deskDialog, editionCompareDialog, capsuleDialog, correctionDialog, returnDialog, fieldbookDialog, contextDialog, inspectDialog, searchDialog, appearanceDialog].find((dialog) => dialog?.open)?.close();
    return;
  }
  if ([searchDialog, inspectDialog, contextDialog, correctionDialog, returnDialog, fieldbookDialog, editionCompareDialog, capsuleDialog, appearanceDialog, deskDialog, focusSheetDialog].some((dialog) => dialog?.open)) return;
  const target = event.target;
  const editing = target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target?.isContentEditable;
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") { event.preventDefault(); openSearch(); }
  else if (!editing && event.key === "/") { event.preventDefault(); openSearch(); }
  else if (!editing && event.key.toLowerCase() === "i") { event.preventDefault(); openInspector(); }
  else if (!editing && event.key.toLowerCase() === "c") { event.preventDefault(); openContext(activePassageAnchor); }
  else if (!editing && event.key.toLowerCase() === "b") { event.preventDefault(); openFieldbook(); }
  else if (!editing && event.key.toLowerCase() === "r") { event.preventDefault(); if (event.shiftKey) markCurrentReturnPoint().catch((error) => { if (returnStatus) returnStatus.textContent = `Could not mark this place: ${error.message}`; }); else openReturnPoint(); }
  else if (!editing && event.key.toLowerCase() === "s") { event.preventDefault(); toggleFieldbookPassage(activePassageAnchor || "", { pageId: pageIdForAnchor(activePassageAnchor || "") }).catch((error) => setFieldbookStatus(`Could not update reading trail: ${error.message}`)); }
  else if (!editing && event.key.toLowerCase() === "d") { event.preventDefault(); if (event.shiftKey) toggleDeskPassage(activePassageAnchor || "", { pageId: pageIdForAnchor(activePassageAnchor || "") }).catch((error) => setDeskStatus(`Could not update reading desk: ${error.message}`)); else openDesk(); }
  else if (!editing && event.key.toLowerCase() === "f") { event.preventDefault(); toggleFocusMode(); }
});

const initial = routeState();
if (location.hash.length > 1) renderRoute(initial.route, initial.anchor, { focus: false, quote: initial.quote });
else bindPageFeatures();
updateProgress();
