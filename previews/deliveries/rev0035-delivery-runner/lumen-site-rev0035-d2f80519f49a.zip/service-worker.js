const CACHE = "lumen-edition-d2f80519f49a995c";
const CORE = ["/", "/notes/", "/editions/", "/now/", "/about/", "/sources/", "/workbench/", "/lab/", "/assets/css/site.21183ec50fa1.css", "/assets/js/site.0f1b087d4f70.js", "/assets/icons/favicon.svg", "/assets/icons/mask-icon.svg", "/meta/search-index.json", "/meta/source-snapshot.json", "/site.webmanifest"];
self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(CORE)));
});
self.addEventListener("activate", (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(
    keys.filter((key) => key.startsWith("lumen-edition-") && key !== CACHE).map((key) => caches.delete(key))
  )).then(() => self.clients.claim()));
});
self.addEventListener("fetch", (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== "GET" || url.origin !== self.location.origin) return;
  if (request.mode === "navigate") {
    event.respondWith(fetch(request).then((response) => {
      const copy = response.clone();
      caches.open(CACHE).then((cache) => cache.put(request, copy));
      return response;
    }).catch(() => caches.match(request).then((hit) => hit || caches.match("/"))));
    return;
  }
  event.respondWith(caches.match(request).then((hit) => hit || fetch(request).then((response) => {
    if (response.ok) caches.open(CACHE).then((cache) => cache.put(request, response.clone()));
    return response;
  })));
});
