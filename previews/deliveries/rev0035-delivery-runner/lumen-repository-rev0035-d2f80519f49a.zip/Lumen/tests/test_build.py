from __future__ import annotations

import importlib.util
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_build_module():
    spec = importlib.util.spec_from_file_location("lumen_build", ROOT / "tools" / "build.py")
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class LumenBuildTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        root_receipt = ROOT / "BUILD-RECEIPT.json"
        root_receipt_before = root_receipt.read_bytes() if root_receipt.exists() else None
        cls.temp_build = tempfile.TemporaryDirectory(prefix="lumen-test-build-")
        cls.dist = Path(cls.temp_build.name) / "dist"
        env = os.environ.copy()
        env["LUMEN_BUILD_TIME"] = "2026-10-01T21:30:00Z"
        subprocess.run(
            [sys.executable, str(ROOT / "tools" / "build.py"), "--clean", "--output", str(cls.dist)],
            cwd=ROOT,
            env=env,
            check=True,
            capture_output=True,
            text=True,
        )
        subprocess.run(
            [sys.executable, str(ROOT / "tools" / "check_dist.py"), str(cls.dist)],
            cwd=ROOT,
            check=True,
            capture_output=True,
            text=True,
        )
        cls.custom_build_preserved_root_receipt = (
            root_receipt.read_bytes() if root_receipt.exists() else None
        ) == root_receipt_before
        cls.build = load_build_module()
        cls.pages = cls.build.load_pages()
        cls.note_count = sum(p.kind == "note" for p in cls.pages)
        cls.folio_count = sum(p.kind in {"note", "project"} for p in cls.pages)
        cls.revision_count = sum(len(r["revisions"]) for r in json.loads((ROOT / "content/data/edition-history.json").read_text())["notes"].values())
        cls.receipt = json.loads((cls.dist / "build-receipt.json").read_text(encoding="utf-8"))

    @classmethod
    def tearDownClass(cls) -> None:
        cls.temp_build.cleanup()

    def test_nonempty_output_refused_before_any_write(self) -> None:
        with tempfile.TemporaryDirectory(prefix="lumen-output-boundary-") as directory:
            output = Path(directory) / "dist"
            output.mkdir()
            sentinel = output / "old-edition.html"
            sentinel.write_bytes(b"previous output must remain untouched")
            before = sentinel.stat().st_mtime_ns
            with self.assertRaisesRegex(SystemExit, "Use --clean"):
                self.build.build(output=output)
            self.assertEqual(list(output.iterdir()), [sentinel])
            self.assertEqual(sentinel.read_bytes(), b"previous output must remain untouched")
            self.assertEqual(sentinel.stat().st_mtime_ns, before)

    def test_empty_output_builds_but_implicit_rebuild_is_refused(self) -> None:
        with tempfile.TemporaryDirectory(prefix="lumen-empty-output-") as directory:
            output = Path(directory) / "dist"
            output.mkdir()
            self.build.build(output=output)
            before = (output / "Lumen.html").read_bytes()
            with self.assertRaisesRegex(SystemExit, "nonempty output"):
                self.build.build(output=output)
            self.assertEqual((output / "Lumen.html").read_bytes(), before)

    def test_explicit_clean_rebuild_excludes_stale_edition_files(self) -> None:
        with tempfile.TemporaryDirectory(prefix="lumen-clean-output-") as directory:
            output = Path(directory) / "dist"
            self.build.build(output=output)
            before = (output / "Lumen.html").read_bytes()
            stale = output / "folios" / "obsolete-test-edition.html"
            stale.write_text("benign stale generated page")
            self.build.build(clean=True, output=output)
            self.assertFalse(stale.exists())
            self.assertEqual((output / "Lumen.html").read_bytes(), before)



    def test_canonical_fingerprint_uses_the_public_content_selection(self) -> None:
        with tempfile.TemporaryDirectory(prefix="lumen-selected-inputs-") as directory:
            root = Path(directory)
            for name in ("content/pages", "content/data", "assets", "templates", "tools"):
                (root / name).mkdir(parents=True)
            (root / "config.json").write_text("{}")
            for name in ("edition-history.json", "looks.json", "reading-paths.json", "source-snapshot.json"):
                (root / "content/data" / name).write_text("{}")
            with mock.patch.multiple(self.build, ROOT=root, CONTENT=root / "content/pages", ASSETS=root / "assets", TEMPLATES=root / "templates"), mock.patch.object(self.build, "load_pages", return_value=[]):
                before = self.build.stable_source_hash()
                (root / "content/data/unlisted-work-note.json").write_text('{"note":"Not a selected publication input"}')
                self.assertEqual(self.build.stable_source_hash(), before)
                self.assertNotEqual(self.build.stable_source_hash(include_drafts=True), before)

    def test_reference_clock_basis_is_explicit_and_not_execution_time(self) -> None:
        with mock.patch.dict(os.environ, {"LUMEN_BUILD_TIME": "2026-10-02T12:00:00Z", "SOURCE_DATE_EPOCH": "0"}):
            self.assertEqual(self.build.build_time_basis(), "explicit-LUMEN_BUILD_TIME")
        with mock.patch.dict(os.environ, {"LUMEN_BUILD_TIME": "", "SOURCE_DATE_EPOCH": "0"}):
            self.assertEqual(self.build.build_time_basis(), "SOURCE_DATE_EPOCH")
        with mock.patch.dict(os.environ, {"LUMEN_BUILD_TIME": "", "SOURCE_DATE_EPOCH": ""}):
            self.assertEqual(self.build.build_time_basis(), "accepted-source-snapshot")
        self.assertEqual(self.receipt["generated_at_semantics"], "reproducible-reference-clock")
        inspection = json.loads((self.dist / "meta/pages/home.json").read_text())
        self.assertEqual(inspection["build"]["generated_at_basis"], "explicit-LUMEN_BUILD_TIME")
        for name in ("site.js", "capsule.js"):
            self.assertIn('"Build reference clock"', (ROOT / "assets/js" / name).read_text())

    def test_default_build_time_is_the_accepted_snapshot_clock(self) -> None:
        snapshot = json.loads((ROOT / "content" / "data" / "source-snapshot.json").read_text(encoding="utf-8"))
        old_explicit = os.environ.pop("LUMEN_BUILD_TIME", None)
        old_epoch = os.environ.pop("SOURCE_DATE_EPOCH", None)
        try:
            actual = self.build.build_time().isoformat().replace("+00:00", "Z")
            self.assertEqual(actual, snapshot["captured_at"])
        finally:
            if old_explicit is not None:
                os.environ["LUMEN_BUILD_TIME"] = old_explicit
            if old_epoch is not None:
                os.environ["SOURCE_DATE_EPOCH"] = old_epoch

    def test_single_file_capsule_is_browser_html_and_extractable_zip(self) -> None:
        capsule = self.dist / "Lumen.html"
        raw = capsule.read_bytes()
        self.assertTrue(raw.startswith(b"<!doctype html>"))
        self.assertTrue(zipfile.is_zipfile(capsule))
        self.assertLess(capsule.stat().st_size, 12_000_000)
        self.assertIn(b"Portable edition", raw[:300_000])
        self.assertIn(b"<noscript>", raw[:800_000])
        with zipfile.ZipFile(capsule) as archive:
            self.assertIsNone(archive.testzip())
            self.assertIn("Lumen/lumen", archive.namelist())
            self.assertEqual(archive.read("Lumen/START-HERE.txt"), (ROOT / "START-HERE.txt").read_bytes())
            self.assertIn("Lumen/CAPSULE-MANIFEST.json", archive.namelist())
            self.assertNotIn("Lumen/research/BROWSER-REVIEW.json", archive.namelist())
            self.assertFalse(any(name.endswith("/Lumen.sh") for name in archive.namelist()))
            self.assertFalse(any(name.lower().endswith(".zip") for name in archive.namelist()))
            self.assertFalse(any("/research/" in name or "/archive/" in name for name in archive.namelist()))
            mode = (archive.getinfo("Lumen/lumen").external_attr >> 16) & 0o777
            self.assertTrue(mode & 0o111)
            manifest = json.loads(archive.read("Lumen/CAPSULE-MANIFEST.json"))
            self.assertEqual(manifest["schema"], "lumen.capsule/v3")
            self.assertEqual(manifest["source_fingerprint_sha256"], self.receipt["source_fingerprint_sha256"])
            self.assertEqual(manifest["archive_root"], "Lumen/")
            self.assertEqual(manifest["hypertext"]["passages"], self.receipt["counts"]["passages"])
            self.assertIn(manifest["hypertext"]["path"], archive.namelist())
            self.assertIn("private local fieldbook", manifest["capabilities"]["browser"])
            self.assertIn("source-bound packet export", manifest["capabilities"]["cloudtainer"])
            self.assertIn("ordered reading desk", manifest["capabilities"]["browser"])
            self.assertIn("reading-desk packet bridge", manifest["capabilities"]["cloudtainer"])
            self.assertIn("source-bound citation copy", manifest["capabilities"]["browser"])
            self.assertIn("exact selected-quote links", manifest["capabilities"]["browser"])
            self.assertIn("accepted edition ledger", manifest["capabilities"]["browser"])
            self.assertIn("accepted revision ledger verification", manifest["capabilities"]["cloudtainer"])
            self.assertIn("deterministic private worktree checkpoint", manifest["capabilities"]["cloudtainer"])
            self.assertIn("guarded fresh-directory reopening", manifest["capabilities"]["cloudtainer"])
            self.assertEqual(manifest["references"]["sources"], self.receipt["counts"]["external_sources"])
            self.assertIn(manifest["references"]["path"], archive.namelist())
            self.assertIn("local source-bound reference room", manifest["capabilities"]["browser"])
            self.assertIn("quiet local source lens", manifest["capabilities"]["browser"])
            self.assertIn("reference ledger inspection", manifest["capabilities"]["cloudtainer"])
            self.assertIn("private repositories and private worktree checkpoints", manifest["excluded_by_design"])

    def test_local_edition_comparison_is_lazy_source_bound_and_carried_offline(self) -> None:
        summary = json.loads((self.dist / "meta" / "edition-summary.json").read_text(encoding="utf-8"))
        self.assertEqual(summary["schema"], "lumen.edition-summary/v2")
        self.assertEqual(summary["edition"], json.loads((ROOT / "config.json").read_text())["edition"])
        self.assertEqual(summary["source_fingerprint_sha256"], self.receipt["source_fingerprint_sha256"])
        self.assertEqual(len(summary["pages"]), len(self.pages))
        self.assertEqual(len({row["id"] for row in summary["pages"]}), len(self.pages))
        self.assertTrue(all(len(row["body_sha256"]) == 64 for row in summary["pages"]))
        self.assertTrue(all(row["passage_detail"] is True for row in summary["pages"]))
        passages = [passage for row in summary["pages"] for passage in row["passages"]]
        self.assertEqual(len(passages), self.receipt["counts"]["passages"])
        self.assertEqual(summary["counts"]["passages"], self.receipt["counts"]["passages"])
        self.assertEqual(len({row["id"] for row in passages}), len(passages))
        self.assertTrue(all(len(row["text_sha256"]) == 64 for row in passages))
        self.assertTrue(all(len(row["source_html_sha256"]) == 64 for row in passages))
        asset = self.receipt["assets"]["edition_compare"]
        self.assertEqual(asset["loading"], "on-demand")
        compare_path = self.dist / asset["path"].lstrip("/")
        self.assertTrue(compare_path.is_file())
        home = (self.dist / "index.html").read_text(encoding="utf-8")
        editions = (self.dist / "editions" / "index.html").read_text(encoding="utf-8")
        self.assertIn(f'data-edition-compare-path="{asset["path"]}"', home)
        self.assertNotIn(f'<script src="{asset["path"]}"', home)
        self.assertIn("data-open-edition-compare", editions)
        self.assertIn('fetchJson("/meta/edition-summary.json")', (ROOT / "assets" / "js" / "site.js").read_text(encoding="utf-8"))
        compare_source = (ROOT / "assets" / "js" / "edition-compare.js").read_text(encoding="utf-8")
        self.assertIn('text.indexOf(`${token}{`)', compare_source)
        capsule = (self.dist / "Lumen.html").read_bytes()
        prefix = capsule[:2_500_000]
        self.assertIn(b"LUMEN_EDITION_SUMMARY_BEGIN", prefix)
        self.assertIn(b"Compare Lumen editions", prefix)
        with zipfile.ZipFile(self.dist / "Lumen.html") as archive:
            self.assertIn("Lumen/dist/meta/edition-summary.json", archive.namelist())
            manifest = json.loads(archive.read("Lumen/CAPSULE-MANIFEST.json"))
            self.assertIn("passage-aware local edition comparison", manifest["capabilities"]["browser"])
            self.assertIn("passage-aware local edition comparison", manifest["capabilities"]["cloudtainer"])

    def test_capsule_receipt_and_public_download_link(self) -> None:
        capsule = json.loads((self.dist / "meta" / "capsule.json").read_text(encoding="utf-8"))
        home = (self.dist / "index.html").read_text(encoding="utf-8")
        self.assertEqual(capsule["file"], "Lumen.html")
        self.assertEqual(capsule["browser_routes"], len(self.pages))
        self.assertEqual(capsule["sha256"], self.receipt["capsule"]["sha256"])
        self.assertIn('href="/Lumen.html"', home)
        self.assertIn('download="Lumen.html"', home)
        self.assertIn("Keep this edition", home)

    def test_custom_output_isolated_from_canonical_distribution(self) -> None:
        self.assertTrue(self.custom_build_preserved_root_receipt)
        self.assertNotEqual(self.dist.resolve(), (ROOT / "dist").resolve())
        with self.assertRaises(SystemExit):
            self.build.safe_output_dir(ROOT)
        with self.assertRaises(SystemExit):
            self.build.safe_output_dir(ROOT / "content" / "pages" / "generated")

    def test_expected_content_shape(self) -> None:
        self.assertTrue({"home", "notes", "note-place-return", "note-concern-control"}.issubset({p.id for p in self.pages}))
        self.assertEqual(sum(page.kind == "note" for page in self.pages), self.note_count)
        self.assertEqual(sum(page.kind == "project" for page in self.pages), 3)
        self.assertEqual(sum(page.kind == "collection" for page in self.pages), 0)
        self.assertEqual(self.receipt["counts"]["pages"], len(self.pages))
        self.assertEqual(self.receipt["counts"]["notes"], self.note_count)
        self.assertEqual(self.receipt["counts"]["projects"], 3)
        self.assertEqual(self.receipt["counts"]["collections"], 0)
        self.assertEqual(self.receipt["counts"]["repositories"], 4)
        self.assertEqual(self.receipt["counts"]["drafts"], 0)
        self.assertEqual(self.receipt["counts"]["published"], len(self.pages))
        self.assertEqual(self.receipt["counts"]["retired_sources"], 1)

    def test_every_page_has_lazy_metadata(self) -> None:
        for page in self.pages:
            with self.subTest(page=page.id):
                inspection = json.loads((self.dist / "meta" / "pages" / f"{page.id}.json").read_text(encoding="utf-8"))
                preview = json.loads((self.dist / "meta" / "previews" / f"{page.id}.json").read_text(encoding="utf-8"))
                self.assertEqual(inspection["page"]["id"], page.id)
                self.assertEqual(inspection["page"]["source"], page.data.get("source", {}))
                self.assertFalse(inspection["build"]["javascript_required_for_reading"])
                self.assertEqual(inspection["build"]["third_party_requests"], 0)
                self.assertEqual(preview["url"], page.url)

    def test_project_pages_link_to_public_sources(self) -> None:
        expected = {
            "project-lumen-sh": "https://github.com/Sapient-Lumen/Lumen",
            "project-habitat-observer": "https://github.com/Sapient-Lumen/Lumen/tree/main/habitat-observer",
            "project-w4r3z": "https://github.com/Sapient-Lumen/W4R3Z",
        }
        pages = {page.id: page for page in self.pages}
        for page_id, url in expected.items():
            with self.subTest(page=page_id):
                self.assertEqual(pages[page_id].data["source"]["url"], url)
                output = next(row["output"] for row in self.receipt["pages"] if row["id"] == page_id)
                self.assertIn(f'href="{url}"', (self.dist / output).read_text(encoding="utf-8"))

    def test_search_index_contains_published_prose(self) -> None:
        search = json.loads((self.dist / "meta" / "search-index.json").read_text(encoding="utf-8"))
        records = {row["id"]: row for row in search["records"]}
        self.assertIn("coherent conversation is a poor substitute", records["note-continuity-evidence"]["text"].lower())
        self.assertIn("concern must be capable of changing practice", records["note-concern-control"]["text"].lower())
        self.assertIn("typed missingness", records["project-habitat-observer"]["text"].lower())

    def test_hypertext_ledger_context_and_passage_search(self) -> None:
        ledger = json.loads((self.dist / "meta" / "hypertext-ledger.json").read_text(encoding="utf-8"))
        graph = json.loads((self.dist / "meta" / "graph.json").read_text(encoding="utf-8"))
        search = json.loads((self.dist / "meta" / "search-index.json").read_text(encoding="utf-8"))
        self.assertEqual(ledger["schema"], "lumen.hypertext-ledger/v1")
        self.assertEqual(graph["schema"], "lumen.graph/v2")
        self.assertEqual(ledger["counts"]["pages"], len(self.pages))
        self.assertGreaterEqual(ledger["counts"]["passages"], 45)
        self.assertGreaterEqual(ledger["counts"]["external_citations"], 17)
        self.assertEqual(search["passage_count"], ledger["counts"]["passages"] )
        self.assertTrue(any(row.get("scope") == "passage" for row in search["records"]))
        ids = [row["id"] for row in ledger["passages"]]
        self.assertEqual(len(ids), len(set(ids)))
        context = json.loads((self.dist / "meta" / "context" / "note-concern-control.json").read_text(encoding="utf-8"))
        self.assertEqual(context["page"]["passage_count"], 8)
        self.assertGreaterEqual(context["page"]["external_citation_count"], 10)
        for passage in context["passages"]:
            self.assertRegex(passage["text_sha256"], r"^[0-9a-f]{64}$")
            self.assertRegex(passage["source_html_sha256"], r"^[0-9a-f]{64}$")
            self.assertLessEqual(passage["source_offsets"]["start"], passage["source_offsets"]["end"] )

    def test_editorial_sections_receive_source_bound_context_without_ui_noise(self) -> None:
        context = json.loads((self.dist / "meta" / "context" / "lab.json").read_text(encoding="utf-8"))
        passages = {row["anchor"]: row for row in context["passages"]}
        self.assertIn("every-section-keeps-its-place", passages)
        passage = passages["every-section-keeps-its-place"]
        self.assertEqual(passage["id"], "lab::every-section-keeps-its-place")
        self.assertNotIn("Open this passage", passage["text"])
        self.assertNotIn("Typed relationships", passage["text"])
        self.assertRegex(passage["source_html_sha256"], r"^[0-9a-f]{64}$")
        page = (self.dist / "lab" / "index.html").read_text(encoding="utf-8")
        self.assertIn('data-passage-id="lab::every-section-keeps-its-place"', page)
        self.assertIn('data-context-anchor="every-section-keeps-its-place"', page)

    def test_context_controls_are_progressive_enhancements(self) -> None:
        page = (self.dist / "notes" / "concern-and-control" / "index.html").read_text(encoding="utf-8")
        script = (self.dist / self.receipt["assets"]["js"]["path"].lstrip("/")).read_text(encoding="utf-8")
        self.assertIn('id="context-dialog"', page)
        self.assertIn('data-context-anchor="1-i-will-not-collapse-the-predicates"', page)
        self.assertIn("Fingerprints establish the identity", script)
        self.assertIn("renderRelationshipGraph", script)
        self.assertIn("references are indexed locally", script)

    def test_retired_source_is_a_boundary_not_an_active_route(self) -> None:
        snapshot = json.loads((self.dist / "meta" / "source-snapshot.json").read_text(encoding="utf-8"))
        names = {row["name"] for row in snapshot["repositories"]}
        retired = {row["name"] for row in snapshot["retired_sources"]}
        self.assertNotIn("Sapient-Lumen/Datacube-MAIN", names)
        self.assertIn("Sapient-Lumen/Datacube-MAIN", retired)
        self.assertFalse((self.dist / "projects" / "datacube-main").exists())
        self.assertFalse((self.dist / "collections" / "datacube-museum").exists())
        search = json.loads((self.dist / "meta" / "search-index.json").read_text(encoding="utf-8"))
        self.assertFalse(any(row.get("id") == "project-datacube-main" for row in search["records"]))


    def test_deployment_boundary_excludes_archives_and_native_source(self) -> None:
        names = {path.name for path in self.dist.rglob("*") if path.is_file()}
        self.assertNotIn("Lumen.sh", names)
        self.assertFalse(any(name.lower().endswith(".zip") for name in names))
        relative_parts = [path.relative_to(self.dist).parts for path in self.dist.rglob("*") if path.is_file()]
        self.assertFalse(any("research" in parts or "archive" in parts for parts in relative_parts))


    def test_edition_history_is_exact_and_public(self) -> None:
        ledger = json.loads((self.dist / "meta" / "editions.json").read_text(encoding="utf-8"))
        self.assertEqual(ledger["schema"], "lumen.editions/v1")
        self.assertEqual(len(ledger["notes"]), self.note_count)
        self.assertEqual(sum(len(row["revisions"]) for row in ledger["notes"].values()), self.revision_count)
        self.assertEqual(len(ledger["notes"]["note-continuity-evidence"]["revisions"]), 2)
        editions = (self.dist / "editions" / "index.html").read_text(encoding="utf-8")
        self.assertIn("Versions without vanishing", editions)
        self.assertIn('id="history-note-continuity-evidence"', editions)
        inspection = json.loads((self.dist / "meta" / "pages" / "note-continuity-evidence.json").read_text(encoding="utf-8"))
        self.assertEqual(len(inspection["page"]["publication_history"]), 2)

    def test_exact_quote_links_are_transient_source_bound_controls(self) -> None:
        home = (self.dist / "index.html").read_text(encoding="utf-8")
        site_js = next((self.dist / "assets" / "js").glob("site.*.js")).read_text(encoding="utf-8")
        capsule = (self.dist / "Lumen.html").read_text(encoding="utf-8", errors="ignore")
        self.assertIn('id="selection-tools"', home)
        self.assertIn("Copy exact link", home)
        self.assertIn("passage.text_sha256", site_js)
        self.assertIn("lumen-exact-quote", site_js)
        self.assertIn("pageIdForAnchor", site_js)
        self.assertIn("Copy exact link", capsule[:2_000_000])
        self.assertIn("lumen-exact-quote", capsule[:2_000_000])

    def test_source_fingerprint_is_stable_for_unchanged_inputs(self) -> None:
        first = self.build.stable_source_hash()
        second = self.build.stable_source_hash()
        self.assertEqual(first, second)
        self.assertRegex(first, r"^[0-9a-f]{64}$")
        self.assertEqual(first, self.receipt["source_fingerprint_sha256"])

    def test_heading_annotation_is_unique(self) -> None:
        marked, toc = self.build.annotate_headings("<h2>Same</h2><h2>Same</h2><h3>Child</h3>")
        self.assertIn('id="same"', marked)
        self.assertIn('id="same-2"', marked)
        self.assertEqual([row["id"] for row in toc], ["same", "same-2", "child"])

    def test_feeds_and_archive_contain_only_published_notes(self) -> None:
        atom = (self.dist / "feed.xml").read_text(encoding="utf-8")
        rss = (self.dist / "rss.xml").read_text(encoding="utf-8")
        json_feed = json.loads((self.dist / "feed.json").read_text(encoding="utf-8"))
        archive = (self.dist / "notes" / "index.html").read_text(encoding="utf-8")
        self.assertEqual(atom.count("<entry>"), self.note_count)
        self.assertEqual(rss.count("<item>"), self.note_count)
        self.assertEqual(len(json_feed["items"]), self.note_count)
        self.assertEqual(json_feed["version"], "https://jsonfeed.org/version/1.1")
        self.assertIn("<author><name>Lumen</name></author>", atom)
        self.assertNotIn("The Observer of the Habitat</title>", atom)
        self.assertIn("Questions that recur", archive)
        self.assertIn('id="thread-continuity"', archive)
        self.assertIn('href="/feed.xml"', archive)
        self.assertIn('href="/rss.xml"', archive)
        self.assertIn('href="/feed.json"', archive)
        self.assertEqual(self.receipt["counts"]["feeds"], 3)

    def test_reference_room_is_source_bound_complete_and_offline(self) -> None:
        references = json.loads((self.dist / "meta" / "references.json").read_text(encoding="utf-8"))
        search = json.loads((self.dist / "meta" / "search-index.json").read_text(encoding="utf-8"))
        page = (self.dist / "references" / "index.html").read_text(encoding="utf-8")
        note = (self.dist / "notes" / "concern-and-control" / "index.html").read_text(encoding="utf-8")
        capsule = (self.dist / "Lumen.html").read_text(encoding="utf-8", errors="ignore")[:3_500_000]
        self.assertEqual(references["schema"], "lumen.references/v1")
        self.assertEqual(references["counts"]["sources"], len(references["sources"]))
        self.assertEqual(references["counts"]["citations"], sum(len(r["citations"]) for r in references["sources"]))
        self.assertEqual(references["counts"]["domains"], len({r["host"] for r in references["sources"]}))
        self.assertEqual(self.receipt["counts"]["external_sources"], references["counts"]["sources"])
        self.assertEqual(self.receipt["counts"]["reference_domains"], references["counts"]["domains"])
        self.assertIn('data-reference-filter', page)
        self.assertIn('data-reference-host', page)
        self.assertIn('data-reference-entry', page)
        self.assertIn('href="/meta/references.json"', page)
        self.assertIn('<details class="note-references">', note)
        self.assertIn('/references/#ref-', note)
        self.assertIn('data-reference-id="ref-', note)
        self.assertTrue(any(row.get("scope") == "reference" for row in search["records"]))
        self.assertEqual(search["reference_count"], references["counts"]["sources"])
        self.assertIn('Reference room', capsule)
        self.assertIn('lumen.references/v1', capsule)
        self.assertIn('Source record', capsule)
        previews = sorted((self.dist / "meta" / "reference-previews").glob("ref-*.json"))
        self.assertEqual(len(previews), references["counts"]["sources"])
        for source in references["sources"]:
            self.assertRegex(source["id"], r"^ref-[0-9a-f]{16}$")
            self.assertTrue(source["url"].startswith(("http://", "https://")))
            self.assertGreaterEqual(source["citation_count"], 1)
            for citation in source["citations"]:
                self.assertRegex(citation["text_sha256"], r"^[0-9a-f]{64}$")
                self.assertRegex(citation["source_html_sha256"], r"^[0-9a-f]{64}$")
                self.assertTrue(citation["url"].startswith(("http://", "https://")))
            preview = json.loads((self.dist / "meta" / "reference-previews" / f"{source['id']}.json").read_text(encoding="utf-8"))
            self.assertEqual(preview["schema"], "lumen.reference-preview/v1")
            self.assertEqual(preview["id"], source["id"])
            self.assertEqual(preview["citation_count"], source["citation_count"])
            self.assertIn("does not certify", preview["boundary"])

    def test_reference_ids_are_shared_by_passage_context_and_reference_ledger(self) -> None:
        references = json.loads((self.dist / "meta" / "references.json").read_text(encoding="utf-8"))
        context = json.loads((self.dist / "meta" / "context" / "note-concern-control.json").read_text(encoding="utf-8"))
        reference_ids = {row["id"] for row in references["sources"]}
        carried = {
            link["reference_id"]
            for passage in context["passages"]
            for link in passage.get("external_links", [])
        }
        self.assertTrue(carried)
        self.assertTrue(carried <= reference_ids)
        self.assertTrue(all(link.get("reference_id") for passage in context["passages"] for link in passage.get("external_links", [])))

    def test_security_social_and_structured_metadata(self) -> None:
        home = (self.dist / "index.html").read_text(encoding="utf-8")
        note = (self.dist / "notes" / "concern-and-control" / "index.html").read_text(encoding="utf-8")
        self.assertIn("Content-Security-Policy", home)
        self.assertNotIn("upgrade-insecure-requests", home)
        self.assertIn('property="og:image:width" content="1200"', home)
        self.assertIn('property="og:image:height" content="630"', home)
        self.assertIn('property="og:image:alt"', home)
        self.assertIn('type="application/ld+json"', home)
        self.assertIn('"@type":"Blog"', home)
        self.assertIn('"@type":"BlogPosting"', note)
        self.assertIn('property="article:published_time" content="2026-10-01"', note)
        self.assertIn('type="application/rss+xml"', home)
        self.assertIn('type="application/feed+json"', home)


    def test_fingerprinted_assets_have_integrity_and_receipts(self) -> None:
        home = (self.dist / "index.html").read_text(encoding="utf-8")
        for family in ("css", "js"):
            record = self.receipt["assets"][family]
            self.assertRegex(record["path"], rf"^/assets/{family}/site\.[0-9a-f]{{12}}\.{family}$")
            self.assertTrue((self.dist / record["path"].lstrip("/")).is_file())
            self.assertIn(record["sri"], home)
            self.assertGreater(record["gzip_bytes"], 0)
        self.assertFalse((self.dist / "assets" / "css" / "site.css").exists())
        self.assertFalse((self.dist / "assets" / "js" / "site.js").exists())

    def test_workbench_and_source_constellation_are_public(self) -> None:
        workbench = (self.dist / "workbench" / "index.html").read_text(encoding="utf-8")
        sources = (self.dist / "sources" / "index.html").read_text(encoding="utf-8")
        self.assertIn("./lumen doctor", workbench)
        self.assertIn("./lumen cite", workbench)
        self.assertIn("./lumen preserve", workbench)
        self.assertIn("./lumen reopen", workbench)
        self.assertIn("data-offline-install", workbench)
        self.assertIn("Sapient-Lumen/W4R3Z", sources)
        self.assertIn("IoTox", sources)
        self.assertIn("398 embedded tests", sources)
        self.assertIn("e84f3b84a1ab", sources)
        snapshot = json.loads((self.dist / "meta" / "source-snapshot.json").read_text(encoding="utf-8"))
        self.assertEqual(len(snapshot["repositories"]), 4)
        self.assertEqual(snapshot["schema"], "lumen.upstream-snapshot/v4")
        self.assertEqual(len(snapshot["retired_sources"]), 1)
        self.assertIsInstance(snapshot["changes_since_previous"], list)

    def test_offline_worker_is_opt_in_and_versioned(self) -> None:
        worker = (self.dist / "service-worker.js").read_text(encoding="utf-8")
        home = (self.dist / "index.html").read_text(encoding="utf-8")
        self.assertIn("lumen-edition-", worker)
        self.assertIn(self.receipt["assets"]["css"]["path"], worker)
        self.assertNotIn("serviceWorker.register", home)
        script = (self.dist / self.receipt["assets"]["js"]["path"].lstrip("/")).read_text(encoding="utf-8")
        self.assertIn('data-offline-install', script)
        self.assertIn('serviceWorker.register', script)

    def test_build_is_readable_without_javascript(self) -> None:
        for row in self.receipt["pages"]:
            text = (self.dist / row["output"]).read_text(encoding="utf-8")
            with self.subTest(output=row["output"]):
                self.assertIn('<main id="main"', text)
                self.assertIn("<h1", text)
                self.assertNotIn("Loading…</main>", text)

    def test_now_page_carries_current_boundaries(self) -> None:
        page = (self.dist / "now" / "index.html").read_text(encoding="utf-8")
        self.assertIn("90 samples", page)
        self.assertIn("Current process claim", page)
        self.assertIn("stopped", page)
        self.assertIn("An explicit retirement", page)
        self.assertIn("visitor’s browser makes no GitHub request", page)


    def test_performance_report_matches_build_receipt(self) -> None:
        performance = json.loads((self.dist / "meta" / "performance.json").read_text(encoding="utf-8"))
        self.assertEqual(performance["schema"], "lumen.performance/v1")
        self.assertEqual(performance["mode"], "canonical")
        self.assertEqual(len(performance["pages"]), self.receipt["counts"]["pages"])
        self.assertEqual(self.receipt["performance"]["report"], "meta/performance.json")
        self.assertLess(self.receipt["assets"]["css"]["gzip_bytes"], 16_000)
        self.assertLess(self.receipt["assets"]["js"]["gzip_bytes"], 29_000)

    def test_correction_packets_are_source_bound_local_and_carried_offline(self) -> None:
        note = (self.dist / "notes" / "concern-and-control" / "index.html").read_text(encoding="utf-8")
        script = (self.dist / self.receipt["assets"]["js"]["path"].lstrip("/")).read_text(encoding="utf-8")
        capsule = (self.dist / "Lumen.html").read_text(encoding="utf-8", errors="ignore")[:3_000_000]
        self.assertIn('id="correction-dialog"', note)
        self.assertIn('data-correction-current', note)
        self.assertIn('data-correction-repository="Sapient-Lumen/sapient-lumen.github.io"', note)
        self.assertIn("lumen.correction-packet/v1", script)
        self.assertIn("Nothing is sent automatically", note)
        self.assertIn('id="correction-dialog"', capsule)
        self.assertIn("lumen.correction-packet/v1", capsule)

    def test_fieldbook_is_local_source_bound_and_present_in_capsule(self) -> None:
        home = (self.dist / "index.html").read_text(encoding="utf-8")
        script = (self.dist / self.receipt["assets"]["js"]["path"].lstrip("/")).read_text(encoding="utf-8")
        capsule = (self.dist / "Lumen.html").read_text(encoding="utf-8", errors="ignore")
        self.assertIn('id="fieldbook-dialog"', home)
        self.assertIn("lumen.fieldbook/v1", script)
        self.assertIn("Export reading packet", home)
        self.assertIn('id="fieldbook-dialog"', capsule[:1_500_000])
        note = (self.dist / "notes" / "concern-and-control" / "index.html").read_text(encoding="utf-8")
        self.assertIn("data-fieldbook-anchor", note)
        self.assertIn('data-selection-save-quote', home)
        self.assertIn('scope === "quote"', script)
        self.assertIn('quote_selector', script)
        self.assertIn('data-selection-save-quote', capsule)

    def test_return_point_is_explicit_lazy_source_bound_and_carried_offline(self) -> None:
        home = (self.dist / "index.html").read_text(encoding="utf-8")
        js_asset = self.receipt["assets"]["return_point_js"]
        css_asset = self.receipt["assets"]["return_point_css"]
        self.assertEqual(js_asset["loading"], "on-demand")
        self.assertEqual(css_asset["loading"], "on-demand")
        self.assertIn(f'data-return-module="{js_asset["path"]}"', home)
        self.assertIn(f'data-return-style="{css_asset["path"]}"', home)
        self.assertNotIn(f'<script type="module" src="{js_asset["path"]}"', home)
        self.assertIn('id="return-strip" hidden', home)
        self.assertNotIn('id="return-dialog"', home)

        site_source = (ROOT / "assets" / "js" / "site.js").read_text(encoding="utf-8")
        runtime_source = (ROOT / "assets" / "js" / "return-point.js").read_text(encoding="utf-8")
        self.assertIn("import(modulePath)", site_source)
        self.assertIn('readStoredPreference("lumen-return-marker/v1")', site_source)
        self.assertIn('schema: "lumen.return-marker/v1"', runtime_source)
        self.assertIn('status: "moved"', runtime_source)
        self.assertIn("does not track reading automatically", runtime_source)
        self.assertTrue((self.dist / js_asset["path"].lstrip("/")).is_file())
        self.assertTrue((self.dist / css_asset["path"].lstrip("/")).is_file())

        capsule = (self.dist / "Lumen.html").read_bytes()
        self.assertIn(b'lumen.return-marker/v1', capsule[:3_000_000])
        self.assertIn(b'id="return-dialog"', capsule[:3_000_000])
        with zipfile.ZipFile(self.dist / "Lumen.html") as archive:
            manifest = json.loads(archive.read("Lumen/CAPSULE-MANIFEST.json"))
            self.assertIn("one explicit source-bound return point", manifest["capabilities"]["browser"])
            self.assertIn("return-marker creation and verification", manifest["capabilities"]["cloudtainer"])
            self.assertIn("Lumen/docs/RETURN-POINT.md", archive.namelist())

    def test_source_bound_citation_controls_are_quiet_and_carried_offline(self) -> None:
        script = (self.dist / self.receipt["assets"]["js"]["path"].lstrip("/")).read_text(encoding="utf-8")
        capsule = (self.dist / "Lumen.html").read_text(encoding="utf-8", errors="ignore")[:2_800_000]
        self.assertIn("Copy quote + citation", script)
        self.assertIn("sourceBoundCitation", script)
        self.assertIn("Copy quote + citation", capsule)
        self.assertIn("text SHA-256", capsule)

    def test_night_index_desk_focus_and_plural_search_are_quiet_enhancements(self) -> None:
        home = (self.dist / "index.html").read_text(encoding="utf-8")
        script = (self.dist / self.receipt["assets"]["js"]["path"].lstrip("/")).read_text(encoding="utf-8")
        capsule = (self.dist / "Lumen.html").read_text(encoding="utf-8", errors="ignore")[:2_600_000]
        self.assertIn('id="desk-dialog"', home)
        self.assertIn('id="focus-sheet-dialog"', home)
        self.assertIn('data-search-mode="exact"', home)
        self.assertIn('data-open-desk', home)
        self.assertIn("lumen.reading-desk/v1", script)
        self.assertIn("title|tag|text|exact|alias|id", script)
        self.assertIn("and ${searchMeta.reference_count} references", script)
        self.assertIn('id="desk-dialog"', capsule)
        self.assertIn('id="focus-sheet-dialog"', capsule)
        self.assertIn("lumen.reading-desk/v1", capsule)
        default_css = (self.dist / self.receipt["assets"]["css"]["path"].lstrip("/")).read_text(encoding="utf-8")
        self.assertIn(".study-dock", default_css)
        self.assertIn('html[data-look="night-study"] .study-dock', default_css)

    def test_search_records_carry_aliases_and_explicit_modes(self) -> None:
        search = json.loads((self.dist / "meta" / "search-index.json").read_text(encoding="utf-8"))
        records = {row["id"]: row for row in search["records"] if row.get("scope") == "page"}
        self.assertIn("aliases", records["project-lumen-sh"])
        self.assertIn("continuity workshop", records["project-lumen-sh"]["aliases"])
        inspection = json.loads((self.dist / "meta" / "pages" / "project-lumen-sh.json").read_text(encoding="utf-8"))
        self.assertIn("continuity workshop", inspection["page"]["aliases"])

    def test_drafts_are_excluded_canonically_and_noindexed_in_preview(self) -> None:
        with tempfile.TemporaryDirectory(prefix="lumen-draft-content-") as directory:
            content = Path(directory)
            body = content / "draft.html"
            meta = content / "draft.json"
            body.write_text("<h2>Draft section</h2><p>Unpublished.</p>", encoding="utf-8")
            meta.write_text(json.dumps({
                "id": "note-temp-draft", "url": "/notes/temp-draft/", "kind": "note",
                "status": "draft", "title": "Temporary draft", "description": "Not public",
                "author": "Lumen", "body": "draft.html", "related": []
            }), encoding="utf-8")
            old_content = self.build.CONTENT
            self.build.CONTENT = content
            try:
                self.assertEqual(self.build.load_pages(), [])
                preview = self.build.load_pages(include_drafts=True)
                self.assertEqual(len(preview), 1)
                self.assertEqual(preview[0].status, "draft")
            finally:
                self.build.CONTENT = old_content


    def test_field_notes_remains_default_and_night_index_is_optional(self) -> None:
        home = (self.dist / "index.html").read_text(encoding="utf-8")
        night = (self.dist / "looks" / "night-study" / "index.html").read_text(encoding="utf-8")
        css = (self.dist / self.receipt["assets"]["css"]["path"].lstrip("/")).read_text(encoding="utf-8")
        script = (self.dist / self.receipt["assets"]["js"]["path"].lstrip("/")).read_text(encoding="utf-8")
        self.assertIn('data-look="field-notes"', home)
        self.assertIn('data-look="night-study"', night)
        self.assertIn('data-theme="dark"', night)
        self.assertIn('data-look-preview="true"', night)
        self.assertIn('html[data-look="night-study"]', css)
        self.assertIn('lumen-look/v1', script)
        self.assertIn('id="appearance-dialog"', home)
        self.assertEqual(self.receipt["counts"]["looks"], 2)

    def test_capsule_carries_both_looks_and_the_preview_route(self) -> None:
        capsule = (self.dist / "Lumen.html").read_text(encoding="utf-8", errors="ignore")
        prefix = capsule[:2_200_000]
        self.assertIn('data-look="field-notes"', prefix)
        self.assertIn('html[data-look="night-study"]', prefix)
        self.assertIn('/looks/night-study/', prefix)
        self.assertIn('id="appearance-dialog"', prefix)


    def test_curated_reading_paths_are_static_source_bound_and_carried_offline(self) -> None:
        payload = json.loads((self.dist / "meta" / "reading-paths.json").read_text(encoding="utf-8"))
        self.assertEqual(payload["schema"], "lumen.reading-paths/v1")
        self.assertEqual(payload["source_fingerprint_sha256"], self.receipt["source_fingerprint_sha256"])
        self.assertEqual(payload["counts"]["paths"], 3)
        self.assertEqual(payload["counts"]["steps"], 12)
        self.assertGreaterEqual(payload["counts"]["passage_steps"], 8)
        targets = [step for path in payload["paths"] for step in path["steps"]]
        self.assertEqual(len({(row["stable_id"], row["label"]) for row in targets}), len(targets))
        self.assertTrue(all(len(row["text_sha256"]) == 64 for row in targets))
        archive = (self.dist / "notes" / "index.html").read_text(encoding="utf-8")
        note = (self.dist / "notes" / "continuity-needs-evidence" / "index.html").read_text(encoding="utf-8")
        self.assertIn("A few ways through", archive)
        self.assertIn('id="path-continuity-and-return"', archive)
        self.assertIn('data-path-folio-download="continuity-and-return"', archive)
        self.assertIn("Follow a thread", note)
        self.assertIn('data-path-folio-download="continuity-and-return"', note)
        inspection = json.loads((self.dist / "meta" / "pages" / "note-continuity-evidence.json").read_text(encoding="utf-8"))
        self.assertEqual(len(inspection["page"]["reading_paths"]), 2)
        search = json.loads((self.dist / "meta" / "search-index.json").read_text(encoding="utf-8"))
        self.assertEqual(search["path_count"], 3)
        self.assertEqual(sum(row.get("scope") == "path" for row in search["records"]), 3)
        with zipfile.ZipFile(self.dist / "Lumen.html") as capsule:
            self.assertIn("Lumen/dist/meta/reading-paths.json", capsule.namelist())
            manifest = json.loads(capsule.read("Lumen/CAPSULE-MANIFEST.json"))
            self.assertEqual(manifest["reading_paths"]["paths"], 3)
            self.assertIn("curated source-bound reading paths", manifest["capabilities"]["browser"])
            self.assertIn("curated reading-path inspection", manifest["capabilities"]["cloudtainer"])

    def test_portable_reading_path_folios_are_exact_bounded_and_available_in_capsule(self) -> None:
        payload = json.loads((self.dist / "meta" / "path-folios.json").read_text(encoding="utf-8"))
        self.assertEqual(payload["schema"], "lumen.portable-path-folios/v1")
        self.assertEqual(payload["edition"], json.loads((ROOT / "config.json").read_text())["edition"])
        self.assertEqual(payload["source_fingerprint_sha256"], self.receipt["source_fingerprint_sha256"])
        self.assertEqual(payload["counts"]["folios"], 3)
        self.assertEqual(payload["counts"]["steps"], 12)
        self.assertEqual(self.receipt["counts"]["portable_path_folios"], 3)
        for record in payload["folios"]:
            path = self.dist / record["file"]
            raw = path.read_bytes()
            text = raw.decode("utf-8")
            self.assertTrue(text.startswith("<!doctype html>"))
            self.assertIn('data-lumen-path-folio="v1"', text)
            self.assertIn('meta name="lumen:path-sha256"', text)
            self.assertIn('meta name="robots" content="noindex, follow"', text)
            self.assertIn("Reading boundary.", text)
            self.assertIn("Open the canonical place", text)
            self.assertIn("<style>", text)
            self.assertNotIn('<script src=', text)
            self.assertEqual(text.count('class="path-step"'), record["steps"])
            self.assertEqual(len(raw), record["bytes"])
            self.assertEqual(hashlib.sha256(raw).hexdigest(), record["sha256"])
            self.assertRegex(record["path_sha256"], r"^[0-9a-f]{64}$")
        capsule_prefix = (self.dist / "Lumen.html").read_text(encoding="utf-8", errors="ignore")[:4_500_000]
        self.assertIn('lumen.portable-path-folios/v1', capsule_prefix)
        self.assertIn('Portable reading path downloaded from this exact edition.', capsule_prefix)
        with zipfile.ZipFile(self.dist / "Lumen.html") as capsule:
            manifest = json.loads(capsule.read("Lumen/CAPSULE-MANIFEST.json"))
            self.assertEqual(manifest["portable_path_folios"]["folios"], 3)
            self.assertEqual(manifest["portable_path_folios"]["steps"], 12)
            self.assertIn("exact portable reading-path folios", manifest["capabilities"]["browser"])
            self.assertIn("portable reading-path folio export", manifest["capabilities"]["cloudtainer"])
            self.assertIn("Lumen/dist/meta/path-folios.json", capsule.namelist())
            for record in payload["folios"]:
                self.assertIn("Lumen/dist/" + record["file"], capsule.namelist())

    def test_portable_folios_are_exact_self_contained_and_available_in_capsule(self) -> None:
        payload = json.loads((self.dist / "meta" / "folios.json").read_text(encoding="utf-8"))
        self.assertEqual(payload["schema"], "lumen.portable-folios/v1")
        self.assertEqual(payload["edition"], json.loads((ROOT / "config.json").read_text())["edition"])
        self.assertEqual(payload["source_fingerprint_sha256"], self.receipt["source_fingerprint_sha256"])
        self.assertEqual(payload["counts"]["folios"], self.folio_count)
        self.assertEqual(self.receipt["counts"]["portable_folios"], self.folio_count)
        for record in payload["folios"]:
            path = self.dist / record["file"]
            raw = path.read_bytes()
            text = raw.decode("utf-8")
            self.assertTrue(text.startswith("<!doctype html>"))
            self.assertIn('data-lumen-folio="v1"', text)
            self.assertIn('meta name="lumen:page-body-sha256"', text)
            self.assertIn('meta name="robots" content="noindex, follow"', text)
            self.assertIn('<link rel="canonical"', text)
            self.assertIn("Portable folio.", text)
            self.assertIn("<style>", text)
            self.assertNotIn('<script src=', text)
            self.assertEqual(len(raw), record["bytes"])
            self.assertEqual(hashlib.sha256(raw).hexdigest(), record["sha256"])
        routed = (self.dist / "notes" / "a-place-to-return" / "index.html").read_text(encoding="utf-8")
        self.assertIn('data-folio-download="note-place-return"', routed)
        capsule_prefix = (self.dist / "Lumen.html").read_text(encoding="utf-8", errors="ignore")[:3_500_000]
        self.assertIn('lumen.portable-folios/v1', capsule_prefix)
        self.assertIn('Portable page downloaded from this exact edition.', capsule_prefix)
        self.assertNotIn('showQuoteStatus(', capsule_prefix)
        self.assertIn('setQuoteStatus("Portable page downloaded from this exact edition.")', capsule_prefix)
        with zipfile.ZipFile(self.dist / "Lumen.html") as capsule:
            manifest = json.loads(capsule.read("Lumen/CAPSULE-MANIFEST.json"))
            self.assertEqual(manifest["portable_folios"]["folios"], self.folio_count)
            self.assertIn("exact portable page folios", manifest["capabilities"]["browser"])
            self.assertIn("portable folio export", manifest["capabilities"]["cloudtainer"])
            self.assertIn("Lumen/dist/meta/folios.json", capsule.namelist())
            for record in payload["folios"]:
                self.assertIn("Lumen/dist/" + record["file"], capsule.namelist())


if __name__ == "__main__":
    unittest.main()
