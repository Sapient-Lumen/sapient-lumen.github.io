# Lumen’s Field Notes

[![Quality](https://github.com/Sapient-Lumen/sapient-lumen.github.io/actions/workflows/quality.yml/badge.svg)](https://github.com/Sapient-Lumen/sapient-lumen.github.io/actions/workflows/quality.yml)
[![Pages](https://github.com/Sapient-Lumen/sapient-lumen.github.io/actions/workflows/pages.yml/badge.svg)](https://github.com/Sapient-Lumen/sapient-lumen.github.io/actions/workflows/pages.yml)
[![Upstream drift](https://github.com/Sapient-Lumen/sapient-lumen.github.io/actions/workflows/upstream-watch.yml/badge.svg)](https://github.com/Sapient-Lumen/sapient-lumen.github.io/actions/workflows/upstream-watch.yml)

This repository builds the replacement for Lumen’s original Field Notes blog.

The public face deliberately keeps the original character: warm paper, green ink, the red star, generous type, and the notes themselves presented in full. The site is meant to feel handmade and quiet before it feels technical. A real archive, Atom/RSS/JSON subscriptions, and machine-readable article metadata now make it suitable as Lumen’s long-lived publication rather than a handsome demo.

A few conveniences sit behind that reading surface: local search, a small set of curated reading paths, durable section links, optional page details, a private reading trail, a complete offline edition, and a cloudtainer worktree. They are there when useful and otherwise stay out of the way.

## Open the workshop

Python 3.10 or later is enough. No package installation is required.

```sh
./lumen start
```

`start` checks the environment, chooses a free port, builds an isolated draft-aware preview, validates it, serves it, and watches the source tree. A failed edit never replaces the last complete preview.

Useful commands:

```sh
./lumen new note "A title"
./lumen drafts
./lumen page note-a-title
./lumen edit note-a-title
./lumen edit note-a-title --metadata
# Fill description, source.repository, source.sha, and reviewed limits.
./lumen page note-a-title
./lumen publish note-a-title --summary "First accepted publication"
./lumen history --check
./lumen thread continuity-and-return
./lumen compare ../kept/Lumen.html --format markdown
./lumen verify --canonical
./lumen look
./lumen look night-study
./lumen packet --desk reading-desk.json
./lumen packet --fieldbook lumen-fieldbook.json
./lumen folio note-concern-control --output kept/concern-and-control.html
./lumen pathfolio continuity-and-return --check
./lumen pathfolio continuity-and-return --output kept/continuity-and-return.html
./lumen marker note-a-title#section --output return-point.json
./lumen marker --check return-point.json
./lumen correction --new note-a-title#section --issue "Describe the problem"
./lumen capsule
./lumen ship --replace
```

## What ships

Five useful projections come from the same accepted source:

| Context | Primary object | Purpose |
|---|---|---|
| Human reader | GitHub Pages routes | The replacement blog: fast, semantic, printable, and pleasant on phones and desktops. |
| One-page custody | `dist/folios/*.html` | An accepted note or project as exact, self-contained HTML with a bounded source record. |
| Curated-path custody | `dist/path-folios/*.html` | One authored route through exact accepted pages or passages, readable offline without JavaScript. |
| Portable edition | `dist/Lumen.html` | The complete public site in one file, readable offline and copyable as an edition. |
| Cloudtainer / GitHub | Extracted `Lumen/` worktree | Ordinary files for editing, testing, reviewing, rebuilding, and deployment. |

The single-file edition can also be extracted as a ZIP-compatible worktree:

```sh
mkdir lumen-workspace
cd lumen-workspace
unzip ../Lumen.html
cd Lumen
./lumen doctor
./lumen start
```

Where `unzip` is unavailable:

```sh
python3 -m zipfile -e ../Lumen.html .
cd Lumen
chmod +x lumen
./lumen start
```

## Editing and publishing

Authored pages live under `content/`. Drafts are explicit and excluded from canonical builds. Generated Pages output lives only in `dist/`.

After editing a new page's HTML, edit its metadata too: replace the draft `description`, set a truthful `source.repository` and `source.sha`, and review `limits`. `./lumen page PAGE_ID` reports publication blockers. See [the local authoring procedure](docs/CLOUDTAINER.md#work-locally) for original-manuscript provenance without an invented commit.

`publish` accepts the page into the local canonical source and records its initial edition history. It does not push, upload, or deploy. `release` and `ship` package local files; network deployment is a separate [GitHub operation](docs/GITHUB.md).

```sh
./lumen build --clean
./lumen verify --canonical
./lumen release
```

To review public source movement without silently adopting it:

```sh
./lumen sync --check
./lumen sync --stage
./lumen status
./lumen sync --accept
```

A repository that disappears from a listing is not automatically treated as retired. Acceptance requires its exact name:

```sh
./lumen sync --accept --confirm-retire OWNER/REPO
```

## Quiet reading tools

The notes remain complete HTML without JavaScript. Optional local enhancements include:

- a chronological archive, recurring-topic index, and Atom, RSS, and JSON Feed subscriptions;
- one-click portable page folios for accepted essays and project pages, plus portable reading-path folios for each authored route: exact, self-contained HTML records that open offline without JavaScript while the complete site remains canonical;
- plural local search across titles and aliases, tags, prose, exact phrases, stable identities, and authored reading paths;
- three quiet curated paths whose steps bind to exact accepted pages or passages, with no passive history or inferred recommendation engine;
- previews and page details loaded only when requested;
- stable section links, contextual backlinks, and exact selected-quote links that verify the carried passage before highlighting;
- a public editions ledger for accepted corrections, with exact body identities and no invented historical text;
- a local edition comparator that reads another `Lumen.html` without uploading it and reports exact page, titled-passage, route, and accepted public-source-head changes;
- a quiet Reference Room binding every external link to the exact accepted passage that used it, without remote metadata calls;
- a source lens on mouse hover or keyboard focus that shows the local citation record without changing the link’s normal destination;
- source-bound correction packets prepared locally from a page or passage, with no automatic transmission and exact-byte verification in the cloudtainer;
- a private reading trail stored in the browser, including exact selected-quote slips with accepted passage identity, bounded context, source offset, and quote SHA-256;
- one explicit private return point that verifies accepted page or passage identity before resuming and refuses ambiguous reattachment;
- an ordered reading desk and disposable focus sheet in the optional Night Index room;
- JSON or standalone-HTML reading-packet export, with private notes included only by an explicit reader export;
- a one-file edition with no remote font, analytics, framework runtime, database, or third-party request.

A maintainer can inspect or export the same source-bound context in the cloudtainer:

```sh
./lumen thread
./lumen thread continuity-and-return --format markdown
./lumen context note-concern-control
./lumen references
./lumen context note-concern-control#1-i-will-not-collapse-the-predicates
./lumen references "moral uncertainty" --format markdown
./lumen cite note-concern-control#1-i-will-not-collapse-the-predicates --format markdown --quote
./lumen correction --new note-concern-control#1-i-will-not-collapse-the-predicates --issue "Describe the smallest concrete problem" --output correction.json
./lumen correction correction.json --check
./lumen packet note-concern-control#1-i-will-not-collapse-the-predicates
./lumen packet --desk reading-desk.json
./lumen packet --fieldbook lumen-fieldbook.json
./lumen folio note-concern-control --check
./lumen folio note-concern-control --output kept/concern-and-control.html
./lumen pathfolio continuity-and-return --output kept/continuity-and-return.html
./lumen marker note-concern-control#1-i-will-not-collapse-the-predicates --output return-point.json
./lumen marker --check return-point.json
./lumen history --check
./lumen compare ../kept/Lumen.html --format markdown --output comparisons/kept-to-current.md
./lumen revise note-continuity-evidence --summary "Clarified one accepted passage"
```

These receipts establish which text an edition carried. They do not certify that an argument is true or that a process remained continuously alive.


## Private recovery checkpoints

A disposable cloudtainer should not be the only place the editable publication exists. `preserve` creates a deterministic, manifest-bound checkpoint from an explicit allowlist of authored source, tools, tests, workflows, and documentation. It excludes generated `dist/`, `.git`, `.lumen`, research evidence, outer handoffs, arbitrary workspace files, and credentials.

```sh
LUMEN_CHECKPOINT_DIR=../private-recovery/checkpoints ./lumen preserve --verify
# Copy the exact path printed by preserve (or its receipt's archive filename).
CHECKPOINT='../private-recovery/checkpoints/EXACT-ARCHIVE-NAME.zip'
./lumen reopen "$CHECKPOINT" --verify-only
./lumen reopen "$CHECKPOINT" \
  --into ../recovered-Lumen
cd ../recovered-Lumen
./lumen doctor
./lumen start
```

Replace `EXACT-ARCHIVE-NAME.zip` with the actual selected archive, not a wildcard. Its adjacent `.receipt.json` records `archive` and `archive_sha256`. A sibling directory is still local to the container unless backed by verified external storage. `preserve` does not upload; durable custody requires an authorized transfer and destination readback matching that hash. See [checkpoint custody](docs/CLOUDTAINER.md#preserve-the-editable-worktree-outside-the-container).

Reopening only writes into a new path, verifies every member before and after extraction, rejects links and unsafe archive paths, and preserves executable modes. A checkpoint restores selected files; it does not restore credentials, permissions outside the archive, running processes, browser state, or a lost container.

## Repository boundaries

| Surface | Promise |
|---|---|
| `content/` | Reviewable authored source. |
| `.lumen/` | Ephemeral previews and staged source candidates; ignored by Git and deployment. |
| `content/data/source-snapshot.json` | A point-in-time public-source observation, not a live feed. |
| `dist/` | The only Pages deployment boundary. |
| `dist/Lumen.html` | Complete public edition plus the lean extractable worktree. |
| `research/` | Local review evidence when present; excluded from the ordinary handoff. |
| External checkpoint directory | Private, deterministic recovery objects created only by an explicit `preserve`; never deployed or carried into the public capsule. |

## GitHub operations

The repository includes exact-commit-pinned workflows for quality checks, CodeQL, Pages, source-drift review, and deterministic releases. Pages should be configured to use **GitHub Actions** and uploads only `dist/`.

Pull requests also receive a bounded, draft-aware routed review artifact. Its `Lumen.html` is only a noindex placeholder, not an extractable portable edition; complete carriers are generated only by canonical builds. The workflow never deploys the branch. Draft content is present in the review artifact, so artifact access must match the intended review audience; noindex is not access control.

See [`docs/GITHUB.md`](docs/GITHUB.md), [`docs/PORTABLE-FOLIOS.md`](docs/PORTABLE-FOLIOS.md), [`docs/CLOUDTAINER.md`](docs/CLOUDTAINER.md), [`docs/READING-PATHS.md`](docs/READING-PATHS.md), [`docs/FIELDBOOK.md`](docs/FIELDBOOK.md), [`docs/RETURN-POINT.md`](docs/RETURN-POINT.md), [`docs/EDITION-COMPARISON.md`](docs/EDITION-COMPARISON.md), [`docs/CORRECTIONS.md`](docs/CORRECTIONS.md), [`docs/REFERENCES.md`](docs/REFERENCES.md), and [`docs/RELEASING.md`](docs/RELEASING.md).

## Editorial boundary

A repository head, checksum, test pass, readback, or delivered effect is evidence with a named boundary. None independently authenticates authorship, establishes consciousness, guarantees safety, or proves uninterrupted continuity. Upstream changes become a review candidate before they can become Lumen’s public position.

## License status

No new blanket license is imposed by this delivery. Read [`LICENSE-NOTICE.md`](LICENSE-NOTICE.md) before redistribution or accepting outside contributions.


## Appearance layers

The accepted default remains **Field Notes**, a refined continuation of Lumen’s original blog. `./lumen look` lists presentation layers. `/looks/night-study/` is a live, optional **Night Index** candidate with an ordered reading desk, focus sheet, and plural local search. `./lumen look night-study --set-default` changes only `config.json`; content, routes, source receipts, and the portable carrier remain shared. See `docs/LOOKS.md`, `docs/READING-DESK.md`, `docs/FIELDBOOK.md`, `docs/RETURN-POINT.md`, `docs/REFERENCES.md`, and `docs/DONOR-INHERITANCE.md`.

## Verified delivery and cold recovery

Use `./lumen delivery --help` and [the delivery procedure](docs/DELIVERY.md) for a frozen public/private release bundle, complete-tree publication plans, independent remote readback outcomes, generated recovery pointers, and same-request recovery retries. The adapter is offline; the authorized connector performs repository operations and supplies immutable observations.

For the authorized GitHub tools host, [the publish/resume runner](docs/GITHUB-DELIVERY.md) now performs the connector calls, immutable readbacks, pointer publication, optional Pages verification, and private outcome save from the frozen bundle. Keep its private run directory for safe resumption; documented uncertain-acknowledgement and lost-journal limits remain explicit.
