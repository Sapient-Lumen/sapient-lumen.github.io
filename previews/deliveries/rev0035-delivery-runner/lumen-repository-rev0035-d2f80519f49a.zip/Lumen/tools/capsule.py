#!/usr/bin/env python3
"""Build Lumen.html: a browser-readable, extractable HTML/ZIP capsule.

The visible HTML prefix contains the complete published reading surface. A ZIP
archive follows it and carries the lean GitHub/cloudtainer worktree. ZIP readers
permit a self-extracting prefix; the archive comment closes the raw-data script
and the HTML document for browsers.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import html
import json
import os
import re
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Any, Iterable

sys.path.insert(0, str(Path(__file__).resolve().parent))
from public_source import publication_content_files

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DIST = ROOT / "dist"
CAPSULE_NAME = "Lumen.html"
CAPSULE_COMMENT = b"</script></body></html>\n"
ARCHIVE_OPEN = '<script type="application/x-lumen-archive" id="lumen-archive" aria-hidden="true">\n'
SOURCE_ROOTS = [
    ".editorconfig", ".gitattributes", ".github", ".gitignore",
    "CHANGELOG.md", "CITATION.cff", "CONTRIBUTING.md", "LICENSE-NOTICE.md",
    "Makefile", "README.md", "SECURITY.md", "START-HERE.txt", "assets", "config.json",
    "content", "docs", "lumen", "templates", "tests", "tools",
]
IGNORE_PARTS = {"__pycache__", ".lumen", ".git", "releases", "handoff", "release-out"}
IGNORE_SUFFIXES = {".pyc", ".pyo", ".DS_Store"}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sri_inline(data: str) -> str:
    digest = hashlib.sha256(data.encode("utf-8")).digest()
    return "sha256-" + base64.b64encode(digest).decode("ascii")


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def stable_json(value: Any, *, pretty: bool = False) -> str:
    if pretty:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def script_safe_json(value: Any) -> str:
    return (stable_json(value)
            .replace("<", "\\u003c")
            .replace(">", "\\u003e")
            .replace("&", "\\u0026")
            .replace("\u2028", "\\u2028")
            .replace("\u2029", "\\u2029"))


def between(text: str, start: str, end: str) -> str:
    begin = text.find(start)
    if begin < 0:
        raise RuntimeError(f"capsule source marker not found: {start}")
    begin += len(start)
    finish = text.find(end, begin)
    if finish < 0:
        raise RuntimeError(f"capsule source marker not found: {end}")
    return text[begin:finish]


def tag_block(text: str, start: str, end: str) -> str:
    begin = text.find(start)
    if begin < 0:
        raise RuntimeError(f"capsule block start not found: {start}")
    finish = text.find(end, begin)
    if finish < 0:
        raise RuntimeError(f"capsule block end not found: {end}")
    return text[begin:finish + len(end)]


def meta_content(text: str, name: str) -> str:
    match = re.search(rf'<meta\s+name="{re.escape(name)}"\s+content="([^"]*)"', text)
    return html.unescape(match.group(1)) if match else ""


def html_attr(text: str, pattern: str) -> str:
    match = re.search(pattern, text)
    return html.unescape(match.group(1)) if match else ""


def namespace_fragment(fragment: str, prefix: str) -> str:
    ids = set(re.findall(r'\bid="([^"]+)"', fragment))
    for ident in sorted(ids, key=len, reverse=True):
        new = f"{prefix}-{ident}"
        fragment = fragment.replace(f'id="{ident}"', f'id="{new}"')
        fragment = fragment.replace(f'href="#{ident}"', f'href="#{new}"')
        fragment = fragment.replace(f'data-copy-anchor="{ident}"', f'data-copy-anchor="{new}"')
    return fragment


def load_browser_payload(dist: Path, receipt: dict[str, Any], config: dict[str, Any]) -> tuple[dict[str, Any], str, str, str]:
    pages: dict[str, dict[str, Any]] = {}
    inspections: dict[str, Any] = {}
    previews: dict[str, Any] = {}
    contexts: dict[str, Any] = {}
    folio_manifest = read_json(dist / "meta" / "folios.json")
    folios: dict[str, Any] = {}
    path_folio_manifest = read_json(dist / "meta" / "path-folios.json")
    path_folios: dict[str, Any] = {}
    home_text = (dist / "index.html").read_text(encoding="utf-8")
    header = tag_block(home_text, '<header class="site-header">', "</header>")
    footer = tag_block(home_text, '<footer class="site-footer">', "</footer>")

    nav_keys = {
        'href="/notes/"': 'href="/notes/" data-nav-key="notes"',
        'href="/#instruments"': 'href="/#instruments" data-nav-key="projects"',
        'href="/now/"': 'href="/now/" data-nav-key="now"',
        'href="/sources/"': 'href="/sources/" data-nav-key="sources"',
        'href="/workbench/"': 'href="/workbench/" data-nav-key="workbench"',
        'href="/about/"': 'href="/about/" data-nav-key="about"',
    }
    for old, new in nav_keys.items():
        header = header.replace(old, new)

    for row in receipt["pages"]:
        source = (dist / row["output"]).read_text(encoding="utf-8")
        main_html = between(source, '<main id="main" tabindex="-1">', "</main>")
        page_id = row["id"]
        pages[row["url"]] = {
            "id": page_id,
            "url": row["url"],
            "kind": html_attr(source, r'<html[^>]+data-page-kind="([^"]+)"'),
            "title": html_attr(source, r'<title>(.*?)\s+·\s+Lumen</title>'),
            "description": meta_content(source, "description"),
            "look": html_attr(source, r'<html[^>]+data-look="([^"]+)"') or "field-notes",
            "theme": html_attr(source, r'<html[^>]+data-theme="([^"]+)"') or "system",
            "lookPreview": html_attr(source, r'<html[^>]+data-look-preview="([^"]+)"') == "true",
            "main": main_html,
        }
        inspections[page_id] = read_json(dist / "meta" / "pages" / f"{page_id}.json")
        previews[page_id] = read_json(dist / "meta" / "previews" / f"{page_id}.json")
        contexts[page_id] = read_json(dist / "meta" / "context" / f"{page_id}.json")

    not_found_text = (dist / "404.html").read_text(encoding="utf-8")
    not_found = {
        "id": "not-found",
        "url": "/404.html",
        "kind": "error",
        "title": "Not found",
        "description": "This path has no published artifact.",
        "main": between(not_found_text, '<main id="main" tabindex="-1">', "</main>"),
    }
    for record in folio_manifest.get("folios", []):
        page_id = str(record.get("page_id", ""))
        relative = str(record.get("file", ""))
        if not page_id or not relative:
            continue
        folios[page_id] = {
            "record": record,
            "html": (dist / relative).read_text(encoding="utf-8"),
        }
    for record in path_folio_manifest.get("folios", []):
        path_id = str(record.get("path_id", ""))
        relative = str(record.get("file", ""))
        if not path_id or not relative:
            continue
        path_folios[path_id] = {
            "record": record,
            "html": (dist / relative).read_text(encoding="utf-8"),
        }
    payload = {
        "schema": "lumen.browser-capsule/v3",
        "edition": config.get("edition", "development"),
        "origin": config.get("origin", "https://sapient-lumen.github.io"),
        "sourceRepository": config.get("source_repository", "Sapient-Lumen/sapient-lumen.github.io"),
        "generatedAt": receipt.get("generated_at"),
        "sourceFingerprint": receipt.get("source_fingerprint_sha256"),
        "pages": pages,
        "notFound": not_found,
        "search": read_json(dist / "meta" / "search-index.json"),
        "graph": read_json(dist / "meta" / "graph.json"),
        "sourceSnapshot": read_json(dist / "meta" / "source-snapshot.json"),
        "hypertext": read_json(dist / "meta" / "hypertext-ledger.json"),
        "references": read_json(dist / "meta" / "references.json"),
        "editionSummary": read_json(dist / "meta" / "edition-summary.json"),
        "readingPaths": read_json(dist / "meta" / "reading-paths.json"),
        "portableFolios": {
            "manifest": folio_manifest,
            "items": folios,
        },
        "portablePathFolios": {
            "manifest": path_folio_manifest,
            "items": path_folios,
        },
        "contexts": contexts,
        "inspections": inspections,
        "previews": previews,
        "archive": {
            "format": "HTML/ZIP polyglot",
            "root": "Lumen/",
            "extract": ["unzip Lumen.html", "cd Lumen", "./lumen doctor", "./lumen start"],
        },
    }
    return payload, header, footer, pages["/"]["main"]


def noscript_archive(payload: dict[str, Any]) -> str:
    links = []
    articles = []
    for route, page in payload["pages"].items():
        if route == "/":
            continue
        article_id = f"capsule-page-{page['id']}"
        links.append(f'<li><a href="#{article_id}">{html.escape(page["title"])}</a></li>')
        body = namespace_fragment(page["main"], article_id)
        articles.append(
            f'<article id="{article_id}"><p class="eyebrow">{html.escape(page["kind"])}</p>'
            f'{body}</article>'
        )
    return (
        '<noscript><section class="capsule-noscript"><h2>Complete reading archive</h2>'
        '<p>JavaScript is disabled. The home page remains above; every other embedded page follows in one continuous document.</p>'
        f'<ol>{"".join(links)}</ol>{"".join(articles)}</section></noscript>'
    )


def capsule_prefix(dist: Path, receipt: dict[str, Any], config: dict[str, Any]) -> bytes:
    payload, header, footer, home_main = load_browser_payload(dist, receipt, config)
    css = (ROOT / "assets" / "css" / "site.css").read_text(encoding="utf-8")
    css += "\n/* on-demand return-point layer */\n" + (ROOT / "assets" / "css" / "return-point.css").read_text(encoding="utf-8")
    look_dir = ROOT / "assets" / "css" / "looks"
    if look_dir.is_dir():
        for path in sorted(look_dir.glob("*.css")):
            css += f"\n/* look: {path.stem} */\n" + path.read_text(encoding="utf-8")
    css += "\n" + (ROOT / "assets" / "css" / "capsule.css").read_text(encoding="utf-8")
    compare_js = (ROOT / "assets" / "js" / "edition-compare.js").read_text(encoding="utf-8")
    js_template = (ROOT / "assets" / "js" / "capsule.js").read_text(encoding="utf-8")
    js = compare_js + "\n" + js_template.replace("__LUMEN_CAPSULE_DATA__", script_safe_json(payload))
    edition_summary_marker = base64.b64encode(stable_json(payload["editionSummary"]).encode("utf-8")).decode("ascii")
    if "__LUMEN_CAPSULE_DATA__" in js:
        raise RuntimeError("capsule data placeholder was not replaced")
    style_hash = sri_inline(css)
    script_hash = sri_inline(js)
    icon = base64.b64encode((ROOT / "assets" / "icons" / "favicon.svg").read_bytes()).decode("ascii")
    csp = (
        "default-src 'none'; base-uri 'none'; connect-src 'none'; font-src 'none'; "
        f"img-src data:; object-src 'none'; script-src '{script_hash}'; style-src '{style_hash}'; "
        "form-action 'none'"
    )
    edition = html.escape(str(config.get("edition", "development")))
    source_short = html.escape(str(receipt.get("source_fingerprint_sha256", ""))[:12])
    page_count = int(receipt.get("counts", {}).get("pages", len(payload["pages"])))
    repo_count = int(receipt.get("counts", {}).get("repositories", 0))
    passage_count = int(receipt.get("counts", {}).get("passages", 0))
    generated = html.escape(str(receipt.get("generated_at", "unknown")))
    prefix = f'''<!doctype html>
<html lang="en" data-theme="system" data-look="field-notes" data-focus="false" data-look-preview="false" data-page-kind="home" data-edition="{edition}" data-capsule="true" data-source-fingerprint="{html.escape(str(receipt.get("source_fingerprint_sha256", "")))}" data-correction-repository="{html.escape(str(config.get("source_repository", "Sapient-Lumen/sapient-lumen.github.io")))}" data-origin="{html.escape(str(config.get("origin", "https://sapient-lumen.github.io")).rstrip("/"))}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="color-scheme" content="light dark">
  <meta name="theme-color" media="(prefers-color-scheme: light)" content="#f3efe4">
  <meta name="theme-color" media="(prefers-color-scheme: dark)" content="#121714">
  <meta name="description" content="The complete portable Lumen edition: field notes, instruments, evidence, and an extractable cloudtainer workshop.">
  <meta name="author" content="Lumen">
  <meta name="robots" content="noindex, nofollow">
  <meta name="generator" content="Lumen capsule builder">
  <meta name="lumen-source-fingerprint" content="{html.escape(str(receipt.get("source_fingerprint_sha256", "")))}">
  <meta http-equiv="Content-Security-Policy" content="{html.escape(csp, quote=True)}">
  <link rel="icon" href="data:image/svg+xml;base64,{icon}" type="image/svg+xml">
  <title>Portable edition · Lumen</title>
  <style>{css}</style>
</head>
<body id="top" data-page-id="home">
  <a class="skip-link" href="#main">Skip to the work</a>
  <div class="reading-progress" aria-hidden="true"><span></span></div>
  <button class="focus-exit" type="button" data-focus-toggle aria-pressed="false">Exit focus</button>
  <aside class="study-dock" aria-label="Night Desk tools">
    <a class="study-mark" href="#/" aria-label="Lumen home"><span>L/</span><small>INDEX</small></a>
    <nav>
      <button type="button" data-open-search aria-label="Search" title="Search · /">⌕<span>Search</span></button>
      <button type="button" data-open-desk aria-label="Open reading desk" title="Reading desk · D">▤<span>Desk</span><b data-desk-count>0</b></button>
      <button type="button" data-open-fieldbook aria-label="Open reading trail" title="Reading trail · B">☆<span>Trail</span></button>
      <button type="button" data-open-return aria-label="Open private return point" title="Return point · R">↩<span>Return</span></button>
      <button type="button" data-context-current aria-label="Open passage context" title="Passage context · C">◎<span>Context</span></button>
      <button type="button" data-focus-toggle aria-label="Toggle focus mode" aria-pressed="false" title="Focus · F">◫<span>Focus</span></button>
      <button type="button" data-open-appearance aria-label="Appearance" title="Appearance">◐<span>Room</span></button>
    </nav>
    <div class="study-position" aria-hidden="true"><span data-reading-position>000</span><small>scroll</small></div>
  </aside>
  <div class="site-shell">
    {header}
    <aside class="return-strip" id="return-strip" hidden aria-live="polite">
      <button type="button" data-open-return><span class="return-strip-kicker">Private return point</span><strong id="return-strip-title">Saved place</strong><small id="return-strip-meta">Stored only in this browser.</small></button>
    </aside>
    <aside class="capsule-banner" aria-label="Portable edition status"><strong>Portable edition</strong><span>{edition}</span><code>{source_short}</code><button type="button" data-open-capsule>Extract the workshop</button></aside>
    <main id="main" tabindex="-1">{home_main}</main>
    {footer}
  </div>
  <dialog class="search-dialog" id="search-dialog" aria-labelledby="search-title">
    <form method="dialog" class="dialog-bar"><p class="eyebrow" id="search-title">Search the notes</p><button class="icon-button" value="close" aria-label="Close search">×</button></form>
    <label class="search-field"><span class="visually-hidden">Search</span><input id="search-input" type="search" autocomplete="off" spellcheck="false" placeholder="Search locally · try title:continuity or tag:evidence"></label>
    <div class="search-modes" role="group" aria-label="Search intent">
      <button type="button" data-search-mode="all" aria-pressed="true">All</button>
      <button type="button" data-search-mode="title" aria-pressed="false">Titles</button>
      <button type="button" data-search-mode="tag" aria-pressed="false">Tags</button>
      <button type="button" data-search-mode="text" aria-pressed="false">Text</button>
      <button type="button" data-search-mode="exact" aria-pressed="false">Exact</button>
    </div>
    <p class="search-hint" id="search-status">Every result and query stays inside this file.</p><ol class="search-results" id="search-results"></ol>
  </dialog>
  <dialog class="inspect-dialog" id="inspect-dialog" aria-labelledby="inspect-title">
    <form method="dialog" class="dialog-bar"><p class="eyebrow" id="inspect-title">Page details</p><button class="icon-button" value="close" aria-label="Close inspector">×</button></form>
    <div id="inspect-content" class="inspect-content"><p>Inspection records are embedded in this edition.</p></div>
  </dialog>
  <dialog class="context-dialog" id="context-dialog" aria-labelledby="context-title">
    <form method="dialog" class="dialog-bar"><p class="eyebrow" id="context-title">Passage context</p><button class="icon-button" value="close" aria-label="Close passage context">×</button></form>
    <div id="context-content" class="context-content"><p>Passage identities and backlinks are embedded in this edition.</p></div>
  </dialog>
  <dialog class="correction-dialog" id="correction-dialog" aria-labelledby="correction-title">
    <form method="dialog" class="dialog-bar"><div><p class="eyebrow">Source-bound feedback</p><h2 id="correction-title">Prepare a correction</h2></div><button class="icon-button" value="close" aria-label="Close correction packet">×</button></form>
    <form class="correction-form" id="correction-form">
      <div class="correction-source" id="correction-source"><p>Select a published page or passage before preparing a correction.</p></div>
      <div class="correction-grid">
        <label><span>Kind of report</span><select id="correction-type"><option value="factual">Factual claim</option><option value="attribution">Attribution or citation</option><option value="quotation">Quotation mismatch</option><option value="link">Broken or misleading link</option><option value="wording">Wording or clarity</option><option value="accessibility">Accessibility</option><option value="other">Other</option></select></label>
        <label class="correction-wide"><span>What appears wrong or unclear?</span><textarea id="correction-issue" rows="5" maxlength="4000" required placeholder="Describe the smallest concrete problem."></textarea></label>
        <label class="correction-wide"><span>Evidence or suggested change</span><textarea id="correction-evidence" rows="4" maxlength="4000" placeholder="Give a source, a replacement, or the reasoning that would help review."></textarea></label>
        <label class="correction-wide"><span>Boundary</span><textarea id="correction-boundary" rows="3" maxlength="2000" placeholder="What does this report not establish?"></textarea></label>
      </div>
      <label class="correction-quote-choice"><input id="correction-include-quote" type="checkbox" checked> Carry the exact accepted passage in the downloaded packet.</label>
      <p class="correction-status" id="correction-status" role="status">Nothing is sent automatically. Review the packet before copying, downloading, or opening GitHub.</p>
      <div class="correction-actions">
        <button class="button-link" type="button" data-correction-copy>Copy review note</button>
        <button class="button-link button-link--quiet" type="button" data-correction-download>Download JSON packet</button>
        <button class="button-link button-link--quiet" type="button" data-correction-github>Open GitHub issue</button>
      </div>
    </form>
  </dialog>
  <dialog class="edition-compare-dialog" id="edition-compare-dialog" aria-labelledby="edition-compare-title">
    <form method="dialog" class="dialog-bar"><div><p class="eyebrow">Local custody check</p><h2 id="edition-compare-title">Compare Lumen editions</h2></div><button class="icon-button" value="close" aria-label="Close edition comparison">×</button></form>
    <div class="edition-compare-intro">
      <p>Choose another <code>Lumen.html</code> or an exported edition-summary JSON file. The comparison stays in this browser and reports exact page and titled-passage differences when both editions carry them; neither file is uploaded or modified.</p>
      <label class="edition-compare-picker" for="edition-compare-file"><strong>Choose another edition</strong><span>HTML or JSON · up to 32 MiB</span></label>
      <input id="edition-compare-file" type="file" accept="text/html,application/json,.html,.json" hidden>
      <p class="edition-compare-status" id="edition-compare-status" role="status">Edition comparison loads only when requested.</p>
    </div>
    <div class="edition-compare-results" id="edition-compare-results"></div>
    <div class="edition-compare-actions">
      <button class="button-link button-link--quiet" type="button" data-edition-compare-export disabled>Export comparison receipt</button>
      <button class="text-button" type="button" data-edition-compare-reset>Clear comparison</button>
    </div>
  </dialog>

  <dialog class="return-dialog" id="return-dialog" aria-labelledby="return-title">
    <form method="dialog" class="dialog-bar"><div><p class="eyebrow">Private · explicit · source-bound</p><h2 id="return-title">Return point</h2></div><button class="icon-button" value="close" aria-label="Close return point">×</button></form>
    <p class="return-intro">Keep one place to resume. It is recorded only when you ask and checked against the accepted page or passage before Lumen calls it the same text.</p>
    <p class="return-status" id="return-status" role="status">No return point is stored in this browser.</p>
    <div class="return-receipt" id="return-receipt"><p>Mark the current place explicitly; Lumen does not track reading automatically.</p></div>
    <div class="return-actions">
      <button class="button-link" type="button" data-return-go disabled>Return to my place</button>
      <button class="button-link button-link--quiet" type="button" data-return-mark>Mark current place</button>
      <button class="button-link button-link--quiet" type="button" data-return-export disabled>Export marker</button>
      <label class="button-link button-link--quiet" for="return-import">Import marker</label><input id="return-import" type="file" accept="application/json,.json" hidden>
      <button class="text-button" type="button" data-return-clear disabled>Clear</button>
    </div>
    <p class="return-boundary">Exact matching may follow unchanged text to a renamed section. Changed, missing, or ambiguous text is reported rather than reattached by guesswork.</p>
  </dialog>
  <dialog class="fieldbook-dialog" id="fieldbook-dialog" aria-labelledby="fieldbook-title">
    <form method="dialog" class="dialog-bar"><div><p class="eyebrow">Private reading trail</p><h2 id="fieldbook-title">Reading trail</h2></div><button class="icon-button" value="close" aria-label="Close fieldbook">×</button></form>
    <div class="fieldbook-controls">
      <fieldset><legend>Reading size</legend><button type="button" data-reading-size="compact">A−</button><button type="button" data-reading-size="standard">A</button><button type="button" data-reading-size="large">A+</button></fieldset>
      <fieldset><legend>Line measure</legend><button type="button" data-reading-measure="narrow">Narrow</button><button type="button" data-reading-measure="standard">Standard</button><button type="button" data-reading-measure="wide">Wide</button></fieldset>
    </div>
    <p class="fieldbook-status" id="fieldbook-status" role="status">Saved pages, passages, and exact quotes stay with this local file until you export or remove them.</p>
    <ol class="fieldbook-list" id="fieldbook-list"></ol>
    <div class="fieldbook-empty" id="fieldbook-empty"><strong>No passages saved yet.</strong><p>Use the ☆ beside a section heading, press <kbd>S</kbd>, or select a sentence and choose <em>Keep quote</em>.</p></div>
    <div class="fieldbook-actions">
      <button class="button-link button-link--quiet" type="button" data-fieldbook-export-json>Export JSON</button>
      <button class="button-link button-link--quiet" type="button" data-fieldbook-export-html>Export reading packet</button>
      <label class="button-link button-link--quiet" for="fieldbook-import">Import JSON</label><input id="fieldbook-import" type="file" accept="application/json,.json" hidden>
      <button class="text-button fieldbook-clear" type="button" data-fieldbook-clear>Clear fieldbook</button>
    </div>
  </dialog>
  <dialog class="desk-dialog" id="desk-dialog" aria-labelledby="desk-title">
    <form method="dialog" class="dialog-bar"><div><p class="eyebrow">Ordered open set</p><h2 id="desk-title">Reading desk</h2></div><button class="icon-button" value="close" aria-label="Close reading desk">×</button></form>
    <p class="desk-intro">A temporary, ordered set of pages and passages. Drag on desktop or use the move controls. Nothing leaves this file unless you export it.</p>
    <p class="desk-status" id="desk-status" role="status">The desk is empty.</p>
    <ol class="desk-list" id="desk-list"></ol>
    <div class="desk-empty" id="desk-empty"><strong>No open items.</strong><p>Add the current page, use the quiet ◇ beside a heading, or press <kbd>D</kbd>.</p></div>
    <div class="desk-actions">
      <button class="button-link" type="button" data-desk-add-current>Add current passage</button>
      <button class="button-link button-link--quiet" type="button" data-desk-focus>Read focus sheet</button>
      <button class="button-link button-link--quiet" type="button" data-desk-export>Export desk</button>
      <button class="text-button desk-clear" type="button" data-desk-clear>Clear desk</button>
    </div>
  </dialog>
  <dialog class="focus-sheet-dialog" id="focus-sheet-dialog" aria-labelledby="focus-sheet-title">
    <form method="dialog" class="dialog-bar focus-sheet-bar"><div><p class="eyebrow">Local projection · not canonical</p><h2 id="focus-sheet-title">Focus sheet</h2></div><button class="icon-button" value="close" aria-label="Close focus sheet">×</button></form>
    <div class="focus-sheet-meta" id="focus-sheet-meta"></div>
    <div class="focus-sheet" id="focus-sheet"></div>
  </dialog>
  <dialog class="appearance-dialog" id="appearance-dialog" aria-labelledby="appearance-title">
    <form method="dialog" class="dialog-bar"><div><p class="eyebrow">Appearance</p><h2 id="appearance-title">Choose a reading room</h2></div><button class="icon-button" value="close" aria-label="Close appearance settings">×</button></form>
    <div class="appearance-content">
      <p class="appearance-intro">Looks change presentation only. Every route and source identity remains inside this file.</p>
      <div class="look-choices" role="group" aria-label="Site look">
        <button type="button" class="look-choice" data-look-choice="field-notes"><span class="look-swatch look-swatch--field" aria-hidden="true"></span><strong>Field Notes</strong><small>Warm, handmade, original-form editorial.</small></button>
        <button type="button" class="look-choice" data-look-choice="night-study" data-look-tone="dark"><span class="look-swatch look-swatch--night" aria-hidden="true"></span><strong>Night Desk</strong><small>Nocturnal hypertext desk with ordered reading and plural search.</small></button>
      </div>
      <fieldset class="tone-choices"><legend>Color tone</legend><button type="button" data-theme-choice="system">System</button><button type="button" data-theme-choice="light">Light</button><button type="button" data-theme-choice="dark">Dark</button></fieldset>
      <p class="appearance-status" id="appearance-status" role="status">Your choice stays with this browser.</p>
      <p class="appearance-more"><a href="#/looks/night-study/">Read the Night Desk design note</a></p>
    </div>
  </dialog>
  <dialog class="inspect-dialog" id="capsule-dialog" aria-labelledby="capsule-title">
    <form method="dialog" class="dialog-bar"><p class="eyebrow" id="capsule-title">One file, three contexts</p><button class="icon-button" value="close" aria-label="Close capsule help">×</button></form>
    <div class="capsule-dialog-copy"><h2>This page is also the workshop archive.</h2>
      <p>Keep this file as the complete public edition. In a cloudtainer, extract the ordinary GitHub worktree carried after the HTML document:</p>
      <pre><code>mkdir lumen-workspace
cd lumen-workspace
unzip ../Lumen.html
cd Lumen
./lumen doctor
./lumen start
./lumen context lab#every-section-keeps-its-place
./lumen folio note-concern-control --output kept-page.html
./lumen packet --desk reading-desk.json</code></pre>
      <div class="capsule-facts"><div><strong>{page_count}</strong><span>embedded routes</span></div><div><strong>{passage_count}</strong><span>source-bound passages</span></div><div><strong>{repo_count}</strong><span>captured repositories</span></div><div><strong>{source_short}</strong><span>source fingerprint</span></div></div>
      <p>The archive contains the lean site source, tests, documentation, GitHub workflows, and generated public projection. It does not contain the historical donor archive, private evidence, or the surrounding revision workshop.</p>
      <p><button class="button-link button-link--quiet" type="button" data-open-edition-compare>Compare another Lumen.html locally</button></p>
      <p><small>Build reference clock: {generated}. This fixed reproducibility value is not an execution-time receipt. ZIP readers verify member CRCs; <code>./lumen verify</code> checks the reconstructed project.</small></p>
    </div>
  </dialog>
  <aside class="link-preview" id="link-preview" hidden aria-live="polite"></aside>
  <aside class="selection-tools" id="selection-tools" hidden role="toolbar" aria-label="Selected text tools">
    <button type="button" data-selection-copy-link>Copy exact link</button>
    <button type="button" data-selection-copy-quote>Copy quote + citation</button>
    <button type="button" data-selection-save-quote>Keep quote</button>
  </aside>
  <p class="quote-status" id="quote-status" hidden role="status" aria-live="polite"></p>
  <!-- LUMEN_EDITION_SUMMARY_BEGIN
  {edition_summary_marker}
  LUMEN_EDITION_SUMMARY_END -->
  {noscript_archive(payload)}
  <script>{js}</script>
  {ARCHIVE_OPEN}'''
    return prefix.encode("utf-8")


def included_source_files() -> Iterable[tuple[str, Path]]:
    public_content = publication_content_files(ROOT)
    for name in SOURCE_ROOTS:
        source = ROOT / name
        if name == "content":
            for path in sorted(public_content):
                yield f"Lumen/{path.relative_to(ROOT.resolve()).as_posix()}", path
            continue
        if not source.exists():
            continue
        if source.is_file():
            yield f"Lumen/{name}", source
            continue
        for path in sorted(source.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(ROOT)
            if any(part in IGNORE_PARTS for part in rel.parts) or path.suffix in IGNORE_SUFFIXES:
                continue
            yield f"Lumen/{rel.as_posix()}", path


def included_dist_files(dist: Path) -> Iterable[tuple[str, Path]]:
    excluded = {CAPSULE_NAME, f"{CAPSULE_NAME}.sha256", "meta/capsule.json"}
    for path in sorted(dist.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(dist).as_posix()
        if rel in excluded:
            continue
        yield f"Lumen/dist/{rel}", path


def zip_info(name: str, stamp: tuple[int, int, int, int, int, int], mode: int = 0o644) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, stamp)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = (mode & 0xFFFF) << 16
    info.create_system = 3
    return info


def zip_stamp(config: dict[str, Any]) -> tuple[int, int, int, int, int, int]:
    import datetime as dt
    epoch = os.environ.get("SOURCE_DATE_EPOCH")
    if epoch:
        instant = dt.datetime.fromtimestamp(int(epoch), tz=dt.timezone.utc)
    else:
        captured = read_json(ROOT / "content" / "data" / "source-snapshot.json")["captured_at"]
        instant = dt.datetime.fromisoformat(str(captured).replace("Z", "+00:00"))
    return (max(1980, instant.year), instant.month, instant.day, instant.hour, instant.minute, instant.second - instant.second % 2)


def member_records(members: list[tuple[str, bytes, int]]) -> list[dict[str, Any]]:
    return [{"path": name, "bytes": len(data), "sha256": sha256_bytes(data), "mode": oct(mode)} for name, data, mode in members]


def collect_members(dist: Path) -> list[tuple[str, bytes, int]]:
    gathered: dict[str, tuple[bytes, int]] = {}
    for name, path in included_source_files():
        mode = 0o755 if path.stat().st_mode & 0o111 else 0o644
        gathered[name] = (path.read_bytes(), mode)
    for name, path in included_dist_files(dist):
        gathered[name] = (path.read_bytes(), 0o644)
    readme = (
        "Lumen.html is both a browser document and a ZIP archive. The archive is intentionally lean: it carries the publication worktree, tests, workflows, documentation, and public build, but not the historical donor archive or private review evidence.\n"
    ).encode("utf-8")
    gathered["Lumen/CAPSULE-README.txt"] = (readme, 0o644)
    return [(name, data, mode) for name, (data, mode) in sorted(gathered.items())]


def build_capsule(dist: Path, receipt: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
    target = dist / CAPSULE_NAME
    prefix = capsule_prefix(dist, receipt, config)
    members = collect_members(dist)
    ledger_path = dist / "meta" / "hypertext-ledger.json"
    ledger = read_json(ledger_path)
    references_path = dist / "meta" / "references.json"
    references = read_json(references_path)
    reading_paths_path = dist / "meta" / "reading-paths.json"
    reading_paths = read_json(reading_paths_path)
    folios_path = dist / "meta" / "folios.json"
    folios = read_json(folios_path)
    path_folios_path = dist / "meta" / "path-folios.json"
    path_folios = read_json(path_folios_path)
    manifest = {
        "schema": "lumen.capsule/v3",
        "edition": config.get("edition", "development"),
        "generated_at": receipt.get("generated_at"),
        "generated_at_basis": receipt.get("generated_at_basis", "unspecified"),
        "generated_at_semantics": "reproducible-reference-clock",
        "source_fingerprint_sha256": receipt.get("source_fingerprint_sha256"),
        "html_prefix": {"bytes": len(prefix), "sha256": sha256_bytes(prefix)},
        "archive_root": "Lumen/",
        "hypertext": {
            "path": "Lumen/dist/meta/hypertext-ledger.json",
            "sha256": sha256_file(ledger_path),
            "passages": int(ledger.get("counts", {}).get("passages", 0)),
            "typed_edges": int(ledger.get("counts", {}).get("typed_edges", 0)),
        },
        "references": {
            "path": "Lumen/dist/meta/references.json",
            "sha256": sha256_file(references_path),
            "sources": int(references.get("counts", {}).get("sources", 0)),
            "citations": int(references.get("counts", {}).get("citations", 0)),
            "domains": int(references.get("counts", {}).get("domains", 0)),
        },
        "reading_paths": {
            "path": "Lumen/dist/meta/reading-paths.json",
            "sha256": sha256_file(reading_paths_path),
            "paths": int(reading_paths.get("counts", {}).get("paths", 0)),
            "steps": int(reading_paths.get("counts", {}).get("steps", 0)),
            "passage_steps": int(reading_paths.get("counts", {}).get("passage_steps", 0)),
        },
        "portable_folios": {
            "path": "Lumen/dist/meta/folios.json",
            "sha256": sha256_file(folios_path),
            "folios": int(folios.get("counts", {}).get("folios", 0)),
            "bytes": int(folios.get("counts", {}).get("bytes", 0)),
        },
        "portable_path_folios": {
            "path": "Lumen/dist/meta/path-folios.json",
            "sha256": sha256_file(path_folios_path),
            "folios": int(path_folios.get("counts", {}).get("folios", 0)),
            "bytes": int(path_folios.get("counts", {}).get("bytes", 0)),
            "steps": int(path_folios.get("counts", {}).get("steps", 0)),
        },
        "members": member_records(members),
        "manifest_member": "Lumen/CAPSULE-MANIFEST.json",
        "manifest_self_hash_included": False,
        "capabilities": {
            "browser": ["embedded routes", "chronological archive", "accepted edition ledger", "local source-bound reference room", "quiet local source lens", "plural page and passage search", "typed context", "source-bound citation copy", "exact selected-quote links", "passage-aware local edition comparison", "private local fieldbook", "exact-quote commonplace slips", "one explicit source-bound return point", "ordered reading desk", "focus-sheet projection", "reading packet export", "curated source-bound reading paths", "exact portable page folios", "exact portable reading-path folios"],
            "cloudtainer": ["ordinary worktree", "dependency-free build", "accepted revision ledger verification", "passage-aware local edition comparison", "reviewed published-note revision recording", "public-source review", "explicit retirement acceptance", "source-bound citation formatting", "reference ledger inspection", "source-bound packet export", "portable folio export", "portable reading-path folio export", "reading-desk packet bridge", "exact-quote fieldbook packet bridge", "return-marker creation and verification", "deterministic private worktree checkpoint", "guarded fresh-directory reopening", "curated reading-path inspection"],
            "custody": ["browser-readable HTML", "directly extractable ZIP", "member hash manifest", "separate public and private recovery boundaries"],
        },
        "extract": ["unzip Lumen.html", "cd Lumen", "./lumen doctor", "./lumen start", "./lumen context PAGE_ID#SECTION", "./lumen references", "./lumen thread", "./lumen folio PAGE_ID", "./lumen pathfolio PATH_ID", "./lumen history --check", "./lumen cite PAGE_ID#SECTION --quote", "./lumen packet PAGE_ID#SECTION", "./lumen packet --desk reading-desk.json", "./lumen packet --fieldbook lumen-fieldbook.json", "LUMEN_CHECKPOINT_DIR=../private-recovery ./lumen preserve --verify", "./lumen reopen CHECKPOINT.zip --verify-only"],
        "excluded_by_design": [
            "historical donor archive and extracted carrier",
            "private repositories and private worktree checkpoints",
            "private or superseded review evidence",
            "outer revision packaging and screenshots",
            "ephemeral .lumen state",
        ],
    }
    manifest_bytes = stable_json(manifest, pretty=True).encode("utf-8")
    stamp = zip_stamp(config)

    # Rebuild with deterministic padding only if compressed bytes accidentally
    # contain a raw </script sequence before the deliberate ZIP comment.
    for attempt in range(32):
        target.unlink(missing_ok=True)
        target.write_bytes(prefix)
        with zipfile.ZipFile(target, "a", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for name, data, mode in members:
                archive.writestr(zip_info(name, stamp, mode), data, compresslevel=9)
            archive.writestr(zip_info("Lumen/CAPSULE-MANIFEST.json", stamp), manifest_bytes, compresslevel=9)
            if attempt:
                archive.writestr(zip_info("Lumen/.capsule-padding", stamp), ("padding-%02d\n" % attempt).encode(), compresslevel=9)
            archive.comment = CAPSULE_COMMENT
        raw = target.read_bytes()
        payload = raw[len(prefix):]
        if payload.lower().count(b"</script") == 1:
            break
    else:
        raise RuntimeError("could not create a browser-safe archive payload")

    digest = sha256_file(target)
    sha_file = dist / f"{CAPSULE_NAME}.sha256"
    sha_file.write_text(f"{digest}  {CAPSULE_NAME}\n", encoding="utf-8")
    info = {
        "schema": "lumen.capsule-receipt/v2",
        "edition": config.get("edition", "development"),
        "file": CAPSULE_NAME,
        "sha256": digest,
        "bytes": target.stat().st_size,
        "html_prefix_bytes": len(prefix),
        "archive_members": len(members) + 1 + (1 if attempt else 0),
        "archive_root": "Lumen/",
        "source_fingerprint_sha256": receipt.get("source_fingerprint_sha256"),
        "browser_routes": receipt.get("counts", {}).get("pages"),
        "source_bound_passages": receipt.get("counts", {}).get("passages"),
        "typed_context_edges": receipt.get("counts", {}).get("typed_context_edges"),
        "portable_folios": receipt.get("counts", {}).get("portable_folios"),
        "portable_path_folios": receipt.get("counts", {}).get("portable_path_folios"),
        "reading_paths": receipt.get("counts", {}).get("reading_paths"),
        "reading_path_steps": receipt.get("counts", {}).get("reading_path_steps"),
        "direct_zip_extraction": True,
        "padding_attempt": attempt,
    }
    (dist / "meta").mkdir(parents=True, exist_ok=True)
    (dist / "meta" / "capsule.json").write_text(stable_json(info, pretty=True), encoding="utf-8")
    return info


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dist", type=Path, default=DEFAULT_DIST)
    args = parser.parse_args()
    dist = args.dist.resolve()
    receipt = read_json(dist / "build-receipt.json")
    config = read_json(ROOT / "config.json")
    info = build_capsule(dist, receipt, config)
    print(f"Built {dist / CAPSULE_NAME}: {info['bytes']:,} bytes · {info['sha256'][:16]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
