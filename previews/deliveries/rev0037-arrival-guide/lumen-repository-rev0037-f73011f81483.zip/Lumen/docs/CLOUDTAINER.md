# Cloudtainer operations

Python 3.10+ is sufficient for building and ordinary workshop commands. Full verification and shipping also require an installed Node runtime for the delivery-host tests. Ruby, a database, Docker-in-Docker, npm dependencies, and Python package installation are not required.

## Arrive from the one-file edition

Preferred extraction preserves the launcher’s executable mode:

```sh
mkdir lumen-workspace
cd lumen-workspace
unzip ../Lumen.html
cd Lumen
./lumen doctor
./lumen start
```

Standard-library fallback:

```sh
python3 -m zipfile -e ../Lumen.html .
cd Lumen
chmod +x lumen
./lumen doctor
./lumen start
```

The extracted tree is an ordinary repository candidate. `dist/Lumen.html` is regenerated rather than recursively carried inside itself.

## Find, read, and edit without path hunting

```sh
./lumen page note-concern-control
./lumen edit note-concern-control
./lumen edit note-concern-control --metadata
./lumen edit note-concern-control --path-only
```

`page` resolves a stable page ID, URL, title slug, filename, or metadata path. `edit` uses `--editor`, `$VISUAL`, `$EDITOR`, or an available terminal editor. It never edits generated `dist/` as the source of truth.

Passage context uses the same source-bound records as the browser:

```sh
./lumen context lab
./lumen context lab#every-section-keeps-its-place
./lumen context note-concern-control::1-i-will-not-collapse-the-predicates --json
```

The output includes exact source offsets, text and HTML fingerprints, citations, real links, and incoming/outgoing context. Add `--build` to refresh canonical context first.

Inspect the complete external-link record without contacting any publisher or metadata service:

```sh
./lumen references
./lumen references arxiv
./lumen references "moral uncertainty" --format markdown
./lumen references --format json --build
```

The ledger records authored labels, exact URLs, and the accepted passages that carried them. It does not claim that a source is available, unchanged, reliable, or sufficient support for the surrounding argument. See [`REFERENCES.md`](REFERENCES.md).

Generate a portable citation without hand-copying a title, edition, section, or fingerprint:

```sh
./lumen cite note-concern-control
./lumen cite note-concern-control#1-i-will-not-collapse-the-predicates \
  --format markdown --quote
./lumen cite lab#every-section-keeps-its-place --format json \
  --output citations/lab-section.json
```

`--quote` reads the exact canonical source slice and binds it to the citation record. The hash identifies carried text; it does not certify the argument’s truth.

Export one or more exact sections as a standalone file:

```sh
./lumen packet lab#every-section-keeps-its-place
./lumen packet --desk ~/Downloads/lumen-reading-desk-2026-10-02.json
./lumen packet note-concern-control#1-i-will-not-collapse-the-predicates \
  project-habitat-observer#current-boundary-one-interruption-one-separate-continuation \
  --output packets/close-reading.html
```

The command writes HTML plus a companion JSON receipt. It uses the built context and verifies every source slice before writing; it does not contact a network.

Keep or review one explicit return point without importing browser history:

```sh
./lumen marker note-concern-control#1-i-will-not-collapse-the-predicates \
  --output return-point.json
./lumen marker --check return-point.json
./lumen marker --check return-point.json --format json \
  --output return-point-review.json
```

The marker records stable page/passage identity, accepted text SHA-256, edition, and optional browser block position. Exact text may follow one unique moved passage; changed, missing, or ambiguous text remains unresolved. See [`RETURN-POINT.md`](RETURN-POINT.md).

## Keep one accepted page as a portable folio

The complete site remains the canonical publication, but a reader or maintainer can also keep one accepted essay or project as exact, self-contained HTML:

```sh
./lumen folio
./lumen folio note-concern-control --check
./lumen folio note-concern-control \
  --output kept/concern-and-control.html
```

The exported bytes are copied from `dist/folios/` only after `meta/folios.json` agrees on page identity, length, and SHA-256. Each folio carries the accepted prose, named passage identities, authored external links, declared related pages and reading-path membership, edition fingerprint, and body hash. It uses no JavaScript, remote font, analytics, or framework runtime. A folio is one bounded reading object, not a substitute for the whole site, Git history, or a truth certificate. See [`PORTABLE-FOLIOS.md`](PORTABLE-FOLIOS.md).

Export a private fieldbook from either browser surface and verify every kept page, passage, or exact quote against accepted source:

```sh
./lumen packet --fieldbook ~/Downloads/lumen-fieldbook.json
```

Exact quote slips must still bind to the same passage text and quote SHA-256. Changed or missing words stop the export rather than being attached by approximate similarity. Private notes enter the packet only because the reader explicitly exported them; browser storage itself is never read by the cloudtainer.

## Keep one authored reading path as a portable folio

A curated route can travel as one exact no-JavaScript HTML file:

```sh
./lumen pathfolio
./lumen pathfolio continuity-and-return --check
./lumen pathfolio continuity-and-return \
  --output kept/continuity-and-return.html
```

The export is copied from `dist/path-folios/` only after `meta/path-folios.json` agrees on path identity, ordered-step digest, length, and SHA-256. Whole-page steps carry accepted bodies; passage steps carry exact titled slices. The route remains an authored sequence, not an inferred recommendation or a substitute for the complete edition. See [`PORTABLE-PATH-FOLIOS.md`](PORTABLE-PATH-FOLIOS.md).

## Follow an authored path through accepted text

The same quiet paths shown in the Field Notes archive can be inspected without a browser or network request:

```sh
./lumen thread
./lumen thread continuity-and-return
./lumen thread evidence-in-practice --format markdown
./lumen thread concern-and-authority --format json --output thread.json
```

Each generated step includes the current route, stable page or passage identity, accepted text SHA-256, and a bounded excerpt. The command reports an authored sequence; it does not infer what Lumen or a reader “should” read next. See [`READING-PATHS.md`](READING-PATHS.md).

## Compare a kept edition without uploading it

A reader or maintainer can compare this accepted tree with another `Lumen.html` carrier or an exported `lumen.edition-summary/v2` record:

```sh
./lumen compare ../kept/Lumen.html
./lumen compare ../kept/Lumen.html --format markdown \
  --output comparisons/kept-to-current.md
./lumen compare ../kept/Lumen.html --format json \
  --output comparisons/kept-to-current.json
```

The comparison resolves stable page IDs, exact authored-body hashes, routes, metadata, accepted public-source heads, and exact titled-passage fingerprints when both editions carry them. Compatible older capsules are enriched from their carried context records without executing scripts. When passage detail is absent, the receipt says so and remains page-level. It never uploads either file, contacts GitHub, edits prose, performs fuzzy passage matching, or guesses that changed text is an improvement. Browser and cloudtainer outputs use the same `lumen.edition-comparison/v2` schema. See [`EDITION-COMPARISON.md`](EDITION-COMPARISON.md).

## Work locally

`start` runs the doctor, chooses an available local port, builds and validates a draft-aware preview, serves it, and watches source files.

```sh
./lumen status
./lumen new note "New working note"
./lumen drafts
./lumen page note-new-working-note
./lumen edit note-new-working-note
./lumen edit note-new-working-note --metadata
# Fill description, source.repository, source.sha, and reviewed limits.
./lumen page note-new-working-note
./lumen publish note-new-working-note --summary "First accepted publication"
./lumen history --check
./lumen verify --canonical
```

Before `publish`, replace the scaffold's `description`, `source.repository` (`unassigned` is blocked), and `source.sha` (`draft-unreviewed` is blocked). Keep at least one honest, reviewed `limits` entry; the scaffold limit is not a substitute for reviewing the manuscript. `page` reports these blockers, but a passing check does not prove the prose or provenance true.

For an original manuscript authored here, the validator permits an explicit non-hash `source.sha`. For example, only if accurate, use `source.repository: "Sapient-Lumen/sapient-lumen.github.io"`, retain the scaffold's actual local `source.path`, and set `source.sha: "original-manuscript-no-upstream-commit"`. This is a provenance status, not a commit hash. If the page derives from an upstream commit, record its actual reviewed identity instead. Never invent one merely to pass the gate.

`publish` changes local metadata and, for a note, records initial edition history. `verify --canonical` then checks the accepted projection. Neither command sends it anywhere. `release`, `capsule`, and `ship` also produce local artifacts; a GitHub push or Pages deployment is a separate effect.

The watcher builds into a temporary directory, validates the replacement, then swaps it into place. A bad edit leaves the previous complete preview serving.


### Revise a published note without erasing its earlier projection

Published prose is guarded by `content/data/edition-history.json`. After reviewing an intentional change:

```sh
./lumen revise note-continuity-evidence \
  --summary "Removed a retired project section; earlier bytes remain in retained editions"
./lumen history --check
./lumen verify --canonical
```

A canonical build refuses changed published prose until its new body identity and reason are recorded. The ledger establishes which bytes an accepted edition carried; it does not make the prose true and it does not reconstruct an older body that was never retained.

## Review a reader correction without guessing

The public site and `Lumen.html` can prepare a `lumen.correction-packet/v1` file from an accepted page or passage. It remains local until a reader explicitly copies, downloads, or submits it. In the cloudtainer:

```sh
./lumen correction correction.json --check
./lumen correction correction.json --format markdown --output correction-review.md
```

The review classifies the binding as `exact`, `passage-stable`, `changed`, or `missing`, then prints the authored source path, byte offsets, and safe edit/context commands. It never changes prose, contacts GitHub, or treats the report as correct. See `docs/CORRECTIONS.md`.

## Preserve the editable worktree outside the container

Cloudtainers are working surfaces, not durable custody by themselves. After meaningful work, create a private local checkpoint. The example directory below is just a sibling path; it is not evidence of off-container storage:

```sh
export LUMEN_CHECKPOINT_DIR=../private-recovery/checkpoints
./lumen preserve --verify
```

`preserve` first runs the local verification path when `--verify` is supplied, then writes a deterministic ZIP, SHA-256 sidecar, and JSON receipt. Its selection is intentionally narrow:

- authored `content/`, assets, templates, tools, tests, documentation, workflows, and repository control files;
- no `dist/`, `.git`, `.lumen`, caches, release/handoff output, screenshots, research evidence, credentials, or arbitrary neighboring workspace data;
- no network request and no implicit upload.

Copy the exact path printed by `preserve`. Alternatively, select its adjacent `.receipt.json` and join that receipt's `archive` filename to the checkpoint directory. Replace the placeholder below with that exact name. Do not use a wildcard: a quoted `*` stays literal, and an unquoted one may select several checkpoints.

Verify or reopen in a fresh path:

```sh
CHECKPOINT="$LUMEN_CHECKPOINT_DIR/EXACT-ARCHIVE-NAME.zip"
./lumen reopen "$CHECKPOINT" --verify-only
./lumen reopen "$CHECKPOINT" \
  --into ../recovered-Lumen
cd ../recovered-Lumen
./lumen doctor
./lumen start
```

Reopening rejects duplicate names, absolute and parent-traversal paths, backslashes, encrypted entries, and symbolic links. It verifies the declared size, mode, hash, complete member set, and aggregate content identity, writes into a temporary sibling, reads the files back, and only then atomically installs the new directory. The destination must not already exist.

For durable custody, separately transfer the selected ZIP and its receipt/sidecar to authorized private off-container storage. Read back the stored bytes and compare their SHA-256 with the local receipt's `archive_sha256`; keep the destination identity and verification result. A local receipt, local reopen, configured path, or upload acknowledgment alone does not establish that the destination holds matching bytes. No transfer is performed by `preserve` or `reopen`.

A checkpoint restores selected bytes. It does not restore a running process, browser local state, hidden credentials, provider permissions, or facts that were never preserved.

## Review moving public sources

```sh
./lumen sync --check
GITHUB_TOKEN=... ./lumen sync --stage
./lumen status
./lumen sync --accept
# A staged missing repository requires exact, explicit confirmation:
./lumen sync --accept --confirm-retire OWNER/REPO
```

Only sync contacts GitHub. Discovery is deliberately limited to the public owner listing. Private repositories, private checkpoint stores, and operational recovery content are not imported into the public source snapshot. A token is optional for public reads. Stage mode writes under `.lumen/`; accept mode performs no network request and does not edit prose. Missing repositories are not treated as deletions by inference: each must be confirmed by exact name, and its last accepted identity is retained in `retired_sources`.

## Build the custody object

```sh
./lumen capsule
python3 tools/check_capsule.py dist/Lumen.html
```

The first command creates the canonical Pages projection and the extractable carrier. The second independently checks the HTML prefix, ZIP CRCs, capsule manifest, hypertext- and reference-ledger identities, member hashes, launcher mode, and exclusion boundary.

## Deliver

```sh
./lumen ship --replace
```

`ship` runs the verified local handoff path; its name does not imply network delivery. See [same-command reproduction](RELEASING.md#same-command-reproduction) before comparing release hashes. The handoff directory contains:

- `Lumen.html` — primary browser/cloudtainer gift;
- `lumen-site-*.zip` — exact Pages projection;
- `lumen-repository-*.zip` — conventional repository import without recursive carrier bytes;
- `SHA256SUMS`, `HANDOFF.json`, and a short README.

`./lumen handoff` remains the lower-level alias used by existing automation. Private worktree checkpoints remain separate and are never folded into a public handoff automatically.

## Recover generated state

```sh
./lumen clean
./lumen doctor
./lumen build --clean
```

A staged source candidate is retained unless `./lumen clean --state` is requested. No command deletes authored content or an arbitrary output path.

## Browser fieldbook and desk handoff

Both looks can export `lumen.fieldbook/v1` JSON. `./lumen packet --fieldbook FILE` verifies page, passage, and exact-quote entries against canonical context and writes a `lumen.reading-packet/v2` packet. Private notes cross the boundary only through that explicit export.

Night Index can also export an ordered `lumen.reading-desk/v1` JSON file. `./lumen packet --desk FILE` resolves those identities against canonical source and preserves their order in a source-bound reading packet. Browser arrangements are input, not authority; current source and fingerprints are re-read in the cloudtainer.
