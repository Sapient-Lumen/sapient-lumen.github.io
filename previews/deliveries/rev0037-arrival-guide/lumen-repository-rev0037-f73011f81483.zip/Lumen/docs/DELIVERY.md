# Offline delivery adapter

`./lumen delivery` is the discoverable operator entry point for the standard-library
local adapter; `python3 tools/delivery.py` remains available standalone. The CLI
forwards verbatim through a separate interpreter, avoiding import cycles. It prepares
inspectable bytes and contracts; it does **not** publish, authenticate GitHub,
create credentials, schedule work, or claim remote recovery custody. Run it with
trusted worktree checkpoints: preparation executes the checkpoint's existing
`tools/lumen_cli.py ship` verifier/build in an isolated reopened copy.

## Local paths and safe replay

All local filesystem arguments use normalized absolute locations. Equivalent
absolute, relative, and `..` spellings refer to the same location, including when
an interrupted command is resumed from a different working directory. Normalize
after checking the supplied spelling: symlink paths and ancestors are refused,
including a symlink component canceled by a later `..`. Normalization never
resolves a symlink or changes a pinned location to a different directory. The
same checks apply to inputs, payload roots, evidence outputs, and restore targets.
Overlap checks use normalized locations as well.

Existing valid v1 finalization and recovery requests may contain absolute paths
with `..`. Replay compares only their explicit local-path fields by normalized
location, while checking every other field and the original JSON encoding.
It retains those request files byte-for-byte, together with their original
attempt request hashes and verification receipts. No migration, evidence erasure,
or replacement is needed. Changed destinations, plans, inventory identities,
contents, modes, and altered evidence still conflict. Recovery's documented
fresh `RESTORE.json` verification timestamp remains the sole normal receipt
replacement on a successful restore replay.

## Prepare a frozen delivery

Create a destination profile JSON (repository names are explicit, not inferred):

```json
{
  "public": {"repository": "example/public-site", "prefix": "releases", "branch": "main"},
  "private": {"repository": "example/private-custody", "prefix": "checkpoints", "branch": "main"}
}
```

```sh
./lumen delivery prepare \
  --release-id reviewed-edition-1 --review review-document-reference \
  --profile /private/destination-profile.json \
  --checkpoint /private/verified-checkpoint.zip \
  --output /private/new-delivery-directory
```

The public destination may additionally specify an explicit `primary_alias`,
for example `"primary_alias": "previews/lumen-workbench.html"`. Prepare copies
only the exact HANDOFF primary HTML bytes to that path. The alias must be an
HTML file outside and noncolliding with the immutable release subtree. Plan
permits an update of this one selected alias, verifies its equality to the
versioned primary, and preserves unrelated files; all versioned release paths
remain immutable. No alias or homepage replacement is inferred automatically.
Private destinations do not accept primary_alias.

The output directory must be new. It is private: DELIVERY.json includes private
inventory/identity metadata. Never upload the entire delivery directory publicly.
Only `public/` is the public payload; only `private/` is the private payload.
Each inventory is independently SHA-256 hashed, includes exact repository paths,
byte lengths, SHA-256, Git blob identity, and modes. Edition and member counts
come from the verified checkpoint, never revision-specific constants.

The checkpoint is copied once, verified, reopened into a fresh temporary tree,
and shipped through the normal canonical verification gate there. This binds
public artifacts to the frozen private source without equating two different
fingerprint algorithms. Later edits to the live worktree cannot mix the bundle.
Private drafts stay in the checkpoint; the existing public source selector and
ship verification remain responsible for the public allowlist. An optional
`--handoff /path/to/existing/handoff` verifies its exact file set and artifact
hashes and requires every public byte to match a new ship from the frozen
checkpoint, using the supplied handoff's reference clock. A mixed handoff fails.

The local release ID is namespaced under each selected destination prefix.
Replaying the identical request at the same output verifies exact payload bytes
and modes and returns the existing record. Changed checkpoint, review,
destination, part size, or supplied handoff conflicts. There is no hidden global
release-ID registry: keep the delivery record and use immutable destination
paths; the connector must refuse reusing an existing ID with different bytes.
`--part-bytes` defaults to 160000. Stable-ID replay does not rebuild artifacts.

Outcomes distinguish `local_bundle=prepared` and `local_private_bytes=verified`
from `remote_private=unobserved`, `remote_public=unobserved`, and
`remote_pointer=unobserved`. A remote public failure cannot erase this local verified
private bundle. Local private verification is not remote upload verification.

## Prepare a pinned change plan

```sh
./lumen delivery plan --bundle /private/delivery-directory \
  --scope public --baseline /private/authenticated-recursive-tree.json \
  --baseline-tree-sha FULL_TREE_OID --baseline-commit FULL_COMMIT_OID \
  --output /private/new-plan-directory
```

Repeat with `--scope private` and that destination's baseline. The first plan
output must be new (or empty). REQUEST.json pins bundle, scope, inventory,
baseline bytes/tree and baseline commit; retry the same output after interruption
or completion. Existing plan files must match exactly and are never rewritten.
Changed inputs, unpinned files, and divergent evidence are refused.
 The baseline must
come from the authorized connector's authenticated response. The local tool
cannot establish provenance or the commit-to-tree association: the connector
must pin and verify that association. It does validate the complete recursive
Git tree, independently rebuilding its object identities, and rejects truncated
or inconsistent responses. It derives all directory identities, supplies a full
candidate tree and publication_guard-compatible change plan, then runs the
existing guard. Only absent versioned payload paths are added; existing versioned paths must
match exact bytes and modes or the stable release ID conflicts. The one optional
explicit primary_alias may be updated through the same pinned guard. Every unselected
baseline path is preserved, with no inferred deletions.

OPERATION.json binds destination, review, release ID, baseline commit/tree,
candidate tree and inventory. An authorized connector must independently
validate its inputs; create exact blobs/tree/commit; verify commit parent/tree;
check the branch still equals the independently pinned baseline immediately
before its non-force ref update; and read back both the ref and returned bytes
at the immutable commit. A connector exposing only `force: false` does not offer
an atomic expected-old-SHA compare-and-swap: preflight and readback detect stale
or unexpected state but cannot remove the interval between those calls. Fail
closed on a changed baseline or unexpected readback, then reconcile explicitly.
Older v1 OPERATION.json descriptive status text mentions compare-and-swap; that
text is retained for exact plan replay compatibility and is not an atomicity
guarantee. No success boolean is accepted as evidence here.
Public and private operations are separate. A failed public operation must not
invalidate a verified private commit/readback result.

## Verify returned bytes and finalize the pointer draft

```sh
./lumen delivery finalize --bundle /private/delivery-directory \
  --private-plan /private/private-plan-directory \
  --private-observation /private/private-observation.json \
  --private-returned /private/private-returned-repository-paths \
  --project-id field-notes-site --output /private/finalization
```

The authorized connector/caller supplies an observation envelope with exactly
these six top-level keys. Values contain the original complete API objects;
additional ordinary API fields inside those objects are retained/allowed:

```json
{
  "repository": {"full_name": "example/private-custody", "private": true},
  "baseline_commit": {"sha": "PINNED_BASELINE_COMMIT", "tree": {"sha": "PINNED_BASELINE_TREE"}, "parents": []},
  "baseline_tree": {"sha": "PINNED_BASELINE_TREE", "truncated": false, "tree": []},
  "commit": {"sha": "RETURNED_IMMUTABLE_COMMIT", "tree": {"sha": "PLANNED_CANDIDATE_TREE"}, "parents": [{"sha": "PINNED_BASELINE_COMMIT"}]},
  "ref": {"ref": "refs/heads/main", "object": {"type": "commit", "sha": "RETURNED_IMMUTABLE_COMMIT"}},
  "tree": {"sha": "PLANNED_CANDIDATE_TREE", "truncated": false, "tree": []}
}
```

The abbreviated empty tree arrays above are documentation placeholders. Supply
complete recursive responses, with blob sizes for every selected payload path.
The profile must name an explicit branch (for example, `main`); the observed
ref must equal exactly `refs/heads/` plus that branch. The connector must obtain repository metadata and immutable commit/tree/byte
responses from the selected authorized repository, and preserve the branch-ref
observation. This offline tool cannot authenticate their network origin and
never accepts an `authenticated: true` assertion as a substitute. Its result
states that trust boundary explicitly.

Finalize checks exact repository/profile identity; private visibility (and
public visibility for public evidence); baseline commit/tree association; a
single exact parent equal to the pinned baseline commit; candidate commit/tree
and exact intended branch-ref association; the whole-tree publication guard; and exact returned
payload sets, modes, byte lengths, SHA-256 and Git blob identities. For private
custody it also reconstructs and verifies the checkpoint against bundle and
transport identities. Returned directories contain only the selected payload,
not unrelated repository files; complete tree responses still cover the whole
repository, including preserved paths.

Only after private verification succeeds, it writes:

- private-VERIFIED.json, retaining the actual verification time and origin boundary
- pointer-payload/recovery/field-notes-current.json, using the existing schema
- pointer-plan/{OPERATION.json,change-plan.json,candidate-tree.json}, an exact
  one-path addition/update pinned to the just-verified private commit/tree
- OUTCOMES.json, with separate private, public and pointer outcomes

The pointer includes checkpoint commit/path/hash, private content identity,
edition, repository, project ID and transport-manifest hash. It invents no
source mirror, test count, deployment, or public-preview claims. The public
result is tracked independently rather than embedded speculatively in the
recovery pointer. `--pointer-path` may explicitly select another repository
path; the default is the existing recovery/field-notes-current.json.

Optional public evidence uses all three flags together:

```sh
--public-plan /private/public-plan-directory \
--public-observation /private/public-observation.json \
--public-returned /private/public-returned-repository-paths
```

Private verification and the pointer draft are durable before this step. Bad
or missing public evidence records verification-failed and returns a nonzero
CLI exit status, without deleting the verified private result. The pointer
remains publication-pending until the authorized connector publishes the
pointer payload using pointer-plan and supplies its own immutable readback:

```sh
--pointer-observation /private/pointer-observation.json \
--pointer-returned /private/pointer-returned-repository-paths
```

The pointer observation uses the same six-key envelope and the generated
pointer plan. It must identify a separate commit whose parent is the verified
private commit and whose complete tree implements exactly the planned pointer
change. Returned pointer bytes must match the exact draft. A stale branch must
be reconciled outside this command; it never silently rebases or broadens the
reviewed change plan.

Retry the same command and finalization output after interruptions. Immutable
per-phase requests pin the bundle, reviewed plan, intended repository/branch and
returned directory. Each observation/returned-file-state combination gets its
own immutable directory under private-attempts/, public-attempts/, or
pointer-attempts/, including original observation bytes and a timed check result.
A failed or incomplete observation does not poison the operation: supply its
correction and retry in the SAME output. Failed attempts stay intact. Missing
returned files may likewise be materialized and retried against the same expected
inventory. Changed plans or targets conflict and require a new explicitly
reviewed operation. Once a phase has verified, a different commit/result cannot
replace that evidence. Unchanged verified receipts are rechecked and retained
byte-for-byte, including their original actual verification timestamps.
Previously verified optional phases remain recorded if omitted on a later
invocation, with their original verification timestamps; omission is not a new
verification. Never treat a local zero exit code as independent network proof.

## Recover exact returned checkpoint bytes

The normal input is the existing `recovery/field-notes-current.json` contract:

```json
{
  "schema_version": 1,
  "project_id": "field-notes-site",
  "repository": "example/private-custody",
  "verified_source_commit": "FULL_IMMUTABLE_PRIVATE_COMMIT_OID",
  "checkpoint_path": "checkpoints/reviewed-edition-1/checkpoint.zip.base64.parts/manifest.json",
  "checkpoint_sha256": "SHA256_OF_DECODED_CHECKPOINT_ZIP",
  "encoding": "lumen.chunked-checkpoint-transport/v1; fetch ordered parts at verified_source_commit",
  "content_identity_sha256": "PRIVATE_CHECKPOINT_CONTENT_IDENTITY",
  "edition": "reviewed-edition",
  "transport_manifest_sha256": "OPTIONAL_SHA256_OF_EXACT_TRANSPORT_MANIFEST_BYTES"
}
```

Existing pointers without the optional strengthened transport pin are accepted:
the pointer independently binds the decoded ZIP, edition, and private content
identity, which must agree with both transport and verified checkpoint. The
immutable repository/commit/path identifies the authorized retrieval operation.
Public preview and source-mirror identifiers remain independent metadata; they
are never substituted for checkpoint or public-source fingerprints.

The authorized connector creates/publishes a pointer only after verifying
immutable commit/tree membership and returned-byte evidence for the entire
private inventory. This adapter intentionally does not generate or publish a
pointer from an unverified commit string. The finalize command below issues the draft from supplied verified evidence;
authenticated retrieval and actual publication remain connector integration.
The pointer file's external SHA-256 must be pinned independently. Its commit
field is a retrieval coordinate, not local proof of remote origin. The original
thin `lumen.delivery-recovery-pointer/v1` form remains a compatibility-only
internal input (`commit`, `transport_path`, `transport_sha256`); routine operators
should use the existing field-notes-current.json file.

```sh
./lumen delivery recover --pointer /private/recovery/field-notes-current.json \
  --pointer-sha256 INDEPENDENT_POINTER_SHA256 \
  --parts /private/returned-repository-paths \
  --into /private/new-editable-worktree \
  --output /private/new-recovery-evidence
```

The parts directory mirrors repository-relative paths. Recovery validates the
pointer hash, transport hash, ordered part SHA-256/Git hashes/lengths, encoded
archive hash, strict base64, complete archive hash/length, checkpoint schema,
member identities, edition and private content identity. It invokes existing
checkpoint verification and reopening. All expected source files and modes are
read back. An existing destination is accepted only when the exact file and
directory sets, modes and contents match; altered work is refused, never
overwritten. The evidence output starts as a new private directory; retry the **same command
with the same output directory** after interruption or a lost acknowledgement.
REQUEST.json pins pointer/transport/archive identities, returned-parts location,
and restore destination. Existing evidence must match exactly. A request-only
or archive-only interruption resumes; a completed restore is reverified without
rewriting its source files. Unknown files, changed requests, divergent archives,
and divergent receipts are preserved and refused. An empty evidence directory
can be adopted if interruption happened before its request was written.

RESTORE.json records `verified_at`, the actual UTC time of the verification just
performed. A successful replay revalidates the previous receipt and replaces only
that receipt with the new verification time. It never invents an earlier completion
time. Evidence writes are atomic; this does not authorize concurrent writers or
concurrent edits to restored files. Failures may retain partial evidence for inspection.
Symlink destinations, payloads and path ancestors are refused.

## Tests

`PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -p test_delivery.py`
uses tiny synthetic checkpoints and a mocked ship operation to test adapter
contracts without recursively calling ship's test gate. It does not substitute
for the real canonical gate: normal prepare always runs ship. Run a real
checkpoint→prepare→plan→connector-readback→recover acceptance separately after
review/integration, with explicit fresh private destinations.

## Online publish/resume entry point

For the reusable authorized GitHub connector driver, bounded stop/resume,
private-pointer-public sequencing, optional exact live Pages checks, and
private outcome-record publication, see [GITHUB-DELIVERY.md](GITHUB-DELIVERY.md).
The local adapter above remains credential-free; the JS tools-host pump owns
connector calls and preserves their durable acknowledgements.
