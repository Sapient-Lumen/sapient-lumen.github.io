# Reading paths

Reading paths are small, authored sequences through the accepted publication. They are meant for a human reader who would rather follow one question than browse a directory.

The source is `content/data/reading-paths.json`. Every step names a stable page identity and may name one exact passage anchor. Canonical builds fail when a page, passage, path ID, or repeated target is invalid. Generated records add the accepted page or passage fingerprint, bounded excerpt, and current route; the authored file does not duplicate derived hashes.

The public surface stays quiet:

- the archive offers a compact set of curated threads;
- pages that belong to a thread receive a small previous/next path navigator after the essay;
- ordinary links remain ordinary links;
- no reading history is recorded and no path is chosen for the reader.

The cloudtainer exposes the same source-bound projection:

```sh
./lumen thread
./lumen thread continuity-and-return
./lumen thread evidence-in-practice --format markdown
./lumen thread concern-and-authority --format json --output thread.json
```

`dist/meta/reading-paths.json` is the generated record used by Pages, the single-file edition, tests, and the CLI. Its hashes establish which accepted text a path step named. They do not establish that the sequence is the only good reading order or that one step proves the next.
