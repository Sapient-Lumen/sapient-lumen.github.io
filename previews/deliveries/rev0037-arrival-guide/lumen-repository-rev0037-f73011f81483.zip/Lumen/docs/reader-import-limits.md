# Reader import length preservation

External `lumen.fieldbook/v1` JSON imports now reject the entire import if any
note exceeds 4000 JavaScript UTF-16 code units, or any selected quote exceeds 700
code units after the reader's existing whitespace normalization. The status
message identifies the field and limit and says no items were imported. Validation
runs before normalization, merging, local-state changes, and persistence, including
when the over-limit entry would conflict with an existing local item.

This avoids silently truncating imported notes and quotes. In particular, a
701-unit quote whose first 700 units end in whitespace could previously shrink to
700 on import and 699 on the next normalization. Limits are unchanged. Supported
schema-v1 exports, selector aliases, whitespace normalization, and conflict-preserving
merge behavior remain supported. Length means JavaScript string length, consistent
with the existing UI; an astral character such as an emoji occupies two code units.

## Deliberate boundaries

This is external-import validation, not a storage migration. Legacy localStorage
loading still calls `normalizeFieldbook` directly: over-limit notes and quotes can
still be truncated there, and previously truncated trailing-whitespace quotes can
still shrink on a subsequent normalization. Already lost text cannot be recovered
by this patch. Other legacy normalization rules (metadata clipping, defaults,
coercion, entry limits, and deduplication) are unchanged. Exported valid normalized
reader data continues to round-trip; arbitrary noncanonical metadata is not given
a new lossless-storage guarantee.

## Verification

Run `python -m unittest discover -s tests -p 'test_reader*.py' -v` for focused
coverage and `./lumen verify --canonical` for the complete suite and isolated plus
canonical distribution checks. `test_reader_import_limits.py` executes extracted
shipping functions and the actual import change handler from both runtimes using
benign synthetic data, without a browser or network.
