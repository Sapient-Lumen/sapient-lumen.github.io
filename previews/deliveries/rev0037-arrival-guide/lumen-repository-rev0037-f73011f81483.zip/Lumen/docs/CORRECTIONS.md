# Source-bound corrections

A correction should identify the accepted text it concerns without pretending that a URL or copied sentence will remain unchanged forever.

The browser’s **Passage context → Suggest a correction** action prepares a `lumen.correction-packet/v1` object. The page sends nothing automatically. A reader may copy a review note, download the JSON packet, or open a prefilled GitHub issue and still decide not to submit it.

## What a packet binds

A packet carries:

- the public edition and complete source-tree fingerprint;
- stable page and optional passage identities;
- page, normalized-text, and exact-HTML SHA-256 values;
- source offsets for a passage;
- the reader-entered issue, evidence or suggested change, and stated boundary;
- optionally, the exact accepted passage text;
- a content hash over the stable JSON packet.

It explicitly excludes browser history, the local reading trail, the reading desk, private notes, and credentials.

## Review in the cloudtainer

```sh
./lumen correction lumen-correction-note-concern-control-*.json --check
./lumen correction correction.json --format markdown --output review.md
```

The verifier reports one of four states:

- `exact`: packet and current accepted tree identify the same bytes;
- `passage-stable`: the wider tree changed, but the bound page or passage bytes are still exact;
- `changed`: the current accepted bytes differ, so the report must not be silently reattached;
- `missing`: the page or passage cannot be resolved.

A maintainer can also create a packet locally:

```sh
./lumen correction \
  --new note-concern-control#1-i-will-not-collapse-the-predicates \
  --type attribution \
  --issue "The citation appears narrower than the surrounding sentence." \
  --evidence "Explain the source or proposed wording here." \
  --output correction.json
```

Validation locates the authored body and source slice. It never edits prose, opens a network connection, accepts the report as true, or records a new public revision. A reviewed prose change still uses `./lumen revise … --summary …`, followed by `./lumen history --check` and the canonical verification pipeline.

## GitHub boundary

The generated issue draft includes stable identities and fingerprints. GitHub remains a transport and review surface, not an authority that automatically changes the publication. Do not paste credentials, private workshop material, or unrelated operational records into a correction packet or issue.
