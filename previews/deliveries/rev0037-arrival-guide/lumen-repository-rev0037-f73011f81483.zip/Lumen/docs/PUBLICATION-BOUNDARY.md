# Public selection and private recovery

The carrier and public repository handoff share tools/public_source.py for content selection. Only published page metadata and its named body, plus the four reviewed content/data records, are selected. Draft pairs, orphan content files and unlisted data files are omitted. Unknown status, symbolic content paths, missing bodies and a shared public/draft body are errors. Private checkpoint selection remains separate and deliberately retains editable drafts.

This selector is not a secret scanner. Assets, documentation, tooling, tests and workflows are deliberately public source roots and must remain suitable for publication. Never put private research, credentials, operational state or private reader exports in those roots. Publication review must inspect the complete selected member list, not only rendered pages. A source archive is public data when embedded in a public HTML file.

The gift includes GitHub workflows as editable source. In particular it includes a four-hour public-upstream review schedule. Shipping a file is not a decision to install or activate those jobs or change repository access. Review deployment settings and workflows separately before adopting them.

Browser edition comparison keeps Git object identifiers separate from SHA-256 content fingerprints. It accepts full 40- or 64-character Git identifiers; missing or invalid identifiers produce an unknown comparison rather than a false unchanged claim. Optional Node-based pure-data regression tests exercise this reader logic without launching a browser; Python remains the build dependency.

Legacy homepage fragments are retained in home articles. Capsule routing now preserves plain fragments on initial entry and later hash changes, targeting the complete home view. This is covered by pure routing tests; direct browser acceptance is still required.

## Corpus growth review, 2 October 2026

Importing three already published essays grows the accepted corpus from four to seven notes and seventeen to twenty routes. Measured output before budget adjustment: homepage 86,962 bytes, search index 320,342 bytes, edition summary 112,450 bytes. The former 55,000 / 280,000 / 100,000-byte ceilings rejected this legitimate addition. Deliberately reviewed ceilings are now 110,000 / 400,000 / 150,000 bytes respectively. Executable asset, per-folio, aggregate-folio and complete carrier limits are unchanged. These remain finite gates; future corpus growth must prompt review rather than automatic budget inflation. Tests compare generated counts to accepted source records instead of freezing the old four-note corpus.

The offline import helper requires a separately verified source-file SHA-256 and full immutable source commit label. It plans by default, skips existing source identities, and refuses target replacement. It preserves prose and maps known legacy links to existing routes. It does not authenticate the commit label over the network. A partial write is a stopped import requiring inspection; do not erase divergent files to force a retry.

## Reader import review, rev0027

The fieldbook safeguards crossed the original 116,000-byte raw hosted-script gate by approximately 1.3 KiB. The finite gate is deliberately revised to 120,000 bytes; its 29,000-byte compressed-transfer gate stays unchanged. This is a reviewed cost of preserving local notes and bounding imports, not automatic inflation for every new feature. Further reader growth should consider extracting optional modules.

## Canonical identity and selected inputs

Canonical source fingerprints now use the same selected public content as public packaging. Unlisted content/data files do not alter an edition that cannot carry them. Draft-aware previews retain their separate input set. Published page bodies, reviewed data, assets, templates and tools still determine canonical identity. A fingerprint names its declared input set; it is not a claim about every neighboring file or an execution timestamp.
