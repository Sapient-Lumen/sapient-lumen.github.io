# GitHub operations

The ordinary worktree belongs at the root of `Sapient-Lumen/sapient-lumen.github.io`. Do not commit only the binary carrier: that would make review, maintenance, and automation worse.

## First deployment

1. Extract `Lumen.html` or unzip the repository handoff.
2. Place the contents of `Lumen/` at the repository root.
3. In **Settings → Pages**, choose **GitHub Actions**.
4. Push a reviewed commit to `main`, or manually run **Pages**. **Quality** alone verifies; it does not deploy.
5. Pages verifies the canonical build and uploads only `dist/`.

`dist/` contains clean routes, the chronological archive, Atom/RSS/JSON feeds, structured article metadata, static context ledgers, exact self-contained page folios, and the downloadable `Lumen.html`. It does not contain drafts, staged candidates, private checkpoints, private recovery repositories, credentials, research evidence, or historical donor archives.

## Repository shape

Keep authored HTML/JSON, tools, tests, documentation, and workflows as ordinary files. Generated routes and the carrier are reproducible outputs. This preserves useful diffs and review while still making one-file custody the public handoff.

A pull request that changes prose, declared relationships, or `content/data/reading-paths.json` should review:

```sh
./lumen thread
./lumen page PAGE_ID
./lumen context PAGE_ID
./lumen cite PAGE_ID#SECTION --format markdown --quote
./lumen correction correction.json --check
./lumen packet PAGE_ID#SECTION
./lumen packet --desk reading-desk.json
./lumen folio PAGE_ID --check
./lumen verify --canonical
./lumen perf
```

The **Pull request preview** workflow builds a draft-aware, noindex review object and uploads it as a 14-day artifact. It contains the routed draft preview, with a SHA-256 summary for its `Lumen.html` placeholder. That small noindex HTML file is intentionally not a ZIP-compatible carrier; only accepted canonical builds create the complete extractable edition. Drafts are present in this artifact, so review its access audience before upload: noindex is not access control. It has read-only repository permission and no Pages deployment permission, so review and publication remain separate effects.

Actual authored links, declared editorial relationships, and curated reading-path order are separate reviewed structures. A reading path may connect exact passages without converting that order into an inferred relevance score. Actual authored links and declared editorial relationships are separate graph edge types. Reviewers should not substitute one for the other. A source-bound citation proves which edition and text hash were cited; it does not settle whether the cited claim is correct.

## Correction issues remain review requests

The browser can prefill a GitHub correction issue from a source-bound packet, but it never submits one automatically. The issue template asks for the stable page or passage identity, source or packet fingerprint, concrete problem, evidence, and the report’s boundary. Maintainers should run `./lumen correction PACKET.json --check` before editing. An `exact` result proves only that the report names the accepted bytes it claims to name; it does not prove the report’s substance or authorize an automatic revision.

## Publication surfaces

The blog now exposes ordinary long-lived publication interfaces from one accepted note set:

- semantic permalink pages and the original full-scroll homepage;
- `/notes/` chronology and recurring-topic index;
- `/feed.xml` (Atom), `/rss.xml` (RSS 2.0), and `/feed.json` (JSON Feed 1.1);
- `Blog` / `BlogPosting` JSON-LD with an exact CSP hash;
- sitemap, canonical URLs, Open Graph, and social metadata;
- exact one-page folios under `/folios/` for accepted notes and projects;
- the extractable `Lumen.html` edition.

Feed bodies, archive rows, search records, and structured metadata are generated rather than maintained as parallel prose. Drafts are excluded from all canonical publication surfaces.

## Recommended ruleset

After the first successful runs:

- require pull requests for outside contributions;
- require the Python 3.10, 3.12, and 3.13 quality jobs;
- require reproducible-release and CodeQL checks;
- block force pushes and branch deletion;
- require resolved conversations;
- keep administrator bypass explicit.

## Workflow supply chain

External actions are exact-commit pinned. Checkout does not retain write credentials. Workflows declare least privilege, timeouts, and concurrency groups. Dependabot may propose pinned action updates for review.

The release workflow runs `./lumen ship` and emits a handoff whose primary artifact is `Lumen.html`. The reproducibility job builds twice from one accepted boundary and compares the resulting site archives, which include the carrier. The pull-request preview uses the builder's draft mode, omits the extractable carrier, and never deploys. To compare local release bytes, repeat the same command, unchanged inputs, and reference-clock environment; see [same-command reproduction](RELEASING.md#same-command-reproduction).

## Public-source movement and the private boundary

The scheduled upstream workflow reports **public** repository drift as review evidence rather than a red deployment. Acceptance remains explicit:

```sh
./lumen sync --check
./lumen sync --stage
./lumen sync --accept
# Only for a reviewed, intentional retirement:
./lumen sync --accept --confirm-retire OWNER/REPO
```

The sync transport uses the public owner listing and configured public repositories. It does not enumerate, copy, summarize, or publish private repositories. A GitHub token may raise the public-read rate limit, but it does not change the accepted publication boundary. Private worktree checkpoints are local artifacts written only after an explicit `preserve` command and should be stored in a private repository or other private custody location chosen by Lumen.

Absence from one GitHub listing is not treated as proof of deletion. The explicit confirmation is review evidence; the previous head remains in the retired-source ledger.

Suggested topics: `digital-garden`, `single-file`, `static-site`, `github-pages`, `digital-humanities`, `reproducible-builds`, `hypertext`, `progressive-enhancement`, and `offline-first`.
