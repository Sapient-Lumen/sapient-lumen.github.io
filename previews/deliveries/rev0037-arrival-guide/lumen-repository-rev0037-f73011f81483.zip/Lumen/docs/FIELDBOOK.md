# Private fieldbook and exact quote slips

The fieldbook is a reader-owned layer over Lumen’s accepted page and passage ledger. It is intentionally quiet: the notes remain complete ordinary HTML, and nothing is saved until the reader acts.

## What can be kept

A fieldbook entry has one of three scopes:

- **Page** — a stable published page plus the accepted page-body hash.
- **Passage** — one titled section plus its exact source-HTML and normalized-text hashes.
- **Quote** — selected words inside an accepted passage, plus the passage identity, edition, normalized quote offset, bounded before/after context, and quote SHA-256.

The browser stores these entries under the `lumen.fieldbook/v1` schema. Quote support extends that schema without invalidating earlier page and passage exports.

## Keeping an exact quote

Select text inside a titled section. The small selection toolbar offers three actions:

1. copy an exact verified link;
2. copy the quote with a source-bound citation;
3. keep the quote in the private reading trail.

The third action does not create a public annotation, account record, or source edit. It creates a local commonplace slip. Reopening it first checks the accepted passage fingerprint and then applies the bounded quote selector. If the passage changed, Lumen opens the section and says that the older words were not reconstructed.

## Local privacy boundary

Fieldbook state uses browser storage and is best effort. It is not durable archival custody, canonical publication, or a synchronized account. It may be cleared by the browser or lost with a disposable profile.

Private notes stay local until the reader explicitly exports JSON or a standalone HTML packet. The routed site and `Lumen.html` do not transmit them.

## Crossing into the cloudtainer

Export JSON from the reading trail, then run:

```sh
./lumen packet --fieldbook lumen-fieldbook.json
```

The command reads canonical built context and verifies every selected object. For an exact quote it checks:

- stable page and passage identity;
- accepted passage text fingerprint;
- the declared quote offset, with bounded context only as a deterministic fallback;
- quote SHA-256;
- exact normalized text equality.

A missing or changed binding is an error. The command never repairs a quote by approximate similarity. Successful export emits `lumen.reading-packet/v2` JSON and a standalone HTML packet containing the selected objects, receipts, accepted parent passages for quote slips, and any notes the reader explicitly exported.

## Distinction from the Night Index reading desk

The reading desk is a temporary, ordered page/passage set used to build a focus sheet. The fieldbook is a quieter collection shared by both looks and can retain sentence-scale quote slips. Both are local reader projections; neither rewrites authored source.

## What the receipts establish

The receipts establish which accepted bytes and normalized words an entry named under a particular edition. They do not establish that the quote is true, representative, fairly interpreted, externally timestamped, or authored by the person named in metadata.

## Conservative import

Fieldbook import checks the v1 schema, limits the file to 32 MiB and the entry set to 250 distinct identities, then merges without replacing different local entries. The status reports additions, unchanged entries, conflicts retained locally, and items that did not fit. Keep the imported file while reviewing conflicts; this operation does not silently choose its notes over yours. Local storage remains best effort. This is an import safeguard, not a backup promise.

## Capacity and round-trip boundary

The reading trail accepts up to250 saved items. A new page, passage, or quote at capacity is refused; existing entries are not evicted. Refreshing or removing an existing item remains available. Notes entered through the interface are bounded to4,000 JavaScript string code units and selected quotes to700. Synthetic tests exercise valid JSON round trips, preserved local notes on conflicts, exact Blob contents, and escaped reading packets in both runtimes. They do not establish that a particular browser completed a download or clipboard write.

These save guards prevent new capacity overflows. They do not recover previously oversized local storage, and external imports now reject over-limit notes and quotes before mutation; other noncanonical metadata still uses the existing bounded normalizer. Preserve original exported JSON before importing legacy or externally modified data.
