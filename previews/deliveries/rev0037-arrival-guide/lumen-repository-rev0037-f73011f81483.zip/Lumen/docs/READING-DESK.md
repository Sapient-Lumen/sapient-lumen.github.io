# Reading desk and focus sheet

The reading desk is a browser-local **ordered open set**. It is intentionally smaller and more temporary than the annotated reading trail.

- The **desk** answers: what am I actively comparing, and in what order?
- The **reading trail** answers: what did I save, and what private note did I attach?
- The **focus sheet** is a disposable projection of the desk. It is never canonical source.

The distinction comes from a useful property of the original Hyperepo donor: the open story was data, not merely whatever tabs happened to be visible. Lumen keeps that idea while using stable page and passage identities instead of donor-specific runtime state.

## Browser use

In Night Index, open the desk with the dock or press `D`. Use `Shift+D` to add or remove the current passage. Reorder items by drag or with the move controls. The desk stays in this browser under the `lumen.reading-desk/v1` schema.

Export produces JSON containing ordered stable identities, exact carried text, source fingerprints, and the edition that supplied each entry. It does not publish the desk or modify authored content.

## Desk versus fieldbook

The reading desk is a temporary ordered working set for Night Index. The private fieldbook is a quieter, longer-lived reader collection shared by both looks. A fieldbook entry may name an entire page, a passage, or an exact selected quote; the desk deliberately stays at page/passage granularity so it can assemble readable focus sheets.

Use `./lumen packet --desk` to carry an ordered session. Use `./lumen packet --fieldbook` to verify a reader-owned collection, including exact quote slips and explicitly exported private notes.

## Cloudtainer bridge

```sh
./lumen packet --desk ~/Downloads/lumen-reading-desk-2026-10-02.json
```

The command resolves the ordered stable identities against the current canonical context and writes a source-bound HTML packet plus JSON receipt. Explicit targets can be added after the desk:

```sh
./lumen packet --desk desk.json note-concern-control#8-what-i-undertake
```

A fingerprint mismatch is preserved in the exported desk. The cloudtainer resolves current source and records its own fingerprint; it never silently asserts that changed text is identical.

## Boundaries

The desk is local convenience, not a permissions system, recovery authority, publication queue, or proof that a reader opened every item. Browser storage can be cleared. Export is the custody boundary.

## Capacity

The reading desk accepts up to64 entries. A new entry at capacity is refused without evicting an existing one. Closing or refreshing an existing entry remains available. The guard prevents new overflow; it does not restore entries already omitted by legacy oversized-state normalization.
