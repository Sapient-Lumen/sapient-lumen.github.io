# What the Hyperepo donor contributes

Lumen does not ship the donor runtime, historical corpus, owner workspace, or private restoration machinery. The donor was studied as prior art and retained outside the ordinary handoff.

The parts that earned a new implementation are small and structural:

| Donor idea | Lumen construction |
|---|---|
| One-file custody | `Lumen.html` is a browser document and a directly extractable worktree. |
| Ordered open story | The browser-local reading desk stores an ordered set of stable page or passage identities. |
| Curated trails through a corpus | Three authored reading paths bind a quiet public sequence to exact accepted pages and passages without becoming a recommendation engine. |
| Focus transclusion | A focus sheet assembles the current desk without claiming to be canonical source. |
| Several search intents | Local title/alias, tag, prose, exact-phrase, and stable-ID search share one embedded index. |
| Pins and tiny working objects | The reading trail, exact-quote commonplace slips, one explicit return point, and desk keep selected objects near the prose without turning the blog into a dashboard. |
| Stable identity apart from display | IDs, URLs, titles, aliases, exact source slices, and fingerprints are separate fields. |
| Source and projection are different | Authored `content/`, generated `dist/`, the Pages site, packets, and the carrier are explicit states. |
| Honest missingness | Unavailable observations and retired sources are not recreated merely to make the surface look complete. |

## Authored routes, not behavioral recommendations

The donor’s structural trails suggested one additional construction that belongs in a public blog: a small number of human-readable routes through questions that recur across separate notes. Lumen’s paths are deliberately authored and source-bound. They do not learn from clicks, retain private reading history, rank every page, or claim that adjacency is evidence. Each step can be inspected as an exact accepted page or passage in the cloudtainer and carried offline in `Lumen.html`.

## Tiny working objects, not a second application

The donor treated pins, focus records, and selected structures as durable working objects rather than transient interface state. Lumen now borrows that idea at sentence scale. A reader can keep an exact quote slip whose identity is bound to a source passage, edition, offset, bounded context, and quote hash. It stays visually subordinate to the note, lives only in local browser state until exported, and can be re-verified by the ordinary cloudtainer worktree.

This is the Hyperepo inheritance in its quietest form: the selected object can travel without pretending that a browser selection is canonical source or that approximate text matching is good enough.

The return point applies the same rule to continuity. It stores one reader-chosen page or passage with exact accepted hashes, then either confirms, uniquely relocates, or refuses to guess in a later edition. The ordinary page remains a blog; the deeper object model appears only when continuity is useful.

What was deliberately not inherited:

- the donor’s entire plugin and owner-server environment;
- automatic background admission of the whole archive;
- public writer, restore, or deletion authority;
- search limited to whatever records have already arrived;
- the donor’s literal `<pre>` workbench as the public reading face;
- the old private corpus, maps, pins, timelines, and personal labels as Lumen content.

The result should feel like a good field-notes site. The inherited machinery is successful when a reader notices useful continuity, context, and custody—not the name of the system that inspired it.
