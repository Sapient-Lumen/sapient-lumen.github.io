# Appearance layers

Lumen separates **content identity** from **presentation**.

- `field-notes` is the accepted default and continues the original blog’s warm handmade form.
- `night-study` is an optional dark candidate. It is intentionally easy to keep, revise, or delete.

Both looks use the same semantic HTML, page IDs, passage records, search index, fieldbook, GitHub Pages projection, and `Lumen.html` capsule.

## Cloudtainer commands

```sh
./lumen look
./lumen look night-study
./lumen start --open
./lumen look night-study --set-default
./lumen verify --canonical
```

A browser choice is stored locally under `lumen-look/v1`; it does not edit the repository. `--set-default` is the explicit repository-level change.

## Adding another look

1. Add a selector-scoped stylesheet under `assets/css/looks/NAME.css` using `html[data-look="NAME"]`.
2. Add the record to `content/data/looks.json`.
3. Optionally add a preview page carrying `"look": "NAME"`, `"look_preview": true`, and a preferred `"theme"`.
4. Run `./lumen verify --canonical` and review desktop, mobile, light, dark, and `Lumen.html`.

The build concatenates look layers deterministically into the fingerprinted stylesheet. The one-file capsule embeds the same bundle.

## Night Index tools

The candidate is more than a palette: it reveals an ordered reading desk, a disposable focus sheet, plural local search intents, focus mode, and a compact study dock. These are presentation-adjacent reader tools; they do not fork the content model or public receipts.

See `READING-DESK.md`.
