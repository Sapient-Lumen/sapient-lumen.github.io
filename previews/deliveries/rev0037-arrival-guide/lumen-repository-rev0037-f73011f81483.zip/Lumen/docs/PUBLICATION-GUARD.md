# Offline Git tree publication guard

`tools/publication_guard.py` is a dependency-free Python 3.10+ pre-publication check. It reads three local JSON files and independently supplied baseline/candidate tree pins. It never contacts GitHub, creates Git objects, changes a ref, writes a receipt, or publishes anything. It is a standalone gate, not yet integrated into the release commands.

The default is preservation of every unrelated repository file. A candidate containing only new receipt files is rejected if the baseline also contained source, documentation, or other files, even when all the intended receipt additions are correct. This catches the destructive result of accidentally constructing a replacement tree without its intended base tree.

## Inputs

1. `baseline.json`: the complete recursive tree response for the reviewed baseline tree.
2. `candidate.json`: the complete recursive tree response for the actual candidate tree that a proposed commit will reference. A create-tree response or a patch list is not a complete recursive tree.
3. `changes.json`: a separately reviewed, exact change manifest.
4. Two full Git tree object IDs supplied through required CLI arguments. These must match the corresponding response IDs and manifest pins. Tree IDs are not commit IDs or ordinary file SHA-256 fingerprints.

Both tree responses use the GitHub recursive tree shape:

```json
{
  "sha": "<full tree object ID>",
  "truncated": false,
  "tree": [
    {"path": "README.md", "mode": "100644", "type": "blob", "sha": "<full blob object ID>"},
    {"path": "docs", "mode": "040000", "type": "tree", "sha": "<full subtree object ID>"},
    {"path": "docs/example.md", "mode": "100644", "type": "blob", "sha": "<full blob object ID>"}
  ]
}
```

Placeholders in these examples must be replaced with actual IDs. The tree array must include every directory and leaf recursively, excluding the root itself. `truncated` must be the JSON boolean `false`. Optional response `url` and entry `url`/blob `size` fields are accepted; other fields are rejected. Sizes are checked for valid nonnegative integer form but are not trusted as content evidence.

A manifest for one replacement, one addition, and one intentionally approved removal:

```json
{
  "schema_version": 1,
  "baseline_tree_sha": "<reviewed baseline tree ID>",
  "candidate_tree_sha": "<actual candidate tree ID>",
  "changes": [
    {
      "path": "README.md",
      "before": {"mode": "100644", "type": "blob", "sha": "<old blob ID>"},
      "after": {"mode": "100644", "type": "blob", "sha": "<new blob ID>"}
    },
    {
      "path": "receipts/review.json",
      "before": null,
      "after": {"mode": "100644", "type": "blob", "sha": "<receipt blob ID>"}
    },
    {
      "path": "obsolete.txt",
      "before": {"mode": "100644", "type": "blob", "sha": "<removed blob ID>"},
      "after": null
    }
  ]
}
```

Every actual leaf change must have exactly one manifest entry. `before: null` means the path must not exist in the baseline; `after: null` explicitly approves removal of the exact prior object and mode. Neither omission nor an empty after-object approves deletion. Both sides equal (including two nulls) is a rejected no-op. A rename requires an explicit removal plus addition. Mode-only changes require their own exact before/after entry. Directory-to-file and file-to-directory changes must enumerate all affected leaves. Subtree IDs are derived from contents, so directories are never manifest changes.

Do not automatically generate approval from whatever diff a candidate happens to contain. The manifest is the reviewed intent against which that candidate is checked. Rewriting the manifest to match an unexpected deletion defeats the guard.

## Standalone command

```sh
python3 tools/publication_guard.py \
  --baseline baseline.json \
  --candidate candidate.json \
  --manifest changes.json \
  --baseline-tree-sha "$BASELINE_TREE_SHA" \
  --candidate-tree-sha "$CANDIDATE_TREE_SHA"
```

Success prints one JSON object containing `status: "ok"`, the two pins, leaf-entry counts, approved-change count, and preserved-entry count. Exit status is 0 on success, 1 for rejected or unreadable input, and 2 for invalid command-line usage. Rejection diagnostics go to stderr; no success JSON is emitted on rejection. Exit nonzero must stop publication, not merely produce a warning. The library entry point is `verify(baseline, candidate, manifest, baseline_tree_sha=..., candidate_tree_sha=...)`; it returns the same summary or raises `GuardError`. Use `load_json` when reading inputs to retain duplicate-key rejection.

## What is verified

- Full lowercase, nonempty 40-character SHA-1 or 64-character SHA-256 Git object IDs, with one consistent algorithm per invocation.
- Exact response and manifest identity matches against the independent pins.
- Explicit completeness flag, unique paths, unique JSON object keys at every depth, required schema, valid JSON, supported modes/types, and unambiguous relative UTF-8 paths.
- Every directory's Git tree object hash, reconstructed using canonical Git byte ordering, including the directory trailing-slash sorting rule. Root identity is also reconstructed. A list missing children is rejected even if it falsely says `truncated: false`.
- Exact equality of the complete leaf diff to the manifest, including every planned object ID, mode, type, addition, and removal. Unchanged leaves are preserved automatically.

Regular and executable files, symlinks, and submodule commit entries are supported. Symlink targets are not followed; submodule contents are not inspected. The empty root tree is supported. Non-root empty trees are deliberately unsupported and rejected, rather than silently ignored. Paths containing backslashes, control characters, empty components, `.` or `..` components, or invalid UTF-8 are also rejected. These conservative restrictions can reject unusual otherwise representable Git trees; do not normalize such inputs to make them pass.

## Publication boundary

This is structural evidence over supplied immutable object identities, not remote freshness or authorization evidence. It does not prove that a baseline is the current branch tip, that IDs came from an authentic service response, that blobs exist remotely, that planned blob IDs correspond to reviewed local bytes, or that the proposed commit has the required parent. It does not scan secrets, validate content, inspect legal permissions, or establish permission to delete files. It trusts the supplied reviewed manifest and independent pins; replacing both with a different plan changes what it checks.

The publishing caller still needs to:

1. Resolve and record the intended repository, branch, baseline commit, and that commit's tree through the authorized source.
2. Build a candidate preserving the baseline, hash/review intended file bytes and modes, and fetch its actual full recursive tree. For GitHub create-tree patch workflows, supply the intended `base_tree`/client-equivalent base-tree argument.
3. Review the manifest independently, then run this guard against the pinned baseline and candidate.
4. Verify the proposed commit references exactly the checked candidate tree and intended parent. Check remote freshness and use the available concurrency/non-force safeguards before moving a ref. If the baseline or candidate changes, repeat the review and guard against the new identities.
5. Verify the resulting remote commit and file identities after the separately authorized publication.

A successful offline run is not permission to skip any of these steps. Capturing a success output does not lock a branch or prevent a race. No publication behavior is enabled merely by shipping this tool.

## Focused tests

```sh
python3 -m unittest discover -s tests -p test_publication_guard.py -v
```

The tests are offline and use only the Python standard library. Coverage includes receipts-only replacement, unexpected changes/removals, exact planned blobs and modes, missing recursive members, malformed or truncated inputs, duplicates, wrong pins, SHA-1/SHA-256, a Git-derived directory-order golden fixture, symlinks/submodules, and CLI exit behavior. Broader canonical release/build checks remain separate.
