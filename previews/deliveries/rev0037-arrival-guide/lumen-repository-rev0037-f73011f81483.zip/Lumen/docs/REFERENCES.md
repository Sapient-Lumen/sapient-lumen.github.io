# Reference room

The public site carries a local reference ledger at `dist/meta/references.json` and a human reading surface at `/references/`.

The ledger is generated from the accepted authored HTML. It records:

- the exact external URL that appeared in the publication;
- a conservative canonical URL used only for stable local identity;
- the author’s link label rather than remotely fetched title metadata;
- every accepted page and source-bound passage in which the link appears;
- the text and source-HTML fingerprints of that passage.

No publisher, search engine, DOI service, archive, or metadata API is contacted during build, search, capsule use, or local inspection. Query strings are retained. URL fragments are omitted from source identity because they locate a place within one remote document rather than define a different source.

## Browser use

Ordinary reading does not expose the machinery. A note with external sources ends with one collapsed **References** disclosure. The complete Reference Room can filter by authored label, URL, passage, page, or domain. It remains fully readable without JavaScript; filtering is only an enhancement.

On devices with a precise pointer, hovering an external prose link shows a small local **source lens**. Keyboard focus opens the same card. It reports the authored label, domain, and how many accepted passages use that source, then repeats the evidential boundary. The link itself is never intercepted, no remote preview is fetched, and touch devices keep ordinary link behavior.

Each source lens reads one generated record under `dist/meta/reference-previews/`. The one-file edition resolves the same stable reference identity from its embedded ledger instead of making a file request.

The single-file `Lumen.html` edition embeds the same ledger and can download it as `lumen-references.json` without a network request.

## Cloudtainer use

```sh
./lumen references
./lumen references arxiv
./lumen references "moral uncertainty" --format markdown
./lumen references --format json --build
```

`--build` refreshes canonical output before reading the ledger. Without it, the command inspects the accepted generated ledger already present in `dist/`.

## Boundary

A reference record proves only that an exact accepted passage linked to an exact URL under a named edition. It does not prove that the remote document is available, unchanged, trustworthy, or sufficient support for the surrounding claim. Lumen’s arguments must still stand on their reasons.
