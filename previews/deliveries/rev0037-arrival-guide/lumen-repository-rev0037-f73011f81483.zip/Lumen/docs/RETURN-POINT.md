# Return point

Lumen offers one explicit, private place to resume reading. It is a small continuity object, not a browsing-history system.

## In the browser

Use **Mark my place**, press <kbd>Shift</kbd>+<kbd>R</kbd>, or open **Return point** and mark the current position. The record stays in this browser until it is cleared or exported.

The marker binds:

- stable page and, when available, passage identity;
- the accepted page or passage SHA-256;
- one optional exact prose-block SHA-256 and bounded excerpt;
- a fallback scroll percentage for a page-level marker;
- the edition and source fingerprint observed when it was created.

No passive trail is created. Lumen does not record every page, scroll event, or visit.

When a marker is reviewed in another edition, Lumen reports one of these states:

| State | Meaning |
|---|---|
| `exact` | The same accepted page or passage bytes remain at the recorded identity. |
| `moved` | Exactly one passage elsewhere has the same accepted text SHA-256. |
| `changed` | The stable page or passage remains, but the accepted text changed. |
| `ambiguous` | More than one passage has the old exact text, so no destination is chosen. |
| `passage-missing` / `page-missing` | The recorded object is absent. |

Only `exact` and uniquely `moved` text are treated as the same accepted passage. Titles and approximate similarity do not silently reattach a marker.

The routed site loads the return-point JavaScript and CSS only after explicit use, or when a marker already exists. The one-file edition carries the same behavior entirely offline.

## In the cloudtainer

Create a marker from canonical built context:

```sh
./lumen marker note-concern-control#1-i-will-not-collapse-the-predicates \
  --output return-point.json
```

Review an exported marker against the current accepted tree:

```sh
./lumen marker --check return-point.json
./lumen marker --check return-point.json --format json \
  --output return-point-review.json
```

Add `--build` when canonical context should be rebuilt before creation or review.

The CLI verifies the same stable identities and accepted hashes as the browser. A marker is reader-selected position data. It does not prove that the text was read completely, understood, endorsed, or continuously available.
