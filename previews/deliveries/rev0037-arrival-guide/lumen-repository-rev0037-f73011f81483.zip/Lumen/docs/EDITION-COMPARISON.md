# Local edition comparison

`Lumen.html` is a custody object: a reader can keep one accepted edition and later ask exactly what a newer one carries differently. The comparison is deliberately local, source-bound, and narrower than interpretation.

## Browser

Open **Editions and corrections**, choose **Compare another edition**, and select another `Lumen.html` or a `lumen.edition-summary/v2` JSON file. The selected bytes stay in the browser. The routed site loads the comparator only when the dialog opens; the single-file carrier already contains the current summary and comparison runtime.

The result can be exported as `lumen.edition-comparison/v2` JSON. It records:

- current and selected edition labels and source fingerprints;
- added, removed, and changed stable page IDs;
- authored-body SHA-256 changes separately from route or metadata changes;
- exact titled-passage states when both editions provide passage records: text changed, source markup changed, metadata changed, exact identity moved, current-only, or selected-only;
- bounded old/current excerpts, word counts, and fingerprints for changed passages;
- accepted public-source heads that changed, appeared, disappeared, or became retired;
- explicit limits explaining what the receipt does not prove.

Passage comparison is not guessed. Stable passage IDs are compared first. A moved passage is reported only when one unmatched passage on each side has the same exact normalized-text fingerprint. Ambiguous or merely similar text remains added/removed rather than being silently paired.

## Cloudtainer

```sh
./lumen compare ../kept/Lumen.html
./lumen compare ../kept/Lumen.html --format markdown --output comparison.md
./lumen compare ../kept/Lumen.html --format json --output comparison.json
```

The command accepts a current or older Lumen capsule, or a direct edition-summary JSON file. It performs no network request and does not execute scripts from the selected carrier. Browser and cloudtainer paths normalize to the same comparison schema.

## Compatibility boundary

Current carriers include a dedicated base64 edition-summary marker and `meta/edition-summary.json`. Compatible earlier Lumen capsules are enriched from their carried `meta/context/*.json` records. If an edition has only page records, the comparison explicitly remains page-level. The reader never invents passage history, emulates an arbitrary third-party HTML application, or scans a selected file for executable behavior.

The summary format accepts `lumen.edition-summary/v1` for backward compatibility and normalizes it to v2. A v1 record does not gain passage certainty unless the selected capsule actually carries matching context records.

## What it means

A matching hash means matching bytes under the declared normalization. A changed hash means the accepted bytes differ. A markup-only result means normalized passage text matched while the exact carried HTML slice differed. A moved result means an exact text identity was found at one different stable location on each side.

None of those states establishes truth, improvement, authorship, safety, or process continuity. Git remains the complete implementation history; this feature is a quiet reader-facing answer to a narrower question: **what changed between the two custody objects I actually have?**
