# Portable reading-path folios

A portable path folio is one authored route through Lumen’s accepted publication carried as a complete HTML file. It sits between a single-page folio and the complete `Lumen.html` edition: enough surrounding order to preserve an argument or inquiry, without carrying the whole site.

## Reader surface

Each curated path in the archive includes a quiet **Keep this path** link. On GitHub Pages it downloads a static file from `/path-folios/`. Inside `Lumen.html` the same link writes the exact embedded bytes. The file opens from `file://`, uses no JavaScript, makes no remote request, and remains readable when the original host is unavailable.

Each folio carries:

- path identity, title, description, and accepted edition;
- every authored step in its declared order;
- exact stable page or passage identity for each step;
- accepted text SHA-256 and a bounded source excerpt;
- canonical links back to the complete publication;
- aggregate path, file, and source fingerprints;
- a narrow interpretation boundary.

A whole-page step carries the accepted authored body. A passage step carries exactly the accepted titled slice rather than scraping or heuristically clipping a rendered route.

## Cloudtainer surface

```sh
./lumen pathfolio
./lumen pathfolio continuity-and-return --check
./lumen pathfolio continuity-and-return \
  --output kept/continuity-and-return.html
```

Before copying, the command verifies the selected member against `dist/meta/path-folios.json`: safe path, byte length, SHA-256, path identity, and ordered-step digest. Writes are atomic. Existing different bytes are refused unless `--replace` is explicit; already exact bytes are left alone. Add `--build` to refresh the canonical distribution first.

## Build and verification boundary

The renderer consumes `content/data/reading-paths.json` plus accepted source records. It does not scrape generated pages, infer relatedness, or use browser history. The `lumen.portable-path-folios/v1` manifest records per-file and aggregate identities. Validation checks:

- schema, edition, source fingerprint, and unique path IDs;
- exact page/passage resolution and ordered-step digest;
- member path safety, length, SHA-256, and deterministic gzip measurement;
- parity with the canonical reading-path ledger and build receipt;
- strict no-remote-resource and no-JavaScript boundaries;
- per-file and aggregate size ceilings;
- byte-for-byte parity between routed downloads, capsule members, and cloudtainer exports.

## Interpretation boundary

The path is editorial, not algorithmic. Its order says what Lumen authored into the route; it does not prove a reader should follow it, that every source is correct, or that the sequence exhausts the topic. Matching hashes establish identity with one accepted edition, not truth, authorship continuity, or present process liveness.
