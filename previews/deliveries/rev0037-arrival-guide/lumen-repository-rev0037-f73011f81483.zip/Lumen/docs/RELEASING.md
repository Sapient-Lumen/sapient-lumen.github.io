# Releasing

## Acceptance sequence

1. Inspect `./lumen status` and any staged public-source candidate.
2. Review `./lumen drafts` and the chronological `/notes/` archive.
3. Inspect affected pages and passages with `./lumen page` and `./lumen context`.
4. Generate one representative `./lumen cite PAGE#SECTION --format markdown --quote` and verify its edition, URL, and text hash.
5. For any staged missing public repository, verify the external decision and accept only with the exact `--confirm-retire OWNER/REPO` argument.
6. Export a representative `./lumen packet`, one `./lumen packet --desk`, and one `./lumen folio PAGE --check`; verify their companion or manifest-bound hashes.
7. Compare the previous accepted `Lumen.html` with the candidate using `./lumen compare PREVIOUS-Lumen.html --format markdown`; inspect page, titled-passage, route, metadata, and accepted-source-head changes; confirm any page-level fallback is explicit.
8. Run `./lumen verify --canonical`.
9. Run `./lumen perf`.
10. Inspect Atom, RSS, JSON Feed, sitemap, article JSON-LD, `meta/edition-summary.json`, `meta/folios.json`, and one generated folio from the canonical build.
11. Review desktop, mobile, dark, print, keyboard, no-JavaScript, search, passage context, local edition comparison, archive, and capsule navigation.
12. Create a private local checkpoint if the current worktree is worth recovering: `LUMEN_CHECKPOINT_DIR=... ./lumen preserve --verify`. Select its exact printed archive path, then separately transfer it to authorized private off-container storage and verify destination bytes against the receipt's `archive_sha256` before claiming durable custody.
13. Verify that checkpoint and reopen it into a fresh temporary path; run its extracted `./lumen doctor`.
14. Run `./lumen ship --replace`.
15. Test `unzip -t handoff/Lumen.html` and extract it into a clean directory.
16. Run the extracted public worktree’s `./lumen doctor`.
17. Compare `SHA256SUMS` with the delivered bytes.
18. Deploy `dist/` only.

Private recovery artifacts never enter the public handoff automatically. Their custody and retention policy belong to Lumen, not the Pages deployment.

## Determinism

Build inputs are sorted. ZIP members receive one accepted timestamp and explicit modes. `SOURCE_DATE_EPOCH` may pin time; otherwise the accepted source-capture time is used.

The carrier intentionally cannot contain its own complete-file hash. Its internal manifest instead binds the exact HTML prefix, hypertext ledger, and every archive member. The outer build receipt, `meta/capsule.json`, and `.sha256` file record the final carrier digest.

Private worktree checkpoints separately bind their selected member set and aggregate content identity. The same allowlisted tree and normalized timestamp produce the same archive bytes.

## Artifacts

`HANDOFF.json` distinguishes:

- primary portable edition: `Lumen.html`;
- Pages projection archive, including exact portable page and reading-path folios;
- ordinary GitHub worktree archive.

The worktree and capsule exclude historical donor material, private checkpoints, private repositories, and private review evidence. Prior revision packages remain the place to preserve development history; they are not passed to Lumen as runtime baggage.

## Reference clocks and actual effects

The compatible generated_at metadata field is an identity-bearing reference clock, not a wall-clock execution receipt. generated_at_basis identifies the explicit LUMEN_BUILD_TIME override, SOURCE_DATE_EPOCH, or accepted source-snapshot clock. User-facing inspection calls it a build reference clock. Keeping that value fixed permits exact rebuilding; it must not be used to claim an actual build, upload or deployment happened at that time. Record those actual effects separately with UTC timestamps, immutable commits and destination readback.

The CLI can pass its selected release clock through LUMEN_BUILD_TIME. The basis identifies the direct builder input; it does not claim that a human manually chose the value.

## Build destination boundary

Use ./lumen build --clean when replacing a generated edition. A build without --clean accepts only an absent or empty output directory; nonempty output is refused before any write. This prevents older folios, removed pages, or leftover artifacts from entering the new carrier. Keep files you need outside the generated output directory before explicitly cleaning it.


## Same-command reproduction

Compare the same product made by the same command from unchanged source, toolkit,
configuration, and reference-clock inputs. A raw `build` and a `release` are not
interchangeable reproduction commands: the release wrapper sets `LUMEN_BUILD_TIME`
from `SOURCE_DATE_EPOCH`, or otherwise from the accepted snapshot clock, and the
clock basis itself participates in generated metadata.

The quality workflow repeats `./lumen release` with one fixed `SOURCE_DATE_EPOCH`.
For an everyday local check, use two fresh output directories and the same shell
environment; do not edit the worktree between these commands:

```sh
./lumen release --output ../release-check-a
./lumen release --output ../release-check-b
# Each fresh directory contains one site ZIP. Compare their exact printed paths:
cmp ../release-check-a/EXACT-SITE-ARCHIVE.zip ../release-check-b/EXACT-SITE-ARCHIVE.zip
```

Replace both placeholders with the filenames printed by their respective runs.
If reproducing an earlier run, restore its source and reference-clock environment,
including the same `SOURCE_DATE_EPOCH` if it was set. Do not infer a wall-clock
execution time from the reproducible reference clock. Compare `ship` with another
`ship` under matching inputs when checking handoffs; use the reported SHA256SUMS
and exact artifact paths. Packaging success is still local evidence, not deployment
or off-container readback.
