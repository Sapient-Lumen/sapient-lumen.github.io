# GitHub delivery runner

This is the online companion to [DELIVERY.md](DELIVERY.md). It consumes an
already reviewed, frozen `DELIVERY.json` bundle. It does not rebuild the HTML,
read a whole workshop for publication, create credentials, schedule itself, or
install anything. The Python host uses only the standard library. The small
JavaScript pump runs in `functions.exec`, where the existing authorized GitHub
connector is available. Node is used by local verification smoke/integration
suites, not by the live tools-host pump. No npm dependencies are required.

## The normal invocation

Review `tools/github_delivery_runner.js` and `tools/delivery_runner.py`, then
load the local JS source into the authorized tools host. This is executable
`functions.exec` code, not a terminal command. Use explicit absolute paths:

```javascript
const loaded = await tools.exec_command({
  cmd: "cat '/absolute/Lumen/tools/github_delivery_runner.js'",
  max_output_tokens: 12000
});
if (loaded.exit_code !== 0 || loaded.session_id) throw new Error('Runner source unavailable');
const run = new Function(loaded.output + '\nreturn runGitHubDelivery;')();
text(await run(tools, {
  helper: '/absolute/Lumen/tools/delivery_runner.py',
  run: '/private/release-delivery-run',
  bundle: '/private/frozen-delivery',
  projectId: 'field-notes-site',
  pagesUrl: 'https://sapient-lumen.github.io',
  maxActions: 20,
  stopAfter: 'private'
}));
```

The first call pins the normalized bundle location, its exact record hash,
project ID, selected recovery-pointer path, and optional Pages URL. Omit
`pagesUrl` if live Pages verification is not requested. No repository or alias
is inferred: both repositories/branches and the only permitted mutable public
alias come from the reviewed bundle's explicit profile. The homepage is
preserved unless that exact path was selected explicitly in that profile.
Private transport members must each be smaller than 1 MB.

Run the same pump again to resume, keeping `helper` and `run`, but omitting
`bundle`, `projectId`, `pagesUrl`, and `stopAfter`. Saved request settings apply.
`maxActions` limits the number of acknowledged tool actions per invocation;
a limit never stops in the middle of a dispatched mutation. A new invocation
refreshes an earlier unissued ref preflight before dispatching a ref write; an
already-issued uncertain ref update is reconciled rather than repeated. `stopAfter` may be
`private`, `pointer`, `public`, or `evidence`; it stops after that phase's exact
readback and local verification. The returned boundary is resumable. A live
Pages `pending` result returns promptly; re-invoke after the external deployment
or CDN has progressed. There is no polling daemon or new scheduler.

## What one run owns

The normal successful sequence is:

1. Read private repository metadata, intended ref, immutable baseline commit,
   and complete recursive tree through the authorized connector. Check identity,
   private visibility, and commit/tree association.
2. Use `delivery.plan` and the existing whole-tree guard. Upload selected blobs
   once per Git identity, including binary artifacts encoded as base64; alias
   copies do not create duplicate blob uploads. Create a candidate from an
   explicit base tree, re-read and verify the full tree, create its commit, and
   re-read/verify the commit's exact tree and single parent.
3. Re-read the branch immediately before a non-force update; independently read
   the resulting ref, immutable tree and selected file bytes. Materialize and
   verify the exact inventory. Finalize private custody and generate the pointer.
4. Publish and independently verify the generated private recovery pointer.
5. Repeat the guarded publication/readback for the frozen public payload. A
   public failure leaves verified private custody and pointer evidence intact.
6. If requested, verify the selected public commit's successful branch-deployed
   Pages workflow, then download and hash the complete live versioned primary
   HTML and explicit alias. No HEAD-only, substring, or success-boolean check
   substitutes for byte identity.
7. Publish and independently read back one private outcome record at
   `<private-prefix>/<release-id>/DELIVERY-OUTCOME.json`. It contains only this
   release's selected inventories, bundle hash, review reference, verified phase
   results/times and optional live verification. It contains no whole-workshop
   snapshot, credentials, unrelated project records, or speculative claims.

The last outcome record records the already established publication results;
it cannot contain its own future commit identity. Its separate local
`evidence-VERIFIED.json` pins that final receipt commit/tree/readback. The result
returned by the pump includes each phase's status and immutable commit.

The host persists mutation intent before dispatch and the original connector
response before accepting it. Large uploads/responses cross the local shell
boundary in bounded chunks; payload bytes are not printed in progress messages.
Completed replay uses saved verified evidence, performs no remote calls or
mutations, and retains completed evidence byte-for-byte. Its live result is a
historical observation at the recorded verification time, not a claim that a
mutable alias still serves that old release today.

## Authentication and concurrency boundary

The JS pump calls only the allowlisted existing GitHub connector tools. No token,
SSH key, new OAuth grant, credential environment lookup, or alternative private
GitHub transport exists in this runner. Repository, Git object and small-file
observations come from the authenticated connector.

Selected public artifacts at least 1 MB are downloaded at the immutable commit
from `raw.githubusercontent.com`, after authenticated tree identity/size/mode
verification. This is the chosen public byte transport, never a fallback around
a connector permission denial. Private bytes never use it. Public download
redirects are refused and the complete bytes must match the frozen SHA-256 and
Git blob identity. Optional live HTML reads use only the explicitly pinned
HTTPS owner-root `github.io` origin and selected public paths.

GitHub's connector does not expose atomic expected-old-SHA compare-and-swap.
The runner therefore makes an immediate baseline-head check, sends
`force: false`, then verifies the observed ref. Ordinary concurrent sibling
advancement is rejected. This is not a stronger atomic CAS primitive. A
confirmed pre-update branch advance returns a conflict before ref mutation.
After inspecting it, explicitly replan the same frozen bundle; old candidate
and commit evidence is archived, not erased. No artifacts are rebuilt.

Pointer publication is deliberately pinned to the just-verified private
checkpoint commit. If another actor advances private main before the pointer,
stop for a separately reviewed pointer reconciliation; the runner does not
silently relax that existing finalization contract.

## Pauses and operator reconciliation

The local host takes one JSON request on stdin:

```sh
python3 tools/delivery_runner.py rpc --run /private/release-delivery-run <<'JSON'
{"command":"status"}
JSON
```

Useful commands, always in the same run directory:

- `{"command":"retry-read"}`: after fixing a failed or corrupt harmless read,
  issue a new read attempt while preserving the original mutation uncertainty.
- `{"command":"reconcile"}`: after resolving a blocker, read the expected blob,
  tree or branch to establish a lost mutation acknowledgement. It never repeats
  the write. If that observation is inconclusive, it stays paused.
- `{"command":"adopt-commit","sha":"FULL_SHA"}`: recover a create-commit
  acknowledgement by fetching that exact object and requiring the intended
  tree, single parent and stable release/inventory message. A rejected SHA can
  be corrected using the same command. No speculative replacement commit is
  created.
- `{"command":"replan","scope":"public"}`: after a confirmed pre-ref
  concurrency conflict, generate a fresh whole-tree guarded plan on the next
  run from unchanged frozen bytes. Private/evidence phases are also supported.
- `{"command":"retry-confirmed-unexecuted","action_id":"EXACT_ORIGINAL_ID",
  "confirmed_not_applied":true,"resolution_reference":"verified rejection and approval reference"}`:
  an exceptional operator-controlled retry after unequivocally establishing
  nonexecution and resolving any required approval. A timeout, missing
  acknowledgement, or unknown commit SHA is not such evidence. The pump never
  invokes this command. The assertion is retained as operator evidence, never
  represented as authenticated network proof. Retrying a ref first refreshes
  the pre-update head check. Existing authorization/approval controls still apply.

Known connector constraint: commit creation supplies neither a deterministic
clock nor an idempotency key. If its successful SHA and acknowledgement are both
lost before durable recording, the safe outcome is a pause for exact object
adoption. Searching or inventing another commit is not a safe substitute.
If a local host command outlives the initial exec wait, the pump polls that exact
exec session with `write_stdin`; without that capability it returns the session
ID and must not start the command again until that session is resolved.

Keep the private run directory. A fresh journal encountering any existing
immutable release-ID paths stops before publication, including when a newer
release has since moved the public alias. This prevents duplicate commits and
rollback of a newer alias. Automatic remote reconstruction of the complete
journal is not implemented. Cross-workspace continuation requires an exact copy
of the original private journal and frozen bundle with preserved location pins,
or a separately reviewed import of the original authenticated baseline,
plan, commit/ref/tree observations and immutable returned bytes. The final
outcome record alone is not that complete journal or permission to invent a
historical branch observation. Reusing an ID with changed bytes is refused.

Live Pages support is intentionally limited to this owner-root, branch-deployed
site: `dynamic/pages/pages-build-deployment` at the exact public commit. Custom
Actions Pages workflows, project-subpath sites and custom domains are outside
this version's contract. A failed deployment preserves Git/private success and
returns `deployment-failed`; a pending workflow/CDN returns `pending`. Later
invocation checks again without repeating completed writes.

## Verification

```sh
python3 -m unittest discover -s tests -p test_delivery_runner.py
node tests/test_github_delivery_runner.js
```

The normal Python test discovery automatically executes a fast JS host smoke
in an isolated V8 context through installed Node. Missing Node fails explicitly;
host validation is never silently skipped. Existing Quality CI runs this through
`./lumen verify`; normal `./lumen ship` also includes it. The slower full Node
failure suite below is an explicit integration gate.

The Node integration harness executes the actual JS pump and Python host against
in-memory GitHub mock repositories. It covers stopped/resumed delivery, alias
blob deduplication, protected unrelated files, lost acknowledgements, verified
orphan adoption, failed-read recovery, concurrency replan, newer-alias replay
protection, pending Pages/CDN, automatic scoped receipt publication, and zero-
mutation completed replay. Mock results are not evidence of a live publication;
a real connector acceptance run is a separate gate.
