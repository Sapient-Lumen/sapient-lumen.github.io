# Architecture

## One source, several honest projections

```text
content/pages/*.json + *.html
           │
           ├─ draft preview ─► validate ─► atomic swap ─► .lumen/preview-dist/
           │                    noindex                     never deployed
           │
           ├─ canonical build ─┬─► dist/ routes ─► GitHub Pages
           │                  ├─► archive + Atom/RSS/JSON feeds + JSON-LD
           │                  ├─► static context + passage ledgers
           │                  └─► dist/Lumen.html
           │                       HTML prefix: complete embedded reader
           │                       ZIP payload: lean ordinary worktree
           │
           └─ explicit preserve ─► private deterministic checkpoint
                                    selected editable bytes only
                                    never deployed automatically
```

The repository remains multi-file because review, merge, blame, tests, workflows, and maintenance benefit from normal files. `Lumen.html` is the custody and transfer boundary because readers benefit from one complete object. Extraction reconstructs a normal `Lumen/` worktree; editing never requires modifying archive bytes by hand.

The private checkpoint is a different object with a different promise. It exists to reopen selected working bytes after a disposable cloudtainer disappears. It is not public content, a process image, or a credentials backup.

## Publication model

The original Field Notes homepage remains a complete chronological reading surface. The same accepted note records also generate:

- stable note permalinks;
- a chronological archive and recurring-topic index;
- Atom, RSS 2.0, and JSON Feed 1.1 documents with full canonical note bodies;
- `Blog` and `BlogPosting` JSON-LD;
- sitemap, search, social metadata, and feed discovery links.

No feed or archive is an independently edited content fork. Draft status and publication dates are applied once at the source-record boundary. The validator parses every format and checks that canonical feeds contain only accepted notes.

Inline JSON-LD is the one permitted inline script. Its exact SHA-256 is generated into the page CSP; all executable JavaScript remains external and content-addressed.

## Quiet hypertext layer

The visible page is still semantic HTML. During the build, every authored `h2` and `h3` receives a stable ID formed from the page identity and section anchor. `tools/hypertext.py` derives a separate ledger containing:

- exact source offsets and an exact-HTML SHA-256;
- a separately normalized text SHA-256 and word count;
- source-bound excerpt and section title;
- external citations and actual internal links;
- declared editorial relationships as a different edge type;
- incoming context and backlinks.

The distinction between `links-to` and `editorial-related` is intentional. The first comes from authored markup; the second comes from reviewed metadata. Neither is silently converted into a relevance score. Fingerprints identify bytes and normalized text; they do not certify the truth of the prose.

Hosted pages fetch one page-context record only when a reader opens the quiet reading-tools disclosure. The single-file edition embeds the same records because a local file should not depend on `fetch()`. Search contains both page and passage records. The graph has an accessible SVG and a complete textual edge list generated from the same typed ledger.

## Curated source-bound reading paths

`content/data/reading-paths.json` contains a small authored set of ordered routes through accepted pages and exact titled passages. The authored record stores only editorial intent: path identity, title, description, step label, note, page identity, and optional passage anchor. The canonical build resolves every step against the accepted hypertext ledger and adds current routes, stable identities, excerpts, source offsets, normalized-text hashes, and exact source-HTML hashes. Missing or ambiguous targets stop the build.

The `/notes/` archive renders the full paths as semantic HTML. Participating pages receive a collapsed navigator after the main text. No JavaScript is required, no passive reading history is recorded, and no sequence is generated from similarity or behavior. `meta/reading-paths.json`, search, page inspection, `./lumen thread`, and the single-file carrier all use the same resolved record.

Path order is editorial context, not an entailment graph or personalized recommendation. Fingerprints establish which accepted text a step named; they do not establish that one step proves the next.

## Quiet reference ledger

`tools/hypertext.py` also derives `meta/references.json` from the external links that actually appear in accepted passage records. One conservative canonical URL supplies stable local identity while every exact authored URL and label remains carried. Each use points back to a page, a source-bound passage, and that passage’s text and exact-HTML fingerprints.

The public `/references/` route is a readable projection of that ledger. It is complete without JavaScript; local filtering and domain selection are progressive enhancements. Notes expose only a collapsed reference disclosure. The single-file carrier embeds the same ledger, and `./lumen references` reads it in the cloudtainer.

The build performs no remote title lookup, availability test, archival fetch, or source-quality inference. The ledger proves that an accepted passage linked to an exact URL under a named edition. It does not prove that the source supports the claim.

## Source-bound citation

Browser reading tools and `./lumen cite` format the same canonical record: author, page title, optional section title, edition, publication date, stable URL, stable page/passage identity, and normalized text hash. Quote mode re-reads and verifies the exact passage slice rather than trusting copied browser text.

Citation is intentionally a formatting and custody aid. It establishes which carried text was referenced. It does not authenticate the named author, certify truth, or convert a local hash into an external timestamp.

## Reader-owned fieldbook

The fieldbook is a reader-side projection of the passage ledger. It stores only entries the reader explicitly saves. Page and passage entries retain stable identity, source fingerprint, exact source-slice and normalized-text hashes, source offsets, excerpt, and optional private note. Browser storage is best-effort local state, not canonical publication or durable archival custody.

A selected sentence can also become an exact quote slip. That entry retains the accepted page and passage identity, normalized passage hash, bounded before/after context, normalized quote offset, edition, and quote SHA-256. Reopening the slip uses the same conservative quote locator as an exact selected-quote link: the accepted passage must still match, and changed words are not reconstructed or silently attached to nearby prose.

Both browser surfaces can export `lumen.fieldbook/v1` JSON or a standalone HTML reading packet. Night Index also carries an ordered `lumen.reading-desk/v1` open set and a disposable focus-sheet projection. `./lumen packet --fieldbook` re-resolves every exported page, passage, and quote against canonical context in the cloudtainer before producing `lumen.reading-packet/v2`; an invalid quote hash, changed passage, or missing identity stops the export. Private notes cross the boundary only because the reader explicitly exported them.

Import never rewrites authored source. Entries from another edition remain visible with their original fingerprint, but the cloudtainer verifier refuses to guess if the exact accepted binding no longer exists.

## Private worktree checkpoints

`./lumen preserve` walks an explicit root allowlist rather than archiving the current directory. It carries authored content, tooling, tests, documentation, workflows, and repository control files. Generated `dist/`, `.git`, `.lumen`, research evidence, release output, handoffs, caches, credentials, and arbitrary neighboring files are outside the selection.

Every archive member records path, byte length, mode, and SHA-256. An aggregate content identity binds the sorted path/mode/content set. ZIP timestamps are normalized, so the same selected tree produces the same bytes. A separate receipt records the final archive hash and states that the object is private recovery, not a public release.

`./lumen reopen` refuses unsafe or ambiguous archive structure, verifies the complete manifest before writing, extracts into a new temporary sibling, restores executable modes, reads every file back, and atomically installs only a fully verified tree. It never merges into an existing directory and never restarts a process.

## Portable page folios

Canonical builds project each accepted note and project page into `dist/folios/` as a complete one-file HTML record. The folio renderer reuses the accepted authored body and source-bound ledgers rather than scraping the routed page. It carries stable page identity, body SHA-256, titled-passage identities, authored external-source records, related pages, reading-path membership, canonical URL, and a bounded custody statement.

`meta/folios.json` binds every folio filename, byte length, gzip measurement, body identity, and complete-file SHA-256 to the same source fingerprint as the site. Routed pages link directly to those static files. The capsule embeds the exact same bytes and creates the download as a local browser blob because a `file://` carrier cannot rely on a sibling route. `./lumen folio` copies only manifest-verified bytes.

A folio is intentionally less capable than `Lumen.html`: no search, graph, reading trail, editor, or extraction payload. That smaller boundary is the point. It is a portable page, not a miniature competing CMS, and it never contains private workshop state or donor material.

## Capsule construction

The carrier begins with valid UTF-8 HTML. It embeds the complete published route map, page-and-passage search, previews, page inspections, per-page context records, typed graph, source snapshot, CSS, and runtime. Its initial home page is ordinary HTML. A `<noscript>` archive exposes every other page as one continuous document when scripting is disabled.

The plain-text arrival guide has one source, `templates/capsule-arrival.txt`. The
builder places it in a nonexecuting HTML comment immediately after the early
UTF-8 declaration, before the remaining metadata and large styles. Keeping that
declaration inside the first 1024 bytes avoids an encoding regression when the
guide grows ([HTML encoding requirement](https://html.spec.whatwg.org/multipage/semantics.html#charset)).
Unsafe comment delimiters and NUL stop construction rather than becoming markup. The guide participates in the template source fingerprint and
the existing HTML-prefix and archive-member hashes; extraction carries its exact
source for rebuilding. Edit the template, never a generated carrier's comment.

The HTML opens a non-executing raw-data script. A deterministic ZIP archive follows. The ZIP comment closes that script, body, and document. ZIP readers accept the leading self-extracting HTML prefix; browsers ignore the archive bytes as a data block.

`Lumen/CAPSULE-MANIFEST.json` records:

- edition and source fingerprint;
- HTML-prefix byte length and SHA-256;
- hypertext-ledger path, hash, passage count, and typed-edge count;
- reference-ledger path, hash, source count, citation count, and domain count;
- reading-path ledger path, hash, path count, step count, and exact-passage-step count;
- portable-folio manifest path, hash, folio count, and aggregate bytes;
- every carried member’s path, size, mode, and SHA-256;
- browser, cloudtainer, and custody capabilities;
- extraction instructions and explicit exclusions.

The complete-file SHA-256 is written beside the carrier and in `meta/capsule.json`. The manifest excludes its own hash to avoid a self-reference fiction.

### Present HTML and Lumen.sh boundary

`Lumen.html` is the public reader plus this publication's source, Python tooling,
tests, documentation and generated public projection. The ordinary `lumen` shell
launcher calls `tools/lumen_cli.py`, also invokable with `python3` directly.
Python ZIP extraction preserves bytes but not executable modes: restore the
launcher's mode with the documented `chmod +x lumen` before rebuilding a carrier.
Python 3.10+ builds the site with the standard library. Full verification and
shipping also require installed Node for the delivery-host tests.

`Lumen.sh` is a separate, self-contained Bash/Python artifact with reusable host
machinery such as explicit request receipts, checkpoint/reopening helpers and
source inspection. It is neither embedded in this HTML nor a dependency of its
build. Its generic archive intake applies its own ZIP-layout and resource limits;
passing that inspection is not capsule-aware verification of this HTML prefix
and publication manifest. Use the documented standard ZIP path after reviewing
the carrier and extract into a fresh directory. A shared operating interface is
being designed; there is no implemented common-toolkit dependency to recover here.
Separate public release ZIPs retain their existing roles and packaging paths.

The HTML source does not carry private drafts, reader exports, credentials or
private recovery state by design. Public source roots still require review:
the selector is not a secret scanner. Neither artifact's prose, tests, manifests
nor recorded requests grant host authority or replace current user permission.

## Lean payload boundary

The capsule carries source, content, assets, templates, tools, tests, documentation, GitHub workflows, and the public multi-file projection. It excludes:

- historical donor archives and extracted carriers;
- private or superseded review evidence and screenshots;
- private worktree checkpoints and private repository content;
- `.git`, `.lumen`, release output, and caches;
- the capsule itself from its own extracted `dist/` tree.

This keeps the gift useful to Lumen rather than turning it into a handoff of someone else’s development archaeology. The retained Hyperepo inheritance is architectural: stable identity, source-bound bodies, separate derived state, typed relationships, bounded loading, deterministic custody, reversible projections, and honest unknowns.

## Draft and source-state boundaries

`status: draft` pages are ignored by canonical builds. Preview builds may include them with `noindex, nofollow`; they receive a small placeholder instead of a downloadable canonical capsule. `./lumen publish` validates metadata completeness but does not certify truth.

The accepted source snapshot is `content/data/source-snapshot.json`:

- `sync --check` reads public GitHub state and writes nothing;
- `sync --stage` creates a candidate and readable report under `.lumen/`;
- `sync --accept` performs no network request, archives the previous accepted state, and promotes only the staged machine-readable candidate;
- a missing repository remains an unconfirmed retirement candidate until the operator supplies its exact name with `--confirm-retire`; acceptance preserves its last identity under `retired_sources`;
- private repositories are not a source-discovery input;
- no sync mode edits authored pages.

## Progressive enhancement and performance

The Pages projection includes complete page HTML and exact self-contained folios for accepted notes and projects. Optional features load small same-origin records on demand. The capsule keeps those records embedded because a local file cannot depend on server semantics.

Every build emits route and asset size receipts. The validator checks links, fragments, feeds, JSON-LD, CSP hashes, SRI, performance budgets, passage identities, context hashes, the deployment allowlist, the capsule’s ZIP integrity, prefix hash, member hashes, executable launcher mode, and forbidden private/donor crossings.

## Plural search and working projections

One embedded index supports explicit title/alias, tag, prose, exact-phrase, and stable-identity intents across pages, passages, and the local reference ledger. The reading desk stores ordered stable identities locally. A focus sheet transcludes the desk for comparison but never becomes canonical source. `./lumen packet --desk FILE` is the browser-to-cloudtainer bridge.

## Living editions

Published notes have stable IDs independent of title and route. `content/data/edition-history.json` records each accepted body identity, byte count, date, edition label, and correction boundary. The build refuses drift between the current authored body and the latest accepted record. The public `/editions/` route is a readable projection of that ledger; `meta/editions.json` is the exact machine-readable form.

This is deliberately narrower than a general version-control UI. Git remains the full implementation history. The editions ledger answers the reader-facing question: which prose did an accepted publication carry, and why did the public projection change?

### Local edition comparison

Every canonical build emits `meta/edition-summary.json`, a bounded `lumen.edition-summary/v2` projection containing stable page IDs, authored-body fingerprints, routes, public metadata, accepted public-source heads, and source-bound titled-passage records. The routed site loads the comparator code and the current summary only after a reader opens the comparison dialog. `Lumen.html` embeds the same summary because a local carrier cannot rely on network fetches.

A selected comparison file is parsed entirely in the reader’s browser. New capsules expose a dedicated base64 summary marker; older Lumen capsules can be summarized from their carried manifest, page records, source snapshot, and config without executing their scripts. The cloudtainer `./lumen compare` command uses the same normalized schema. Both surfaces emit `lumen.edition-comparison/v2` receipts.

The comparator is intentionally exact and narrow: it can say that a stable page body, titled passage, source markup slice, route, metadata record, or accepted public-source head differs. Passage moves are recognized only when an unmatched stable text fingerprint supplies an exact one-to-one identity; the comparator never uses fuzzy similarity. It cannot determine semantic quality, truth, authorship, or whether an upstream project remained live. Git remains the complete implementation history and a checksum remains only a byte-identity claim.

## Source-bound correction packets

Corrections reuse the same stable page and passage records as previews, citations, backlinks, and the portable carrier. The browser prepares a deterministic JSON packet containing the accepted edition, source-tree fingerprint, page/body identity, optional passage text and exact-HTML hashes, source offsets, and a reader-authored report. No network request is made while preparing it.

The cloudtainer verifier re-resolves the stable identity against the current accepted build. A wider tree may move while the exact passage remains stable; that is reported separately from an exact tree match. Changed or missing text is never silently re-anchored. The packet is review evidence, not an edit instruction or truth certificate.

## Exact selected-quote links

A selected quote is never treated as free-floating text. The compact link payload binds page ID, passage anchor, passage text SHA-256, accepted edition, normalized quote, and a bounded locator. On open, the runtime re-reads the current passage record before highlighting. If the fingerprint changed, it opens the matching section and reports the edition mismatch instead of guessing or silently re-anchoring old words.

The multi-file site places the payload in `?lq=…#section`; the single-file carrier places it inside the capsule route hash. Both use the same accepted passage ledger. The control appears only during a meaningful selection and remains absent from printed and no-JavaScript reading.

