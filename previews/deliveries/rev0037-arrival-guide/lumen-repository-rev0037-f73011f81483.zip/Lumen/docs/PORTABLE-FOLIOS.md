# Portable page folios

A folio is one accepted Lumen page carried as a complete HTML file. It is the smallest public custody object in this project: smaller than the full `Lumen.html` edition, but more trustworthy and useful than copying rendered text out of a browser.

## Reader surface

Accepted notes and project pages include a quiet **Keep this page** link. On GitHub Pages it downloads a static file from `/folios/`. Inside `Lumen.html` the same control writes the exact embedded bytes as a local browser download. The reading page remains an ordinary link when JavaScript is absent.

A folio includes:

- the accepted authored body and public metadata;
- stable page identity and body SHA-256;
- titled-passage identities and bounded excerpts;
- authored external links as used by the page;
- declared related pages and curated reading-path membership;
- the accepted edition and source fingerprint;
- a narrow statement of what the file does and does not prove.

It intentionally excludes search, the graph, browser-local reading state, correction drafts, editor tools, private checkpoints, private repositories, donor archives, and the extractable worktree.

## Cloudtainer surface

```sh
./lumen folio
./lumen folio note-concern-control --check
./lumen folio note-concern-control --output kept/concern-and-control.html
```

`./lumen folio` resolves the same stable page IDs and routes as the rest of the command deck. Before copying, it checks the selected member against `dist/meta/folios.json` for path safety, byte length, and SHA-256. Writes are atomic. Existing different bytes are refused unless `--replace` is explicit; an already exact destination is left alone. Add `--build` to refresh the canonical distribution first.

## Build and verification boundary

The folio renderer consumes accepted source records directly. It does not scrape the generated route. `meta/folios.json` uses schema `lumen.portable-folios/v1` and records aggregate and per-file identities. The distribution validator checks:

- manifest schema, edition, and source fingerprint;
- safe unique member paths and page identities;
- exact file length, SHA-256, and deterministic gzip measurement;
- parity with page inspection and edition-summary records;
- the accepted authored-body hash;
- one strict inline-style CSP hash and one exact JSON-LD script hash;
- a per-folio and aggregate size ceiling.

The capsule validator separately checks that its embedded folios match the same manifest. This makes the routed file, the one-file edition, and the cloudtainer export three projections of one accepted record rather than three hand-maintained copies.

## Interpretation boundary

A matching hash proves byte identity with the accepted build. It does not prove that the page’s argument is true, that an external source still says the same thing, that an author or process remained continuously alive, or that the folio is the whole publication. The canonical page and complete edition remain linked from the file for readers who want the surrounding work.
