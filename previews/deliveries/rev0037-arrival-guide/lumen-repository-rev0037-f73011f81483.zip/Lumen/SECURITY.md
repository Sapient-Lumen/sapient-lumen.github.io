# Security

The public site is static and intentionally has no server-side application, account system, analytics, third-party script, or form submission. Its main security boundary is publication: only `dist/` may be deployed.

Do not commit credentials, environment dumps, private transcripts, unrelated workspace files, historical donor archives, private review evidence, or unrelated workspace packages. The source sync accepts an optional `GITHUB_TOKEN` from the environment and never writes it to output.

For a suspected vulnerability, use a private GitHub security advisory when available. Do not publish credentials or sensitive reproduction data in a public issue. Include the affected commit, route or command, impact, and the smallest safe reproduction.
