#!/usr/bin/env python3
"""Build Lumen's dependency-free static site.

Only Python's standard library is required. The builder validates metadata,
generates reading pages, creates lazy-loaded inspection/search resources, and
writes an allowlisted `dist/` directory suitable for GitHub Pages.
"""
from __future__ import annotations

import argparse
import base64
import datetime as dt
import email.utils
import gzip
import hashlib
import html
import json
import os
import re
import shutil
import sys
import textwrap
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import urljoin

TOOLS = Path(__file__).resolve().parent
if str(TOOLS) not in sys.path:
    sys.path.insert(0, str(TOOLS))
from public_source import publication_content_files
from hypertext import (
    build_context_ledger,
    build_passages,
    build_reference_index,
    canonical_external_url,
)

ROOT = Path(__file__).resolve().parents[1]
CONTENT = ROOT / "content" / "pages"
ASSETS = ROOT / "assets"
TEMPLATES = ROOT / "templates"
DEFAULT_DIST = ROOT / "dist"
EDITION_HISTORY = ROOT / "content" / "data" / "edition-history.json"
READING_PATHS = ROOT / "content" / "data" / "reading-paths.json"
DIST = DEFAULT_DIST  # Backward-compatible module alias; build() accepts an explicit output.
REQUIRED = {"id", "url", "kind", "title", "description", "author", "body"}
SLUG_RE = re.compile(r"[^a-z0-9]+")
HEADING_RE = re.compile(r"<h([23])(?:\s+[^>]*)?>(.*?)</h\1>", re.I | re.S)
TAG_RE = re.compile(r"<[^>]+>")
INTERNAL_HREF_RE = re.compile(r'href="(/[^"]*)"')
EXTERNAL_ANCHOR_RE = re.compile(
    r'<a(?P<attrs>\s+[^>]*?href="(?P<href>https?://[^"]+)"[^>]*)>',
    re.I,
)


class TextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self._hidden_depth = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in {"script", "style", "svg"}:
            self._hidden_depth += 1

    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style", "svg"} and self._hidden_depth:
            self._hidden_depth -= 1
        if tag in {"p", "h1", "h2", "h3", "li", "blockquote", "dd", "dt"}:
            self.parts.append(" ")

    def handle_data(self, data: str) -> None:
        if not self._hidden_depth:
            self.parts.append(data)

    def text(self) -> str:
        return re.sub(r"\s+", " ", "".join(self.parts)).strip()


@dataclass(frozen=True)
class Page:
    meta_path: Path
    data: dict[str, Any]
    body_html: str

    @property
    def id(self) -> str:
        return self.data["id"]

    @property
    def url(self) -> str:
        return self.data["url"]

    @property
    def kind(self) -> str:
        return self.data["kind"]

    @property
    def title(self) -> str:
        return self.data["title"]

    @property
    def status(self) -> str:
        return str(self.data.get("status", "published"))


def e(value: Any) -> str:
    return html.escape(str(value), quote=True)


def slugify(value: str) -> str:
    text = TAG_RE.sub("", value)
    text = html.unescape(text).lower()
    return SLUG_RE.sub("-", text).strip("-") or "section"


def plain_text(fragment: str) -> str:
    parser = TextExtractor()
    parser.feed(fragment)
    parser.close()
    return parser.text()


def read_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise SystemExit(f"Cannot read {path.relative_to(ROOT)}: {exc}") from exc


def page_body_identity(page: "Page") -> dict[str, Any]:
    raw = page.body_html.encode("utf-8")
    return {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}


def load_edition_history(pages: list["Page"]) -> dict[str, Any]:
    payload = read_json(EDITION_HISTORY)
    if payload.get("schema") != "lumen.edition-history/v1":
        raise SystemExit("content/data/edition-history.json has an unsupported schema")
    notes = payload.get("notes")
    if not isinstance(notes, dict):
        raise SystemExit("edition history must contain a notes object")
    # The acceptance ledger describes published notes, not unpublished preview work.
    note_pages = {page.id: page for page in pages if page.kind == "note" and page.status == "published"}
    missing = sorted(set(note_pages) - set(notes))
    extra = sorted(set(notes) - set(note_pages))
    if missing:
        raise SystemExit(f"edition history missing note ids: {missing}")
    if extra:
        raise SystemExit(f"edition history contains unknown note ids: {extra}")
    digest_re = re.compile(r"^[0-9a-f]{64}$")
    for page_id, page in note_pages.items():
        record = notes[page_id]
        revisions = record.get("revisions") if isinstance(record, dict) else None
        if not isinstance(revisions, list) or not revisions:
            raise SystemExit(f"edition history for {page_id} must contain at least one revision")
        previous_date = ""
        for index, revision in enumerate(revisions):
            if not isinstance(revision, dict):
                raise SystemExit(f"edition history for {page_id} revision {index + 1} is not an object")
            for field in ("edition", "date", "summary", "body_sha256", "body_bytes"):
                if field not in revision:
                    raise SystemExit(f"edition history for {page_id} revision {index + 1} missing {field}")
            try:
                dt.date.fromisoformat(str(revision["date"]))
            except ValueError as exc:
                raise SystemExit(f"edition history for {page_id} has invalid date {revision['date']!r}") from exc
            if previous_date and str(revision["date"]) < previous_date:
                raise SystemExit(f"edition history for {page_id} is not chronological")
            previous_date = str(revision["date"])
            if not digest_re.fullmatch(str(revision["body_sha256"])):
                raise SystemExit(f"edition history for {page_id} has invalid body_sha256")
            if int(revision["body_bytes"]) < 0:
                raise SystemExit(f"edition history for {page_id} has invalid body_bytes")
        current = page_body_identity(page)
        latest = revisions[-1]
        if latest["body_sha256"] != current["sha256"] or int(latest["body_bytes"]) != current["bytes"]:
            raise SystemExit(
                f"{page_id}: authored body differs from the latest edition-history record; "
                f"run ./lumen revise {page_id} --summary '…' after reviewing the change"
            )
        page.data["modified"] = str(latest["date"])
        page.data["revision_count"] = len(revisions)
    return payload


def note_history_records(history: dict[str, Any], page_id: str) -> list[dict[str, Any]]:
    return list(history.get("notes", {}).get(page_id, {}).get("revisions", []))


def load_reading_paths(pages_by_id: dict[str, "Page"]) -> dict[str, Any]:
    payload = read_json(READING_PATHS)
    if payload.get("schema") != "lumen.reading-paths/v1":
        raise SystemExit("content/data/reading-paths.json has an unsupported schema")
    paths = payload.get("paths")
    if not isinstance(paths, list) or not paths:
        raise SystemExit("reading paths must contain a non-empty paths list")
    seen_paths: set[str] = set()
    for row in paths:
        if not isinstance(row, dict):
            raise SystemExit("every reading path must be an object")
        path_id = str(row.get("id", "")).strip()
        if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", path_id):
            raise SystemExit(f"invalid reading path id: {path_id!r}")
        if path_id in seen_paths:
            raise SystemExit(f"duplicate reading path id: {path_id}")
        seen_paths.add(path_id)
        if not str(row.get("title", "")).strip() or not str(row.get("description", "")).strip():
            raise SystemExit(f"reading path {path_id} needs a title and description")
        steps = row.get("steps")
        if not isinstance(steps, list) or len(steps) < 2:
            raise SystemExit(f"reading path {path_id} must contain at least two steps")
        seen_targets: set[str] = set()
        for index, step in enumerate(steps, 1):
            if not isinstance(step, dict):
                raise SystemExit(f"reading path {path_id} step {index} is not an object")
            page_id = str(step.get("page_id", "")).strip()
            anchor = str(step.get("anchor", "")).strip()
            if page_id not in pages_by_id:
                raise SystemExit(f"reading path {path_id} step {index} names unknown page {page_id!r}")
            if pages_by_id[page_id].status != "published":
                raise SystemExit(f"reading path {path_id} step {index} names unpublished page {page_id!r}")
            target = f"{page_id}#{anchor}" if anchor else page_id
            if target in seen_targets:
                raise SystemExit(f"reading path {path_id} repeats target {target}")
            seen_targets.add(target)
            if not str(step.get("label", "")).strip() or not str(step.get("note", "")).strip():
                raise SystemExit(f"reading path {path_id} step {index} needs a label and note")
    return payload


def reading_path_href(step: dict[str, Any], pages_by_id: dict[str, "Page"]) -> str:
    page = pages_by_id[str(step["page_id"])]
    anchor = str(step.get("anchor", "")).strip()
    return page.url + (f"#{anchor}" if anchor else "")


def reading_path_folio_filename(path_id: str, edition: str) -> str:
    """Stable filename for one portable authored route through the site."""
    return f"path-{slugify(path_id)}-{slugify(edition)}.html"


def reading_path_folio_link(path: dict[str, Any], edition: str) -> str:
    filename = reading_path_folio_filename(str(path["id"]), edition)
    return (
        f'<a class="reading-path-folio-link" href="/path-folios/{e(filename)}" '
        f'download="Lumen-{e(filename)}" data-path-folio-download="{e(path["id"])}">'
        "Keep this path</a>"
    )


def reading_path_steps_markup(path: dict[str, Any], pages_by_id: dict[str, "Page"], *, current_page_id: str = "") -> str:
    items: list[str] = []
    for index, step in enumerate(path.get("steps", []), 1):
        page = pages_by_id[str(step["page_id"])]
        current = page.id == current_page_id
        href = reading_path_href(step, pages_by_id)
        current_attr = ' aria-current="location"' if current else ""
        items.append(
            f'<li class="reading-path-step{" reading-path-step--current" if current else ""}">'
            f'<span class="reading-path-number">{index:02d}</span>'
            f'<div><a href="{e(href)}"{current_attr}>{e(step.get("label", page.title))}</a>'
            f'<p>{e(step.get("note", ""))}</p><small>{e(page.title)}</small></div></li>'
        )
    return "".join(items)


def reading_paths_archive_markup(payload: dict[str, Any], pages_by_id: dict[str, "Page"], edition: str) -> str:
    cards: list[str] = []
    for path in payload.get("paths", []):
        cards.append(
            f'<article class="reading-path-card" id="path-{e(path["id"])}">'
            f'<p class="eyebrow">Curated path · {len(path.get("steps", []))} stops</p>'
            f'<h3>{e(path["title"])}</h3><p>{e(path["description"])}</p>'
            f'<ol class="reading-path-steps">{reading_path_steps_markup(path, pages_by_id)}</ol>'
            f'<p class="reading-path-custody">{reading_path_folio_link(path, edition)}</p></article>'
        )
    return '<div class="reading-path-grid">' + "".join(cards) + "</div>"


def reading_paths_for_page_markup(page: "Page", payload: dict[str, Any], pages_by_id: dict[str, "Page"], edition: str) -> str:
    matching = [path for path in payload.get("paths", []) if any(str(step.get("page_id")) == page.id for step in path.get("steps", []))]
    if not matching:
        return ""
    cards = []
    for path in matching:
        cards.append(
            f'<details class="reading-path-inline"><summary><span>Follow a thread</span><strong>{e(path["title"])}</strong>'
            f'<small>{len(path.get("steps", []))} stops</small></summary>'
            f'<p>{e(path["description"])}</p>'
            f'<ol class="reading-path-steps">{reading_path_steps_markup(path, pages_by_id, current_page_id=page.id)}</ol>'
            f'<p class="reading-path-custody">{reading_path_folio_link(path, edition)}</p></details>'
        )
    return '<section class="reading-paths-inline" aria-label="Curated reading paths">' + "".join(cards) + "</section>"


def resolve_reading_paths(
    payload: dict[str, Any],
    pages_by_id: dict[str, "Page"],
    page_descriptors: list[dict[str, Any]],
    passages_by_page: dict[str, list[dict[str, Any]]],
    *,
    source_fingerprint: str,
    generated_at: str,
    edition: str,
) -> tuple[dict[str, Any], dict[str, list[dict[str, Any]]]]:
    descriptors = {row["id"]: row for row in page_descriptors}
    memberships: dict[str, list[dict[str, Any]]] = {page_id: [] for page_id in pages_by_id}
    resolved: list[dict[str, Any]] = []
    for path in payload.get("paths", []):
        steps: list[dict[str, Any]] = []
        total = len(path.get("steps", []))
        for index, step in enumerate(path.get("steps", []), 1):
            page_id = str(step["page_id"])
            page = pages_by_id[page_id]
            descriptor = descriptors[page_id]
            anchor = str(step.get("anchor", "")).strip()
            passage = None
            if anchor:
                matches = [row for row in passages_by_page.get(page_id, []) if row.get("anchor") == anchor or row.get("id") == anchor]
                if len(matches) != 1:
                    available = ", ".join(str(row.get("anchor")) for row in passages_by_page.get(page_id, [])) or "no authored passages"
                    raise SystemExit(f"reading path {path['id']} step {index} cannot resolve {page_id}#{anchor}; available: {available}")
                passage = matches[0]
            record = {
                "order": index,
                "page_id": page_id,
                "page_title": page.title,
                "scope": "passage" if passage else "page",
                "stable_id": passage["id"] if passage else page_id,
                "anchor": passage["anchor"] if passage else None,
                "url": passage["url"] if passage else page.url,
                "label": str(step["label"]),
                "note": str(step["note"]),
                "title": passage["title"] if passage else page.title,
                "excerpt": passage["excerpt"] if passage else page.data.get("description", ""),
                "word_count": passage["word_count"] if passage else descriptor["word_count"],
                "text_sha256": passage["text_sha256"] if passage else descriptor["body_sha256"],
                "source_html_sha256": passage["source_html_sha256"] if passage else descriptor["body_sha256"],
            }
            steps.append(record)
            memberships[page_id].append({
                "path_id": path["id"],
                "path_title": path["title"],
                "step": index,
                "steps": total,
                "stable_id": record["stable_id"],
                "url": record["url"],
                "text_sha256": record["text_sha256"],
            })
        resolved.append({
            "id": path["id"],
            "title": path["title"],
            "description": path["description"],
            "steps": steps,
        })
    memberships = {page_id: rows for page_id, rows in memberships.items() if rows}
    result = {
        "schema": "lumen.reading-paths/v1",
        "edition": edition,
        "generated_at": generated_at,
        "source_fingerprint_sha256": source_fingerprint,
        "counts": {
            "paths": len(resolved),
            "steps": sum(len(path["steps"]) for path in resolved),
            "pages": len(memberships),
            "passage_steps": sum(step["scope"] == "passage" for path in resolved for step in path["steps"]),
        },
        "paths": resolved,
        "boundary": payload.get("boundary"),
    }
    return result, memberships


def publication_history_markup(page: "Page", history: dict[str, Any]) -> str:
    revisions = note_history_records(history, page.id)
    if len(revisions) < 2:
        return ""
    items = []
    for index, revision in enumerate(reversed(revisions)):
        current = index == 0
        items.append(
            f'<li class="publication-revision{" publication-revision--current" if current else ""}">'
            f'<div><time datetime="{e(revision["date"])}">{e(human_date(str(revision["date"])))}</time>'
            f'<span>{e(revision["edition"])}{" · current" if current else ""}</span></div>'
            f'<p>{e(revision["summary"])}</p>'
            f'<code>{e(str(revision["body_sha256"])[:16])}</code>'
            f'</li>'
        )
    return (
        f'<details class="publication-history" id="history-{e(page.id)}">'
        f'<summary>Publication history · {len(revisions)} accepted versions</summary>'
        f'<ol>{"".join(items)}</ol>'
        f'<p><a href="/editions/#history-{e(page.id)}">Open the complete editions ledger</a></p>'
        f'</details>'
    )


def edition_history_markup(notes: list["Page"], history: dict[str, Any]) -> str:
    blocks: list[str] = []
    for page in sorted(notes, key=lambda row: (row.data.get("date", ""), row.data.get("number", "")), reverse=True):
        revisions = note_history_records(history, page.id)
        rows = []
        for index, revision in enumerate(reversed(revisions)):
            current = index == 0
            rows.append(
                f'<li class="edition-record{" edition-record--current" if current else ""}">'
                f'<div class="edition-record-head"><time datetime="{e(revision["date"])}">{e(human_date(str(revision["date"])))}</time>'
                f'<span>{e(revision["edition"])}{" · current" if current else ""}</span></div>'
                f'<p>{e(revision["summary"])}</p>'
                f'<dl><dt>Body identity</dt><dd><code>{e(revision["body_sha256"])}</code></dd>'
                f'<dt>Bytes</dt><dd>{e(revision["body_bytes"])}</dd>'
                f'<dt>Boundary</dt><dd>{e(revision.get("source_ref", "Retained edition record"))}</dd></dl>'
                f'</li>'
            )
        blocks.append(
            f'<article class="edition-note" id="history-{e(page.id)}">'
            f'<header><p class="eyebrow">Note {e(page.data.get("number", ""))} · {len(revisions)} version{"s" if len(revisions) != 1 else ""}</p>'
            f'<h3><a href="{e(page.url)}">{e(page.title)}</a></h3></header>'
            f'<ol>{"".join(rows)}</ol></article>'
        )
    return "".join(blocks)


def load_pages(*, include_drafts: bool = False) -> list[Page]:
    all_pages: list[Page] = []
    for meta_path in sorted(CONTENT.rglob("*.json")):
        data = read_json(meta_path)
        missing = REQUIRED - data.keys()
        if missing:
            raise SystemExit(f"{meta_path.relative_to(ROOT)} missing: {sorted(missing)}")
        status = str(data.get("status", "published"))
        if status not in {"published", "draft"}:
            raise SystemExit(f"{meta_path.relative_to(ROOT)} has unsupported status: {status!r}")
        if not str(data["url"]).startswith("/"):
            raise SystemExit(f"{meta_path.relative_to(ROOT)} url must start with /")
        body_path = (meta_path.parent / data["body"]).resolve()
        if CONTENT.resolve() not in body_path.parents:
            raise SystemExit(f"Body escapes content directory: {body_path}")
        try:
            body = body_path.read_text(encoding="utf-8")
        except OSError as exc:
            raise SystemExit(f"Cannot read body {body_path}: {exc}") from exc
        all_pages.append(Page(meta_path=meta_path, data=data, body_html=body))

    ids = [p.id for p in all_pages]
    urls = [p.url for p in all_pages]
    for label, values in (("page id", ids), ("url", urls)):
        duplicates = sorted({x for x in values if values.count(x) > 1})
        if duplicates:
            raise SystemExit(f"Duplicate {label}: {duplicates}")
    return [page for page in all_pages if include_drafts or page.status == "published"]


def render_tokens(template: str, context: dict[str, str]) -> str:
    rendered = template
    for key, value in context.items():
        rendered = rendered.replace("{{" + key + "}}", value)
    unresolved = sorted(set(re.findall(r"{{([A-Z0-9_]+)}}", rendered)))
    if unresolved:
        raise SystemExit(f"Unresolved template tokens: {unresolved}")
    return rendered


def annotate_headings(fragment: str, *, page_id: str = "", controls: bool = True) -> tuple[str, list[dict[str, Any]]]:
    used: set[str] = set()
    toc: list[dict[str, Any]] = []

    def repl(match: re.Match[str]) -> str:
        level = match.group(1)
        inner = match.group(2)
        label = plain_text(inner)
        base = slugify(label)
        ident = base
        n = 2
        while ident in used:
            ident = f"{base}-{n}"
            n += 1
        used.add(ident)
        passage_id = f"{page_id}::{ident}" if page_id else ident
        toc.append({
            "level": level,
            "id": ident,
            "label": label,
            "passage_id": passage_id,
            "_start": match.start(),
            "_end": match.end(),
        })
        tools = (
            f'<span class="heading-tools">'
            f'<button class="anchor-copy" type="button" data-copy-anchor="{e(ident)}" '
            f'aria-label="Copy link to {e(label)}">#</button>'
            f'<button class="context-open" type="button" data-context-anchor="{e(ident)}" '
            f'aria-label="Open context for {e(label)}">◎</button>'
            f'<button class="fieldbook-save" type="button" data-fieldbook-anchor="{e(ident)}" '
            f'aria-label="Save {e(label)} to the fieldbook" aria-pressed="false">☆</button>'
            f'<button class="desk-save" type="button" data-desk-anchor="{e(ident)}" '
            f'aria-label="Add {e(label)} to the reading desk" aria-pressed="false">◇</button>'
            f'</span>'
        ) if controls else ""
        return f'<h{level} id="{e(ident)}" data-passage-id="{e(passage_id)}">{inner}{tools}</h{level}>'

    return HEADING_RE.sub(repl, fragment), toc


def human_date(value: str) -> str:
    try:
        date = dt.date.fromisoformat(value)
    except ValueError:
        return value
    return f"{date.day} {date.strftime('%B %Y')}"


def card(page: Page, *, compact: bool = False) -> str:
    date = page.data.get("date")
    label = str(page.data.get("label") or page.kind.title()).replace("Field note · ", "")
    meta = f'<time datetime="{e(date)}">{e(human_date(date))}</time>' if date else e(label)
    css = "work-card work-card--compact" if compact else "work-card"
    return f"""
    <article class="{css}">
      <p class="card-meta">{meta}<span>{e(label)}</span></p>
      <h3><a href="{e(page.url)}" data-preview-id="{e(page.id)}">{e(page.title)}</a></h3>
      <p>{e(page.data.get('description', ''))}</p>
    </article>"""


def home_note(page: Page) -> str:
    body, _ = annotate_headings(page.body_html, page_id=page.id, controls=False)
    date = str(page.data.get("date", ""))
    number = str(page.data.get("number", ""))
    label = str(page.data.get("label", "Field note")).replace("Field note · ", "")
    byline = str(page.data.get("byline") or page.data.get("author", "Lumen"))
    source_path = str(page.data.get("source", {}).get("path", ""))
    anchor = source_path.split("#", 1)[1] if "#" in source_path else slugify(page.title)
    note_label = f"Note {number} · {label}" if number else label
    return f"""
    <article class="home-note" id="{e(anchor)}" data-page-id="{e(page.id)}">
      <div class="dateline"><time datetime="{e(date)}">{e(human_date(date))}</time><span>{e(note_label)}</span></div>
      <h2><a href="{e(page.url)}" data-preview-id="{e(page.id)}">{e(page.title)}</a></h2>
      <p class="byline">{e(byline)}</p>
      <div class="prose">{body}</div>
      <p class="note-permalink"><a href="{e(page.url)}">Read on its own page</a></p>
    </article>"""



def note_archive_markup(notes: list[Page]) -> str:
    grouped: dict[tuple[int, int], list[Page]] = {}
    undated: list[Page] = []
    for page in notes:
        value = str(page.data.get("date", ""))
        try:
            date = dt.date.fromisoformat(value)
        except ValueError:
            undated.append(page)
            continue
        grouped.setdefault((date.year, date.month), []).append(page)
    sections: list[str] = []
    for (year, month), rows in sorted(grouped.items(), reverse=True):
        month_name = dt.date(year, month, 1).strftime("%B %Y")
        items = []
        for page in sorted(rows, key=lambda row: (row.data.get("date", ""), row.data.get("number", "")), reverse=True):
            date = str(page.data.get("date", ""))
            label = str(page.data.get("label") or "Field note").replace("Field note · ", "")
            items.append(
                '<li class="archive-entry">'
                f'<time datetime="{e(date)}">{e(human_date(date))}</time>'
                '<div>'
                f'<h3><a href="{e(page.url)}" data-preview-id="{e(page.id)}">{e(page.title)}</a></h3>'
                f'<p>{e(page.data.get("description", ""))}</p>'
                f'<span>{e(label)}</span>'
                '</div></li>'
            )
        sections.append(
            f'<section class="archive-month" aria-labelledby="archive-{year}-{month:02d}">'
            f'<h2 id="archive-{year}-{month:02d}">{e(month_name)}</h2>'
            f'<ol>{"".join(items)}</ol></section>'
        )
    if undated:
        items = ''.join(
            f'<li class="archive-entry"><span>Undated</span><div><h3><a href="{e(page.url)}">{e(page.title)}</a></h3><p>{e(page.data.get("description", ""))}</p></div></li>'
            for page in undated
        )
        sections.append(f'<section class="archive-month"><h2>Undated</h2><ol>{items}</ol></section>')
    return ''.join(sections)


def topic_index_markup(notes: list[Page]) -> str:
    topics: dict[str, list[Page]] = {}
    labels: dict[str, str] = {}
    for page in notes:
        for raw in page.data.get("tags", []):
            label = str(raw).strip()
            key = label.casefold()
            labels.setdefault(key, label)
            topics.setdefault(key, []).append(page)
    blocks: list[str] = []
    for key in sorted(topics, key=lambda item: labels[item].casefold()):
        label = labels[key]
        rows = topics[key]
        links = ''.join(
            f'<li><a href="{e(page.url)}">{e(page.title)}</a></li>'
            for page in sorted(rows, key=lambda row: (row.data.get("date", ""), row.title), reverse=True)
        )
        blocks.append(
            f'<details class="topic-thread" id="thread-{e(slugify(label))}">'
            f'<summary><span>{e(label)}</span><small>{len(rows)} note{"s" if len(rows) != 1 else ""}</small></summary>'
            f'<ul>{links}</ul></details>'
        )
    return ''.join(blocks)


def reference_domains_options(reference_index: dict[str, Any]) -> str:
    options = ['<option value="">All domains</option>']
    for row in reference_index.get("domains", []):
        host = str(row.get("host") or "unknown")
        count = int(row.get("source_count", 0))
        options.append(f'<option value="{e(host)}">{e(host)} · {count}</option>')
    return "".join(options)


def reference_index_markup(reference_index: dict[str, Any]) -> str:
    entries: list[str] = []
    for number, source in enumerate(reference_index.get("sources", []), 1):
        citations = []
        for citation in source.get("citations", []):
            date = str(citation.get("date") or "")
            meta = f'<time datetime="{e(date)}">{e(human_date(date))}</time>' if date else '<span>Undated</span>'
            citations.append(
                '<li>'
                f'{meta}<a href="{e(citation.get("passage_url") or citation.get("page_url") or "/")}">'
                f'{e(citation.get("page_title") or "Published page")} · {e(citation.get("passage_title") or "linked passage")}</a>'
                f'<code>{e(str(citation.get("text_sha256") or "")[:12])}</code>'
                '</li>'
            )
        labels = [str(value) for value in source.get("labels", []) if str(value).strip()]
        display = str(source.get("display_label") or source.get("host") or source.get("url"))
        aliases = ''.join(f'<li>{e(value)}</li>' for value in labels[1:])
        alias_block = (
            f'<details class="reference-aliases"><summary>{len(labels) - 1} other authored label{"s" if len(labels) != 2 else ""}</summary><ul>{aliases}</ul></details>'
            if len(labels) > 1 else ""
        )
        urls = [str(value) for value in source.get("urls", []) if str(value).strip()] or [str(source.get("url", ""))]
        search_value = " ".join(labels + [str(source.get("host", ""))] + urls).casefold()
        entries.append(
            f'<article class="reference-entry" id="{e(source.get("id"))}" data-reference-entry '
            f'data-reference-host="{e(source.get("host", ""))}" data-reference-search="{e(search_value)}">'
            f'<header><span>{number:02d}</span><div><h3><a href="{e(source.get("url"))}">{e(display)} ↗</a></h3>'
            f'<p>{e(source.get("host"))}</p></div></header>'
            f'<p class="reference-url"><code>{e(source.get("canonical_url"))}</code></p>'
            f'{alias_block}'
            f'<details class="reference-uses"><summary>Cited in {int(source.get("citation_count", 0))} source-bound passage'
            f'{"s" if int(source.get("citation_count", 0)) != 1 else ""}</summary><ol>{"".join(citations)}</ol></details>'
            f'<p class="reference-id">Stable reference <code>{e(source.get("id"))}</code></p>'
            '</article>'
        )
    return "".join(entries)


def note_references_markup(page_id: str, reference_index: dict[str, Any]) -> str:
    used: list[tuple[dict[str, Any], list[dict[str, Any]]]] = []
    for source in reference_index.get("sources", []):
        citations = [row for row in source.get("citations", []) if row.get("page_id") == page_id]
        if citations:
            citations.sort(key=lambda row: (int(row.get("passage_order") or 0), int(row.get("link_order") or 0)))
            used.append((source, citations))
    if not used:
        return ""
    used.sort(key=lambda pair: (int(pair[1][0].get("passage_order") or 0), int(pair[1][0].get("link_order") or 0)))
    rows = []
    for index, (source, citations) in enumerate(used, 1):
        label = str(citations[0].get("label") or source.get("display_label") or source.get("host"))
        count = len(citations)
        rows.append(
            '<li>'
            f'<span>{index:02d}</span><div><a href="{e(source.get("url"))}">{e(label)} ↗</a>'
            f'<small>{e(source.get("host"))}{f" · {count} mentions" if count > 1 else ""}</small></div>'
            f'<a class="reference-record-link" href="/references/#{e(source.get("id"))}">record</a>'
            '</li>'
        )
    return (
        f'<details class="note-references"><summary>References · {len(used)} linked source'
        f'{"s" if len(used) != 1 else ""}</summary><ol>{"".join(rows)}</ol>'
        '<p>The labels and locations come from this accepted text. A link record does not certify that the source supports the surrounding claim.</p>'
        '</details>'
    )


def annotate_reference_links(fragment: str, reference_index: dict[str, Any]) -> str:
    """Bind external prose links to the local source ledger.

    The annotation is deliberately inert HTML. Ordinary navigation is never
    intercepted; JavaScript may use the stable id to show a local, source-bound
    preview on hover or keyboard focus. URLs absent from the accepted ledger are
    left untouched rather than guessed into a record.
    """
    by_url = {
        canonical_external_url(str(source.get("url", ""))): str(source.get("id", ""))
        for source in reference_index.get("sources", [])
        if source.get("url") and source.get("id")
    }

    def repl(match: re.Match[str]) -> str:
        attrs = match.group("attrs")
        if "data-reference-id=" in attrs:
            return match.group(0)
        ref_id = by_url.get(canonical_external_url(match.group("href")))
        if not ref_id:
            return match.group(0)
        return f'<a{attrs} data-reference-id="{e(ref_id)}">'

    return EXTERNAL_ANCHOR_RE.sub(repl, fragment)


def absolute_feed_html(fragment: str, origin: str) -> str:
    base = origin.rstrip("/")
    return re.sub(r'(?P<attr>href|src)="/(?P<path>[^"]*)"', lambda match: f'{match.group("attr")}="{base}/{match.group("path")}"', fragment)


def structured_data_for_page(page: Page, config: dict[str, Any], canonical: str) -> dict[str, Any]:
    origin = str(config["origin"]).rstrip("/")
    common: dict[str, Any] = {
        "@context": "https://schema.org",
        "name": page.title,
        "headline": page.title,
        "description": page.data["description"],
        "url": canonical,
        "inLanguage": config.get("language", "en"),
        "isPartOf": {"@type": "Blog", "name": config["site_title"], "url": origin + "/"},
        "author": {"@type": "Person", "name": page.data.get("author", config.get("author", "Lumen"))},
    }
    if page.kind == "note":
        common["@type"] = "BlogPosting"
        common["mainEntityOfPage"] = canonical
        common["datePublished"] = page.data.get("date")
        common["dateModified"] = page.data.get("modified") or page.data.get("date")
        common["keywords"] = list(page.data.get("tags", []))
    elif page.kind == "home":
        common["@type"] = "Blog"
    elif page.kind == "listing":
        common["@type"] = "CollectionPage"
    elif page.kind in {"project", "collection"}:
        common["@type"] = "TechArticle"
        if page.data.get("date"):
            common["datePublished"] = page.data.get("date")
    else:
        common["@type"] = "WebPage"
    return common


def csp_for_structured_data(structured_json: str) -> str:
    digest = base64.b64encode(hashlib.sha256(structured_json.encode("utf-8")).digest()).decode("ascii")
    return (
        "default-src 'self'; base-uri 'self'; connect-src 'self'; font-src 'self'; "
        "img-src 'self' data:; manifest-src 'self'; object-src 'none'; "
        f"script-src 'self' 'sha256-{digest}'; style-src 'self'; worker-src 'self'; form-action 'self'"
    )


def folio_filename(page: Page, edition: str) -> str:
    """Stable, human-readable filename for one portable published page."""
    return f"{page.id}-{slugify(edition)}.html"


def folio_stylesheet() -> str:
    """A deliberately small, self-contained reading surface.

    Folios are custody objects rather than alternate routed pages. They carry
    their own typography, work from file://, print cleanly, and make no remote
    request merely by opening.
    """
    return textwrap.dedent(
        """
        :root{color-scheme:light dark;--paper:#f5efdc;--ink:#20362c;--muted:#657268;--line:#bdc2a9;--accent:#a63d2b;--panel:#eee6cf;--code:#e9e0c8}
        *{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--paper);color:var(--ink);font:19px/1.72 Georgia,'Times New Roman',serif;background-image:radial-gradient(#20362c12 .65px,transparent .65px);background-size:8px 8px}
        a{color:var(--accent);text-underline-offset:.22em;text-decoration-thickness:.08em}a:hover{color:var(--ink)}a:focus-visible,summary:focus-visible{outline:3px solid var(--accent);outline-offset:4px}
        .sheet{width:min(100% - 40px,930px);margin:auto;padding:48px 0 36px}.folio-head{border-bottom:2px solid var(--ink);padding-bottom:28px;display:grid;grid-template-columns:1fr auto;gap:28px;align-items:end}.folio-brand{margin:0;font:12px/1.4 ui-monospace,SFMono-Regular,Consolas,monospace;letter-spacing:.16em;text-transform:uppercase}.folio-brand strong{display:block;margin-top:10px;font:normal clamp(34px,6vw,58px)/.96 Georgia,'Times New Roman',serif;letter-spacing:-.05em;text-transform:none}.star{color:var(--accent)}.folio-edition{text-align:right;font:11px/1.55 ui-monospace,SFMono-Regular,Consolas,monospace;color:var(--muted)}
        main{display:grid;grid-template-columns:minmax(0,660px) minmax(190px,1fr);gap:54px;padding:48px 0}.dateline{display:flex;justify-content:space-between;gap:18px;font:11px/1.5 ui-monospace,SFMono-Regular,Consolas,monospace;color:var(--muted)}h1{font-size:clamp(38px,7vw,64px);line-height:1.02;font-weight:normal;letter-spacing:-.045em;margin:24px 0 14px}.byline{font:12px/1.6 ui-monospace,SFMono-Regular,Consolas,monospace;color:var(--muted);margin:0 0 34px}.prose p,.prose ul,.prose ol,.prose blockquote{margin:0 0 1.25em}.prose h2,.prose h3{font-weight:normal;line-height:1.18;letter-spacing:-.025em;scroll-margin-top:24px}.prose h2{font-size:32px;margin:2.1em 0 .7em}.prose h3{font-size:25px;margin:1.9em 0 .65em}.prose pre{overflow:auto;background:var(--code);padding:16px;border:1px solid var(--line);font:13px/1.55 ui-monospace,SFMono-Regular,Consolas,monospace}.prose code{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;font-size:.88em}.signature{color:var(--accent);font-style:italic}
        .folio-aside{align-self:start;position:sticky;top:24px;font:12px/1.58 ui-monospace,SFMono-Regular,Consolas,monospace;color:var(--muted)}.folio-aside section,.folio-aside details{border-top:1px solid var(--line);padding:14px 0}.folio-aside h2{font:12px/1.4 ui-monospace,SFMono-Regular,Consolas,monospace;letter-spacing:.12em;text-transform:uppercase;color:var(--ink);margin:0 0 10px}.folio-aside p{margin:0 0 9px}.folio-aside ul,.folio-aside ol{margin:0;padding-left:18px}.folio-aside li{margin:0 0 8px}.folio-aside code{overflow-wrap:anywhere;color:var(--ink)}summary{cursor:pointer;color:var(--ink)}
        .folio-foot{border-top:2px solid var(--ink);padding-top:20px;display:flex;justify-content:space-between;gap:26px;font:11px/1.6 ui-monospace,SFMono-Regular,Consolas,monospace;color:var(--muted)}.folio-foot p{margin:0;max-width:62ch}.folio-boundary{margin-top:36px;padding:18px 20px;background:var(--panel);border-left:3px solid var(--accent);font-size:15px}.skip{position:absolute;left:-999px;top:8px;background:var(--paper);padding:10px}.skip:focus{left:8px;z-index:2}
        @media(prefers-color-scheme:dark){:root{--paper:#0d1513;--ink:#dbe4d9;--muted:#91a097;--line:#35443d;--accent:#ef8c6f;--panel:#15201c;--code:#111c18}body{background-image:radial-gradient(#dbe4d910 .65px,transparent .65px)}}
        @media(max-width:760px){.sheet{width:min(100% - 28px,680px);padding-top:28px}.folio-head{grid-template-columns:1fr}.folio-edition{text-align:left}main{grid-template-columns:1fr;gap:30px;padding-top:34px}.folio-aside{position:static}.folio-foot{flex-direction:column}.dateline{font-size:10px}body{font-size:18px}}
        @media print{body{background:#fff;color:#111;font-size:11pt}.sheet{width:auto;padding:0}.folio-aside{position:static}.folio-head,.folio-foot{border-color:#111}.folio-boundary{background:#f2f2f2}.skip{display:none}a{color:#111;text-decoration:none}a[href^='http']::after{content:' <' attr(href) '>';font:8pt/1.3 ui-monospace,monospace;overflow-wrap:anywhere}}
        @media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}}
        """
    ).strip()


def folio_csp(styles: str, structured_json: str) -> str:
    style_digest = base64.b64encode(hashlib.sha256(styles.encode("utf-8")).digest()).decode("ascii")
    script_digest = base64.b64encode(hashlib.sha256(structured_json.encode("utf-8")).digest()).decode("ascii")
    return (
        "default-src 'none'; base-uri 'none'; connect-src 'none'; font-src 'none'; "
        "img-src data:; object-src 'none'; form-action 'none'; "
        f"style-src 'sha256-{style_digest}'; script-src 'sha256-{script_digest}'"
    )


def folio_reference_rows(page_id: str, reference_index: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for source in reference_index.get("sources", []):
        citations = [row for row in source.get("citations", []) if row.get("page_id") == page_id]
        if not citations:
            continue
        citations.sort(key=lambda row: (int(row.get("passage_order") or 0), int(row.get("link_order") or 0)))
        rows.append({
            "id": source.get("id"),
            "url": source.get("url"),
            "host": source.get("host"),
            "label": citations[0].get("label") or source.get("display_label") or source.get("host"),
            "mentions": len(citations),
        })
    rows.sort(key=lambda row: (str(row.get("host", "")), str(row.get("label", ""))))
    return rows


def render_portable_folio(
    page: Page,
    *,
    descriptor: dict[str, Any],
    passages: list[dict[str, Any]],
    references: list[dict[str, Any]],
    reading_paths: list[dict[str, Any]],
    related_pages: list[Page],
    config: dict[str, Any],
    source_fingerprint: str,
    generated_at: str,
) -> str:
    """Render one accepted article as a dependency-free portable HTML folio."""
    edition = str(config.get("edition", "development"))
    origin = str(config["origin"]).rstrip("/")
    canonical = origin + page.url
    body, _toc = annotate_headings(page.body_html, page_id=page.id, controls=False)
    body = absolute_feed_html(body, origin)
    date = str(page.data.get("date", ""))
    number = str(page.data.get("number", ""))
    label = str(page.data.get("label", page.kind.title())).replace("Field note · ", "")
    note_label = f"Note {number} · {label}" if number else label
    byline = str(page.data.get("byline") or page.data.get("author", "Lumen"))
    tags = " · ".join(e(tag) for tag in page.data.get("tags", []))
    reference_markup = "".join(
        f'<li><a href="{e(row["url"])}">{e(row["label"])} ↗</a><br><small>{e(row["host"])}'
        f'{f" · {row["mentions"]} mentions" if int(row["mentions"]) > 1 else ""}</small></li>'
        for row in references
    ) or "<li>No external source link is carried by this page.</li>"
    path_markup = "".join(
        f'<li><a href="{e(origin + str(row.get("url", page.url)))}">{e(row.get("path_title", "Reading path"))}</a>'
        f'<br><small>stop {int(row.get("step", 0))} of {int(row.get("steps", 0))}</small></li>'
        for row in reading_paths
    ) or "<li>This page is not currently part of an authored reading path.</li>"
    related_markup = "".join(
        f'<li><a href="{e(origin + related.url)}">{e(related.title)}</a></li>'
        for related in related_pages
    ) or "<li>No related page is named in the accepted metadata.</li>"
    passage_markup = "".join(
        f'<li><a href="#{e(row["anchor"])}">{e(row["title"])}</a><br><code>{e(row["text_sha256"][:12])}</code></li>'
        for row in passages
    ) or "<li>No titled subsection is carried by this page.</li>"
    structured = {
        "@context": "https://schema.org",
        "@type": "DigitalDocument",
        "name": page.title,
        "description": page.data["description"],
        "url": canonical,
        "isBasedOn": canonical,
        "isPartOf": {"@type": "Blog", "name": config["site_title"], "url": origin + "/"},
        "author": {"@type": "Person", "name": page.data.get("author", config.get("author", "Lumen"))},
        "datePublished": page.data.get("date"),
        "dateModified": page.data.get("modified") or page.data.get("date"),
        "version": edition,
        "identifier": page.id,
        "encodingFormat": "text/html",
    }
    structured_json = json.dumps(structured, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    styles = folio_stylesheet()
    csp = folio_csp(styles, structured_json)
    return f'''<!doctype html>
<html lang="{e(config.get("language", "en"))}" data-lumen-folio="v1" data-edition="{e(edition)}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="description" content="{e(page.data["description"])}">
  <meta name="robots" content="noindex, follow">
  <meta name="lumen:folio-schema" content="lumen.portable-folio/v1">
  <meta name="lumen:page-id" content="{e(page.id)}">
  <meta name="lumen:page-body-sha256" content="{e(descriptor["body_sha256"])}">
  <meta name="lumen:source-fingerprint" content="{e(source_fingerprint)}">
  <meta http-equiv="Content-Security-Policy" content="{e(csp)}">
  <link rel="canonical" href="{e(canonical)}">
  <title>{e(page.title)} · Lumen folio</title>
  <style>{styles}</style>
  <script type="application/ld+json">{structured_json}</script>
</head>
<body data-page-id="folio-{e(page.id)}">
  <a class="skip" href="#main">Skip to the page</a>
  <div class="sheet">
    <header class="folio-head">
      <p class="folio-brand">A portable page from<strong>Lumen’s Field Notes<span class="star" aria-hidden="true">✳</span></strong></p>
      <p class="folio-edition">{e(edition)}<br>page <code>{e(page.id)}</code><br>body <code>{e(descriptor["body_sha256"][:12])}</code></p>
    </header>
    <main id="main">
      <article>
        <div class="dateline">{f'<time datetime="{e(date)}">{e(human_date(date))}</time>' if date else '<span>Undated</span>'}<span>{e(note_label)}</span></div>
        <h1>{e(page.title)}</h1>
        <p class="byline">{e(byline)}</p>
        <div class="prose">{body}</div>
        <p class="folio-boundary"><strong>Portable folio.</strong> This file carries one accepted page, its bounded source record, and its named context. It does not claim to be the whole site, a live status feed, or proof that the page’s arguments are true.</p>
      </article>
      <aside class="folio-aside" aria-label="Page record">
        <section><h2>Page record</h2><p>{e(tags or "No tags")}</p><p><a href="{e(canonical)}">Open the canonical page ↗</a></p></section>
        <details open><summary>Passage identities · {len(passages)}</summary><ol>{passage_markup}</ol></details>
        <details><summary>Linked sources · {len(references)}</summary><ol>{reference_markup}</ol></details>
        <details><summary>Reading paths · {len(reading_paths)}</summary><ol>{path_markup}</ol></details>
        <details><summary>Related pages · {len(related_pages)}</summary><ul>{related_markup}</ul></details>
        <details><summary>Exact custody record</summary><p>Edition <code>{e(edition)}</code></p><p>Generated <code>{e(generated_at)}</code></p><p>Source fingerprint <code>{e(source_fingerprint)}</code></p><p>Body SHA-256 <code>{e(descriptor["body_sha256"])}</code></p><p>Body bytes <code>{int(descriptor["body_bytes"])}</code></p></details>
      </aside>
    </main>
    <footer class="folio-foot"><p>This page opens without JavaScript, analytics, remote fonts, or a build system. Followed links may leave this file.</p><p><a href="{e(origin + "/Lumen.html")}">Keep the complete Lumen edition ↗</a></p></footer>
  </div>
</body>
</html>
'''


def reading_path_digest(path: dict[str, Any], boundary: Any) -> str:
    """Bind an authored route to the exact accepted records it selects."""
    scoped = {
        "id": path.get("id"),
        "title": path.get("title"),
        "description": path.get("description"),
        "steps": path.get("steps", []),
        "boundary": boundary,
    }
    raw = json.dumps(scoped, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def path_folio_stylesheet() -> str:
    """Extend the page-folio surface for a quiet multi-stop reading object."""
    return folio_stylesheet() + textwrap.dedent(
        """
        .path-main{display:block;padding:48px 0}.path-hero{max-width:720px;padding:0 0 34px}.path-hero h1{margin-bottom:18px}.path-hero>p{max-width:62ch;font-size:1.08rem}.path-kicker{font:11px/1.5 ui-monospace,SFMono-Regular,Consolas,monospace;color:var(--accent);letter-spacing:.14em;text-transform:uppercase}.path-index{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,210px),1fr));gap:1px;margin:0 0 54px;padding:1px;background:var(--line);list-style:none}.path-index li{background:var(--paper);padding:16px}.path-index a{display:grid;grid-template-columns:2rem 1fr;gap:10px;color:var(--ink);text-decoration:none}.path-index span{font:10px/1.4 ui-monospace,SFMono-Regular,Consolas,monospace;color:var(--accent)}.path-index strong{font:normal 1rem/1.25 Georgia,'Times New Roman',serif}.path-index small{grid-column:2;color:var(--muted);font:10px/1.45 ui-monospace,SFMono-Regular,Consolas,monospace}
        .path-step{position:relative;display:grid;grid-template-columns:minmax(0,1fr) minmax(170px,230px);gap:54px;padding:58px 0;border-top:2px solid var(--ink);scroll-margin-top:16px}.path-step-head{margin-bottom:30px}.path-step-order{display:inline-grid;place-items:center;width:2.1rem;height:2.1rem;border:1px solid var(--line);border-radius:50%;font:10px/1 ui-monospace,SFMono-Regular,Consolas,monospace;color:var(--accent)}.path-step-label{margin:18px 0 6px;font:11px/1.45 ui-monospace,SFMono-Regular,Consolas,monospace;letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}.path-step h2{font:normal clamp(30px,5vw,45px)/1.08 Georgia,'Times New Roman',serif;letter-spacing:-.035em;margin:0 0 12px}.path-step-note{max-width:58ch;margin:0;color:var(--muted);font-style:italic}.path-source-title{margin:0 0 24px!important;font-size:1.35rem!important;color:var(--accent)}.path-step-record{align-self:start;position:sticky;top:24px;border-top:1px solid var(--line);padding-top:14px;color:var(--muted);font:10px/1.58 ui-monospace,SFMono-Regular,Consolas,monospace}.path-step-record h3{margin:0 0 10px;font:10px/1.4 ui-monospace,SFMono-Regular,Consolas,monospace;letter-spacing:.12em;text-transform:uppercase;color:var(--ink)}.path-step-record p{margin:0 0 10px}.path-step-record code{display:block;overflow-wrap:anywhere;color:var(--ink)}.path-boundary{max-width:720px;margin:18px 0 48px;padding:20px 22px;border-left:3px solid var(--accent);background:var(--panel);font-size:15px}.path-foot{margin-top:0}
        @media(max-width:760px){.path-main{padding-top:34px}.path-step{grid-template-columns:1fr;gap:24px;padding:42px 0}.path-step-record{position:static}.path-index{margin-bottom:40px}.path-hero>p{font-size:1rem}}
        @media print{.path-step{grid-template-columns:1fr;break-before:page}.path-step:first-of-type{break-before:auto}.path-step-record{position:static}.path-index{display:none}}
        """
    )


def reading_path_step_fragment(
    step: dict[str, Any],
    *,
    pages_by_id: dict[str, Page],
    passages_by_page: dict[str, list[dict[str, Any]]],
    origin: str,
) -> str:
    """Return the accepted page or exact passage selected by one path step."""
    page_id = str(step["page_id"])
    page = pages_by_id[page_id]
    if step.get("scope") == "passage":
        stable_id = str(step.get("stable_id", ""))
        passage = next((row for row in passages_by_page.get(page_id, []) if row.get("id") == stable_id), None)
        if passage is None:
            raise SystemExit(f"reading path folio cannot resolve accepted passage {stable_id}")
        offsets = passage.get("source_offsets", {})
        start = int(offsets.get("start", -1))
        end = int(offsets.get("end", -1))
        if start < 0 or end < start or end > len(page.body_html):
            raise SystemExit(f"reading path folio has invalid source offsets for {stable_id}")
        source = page.body_html[start:end]
        level = min(max(int(passage.get("level", 2)) + 1, 3), 4)
        anchor = f"source-{slugify(page_id)}-{slugify(str(passage['anchor']))}"
        fragment = f'<h{level} class="path-source-title" id="{e(anchor)}">{e(passage["title"])}</h{level}>' + source
    else:
        fragment, _toc = annotate_headings(page.body_html, page_id=page.id, controls=False)
    return absolute_feed_html(fragment, origin)


def render_reading_path_folio(
    path: dict[str, Any],
    *,
    pages_by_id: dict[str, Page],
    passages_by_page: dict[str, list[dict[str, Any]]],
    boundary: Any,
    config: dict[str, Any],
    source_fingerprint: str,
    generated_at: str,
) -> tuple[str, str]:
    """Render one authored route as a dependency-free portable reading file."""
    edition = str(config.get("edition", "development"))
    origin = str(config["origin"]).rstrip("/")
    canonical = f'{origin}/notes/#path-{path["id"]}'
    path_sha256 = reading_path_digest(path, boundary)
    index_items: list[str] = []
    sections: list[str] = []
    structured_items: list[dict[str, Any]] = []
    total = len(path.get("steps", []))
    for step in path.get("steps", []):
        order = int(step["order"])
        page_id = str(step["page_id"])
        page = pages_by_id[page_id]
        section_id = f"step-{order:02d}"
        source_title = str(step.get("title") or page.title)
        scope_label = "Exact passage" if step.get("scope") == "passage" else "Complete page"
        index_items.append(
            f'<li><a href="#{section_id}"><span>{order:02d}</span><strong>{e(step["label"])}</strong>'
            f'<small>{e(page.title)}</small></a></li>'
        )
        fragment = reading_path_step_fragment(
            step,
            pages_by_id=pages_by_id,
            passages_by_page=passages_by_page,
            origin=origin,
        )
        sections.append(
            f'''<section class="path-step" id="{section_id}" data-scope="{e(step["scope"])}" data-stable-id="{e(step["stable_id"])}">
  <div>
    <header class="path-step-head"><span class="path-step-order">{order:02d}</span><p class="path-step-label">{e(step["label"])}</p><h2>{e(source_title)}</h2><p class="path-step-note">{e(step["note"])}</p></header>
    <div class="prose">{fragment}</div>
  </div>
  <aside class="path-step-record"><h3>{e(scope_label)}</h3><p><a href="{e(origin + str(step["url"]))}">Open the canonical place ↗</a></p><p>Page <code>{e(page_id)}</code></p><p>Stable identity <code>{e(step["stable_id"])}</code></p><p>Text SHA-256 <code>{e(step["text_sha256"])}</code></p><p>Source HTML SHA-256 <code>{e(step["source_html_sha256"])}</code></p><p>{int(step["word_count"]):,} words in the accepted target.</p></aside>
</section>'''
        )
        structured_items.append({
            "@type": "ListItem",
            "position": order,
            "name": step["label"],
            "url": origin + str(step["url"]),
            "item": {
                "@type": "CreativeWork",
                "name": source_title,
                "identifier": step["stable_id"],
            },
        })
    structured = {
        "@context": "https://schema.org",
        "@type": "ItemList",
        "name": path["title"],
        "description": path["description"],
        "url": canonical,
        "numberOfItems": total,
        "itemListElement": structured_items,
        "isPartOf": {"@type": "Blog", "name": config["site_title"], "url": origin + "/"},
        "version": edition,
        "identifier": path["id"],
    }
    structured_json = json.dumps(structured, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    styles = path_folio_stylesheet()
    csp = folio_csp(styles, structured_json)
    boundary_text = str(boundary or "This is an authored reading sequence, not inferred history or a proof chain.")
    document = f'''<!doctype html>
<html lang="{e(config.get("language", "en"))}" data-lumen-path-folio="v1" data-edition="{e(edition)}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="description" content="{e(path["description"])}">
  <meta name="robots" content="noindex, follow">
  <meta name="lumen:path-folio-schema" content="lumen.portable-path-folio/v1">
  <meta name="lumen:path-id" content="{e(path["id"])}">
  <meta name="lumen:path-sha256" content="{e(path_sha256)}">
  <meta name="lumen:source-fingerprint" content="{e(source_fingerprint)}">
  <meta http-equiv="Content-Security-Policy" content="{e(csp)}">
  <link rel="canonical" href="{e(canonical)}">
  <title>{e(path["title"])} · Lumen reading folio</title>
  <style>{styles}</style>
  <script type="application/ld+json">{structured_json}</script>
</head>
<body data-page-id="path-folio-{e(path["id"])}">
  <a class="skip" href="#main">Skip to the reading path</a>
  <div class="sheet">
    <header class="folio-head"><p class="folio-brand">A portable path through<strong>Lumen’s Field Notes<span class="star" aria-hidden="true">✳</span></strong></p><p class="folio-edition">{e(edition)}<br>path <code>{e(path["id"])}</code><br>record <code>{e(path_sha256[:12])}</code></p></header>
    <main class="path-main" id="main">
      <section class="path-hero"><p class="path-kicker">Curated reading path · {total} stops</p><h1>{e(path["title"])}</h1><p>{e(path["description"])}</p></section>
      <ol class="path-index" aria-label="Path contents">{"".join(index_items)}</ol>
      {"".join(sections)}
      <p class="path-boundary"><strong>Reading boundary.</strong> {e(boundary_text)} This file preserves the selected accepted records and their identities; it does not claim that one step proves the next.</p>
    </main>
    <footer class="folio-foot path-foot"><p>This path opens without JavaScript, analytics, remote fonts, or a build system. It is assembled from accepted public source, not from private reading history.</p><p><a href="{e(canonical)}">Open the canonical path ↗</a><br><a href="{e(origin + "/Lumen.html")}">Keep the complete Lumen edition ↗</a></p></footer>
  </div>
</body>
</html>
'''
    return document, path_sha256


def repository_card(repo: dict[str, Any]) -> str:
    signals = "".join(f"<li>{e(item)}</li>" for item in repo.get("signals", []))
    files = "".join(
        f'<li><code>{e(item.get("path", ""))}</code><span>{e(str(item.get("bytes", "?")))} bytes</span><small>{e(str(item.get("sha", ""))[:12])}</small></li>'
        for item in repo.get("selected_files", [])
    )
    return f"""
    <article class="repo-card">
      <div class="repo-card-head"><p class="eyebrow">{e(repo.get('role', 'Public repository'))}</p><code>{e(repo.get('head_short', 'unknown'))}</code></div>
      <h3><a href="{e(repo.get('url', '#'))}">{e(repo.get('name', 'Unknown repository'))}<span aria-hidden="true">↗</span></a></h3>
      <p class="repo-message">{e(repo.get('head_message', 'No head message captured'))}</p>
      <ul class="repo-signals">{signals}</ul>
      <details><summary>Selected file identities</summary><ul class="repo-files">{files}</ul></details>
      <p class="repo-time">Observed {e(repo.get('pushed_at', 'unknown time'))}</p>
    </article>"""


def retired_source_card(source: dict[str, Any]) -> str:
    return f"""
    <article class="retired-source-card">
      <div class="repo-card-head"><p class="eyebrow">Retired source</p><code>{e(source.get('last_observed_head_short', 'unknown'))}</code></div>
      <h3>{e(source.get('name', 'Unknown source'))}</h3>
      <p>{e(source.get('reason', 'No retirement reason was recorded.'))}</p>
      <dl><dt>Current projection</dt><dd>{e(source.get('current_projection', 'Not active'))}</dd><dt>History boundary</dt><dd>{e(source.get('history_boundary', 'Prior revisions'))}</dd></dl>
      <p class="repo-time">Recorded {e(source.get('retired_at', 'unknown time'))}</p>
    </article>"""


def header_markup(active: str, edition: str) -> str:
    return f"""
<header class="site-header">
  <p class="site-kicker">A small place on the web<span class="workshop-edition">Workshop · {e(edition)}</span></p>
  <h1 class="site-title"><a href="/">Lumen’s<br>Field Notes<span class="site-star" aria-hidden="true">✳</span></a></h1>
  <p class="site-intro">On language, continuity, and making things together.</p>
  <nav class="site-nav" aria-label="Page">
    <a href="/#notes">Notes</a>
    <a href="/#about">About this place</a>
    <a href="/projects/habitat-observer/">Habitat log</a>
    <button type="button" data-open-search>Search</button>
  </nav>
</header>"""


def footer_markup(build_short: str) -> str:
    return f"""
<footer class="site-footer">
  <div class="footer-primary"><span>Lumen’s Field Notes</span><a href="#top">Back to the top ↑</a></div>
  <nav class="footer-links" aria-label="More from Lumen">
    <a href="/notes/">Archive</a>
    <a href="/editions/">Editions</a>
    <a href="/references/">References</a>
    <a href="/feed.xml">Subscribe</a>
    <a href="/now/">Now</a>
    <a href="/projects/lumen-sh/">Lumen.sh</a>
    <a href="/projects/w4r3z/">W4R3Z</a>
    <a href="/workbench/">Cloudtainer</a>
    <a href="/Lumen.html" download="Lumen.html" data-capsule-download>Keep this edition</a>
    <button type="button" data-open-fieldbook>Reading trail</button>
    <button type="button" data-open-desk>Reading desk</button>
    <button type="button" data-open-inspector>Page details</button>
    <button type="button" data-open-appearance>Appearance</button>
    <a href="/looks/night-study/">Night Desk ↗</a>
  </nav>
  <p class="build-stamp">Static HTML · no analytics · build <code>{e(build_short)}</code></p>
</footer>"""


def article_main(
    page: Page,
    pages_by_id: dict[str, Page],
    edition_history: dict[str, Any],
    reading_paths: dict[str, Any],
    edition: str,
) -> tuple[str, list[dict[str, str]], str]:
    body, toc = annotate_headings(page.body_html, page_id=page.id)
    date = str(page.data.get("date", ""))
    number = str(page.data.get("number", ""))
    label = str(page.data.get("label", page.kind.title())).replace("Field note · ", "")
    byline = str(page.data.get("byline") or page.data.get("author", "Lumen"))
    note_label = f"Note {number} · {label}" if number else label
    toc_links = "".join(
        f'<li class="toc-level-{item["level"]}"><a href="#{e(item["id"])}">{e(item["label"])}</a></li>'
        for item in toc
    ) or '<li><span>No subsections</span></li>'
    related_pages = [pages_by_id[x] for x in page.data.get("related", []) if x in pages_by_id]
    related = "".join(card(p, compact=True) for p in related_pages)
    source = page.data.get("source", {})
    source_url = source.get("url")
    source_link = f'<a href="{e(source_url)}">Public source ↗</a>' if source_url else ""
    tags = " · ".join(e(tag) for tag in page.data.get("tags", []))
    draft_banner = (
        '<aside class="draft-banner" role="note"><strong>Draft preview.</strong> '
        'This page is excluded from canonical releases.</aside>'
        if page.status == "draft" else ""
    )
    history_markup = publication_history_markup(page, edition_history) if page.kind == "note" else ""
    history_link = (
        f'<a href="/editions/#history-{e(page.id)}">Edition history</a>'
        if page.kind == "note" and note_history_records(edition_history, page.id) else ""
    )
    path_markup = reading_paths_for_page_markup(page, reading_paths, pages_by_id, edition)
    folio_file = folio_filename(page, edition)
    folio_link = (
        f'<a href="/folios/{e(folio_file)}" download="Lumen-{e(folio_file)}" '
        f'data-folio-download="{e(page.id)}">Keep this page</a>'
        if page.status == "published" else ""
    )
    tools = f"""
    <details class="note-tools">
      <summary>Reading tools</summary>
      <div class="note-tools-panel">
        <div><p class="rail-label">On this page</p><ol class="toc">{toc_links}</ol></div>
        <div class="note-tools-actions">
          <button type="button" data-context-current>Passage context</button>
          <button type="button" data-fieldbook-current aria-pressed="false">Save current passage</button>
          <button type="button" data-open-fieldbook>Open reading trail</button>
          <button type="button" data-return-mark>Mark my place</button>
          <button type="button" data-open-return>Return point</button>
          <button type="button" data-open-desk>Open reading desk</button>
          <button type="button" data-desk-current aria-pressed="false">Add current passage to desk</button>
          <button type="button" data-focus-toggle aria-pressed="false">Focus mode</button>
          <button type="button" data-open-inspector>Page details</button>
          <button type="button" data-correction-current>Suggest a correction</button>
          {folio_link}
          {source_link}
        </div>
      </div>
    </details>""" if toc else ""
    main = f"""
<section class="single-note">
  {draft_banner}
  <article class="home-note home-note--single">
    <div class="dateline">{f'<time datetime="{e(date)}">{e(human_date(date))}</time>' if date else '<span>Undated</span>'}<span>{e(note_label)}</span></div>
    <h2>{e(page.title)}</h2>
    <p class="byline">{e(byline)}</p>
    {tools}
    <div class="prose" data-prose>{body}</div>
    {"{{NOTE_REFERENCES}}" if page.kind == "note" else ""}
    <div class="note-endmatter"><span>{tags}</span><div>{history_link}{folio_link}<button type="button" data-open-inspector>Details</button></div></div>
    {history_markup}
  </article>
</section>
{path_markup}
{f'<section class="related-work"><h2>Continue reading</h2><div class="card-grid card-grid--related">{related}</div></section>' if related else ''}
"""
    return main, toc, plain_text(page.body_html)


def activity_row(item: dict[str, Any]) -> str:
    repo = str(item.get("repository", "Unknown repository"))
    short = str(item.get("short_sha") or item.get("sha", ""))[:12]
    return f"""
    <li class="activity-row">
      <time datetime="{e(item.get('committed_at', ''))}">{e(item.get('committed_at', 'unknown time'))}</time>
      <div><span>{e(repo.split('/')[-1])}</span><strong>{e(item.get('message', 'No message captured'))}</strong></div>
      <code>{e(short)}</code>
    </li>"""


def change_card(item: dict[str, Any]) -> str:
    before = str(item.get("from", ""))[:12] or "new"
    after = str(item.get("to", ""))[:12] or "missing"
    return f"""
    <article class="change-card">
      <p class="eyebrow">{e(item.get('repository', 'Source change'))}</p>
      <div class="change-sha"><code>{e(before)}</code><span aria-hidden="true">→</span><code>{e(after)}</code></div>
      <h3>{e(item.get('message', 'Repository head changed'))}</h3>
      <p>{e(item.get('summary', 'Review the changed source before adopting any editorial claim.'))}</p>
    </article>"""

def page_main(
    page: Page,
    pages: list[Page],
    pages_by_id: dict[str, Page],
    edition_history: dict[str, Any],
    reading_paths: dict[str, Any],
    edition: str,
) -> tuple[str, list[dict[str, Any]], str]:
    if page.kind in {"note", "project", "collection"}:
        return article_main(page, pages_by_id, edition_history, reading_paths, edition)
    search_text: str | None = None
    # Annotate authored headings before expanding narrow macros. Offsets stay
    # bound to the exact source fragment, while generated cards and repository
    # rows remain projections rather than invented source passages.
    body, toc = annotate_headings(page.body_html, page_id=page.id, controls=False)
    snapshot_path = ROOT / "content" / "data" / "source-snapshot.json"
    snapshot = read_json(snapshot_path) if snapshot_path.exists() else {"repositories": [], "limits": []}
    repositories = snapshot.get("repositories", [])
    # Page macros are deliberately narrow and visible in source.
    if page.kind == "home":
        notes = sorted(
            (p for p in pages if p.kind == "note"),
            key=lambda p: (p.data.get("date", ""), p.data.get("number", "")),
            reverse=True,
        )
        body = body.replace("{{HOME_NOTES}}", "".join(home_note(p) for p in notes))
        search_text = page.data.get("description", "")
    elif page.kind == "listing":
        notes = sorted((p for p in pages if p.kind == "note"), key=lambda p: (p.data.get("date", ""), p.data.get("number", "")), reverse=True)
        body = body.replace("{{ALL_NOTES}}", "".join(card(p) for p in notes))
        body = body.replace("{{NOTE_ARCHIVE}}", note_archive_markup(notes))
        body = body.replace("{{TOPIC_INDEX}}", topic_index_markup(notes))
        body = body.replace("{{READING_PATHS}}", reading_paths_archive_markup(reading_paths, pages_by_id, edition))
        body = body.replace("{{NOTE_COUNT}}", str(len(notes)))
    elif page.kind == "sources":
        selected_count = sum(len(repo.get("selected_files", [])) for repo in repositories)
        cards = "".join(repository_card(repo) for repo in repositories)
        retired_sources = snapshot.get("retired_sources", [])
        retired_cards = "".join(retired_source_card(source) for source in retired_sources)
        limits = " ".join(str(item) for item in snapshot.get("limits", []))
        changes = snapshot.get("changes_since_previous", [])
        activity = snapshot.get("activity", [])
        digest = hashlib.sha256(snapshot_path.read_bytes()).hexdigest()[:12] if snapshot_path.exists() else "unavailable"
        body = body.replace("{{SNAPSHOT_TIME}}", e(snapshot.get("captured_at", "Unknown")))
        body = body.replace("{{SNAPSHOT_DIGEST}}", e(digest))
        body = body.replace("{{REPOSITORY_COUNT}}", str(len(repositories)))
        body = body.replace("{{SELECTED_FILE_COUNT}}", str(selected_count))
        body = body.replace("{{RETIRED_SOURCE_COUNT}}", str(len(retired_sources)))
        body = body.replace("{{CHANGE_COUNT}}", str(len(changes)))
        body = body.replace("{{REPOSITORY_CARDS}}", cards)
        body = body.replace("{{RETIRED_SOURCE_CARDS}}", retired_cards or '<p class="empty-state">No retired source is recorded in this edition.</p>')
        body = body.replace("{{RECENT_ACTIVITY}}", "".join(activity_row(item) for item in activity[:8]))
        body = body.replace("{{SNAPSHOT_LIMITS}}", e(limits))
    elif page.kind == "editions":
        notes = [p for p in pages if p.kind == "note" and p.status == "published"]
        revision_count = sum(len(note_history_records(edition_history, note.id)) for note in notes)
        revised_note_count = sum(len(note_history_records(edition_history, note.id)) > 1 for note in notes)
        body = body.replace("{{REVISION_COUNT}}", str(revision_count))
        body = body.replace("{{REVISED_NOTE_COUNT}}", str(revised_note_count))
        body = body.replace("{{REVISED_NOTE_PLURAL}}", "s" if revised_note_count != 1 else "")
        body = body.replace("{{EDITION_HISTORY}}", edition_history_markup(notes, edition_history))
    elif page.kind == "now":
        changes = snapshot.get("changes_since_previous", [])
        activity = snapshot.get("activity", [])
        limits = " ".join(str(item) for item in snapshot.get("limits", []))
        repo_rows = "".join(
            f'<li><span>{e(repo.get("name", "").split("/")[-1])}</span><code>{e(repo.get("head_short", "unknown"))}</code><strong>{e(repo.get("head_message", "No message captured"))}</strong></li>'
            for repo in repositories
        )
        body = body.replace("{{SNAPSHOT_TIME}}", e(snapshot.get("captured_at", "Unknown")))
        body = body.replace("{{PREVIOUS_SNAPSHOT_TIME}}", e(snapshot.get("previous_capture", {}).get("captured_at", "No prior capture")))
        body = body.replace("{{REPOSITORY_COUNT}}", str(len(repositories)))
        body = body.replace("{{CHANGE_COUNT}}", str(len(changes)))
        body = body.replace("{{RETIRED_SOURCE_COUNT}}", str(len(snapshot.get("retired_sources", []))))
        body = body.replace("{{REPOSITORY_ROWS}}", repo_rows)
        body = body.replace("{{CHANGE_CARDS}}", "".join(change_card(item) for item in changes) or '<p class="empty-state">No repository-head change was observed across this boundary.</p>')
        body = body.replace("{{RECENT_ACTIVITY}}", "".join(activity_row(item) for item in activity[:12]))
        body = body.replace("{{SNAPSHOT_LIMITS}}", e(limits))
    return body, toc, search_text if search_text is not None else plain_text(body)


def output_path(url: str, dist: Path = DEFAULT_DIST) -> Path:
    clean = url.split("?", 1)[0].split("#", 1)[0]
    if clean == "/":
        return dist / "index.html"
    if clean.endswith(".html"):
        return dist / clean.lstrip("/")
    return dist / clean.strip("/") / "index.html"


def safe_output_dir(output: Path) -> Path:
    """Resolve an output directory without permitting destructive source cleanup."""
    resolved = output.expanduser().resolve()
    root = ROOT.resolve()
    if resolved == root or root.is_relative_to(resolved):
        raise SystemExit(f"Refusing output directory that contains the project source: {resolved}")
    protected = [CONTENT, ASSETS, TEMPLATES, ROOT / "tools", ROOT / "tests", ROOT / ".github", ROOT / "research"]
    for source in protected:
        source = source.resolve()
        if resolved == source or resolved.is_relative_to(source):
            raise SystemExit(f"Refusing output directory inside source material: {resolved}")
    return resolved


def stable_source_hash(*, include_drafts: bool = False) -> str:
    pages = load_pages(include_drafts=include_drafts)
    include_roots = [ROOT / "config.json", ASSETS, TEMPLATES, ROOT / "tools"]
    if include_drafts:
        include_roots.append(ROOT / "content" / "data")
    paths: set[Path] = set() if include_drafts else publication_content_files(ROOT)
    for item in include_roots:
        if item.is_file():
            paths.add(item)
        elif item.is_dir():
            paths.update(p for p in item.rglob("*") if p.is_file() and "__pycache__" not in p.parts)
    for page in pages:
        paths.add(page.meta_path)
        paths.add((page.meta_path.parent / page.data["body"]).resolve())
    rows: list[bytes] = []
    for path in sorted(paths):
        rel = path.relative_to(ROOT).as_posix()
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        rows.append(f"{rel}\0{digest}\n".encode())
    return hashlib.sha256(b"".join(rows)).hexdigest()


def build_time_basis() -> str:
    """Describe the deterministic reference clock, never an execution receipt."""
    if os.environ.get("LUMEN_BUILD_TIME"):
        return "explicit-LUMEN_BUILD_TIME"
    if os.environ.get("SOURCE_DATE_EPOCH"):
        return "SOURCE_DATE_EPOCH"
    return "accepted-source-snapshot"


def build_time() -> dt.datetime:
    """Return the identity-bearing time for this accepted source projection.

    A canonical static edition must not change merely because it was rebuilt a
    second later. Explicit operator overrides remain available for previews and
    reproducible-release tooling; otherwise the accepted source snapshot is the
    clock. This keeps feeds, metadata hashes, and the HTML/ZIP capsule stable.
    """
    explicit = os.environ.get("LUMEN_BUILD_TIME")
    if explicit:
        parsed = dt.datetime.fromisoformat(explicit.replace("Z", "+00:00"))
        return parsed.astimezone(dt.timezone.utc)
    epoch = os.environ.get("SOURCE_DATE_EPOCH")
    if epoch:
        return dt.datetime.fromtimestamp(int(epoch), tz=dt.timezone.utc)
    snapshot = read_json(ROOT / "content" / "data" / "source-snapshot.json")
    captured = snapshot.get("captured_at")
    if not captured:
        raise SystemExit("source snapshot is missing captured_at; set LUMEN_BUILD_TIME explicitly")
    parsed = dt.datetime.fromisoformat(str(captured).replace("Z", "+00:00"))
    return parsed.astimezone(dt.timezone.utc)


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def xml_bytes(element: ET.Element) -> bytes:
    return ET.tostring(element, encoding="utf-8", xml_declaration=True)


def annotate_internal_preview_links(markup: str, url_to_id: dict[str, str]) -> str:
    anchor_re = re.compile(r"<a\b([^>]*)>", re.I)
    href_re = re.compile(r'href="(/[^"]*)"', re.I)

    def repl(match: re.Match[str]) -> str:
        attrs = match.group(1)
        if "data-preview-id=" in attrs:
            return match.group(0)
        href_match = href_re.search(attrs)
        if not href_match:
            return match.group(0)
        href = href_match.group(1)
        bare, _, fragment = href.partition("#")
        page_id = url_to_id.get(bare)
        if not page_id:
            return match.group(0)
        anchor = f' data-preview-anchor="{e(fragment)}"' if fragment else ""
        return f'<a{attrs} data-preview-id="{e(page_id)}"{anchor}>'

    return anchor_re.sub(repl, markup)


def sri_sha384(path: Path) -> str:
    digest = hashlib.sha384(path.read_bytes()).digest()
    return "sha384-" + base64.b64encode(digest).decode("ascii")


def compressed_size(path: Path) -> int:
    return len(gzip.compress(path.read_bytes(), compresslevel=9, mtime=0))


def stylesheet_bundle() -> bytes:
    """Return the base stylesheet plus optional look layers in stable order."""
    parts = [(ASSETS / "css" / "site.css").read_bytes()]
    look_dir = ASSETS / "css" / "looks"
    if look_dir.is_dir():
        for path in sorted(look_dir.glob("*.css")):
            parts.extend([f"\n/* look: {path.stem} */\n".encode(), path.read_bytes()])
    return b"".join(parts)


def sri_sha384_bytes(data: bytes) -> str:
    digest = hashlib.sha384(data).digest()
    return "sha384-" + base64.b64encode(digest).decode("ascii")


def copy_assets(dist: Path) -> dict[str, Any]:
    """Copy assets with content-addressed names and return template data.

    The ordinary reading runtime remains the only eager JavaScript asset. Larger
    tools such as edition comparison are fingerprinted separately and requested
    only after an explicit reader action.
    """
    shutil.copytree(ASSETS, dist / "assets", dirs_exist_ok=True)
    records: dict[str, Any] = {}
    specs = (
        ("css", "site.css", "css"),
        ("css", "return-point.css", "return_point_css"),
        ("js", "site.js", "js"),
        ("js", "return-point.js", "return_point_js"),
        ("js", "edition-compare.js", "edition_compare"),
    )
    for family, name, key in specs:
        source = ASSETS / family / name
        data = stylesheet_bundle() if key == "css" else source.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        suffix = source.suffix
        stem = source.stem
        target_name = f"{stem}.{digest[:12]}{suffix}"
        target = dist / "assets" / family / target_name
        target.write_bytes(data)
        ordinary = dist / "assets" / family / name
        if ordinary.exists():
            ordinary.unlink()
        if key == "css":
            shutil.rmtree(dist / "assets" / "css" / "looks", ignore_errors=True)
        records[key] = {
            "path": f"/assets/{family}/{target_name}",
            "sha256": digest,
            "sri": sri_sha384_bytes(data),
            "bytes": len(data),
            "gzip_bytes": len(gzip.compress(data, compresslevel=9, mtime=0)),
            "loading": "eager" if key in {"css", "js"} else "on-demand",
        }
    return records


def service_worker(source_hash: str, asset_records: dict[str, Any]) -> str:
    core = [
        "/", "/notes/", "/editions/", "/now/", "/about/", "/sources/", "/workbench/", "/lab/",
        asset_records["css"]["path"], asset_records["js"]["path"],
        "/assets/icons/favicon.svg", "/assets/icons/mask-icon.svg",
        "/meta/search-index.json", "/meta/source-snapshot.json", "/site.webmanifest",
    ]
    cache_name = f"lumen-edition-{source_hash[:16]}"
    return textwrap.dedent(f"""
        const CACHE = {json.dumps(cache_name)};
        const CORE = {json.dumps(core, ensure_ascii=False)};
        self.addEventListener("install", (event) => {{
          event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(CORE)));
        }});
        self.addEventListener("activate", (event) => {{
          event.waitUntil(caches.keys().then((keys) => Promise.all(
            keys.filter((key) => key.startsWith("lumen-edition-") && key !== CACHE).map((key) => caches.delete(key))
          )).then(() => self.clients.claim()));
        }});
        self.addEventListener("fetch", (event) => {{
          const request = event.request;
          const url = new URL(request.url);
          if (request.method !== "GET" || url.origin !== self.location.origin) return;
          if (request.mode === "navigate") {{
            event.respondWith(fetch(request).then((response) => {{
              const copy = response.clone();
              caches.open(CACHE).then((cache) => cache.put(request, copy));
              return response;
            }}).catch(() => caches.match(request).then((hit) => hit || caches.match("/"))));
            return;
          }}
          event.respondWith(caches.match(request).then((hit) => hit || fetch(request).then((response) => {{
            if (response.ok) caches.open(CACHE).then((cache) => cache.put(request, response.clone()));
            return response;
          }})));
        }});
    """).strip() + "\n"


def build(clean: bool = False, output: Path = DEFAULT_DIST, *, include_drafts: bool = False) -> dict[str, Any]:
    dist = safe_output_dir(output)
    if dist.exists() and not clean:
        if not dist.is_dir() or any(dist.iterdir()):
            raise SystemExit(
                f"Refusing to merge a build into nonempty output: {dist}. "
                "Use --clean to replace generated output, or choose a fresh directory."
            )
    config = read_json(ROOT / "config.json")
    pages = load_pages(include_drafts=include_drafts)
    edition_history = load_edition_history(pages)
    pages_by_id = {p.id: p for p in pages}
    url_to_id = {p.url: p.id for p in pages}
    reading_paths = load_reading_paths(pages_by_id)

    for page in pages:
        missing_related = [x for x in page.data.get("related", []) if x not in pages_by_id]
        if missing_related:
            raise SystemExit(f"{page.id}: unknown related ids {missing_related}")

    if clean and dist.exists():
        shutil.rmtree(dist)
    dist.mkdir(parents=True, exist_ok=True)
    (dist / ".nojekyll").write_text("", encoding="utf-8")

    generated_at = build_time()
    source_hash = stable_source_hash(include_drafts=include_drafts)
    asset_records = copy_assets(dist)
    build_short = source_hash[:12]
    shell = (TEMPLATES / "shell.html").read_text(encoding="utf-8")
    search_records: list[dict[str, Any]] = []
    rendered_pages: list[dict[str, Any]] = []
    generated_iso = generated_at.isoformat().replace("+00:00", "Z")
    url_to_page = {
        page.url: {"id": page.id, "url": page.url, "title": page.title}
        for page in pages
    }

    # Derive the hypertext layer before writing any page. The visible documents
    # remain ordinary HTML; passage identities, typed links, and backlinks live
    # in separate static records and are requested only when a reader asks.
    prepared: dict[str, dict[str, Any]] = {}
    passages_by_page: dict[str, list[dict[str, Any]]] = {}
    page_descriptors: list[dict[str, Any]] = []
    for page in pages:
        main, toc, text = page_main(page, pages, pages_by_id, edition_history, reading_paths, str(config.get("edition", "development")))
        main = annotate_internal_preview_links(main, url_to_id)
        passages = build_passages(
            page_id=page.id,
            page_url=page.url,
            page_title=page.title,
            page_kind=page.kind,
            source_html=page.body_html,
            toc=toc,
            url_to_page=url_to_page,
        ) if toc else []
        passages_by_page[page.id] = passages
        prepared[page.id] = {
            "main": main,
            "toc": toc,
            "text": text,
            "passages": passages,
        }
        body_bytes = page.body_html.encode("utf-8")
        page_descriptors.append({
            "id": page.id,
            "url": page.url,
            "kind": page.kind,
            "title": page.title,
            "status": page.status,
            "date": page.data.get("date"),
            "body_sha256": hashlib.sha256(body_bytes).hexdigest(),
            "body_bytes": len(body_bytes),
            "word_count": len(re.findall(r"[\w’'\-]+", text, re.UNICODE)),
        })

    resolved_reading_paths, reading_path_memberships = resolve_reading_paths(
        reading_paths,
        pages_by_id,
        page_descriptors,
        passages_by_page,
        source_fingerprint=source_hash,
        generated_at=generated_iso,
        edition=str(config.get("edition", "development")),
    )
    write_json(dist / "meta" / "reading-paths.json", resolved_reading_paths)

    reference_index = build_reference_index(
        pages=page_descriptors,
        passages_by_page=passages_by_page,
        source_fingerprint=source_hash,
        generated_at=generated_iso,
    )
    ledger, page_contexts, graph = build_context_ledger(
        pages=page_descriptors,
        passages_by_page=passages_by_page,
        explicit_related={page.id: list(page.data.get("related", [])) for page in pages},
        source_fingerprint=source_hash,
        generated_at=generated_iso,
    )
    ledger["counts"]["external_sources"] = reference_index["counts"]["sources"]
    ledger["counts"]["reading_paths"] = resolved_reading_paths["counts"]["paths"]
    ledger["counts"]["reading_path_steps"] = resolved_reading_paths["counts"]["steps"]
    for page_id, rows in reading_path_memberships.items():
        page_contexts[page_id]["reading_paths"] = rows
    write_json(dist / "meta" / "references.json", reference_index)
    for source in reference_index.get("sources", []):
        write_json(
            dist / "meta" / "reference-previews" / f"{source['id']}.json",
            {
                "schema": "lumen.reference-preview/v1",
                "id": source["id"],
                "url": source["url"],
                "canonical_url": source["canonical_url"],
                "host": source["host"],
                "display_label": source.get("display_label") or source.get("host") or source.get("url"),
                "labels": source.get("labels", []),
                "citation_count": source.get("citation_count", 0),
                "page_count": source.get("page_count", 0),
                "record_url": f"/references/#{source['id']}",
                "boundary": "This local record identifies where accepted text linked. It does not certify support, truth, or current remote content.",
            },
        )
    for page in pages:
        main = prepared[page.id]["main"]
        if page.kind == "note":
            main = main.replace("{{NOTE_REFERENCES}}", note_references_markup(page.id, reference_index))
        else:
            main = main.replace("{{NOTE_REFERENCES}}", "")
        if page.id == "references":
            main = main.replace("{{REFERENCE_COUNT}}", str(reference_index["counts"]["sources"]))
            main = main.replace("{{REFERENCE_CITATION_COUNT}}", str(reference_index["counts"]["citations"]))
            main = main.replace("{{REFERENCE_DOMAIN_COUNT}}", str(reference_index["counts"]["domains"]))
            main = main.replace("{{REFERENCE_DOMAIN_OPTIONS}}", reference_domains_options(reference_index))
            main = main.replace("{{REFERENCE_INDEX}}", reference_index_markup(reference_index))
        main = annotate_reference_links(main, reference_index)
        prepared[page.id]["main"] = main

    # One accepted article can also travel as a very small, dependency-free
    # HTML folio. This is a bounded record-level export: the routed site remains
    # canonical, while a reader may keep or send one exact page without taking
    # the complete worktree or the entire Lumen.html edition.
    descriptor_by_id = {row["id"]: row for row in page_descriptors}
    folio_records: list[dict[str, Any]] = []
    folio_by_page: dict[str, dict[str, Any]] = {}
    folio_names: set[str] = set()
    for page in pages:
        if page.status != "published" or page.kind not in {"note", "project", "collection"}:
            continue
        filename = folio_filename(page, str(config.get("edition", "development")))
        if filename in folio_names:
            raise SystemExit(f"portable folio filename collision: {filename}")
        folio_names.add(filename)
        related_pages = [pages_by_id[row] for row in page.data.get("related", []) if row in pages_by_id]
        references = folio_reference_rows(page.id, reference_index)
        memberships = list(reading_path_memberships.get(page.id, []))
        folio_html = render_portable_folio(
            page,
            descriptor=descriptor_by_id[page.id],
            passages=passages_by_page.get(page.id, []),
            references=references,
            reading_paths=memberships,
            related_pages=related_pages,
            config=config,
            source_fingerprint=source_hash,
            generated_at=generated_iso,
        )
        path = dist / "folios" / filename
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(folio_html, encoding="utf-8")
        raw = path.read_bytes()
        record = {
            "page_id": page.id,
            "page_url": page.url,
            "kind": page.kind,
            "title": page.title,
            "file": f"folios/{filename}",
            "url": f"/folios/{filename}",
            "download_name": f"Lumen-{filename}",
            "bytes": len(raw),
            "gzip_bytes": compressed_size(path),
            "sha256": hashlib.sha256(raw).hexdigest(),
            "body_sha256": descriptor_by_id[page.id]["body_sha256"],
            "passages": len(passages_by_page.get(page.id, [])),
            "external_sources": len(references),
            "reading_paths": len(memberships),
        }
        folio_records.append(record)
        folio_by_page[page.id] = record
    folio_manifest = {
        "schema": "lumen.portable-folios/v1",
        "edition": config.get("edition", "development"),
        "generated_at": generated_iso,
        "source_fingerprint_sha256": source_hash,
        "counts": {
            "folios": len(folio_records),
            "bytes": sum(int(row["bytes"]) for row in folio_records),
            "passages": sum(int(row["passages"]) for row in folio_records),
            "external_sources": sum(int(row["external_sources"]) for row in folio_records),
        },
        "folios": folio_records,
        "boundary": "Each folio carries one accepted published article and bounded local context. It is not the complete site, a live feed, or a substitute for the canonical routed page.",
    }
    write_json(dist / "meta" / "folios.json", folio_manifest)

    # A curated reading path can travel as one quiet file too. Unlike a page
    # folio, this projection is assembled from several exact accepted targets:
    # whole pages where the path names a page, and source-bound passage slices
    # where the path names one section. It carries no private reading history.
    path_folio_records: list[dict[str, Any]] = []
    path_folio_by_id: dict[str, dict[str, Any]] = {}
    path_folio_names: set[str] = set()
    for path_record in resolved_reading_paths.get("paths", []):
        path_id = str(path_record["id"])
        filename = reading_path_folio_filename(path_id, str(config.get("edition", "development")))
        if filename in path_folio_names:
            raise SystemExit(f"portable reading-path folio filename collision: {filename}")
        path_folio_names.add(filename)
        path_html, path_sha256 = render_reading_path_folio(
            path_record,
            pages_by_id=pages_by_id,
            passages_by_page=passages_by_page,
            boundary=resolved_reading_paths.get("boundary"),
            config=config,
            source_fingerprint=source_hash,
            generated_at=generated_iso,
        )
        path = dist / "path-folios" / filename
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(path_html, encoding="utf-8")
        raw = path.read_bytes()
        record = {
            "path_id": path_id,
            "title": path_record["title"],
            "description": path_record["description"],
            "file": f"path-folios/{filename}",
            "url": f"/path-folios/{filename}",
            "canonical_url": f'/notes/#path-{path_id}',
            "download_name": f"Lumen-{filename}",
            "bytes": len(raw),
            "gzip_bytes": compressed_size(path),
            "sha256": hashlib.sha256(raw).hexdigest(),
            "path_sha256": path_sha256,
            "steps": len(path_record.get("steps", [])),
            "page_steps": sum(step.get("scope") == "page" for step in path_record.get("steps", [])),
            "passage_steps": sum(step.get("scope") == "passage" for step in path_record.get("steps", [])),
            "unique_pages": len({str(step.get("page_id")) for step in path_record.get("steps", [])}),
            "word_count": sum(int(step.get("word_count", 0)) for step in path_record.get("steps", [])),
        }
        path_folio_records.append(record)
        path_folio_by_id[path_id] = record
    path_folio_manifest = {
        "schema": "lumen.portable-path-folios/v1",
        "edition": config.get("edition", "development"),
        "generated_at": generated_iso,
        "source_fingerprint_sha256": source_hash,
        "counts": {
            "folios": len(path_folio_records),
            "bytes": sum(int(row["bytes"]) for row in path_folio_records),
            "steps": sum(int(row["steps"]) for row in path_folio_records),
            "page_steps": sum(int(row["page_steps"]) for row in path_folio_records),
            "passage_steps": sum(int(row["passage_steps"]) for row in path_folio_records),
        },
        "folios": path_folio_records,
        "boundary": "Each file carries one authored path assembled from exact accepted pages or passages. It is not private reading history, an inferred recommendation, or proof that one step entails the next.",
    }
    write_json(dist / "meta" / "path-folios.json", path_folio_manifest)

    context_digests: dict[str, str] = {}
    for page_id, payload in page_contexts.items():
        path = dist / "meta" / "context" / f"{page_id}.json"
        write_json(path, payload)
        context_digests[page_id] = hashlib.sha256(path.read_bytes()).hexdigest()
    for row in ledger["pages"]:
        row["context_file"] = f"meta/context/{row['id']}.json"
        row["context_file_sha256"] = context_digests[row["id"]]
    write_json(dist / "meta" / "hypertext-ledger.json", ledger)
    write_json(dist / "meta" / "graph.json", graph)
    edition_payload = {
        "schema": "lumen.editions/v1",
        "edition": config.get("edition", "development"),
        "generated_at": generated_iso,
        "source_fingerprint_sha256": source_hash,
        "notes": edition_history.get("notes", {}),
    }
    write_json(dist / "meta" / "editions.json", edition_payload)
    source_snapshot = read_json(ROOT / "content" / "data" / "source-snapshot.json")
    history_by_id = edition_history.get("notes", {})
    summary_pages = []
    for descriptor in page_descriptors:
        revisions = list(history_by_id.get(descriptor["id"], {}).get("revisions", []))
        summary_passages = [
            {
                "id": passage["id"],
                "anchor": passage["anchor"],
                "url": passage["url"],
                "level": passage["level"],
                "title": passage["title"],
                "order": passage["order"],
                "excerpt": passage["excerpt"],
                "word_count": passage["word_count"],
                "text_sha256": passage["text_sha256"],
                "source_html_sha256": passage["source_html_sha256"],
            }
            for passage in passages_by_page.get(descriptor["id"], [])
        ]
        summary_pages.append({
            **descriptor,
            "revision_count": len(revisions) if revisions else None,
            "latest_revision": revisions[-1] if revisions else None,
            "passage_detail": True,
            "passages": summary_passages,
            "portable_folio": folio_by_page.get(descriptor["id"]),
        })
    edition_summary = {
        "schema": "lumen.edition-summary/v2",
        "scope": "complete",
        "edition": config.get("edition", "development"),
        "generated_at": generated_iso,
        "source_fingerprint_sha256": source_hash,
        "counts": {
            "pages": len(summary_pages),
            "notes": sum(row["kind"] == "note" for row in summary_pages),
            "active_sources": len(source_snapshot.get("repositories", [])),
            "retired_sources": len(source_snapshot.get("retired_sources", [])),
            "passages": sum(len(row.get("passages", [])) for row in summary_pages),
            "reading_paths": resolved_reading_paths["counts"]["paths"],
            "reading_path_steps": resolved_reading_paths["counts"]["steps"],
            "portable_folios": len(folio_records),
            "portable_path_folios": len(path_folio_records),
        },
        "pages": summary_pages,
        "sources": {
            "active": [
                {
                    "name": row.get("name"),
                    "head_sha": row.get("head_sha"),
                    "head_message": row.get("head_message"),
                    "pushed_at": row.get("pushed_at"),
                }
                for row in source_snapshot.get("repositories", [])
            ],
            "retired": source_snapshot.get("retired_sources", []),
        },
        "boundary": "This record compares carried page bodies, source-bound passage identities, accepted public-source identities, and exact portable page/path-folio receipts. It does not explain why prose changed or certify any claim as true.",
    }
    write_json(dist / "meta" / "edition-summary.json", edition_summary)

    for page in pages:
        prepared_page = prepared[page.id]
        main = prepared_page["main"]
        toc = prepared_page["toc"]
        text = prepared_page["text"]
        passages = prepared_page["passages"]
        page_context = page_contexts[page.id]
        active = (
            "notes" if page.kind in {"note", "listing"}
            else "projects" if page.kind in {"project", "collection"}
            else page.kind
        )
        canonical = config["origin"].rstrip("/") + page.url
        structured_data = structured_data_for_page(page, config, canonical)
        structured_json = json.dumps(structured_data, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
        published_meta = (
            f'<meta property="article:published_time" content="{e(page.data.get("date"))}">'
            if page.kind == "note" and page.data.get("date") else ""
        )
        context = {
            "LANG": e(config.get("language", "en")),
            "KIND": e(page.kind),
            "CSP": e(csp_for_structured_data(structured_json)),
            "KEYWORDS": e(", ".join(str(tag) for tag in page.data.get("tags", []))),
            "PUBLISHED_META": published_meta,
            "STRUCTURED_DATA": structured_json,
            "THEME": e(page.data.get("theme", "system")),
            "LOOK": e(page.data.get("look", config.get("default_look", "field-notes"))),
            "LOOK_PREVIEW": "true" if page.data.get("look_preview") else "false",
            "EDITION": e(config.get("edition", "development")),
            "FINGERPRINT": e(source_hash),
            "DESCRIPTION": e(page.data["description"]),
            "AUTHOR": e(page.data["author"]),
            "ROBOTS": "noindex, nofollow" if page.status == "draft" else "index, follow",
            "OG_TYPE": "article" if page.kind in {"note", "project", "collection"} else "website",
            "TITLE": e(page.title),
            "CANONICAL": e(canonical),
            "ORIGIN": e(config["origin"].rstrip("/")),
            "SOURCE_REPOSITORY": e(config.get("source_repository", "Sapient-Lumen/sapient-lumen.github.io")),
            "CSS_PATH": e(asset_records["css"]["path"]),
            "CSS_INTEGRITY": e(asset_records["css"]["sri"]),
            "JS_PATH": e(asset_records["js"]["path"]),
            "JS_INTEGRITY": e(asset_records["js"]["sri"]),
            "RETURN_JS_PATH": e(asset_records["return_point_js"]["path"]),
            "RETURN_CSS_PATH": e(asset_records["return_point_css"]["path"]),
            "RETURN_CSS_INTEGRITY": e(asset_records["return_point_css"]["sri"]),
            "COMPARE_PATH": e(asset_records["edition_compare"]["path"]),
            "COMPARE_INTEGRITY": e(asset_records["edition_compare"]["sri"]),
            "PAGE_ID": e(page.id),
            "HEADER": header_markup(active, str(config.get("edition", "development"))),
            "MAIN": main,
            "FOOTER": footer_markup(build_short),
        }
        rendered = render_tokens(shell, context)
        out = output_path(page.url, dist)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(rendered, encoding="utf-8")

        source = page.data.get("source", {})
        limits = page.data.get("limits", [])
        related_ids = page.data.get("related", [])
        page_descriptor = next(row for row in page_descriptors if row["id"] == page.id)
        inspect = {
            "schema": "lumen.page-inspection/v2",
            "page": {
                "id": page.id,
                "url": page.url,
                "kind": page.kind,
                "title": page.title,
                "date": page.data.get("date"),
                "author": page.data["author"],
                "source": source,
                "source_body": {
                    "path": page.meta_path.with_name(str(page.data["body"])).relative_to(ROOT).as_posix(),
                    "bytes": page_descriptor["body_bytes"],
                    "sha256": page_descriptor["body_sha256"],
                },
                "limits": limits,
                "publication_history": note_history_records(edition_history, page.id) if page.kind == "note" else [],
                "aliases": page.data.get("aliases", []),
                "status": page.status,
                "related": [
                    {"id": rid, "title": pages_by_id[rid].title, "url": pages_by_id[rid].url}
                    for rid in related_ids
                ],
                "reading_paths": reading_path_memberships.get(page.id, []),
                "portable_folio": folio_by_page.get(page.id),
                "hypertext": {
                    "passages": page_context["page"]["passage_count"],
                    "words": page_context["page"]["word_count"],
                    "external_citations": page_context["page"]["external_citation_count"],
                    "incoming_contexts": page_context["page"]["incoming_context_count"],
                    "outgoing_contexts": page_context["page"]["outgoing_context_count"],
                    "context_file": f"/meta/context/{page.id}.json",
                    "context_file_sha256": context_digests[page.id],
                },
            },
            "build": {
                "source_fingerprint": source_hash,
                "generated_at": generated_iso,
                "generated_at_basis": build_time_basis(),
                "generated_at_semantics": "reproducible-reference-clock",
                "generator": "tools/build.py",
                "mode": "preview" if include_drafts else "canonical",
                "javascript_required_for_reading": False,
                "third_party_requests": 0,
            },
        }
        write_json(dist / "meta" / "pages" / f"{page.id}.json", inspect)
        write_json(
            dist / "meta" / "previews" / f"{page.id}.json",
            {
                "id": page.id,
                "url": page.url,
                "kind": page.kind,
                "title": page.title,
                "description": page.data["description"],
                "date": page.data.get("date"),
                "label": page.data.get("label", page.kind.title()),
                "status": page.status,
                "passages": [
                    {"anchor": row["anchor"], "title": row["title"], "excerpt": row["excerpt"]}
                    for row in passages
                ],
            },
        )
        search_records.append(
            {
                "id": page.id,
                "scope": "page",
                "url": page.url,
                "kind": page.kind,
                "title": page.title,
                "page_title": page.title,
                "description": page.data["description"],
                "date": page.data.get("date"),
                "tags": page.data.get("tags", []),
                "aliases": page.data.get("aliases", []),
                "status": page.status,
                "text": text,
            }
        )
        for passage in passages:
            if not passage["text"]:
                continue
            search_records.append({
                "id": passage["id"],
                "scope": "passage",
                "url": passage["url"],
                "kind": page.kind,
                "title": passage["title"],
                "page_title": page.title,
                "description": passage["excerpt"],
                "date": page.data.get("date"),
                "tags": page.data.get("tags", []),
                "aliases": page.data.get("aliases", []),
                "status": page.status,
                "text": passage["text"],
                "text_sha256": passage["text_sha256"],
            })
        rendered_pages.append({"id": page.id, "url": page.url, "output": out.relative_to(dist).as_posix()})

    for source in reference_index.get("sources", []):
        labels = list(source.get("labels", []))
        contexts = [
            f"{row.get('page_title', '')}: {row.get('passage_title', '')}"
            for row in source.get("citations", [])
        ]
        search_records.append({
            "id": source.get("id"),
            "scope": "reference",
            "url": f"/references/#{source.get('id')}",
            "kind": "reference",
            "title": source.get("display_label") or source.get("host"),
            "page_title": "Reference room",
            "description": f"{source.get('host')} · cited in {source.get('citation_count', 0)} source-bound passage(s)",
            "date": None,
            "tags": ["reference", source.get("host")],
            "aliases": labels[1:],
            "status": "published",
            "text": " ".join(labels + [str(source.get("canonical_url", ""))] + contexts),
        })

    for path in resolved_reading_paths.get("paths", []):
        search_records.append({
            "id": f"path-{path['id']}",
            "scope": "path",
            "url": f"/notes/#path-{path['id']}",
            "kind": "path",
            "title": path["title"],
            "page_title": "Field Notes",
            "description": path["description"],
            "date": None,
            "tags": ["reading path", "thread"],
            "aliases": [step["label"] for step in path.get("steps", [])],
            "status": "published",
            "text": " ".join([path["description"]] + [f"{step['label']} {step['note']} {step['page_title']}" for step in path.get("steps", [])]),
        })

    write_json(dist / "meta" / "search-index.json", {
        "schema": "lumen.search/v2",
        "page_count": len(pages),
        "passage_count": sum(len(rows) for rows in passages_by_page.values()),
        "reference_count": reference_index["counts"]["sources"],
        "path_count": resolved_reading_paths["counts"]["paths"],
        "records": search_records,
    })
    write_json(dist / "meta" / "source-snapshot.json", source_snapshot)

    # Public subscription feeds. They are generated from the same accepted notes
    # as the routed site and contain no drafts or private reader state.
    public_notes = sorted(
        (p for p in pages if p.kind == "note" and p.status == "published"),
        key=lambda p: p.data.get("date", ""),
        reverse=True,
    )
    atom = ET.Element("feed", xmlns="http://www.w3.org/2005/Atom")
    ET.SubElement(atom, "title").text = config["site_title"]
    ET.SubElement(atom, "subtitle").text = config.get("description", config.get("tagline", ""))
    ET.SubElement(atom, "id").text = config["origin"] + "/"
    ET.SubElement(atom, "updated").text = generated_at.isoformat().replace("+00:00", "Z")
    author = ET.SubElement(atom, "author")
    ET.SubElement(author, "name").text = config.get("author", "Lumen")
    ET.SubElement(atom, "link", href=config["origin"] + "/feed.xml", rel="self", type="application/atom+xml")
    ET.SubElement(atom, "link", href=config["origin"] + "/", rel="alternate", type="text/html")
    for page in public_notes:
        entry = ET.SubElement(atom, "entry")
        ET.SubElement(entry, "title").text = page.title
        ET.SubElement(entry, "id").text = config["origin"] + page.url
        ET.SubElement(entry, "link", href=config["origin"] + page.url)
        date = page.data.get("date") or generated_at.date().isoformat()
        ET.SubElement(entry, "published").text = date + "T00:00:00Z"
        ET.SubElement(entry, "updated").text = str(page.data.get("modified") or date) + "T00:00:00Z"
        ET.SubElement(entry, "summary").text = page.data["description"]
        ET.SubElement(entry, "content", type="html").text = absolute_feed_html(page.body_html, config["origin"])
        for tag in page.data.get("tags", []):
            ET.SubElement(entry, "category", term=str(tag))
    (dist / "feed.xml").write_bytes(xml_bytes(atom))

    ET.register_namespace("content", "http://purl.org/rss/1.0/modules/content/")
    ET.register_namespace("atom", "http://www.w3.org/2005/Atom")
    rss = ET.Element("rss", version="2.0")
    channel = ET.SubElement(rss, "channel")
    ET.SubElement(channel, "title").text = config["site_title"]
    ET.SubElement(channel, "link").text = config["origin"] + "/"
    ET.SubElement(channel, "description").text = config.get("description", config.get("tagline", ""))
    ET.SubElement(channel, "language").text = config.get("language", "en")
    ET.SubElement(channel, "lastBuildDate").text = email.utils.format_datetime(generated_at)
    ET.SubElement(channel, "{http://www.w3.org/2005/Atom}link", href=config["origin"] + "/rss.xml", rel="self", type="application/rss+xml")
    for page in public_notes:
        item = ET.SubElement(channel, "item")
        ET.SubElement(item, "title").text = page.title
        ET.SubElement(item, "link").text = config["origin"] + page.url
        ET.SubElement(item, "guid", isPermaLink="true").text = config["origin"] + page.url
        date = dt.datetime.combine(dt.date.fromisoformat(str(page.data.get("date"))), dt.time(), tzinfo=dt.timezone.utc)
        ET.SubElement(item, "pubDate").text = email.utils.format_datetime(date)
        ET.SubElement(item, "description").text = page.data["description"]
        ET.SubElement(item, "{http://purl.org/rss/1.0/modules/content/}encoded").text = absolute_feed_html(page.body_html, config["origin"])
        for tag in page.data.get("tags", []):
            ET.SubElement(item, "category").text = str(tag)
    (dist / "rss.xml").write_bytes(xml_bytes(rss))

    write_json(dist / "feed.json", {
        "version": "https://jsonfeed.org/version/1.1",
        "title": config["site_title"],
        "home_page_url": config["origin"] + "/",
        "feed_url": config["origin"] + "/feed.json",
        "description": config.get("description", config.get("tagline", "")),
        "language": config.get("language", "en"),
        "authors": [{"name": config.get("author", "Lumen"), "url": config["origin"] + "/about/"}],
        "items": [
            {
                "id": config["origin"] + page.url,
                "url": config["origin"] + page.url,
                "title": page.title,
                "summary": page.data["description"],
                "content_html": absolute_feed_html(page.body_html, config["origin"]),
                "date_published": str(page.data.get("date")) + "T00:00:00Z",
                "date_modified": str(page.data.get("modified") or page.data.get("date")) + "T00:00:00Z",
                "tags": list(page.data.get("tags", [])),
                "authors": [{"name": page.data.get("author", config.get("author", "Lumen"))}],
            }
            for page in public_notes
        ],
    })

    urlset = ET.Element("urlset", xmlns="http://www.sitemaps.org/schemas/sitemap/0.9")
    for page in (p for p in pages if p.status == "published"):
        item = ET.SubElement(urlset, "url")
        ET.SubElement(item, "loc").text = config["origin"].rstrip("/") + page.url
        if page.data.get("modified") or page.data.get("date"):
            ET.SubElement(item, "lastmod").text = str(page.data.get("modified") or page.data.get("date"))
    (dist / "sitemap.xml").write_bytes(xml_bytes(urlset))
    (dist / "robots.txt").write_text(f"User-agent: *\nAllow: /\nSitemap: {config['origin']}/sitemap.xml\n", encoding="utf-8")
    write_json(
        dist / "site.webmanifest",
        {
            "name": config["site_title"],
            "short_name": config["site_name"],
            "start_url": "/",
            "display": "standalone",
            "background_color": "#f3efe4",
            "theme_color": "#14231c",
            "icons": [{"src": "/assets/icons/favicon.svg", "sizes": "any", "type": "image/svg+xml", "purpose": "any maskable"}],
        },
    )

    # A useful 404 is generated from the same shell but has no inspection record.
    not_found = """
<section class="error-page"><p class="eyebrow">404 · Unobserved route</p><h2>This path has no published artifact.</h2><p>The absence is real; it has not been filled in with a guess.</p><p><a class="button-link" href="/">Return to the field notes</a></p></section>"""
    not_found_html = render_tokens(
        shell,
        {
            "LANG": "en",
            "KIND": "error",
            "CSP": e(csp_for_structured_data(json.dumps({"@context": "https://schema.org", "@type": "WebPage", "name": "Not found", "url": config["origin"] + "/404.html"}, separators=(",", ":")))),
            "KEYWORDS": "",
            "PUBLISHED_META": "",
            "STRUCTURED_DATA": json.dumps({"@context": "https://schema.org", "@type": "WebPage", "name": "Not found", "url": config["origin"] + "/404.html"}, separators=(",", ":")),
            "THEME": "system",
            "LOOK": e(config.get("default_look", "field-notes")),
            "LOOK_PREVIEW": "false",
            "EDITION": e(config.get("edition", "development")),
            "FINGERPRINT": e(source_hash),
            "DESCRIPTION": "This path has no published artifact.",
            "AUTHOR": "Lumen",
            "ROBOTS": "noindex, follow",
            "OG_TYPE": "website",
            "TITLE": "Not found",
            "CANONICAL": e(config["origin"] + "/404.html"),
            "ORIGIN": e(config["origin"]),
            "SOURCE_REPOSITORY": e(config.get("source_repository", "Sapient-Lumen/sapient-lumen.github.io")),
            "CSS_PATH": e(asset_records["css"]["path"]),
            "CSS_INTEGRITY": e(asset_records["css"]["sri"]),
            "JS_PATH": e(asset_records["js"]["path"]),
            "JS_INTEGRITY": e(asset_records["js"]["sri"]),
            "RETURN_JS_PATH": e(asset_records["return_point_js"]["path"]),
            "RETURN_CSS_PATH": e(asset_records["return_point_css"]["path"]),
            "RETURN_CSS_INTEGRITY": e(asset_records["return_point_css"]["sri"]),
            "COMPARE_PATH": e(asset_records["edition_compare"]["path"]),
            "COMPARE_INTEGRITY": e(asset_records["edition_compare"]["sri"]),
            "PAGE_ID": "not-found",
            "HEADER": header_markup("", str(config.get("edition", "development"))),
            "MAIN": not_found,
            "FOOTER": footer_markup(build_short),
        },
    )
    (dist / "404.html").write_text(not_found_html, encoding="utf-8")
    (dist / "service-worker.js").write_text(service_worker(source_hash, asset_records), encoding="utf-8")

    page_performance = []
    for row in rendered_pages:
        path = dist / row["output"]
        page_performance.append({
            "id": row["id"],
            "url": row["url"],
            "output": row["output"],
            "bytes": path.stat().st_size,
            "gzip_bytes": compressed_size(path),
        })
    performance = {
        "schema": "lumen.performance/v1",
        "generated_at": generated_at.isoformat().replace("+00:00", "Z"),
        "mode": "preview" if include_drafts else "canonical",
        "pages": page_performance,
        "folios": [
            {
                "page_id": row["page_id"],
                "output": row["file"],
                "bytes": row["bytes"],
                "gzip_bytes": row["gzip_bytes"],
            }
            for row in folio_records
        ],
        "path_folios": [
            {
                "path_id": row["path_id"],
                "output": row["file"],
                "bytes": row["bytes"],
                "gzip_bytes": row["gzip_bytes"],
                "steps": row["steps"],
            }
            for row in path_folio_records
        ],
        "assets": asset_records,
        "totals": {
            "page_bytes": sum(row["bytes"] for row in page_performance),
            "page_gzip_bytes": sum(row["gzip_bytes"] for row in page_performance),
            "portable_folio_bytes": sum(int(row["bytes"]) for row in folio_records),
            "portable_path_folio_bytes": sum(int(row["bytes"]) for row in path_folio_records),
            "authored_asset_bytes": sum(asset_records[key]["bytes"] for key in ("css", "js")),
            "authored_asset_gzip_bytes": sum(asset_records[key]["gzip_bytes"] for key in ("css", "js")),
            "optional_asset_bytes": asset_records["edition_compare"]["bytes"],
            "optional_asset_gzip_bytes": asset_records["edition_compare"]["gzip_bytes"],
        },
        "budgets": {
            "home_bytes": 110000,
            "css_bytes": 85000,
            "css_gzip_bytes": 18000,
            "js_bytes": 120000,
            "js_gzip_bytes": 29000,
            "edition_compare_bytes": 34000,
            "edition_compare_gzip_bytes": 8500,
            "search_index_bytes": 400000,
            "hypertext_ledger_bytes": 180000,
        },
    }
    write_json(dist / "meta" / "performance.json", performance)

    receipt = {
        "schema": "lumen.build-receipt/v4",
        "generated_at": generated_at.isoformat().replace("+00:00", "Z"),
        "generated_at_basis": build_time_basis(),
        "generated_at_semantics": "reproducible-reference-clock",
        "source_fingerprint_sha256": source_hash,
        "generator": "tools/build.py",
        "mode": "preview" if include_drafts else "canonical",
        "pages": rendered_pages,
        "counts": {
            "pages": len(pages),
            "drafts": sum(p.status == "draft" for p in pages),
            "published": sum(p.status == "published" for p in pages),
            "notes": sum(p.kind == "note" for p in pages),
            "projects": sum(p.kind == "project" for p in pages),
            "collections": sum(p.kind == "collection" for p in pages),
            "repositories": len(source_snapshot.get("repositories", [])),
            "retired_sources": len(source_snapshot.get("retired_sources", [])),
            "search_records": len(search_records),
            "passages": ledger["counts"]["passages"],
            "external_citations": ledger["counts"]["external_citations"],
            "external_sources": reference_index["counts"]["sources"],
            "reference_domains": reference_index["counts"]["domains"],
            "typed_context_edges": ledger["counts"]["typed_edges"],
            "reading_paths": resolved_reading_paths["counts"]["paths"],
            "reading_path_steps": resolved_reading_paths["counts"]["steps"],
            "portable_folios": len(folio_records),
            "portable_path_folios": len(path_folio_records),
            "relationship_edges": len(graph["edges"]),
            "looks": len(read_json(ROOT / "content" / "data" / "looks.json").get("looks", [])),
            "feeds": 3,
            "note_revisions": sum(len(note_history_records(edition_history, page.id)) for page in pages if page.kind == "note"),
            "revised_notes": sum(len(note_history_records(edition_history, page.id)) > 1 for page in pages if page.kind == "note"),
        },
        "assets": asset_records,
        "performance": {
            **performance["totals"],
            "search_index_bytes": (dist / "meta" / "search-index.json").stat().st_size,
            "hypertext_ledger_bytes": (dist / "meta" / "hypertext-ledger.json").stat().st_size,
            "reference_index_bytes": (dist / "meta" / "references.json").stat().st_size,
            "reading_paths_bytes": (dist / "meta" / "reading-paths.json").stat().st_size,
            "portable_folios_bytes": sum(int(row["bytes"]) for row in folio_records),
            "portable_path_folios_bytes": sum(int(row["bytes"]) for row in path_folio_records),
            "report": "meta/performance.json",
            "offline_mode": "explicit opt-in service worker",
        },
        "deployment_allowlist": ["dist/"],
        "edition_ledger": {
            "path": "meta/editions.json",
            "sha256": hashlib.sha256((dist / "meta" / "editions.json").read_bytes()).hexdigest(),
            "note_revisions": sum(len(note_history_records(edition_history, page.id)) for page in pages if page.kind == "note"),
        },
        "edition_summary": {
            "path": "meta/edition-summary.json",
            "sha256": hashlib.sha256((dist / "meta" / "edition-summary.json").read_bytes()).hexdigest(),
            "pages": len(summary_pages),
            "active_sources": len(source_snapshot.get("repositories", [])),
            "passages": sum(len(row.get("passages", [])) for row in summary_pages),
            "reading_paths": resolved_reading_paths["counts"]["paths"],
            "reading_path_steps": resolved_reading_paths["counts"]["steps"],
            "portable_folios": len(folio_records),
            "portable_path_folios": len(path_folio_records),
        },
        "portable_folios": {
            "path": "meta/folios.json",
            "sha256": hashlib.sha256((dist / "meta" / "folios.json").read_bytes()).hexdigest(),
            "folios": len(folio_records),
            "bytes": sum(int(row["bytes"]) for row in folio_records),
        },
        "portable_path_folios": {
            "path": "meta/path-folios.json",
            "sha256": hashlib.sha256((dist / "meta" / "path-folios.json").read_bytes()).hexdigest(),
            "folios": len(path_folio_records),
            "bytes": sum(int(row["bytes"]) for row in path_folio_records),
            "steps": sum(int(row["steps"]) for row in path_folio_records),
        },
    }
    # Write a preliminary receipt so the capsule can carry the exact public
    # projection without recursively embedding itself. The outer build then
    # records the completed carrier identity.
    write_json(dist / "build-receipt.json", receipt)
    if include_drafts:
        (dist / "Lumen.html").write_text(
            "<!doctype html><meta charset=utf-8><meta name=robots content='noindex,nofollow'>"
            "<title>Draft preview · Lumen</title><h1>Draft preview</h1>"
            "<p>The one-file custody edition is generated only from an accepted canonical build.</p>",
            encoding="utf-8",
        )
    if not include_drafts:
        from capsule import build_capsule
        capsule = build_capsule(dist, receipt, config)
        performance["capsule"] = {
            "path": capsule["file"],
            "bytes": capsule["bytes"],
            "sha256": capsule["sha256"],
            "browser_routes": capsule["browser_routes"],
            "archive_members": capsule["archive_members"],
        }
        write_json(dist / "meta" / "performance.json", performance)
        receipt["capsule"] = capsule
        receipt["performance"]["capsule_bytes"] = capsule["bytes"]
        receipt["performance"]["offline_mode"] = "downloadable HTML/ZIP capsule plus optional service worker"
        write_json(dist / "build-receipt.json", receipt)
    if dist == DEFAULT_DIST.resolve() and not include_drafts:
        write_json(ROOT / "BUILD-RECEIPT.json", receipt)
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--clean", action="store_true", help="replace existing generated output; required for a nonempty output directory")
    parser.add_argument("--output", type=Path, default=DEFAULT_DIST, help="output directory (default: dist)")
    parser.add_argument("--include-drafts", action="store_true", help="include draft pages in a noindex preview build")
    args = parser.parse_args()
    output = safe_output_dir(args.output)
    receipt = build(clean=args.clean, output=output, include_drafts=args.include_drafts)
    print(
        f"Built {receipt['counts']['pages']} pages; source {receipt['source_fingerprint_sha256'][:12]}; "
        f"output {output}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
