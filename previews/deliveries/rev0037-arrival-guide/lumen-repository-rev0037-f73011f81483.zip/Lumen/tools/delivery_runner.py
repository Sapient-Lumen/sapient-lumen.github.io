#!/usr/bin/env python3
"""Credential-free durable host for the GitHub MCP delivery pump.

All remote writes are emitted as explicit connector requests. This process never
acquires credentials. Private payloads never pass through the public downloader.
"""
from __future__ import annotations
import argparse
import base64
import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import sys
import urllib.request
import uuid

import delivery as d
import publication_guard as g

PREFIX = 'mcp__codex_apps__github_'
SCOPES = ('private', 'pointer', 'public', 'evidence')


def require(ok, message):
    d.require(ok, message)


def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    d.atomic_save(path, d.encoded(obj))


def immutable(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    d.evidence_file(path, d.encoded(obj))


def unwrap(result, *, file=False):
    require(isinstance(result, dict) and not result.get('isError'), 'connector returned an error; inspect the action receipt')
    value = result.get('structuredContent', result)
    if file:
        require(isinstance(value, dict) and value.get('encoding') == 'base64', 'file response must declare base64 encoding')
        return value
    if isinstance(value, dict) and isinstance(value.get('content'), str):
        value = json.loads(value['content'])
    require(isinstance(value, dict), 'connector JSON object required')
    return value


def tree_files(tree):
    return g.complete_tree(tree, tree['sha'], 'authenticated tree')


class Runner:
    def __init__(self, root):
        self.root = d.local_path(root)
        d.no_symlink_path(self.root)
        self.request = d.load(self.root/'REQUEST.json')
        self.bundle = d.local_path(self.request['bundle'])
        self.record = d.load(self.bundle/'DELIVERY.json')
        require(d.sha(d.regular(self.bundle/'DELIVERY.json')) == self.request['bundle_sha256'], 'frozen bundle record changed')
        d.profile_check(self.record['request']['profile'])
        for scope in ('private', 'public'):
            rows = d.inventory(self.bundle/scope)
            require(rows == self.record[scope+'_inventory'] and d.sha(d.encoded(rows)) == self.record[scope+'_inventory_sha256'], 'frozen payload changed')
        require(all(row['bytes'] < 1000000 for row in self.record['private_inventory']), 'private transport files must remain below 1 MB for connector exact readback')
        d.verify_primary_alias(self.record, self.bundle)
        self.state = d.load(self.root/'STATE.json')
        for pending_key in ('pending', 'unresolved'):
            action = self.state.get(pending_key)
            if action:
                require(str(uuid.UUID(action['id'])) == action['id'], 'invalid action ID')
                bound = dict(action); bound.pop('failed', None)
                require(bound == d.load(self.root/'actions'/action['id']/'INTENT.json'), 'pending action differs from its immutable intent')
        self.scopes = ('private', 'pointer', 'public') + (('pages',) if self.request.get('pages_url') else ()) + ('evidence',)

    def save(self):
        write(self.root/'STATE.json', self.state)

    def phase(self, scope):
        return self.state['phases'].setdefault(scope, {})

    def destination(self, scope):
        return self.record['request']['profile']['public' if scope in ('public', 'pages') else 'private']

    def rows(self, scope):
        if scope == 'pages':
            profile = self.destination('public')
            prefix = profile['prefix']+'/'+self.record['request']['release_id']+'/'
            primary = d.load(self.bundle/'public'/prefix/'HANDOFF.json')['primary']['file']
            selected = {prefix+primary, profile.get('primary_alias')}
            return [row for row in self.record['public_inventory'] if row['path'] in selected]
        if scope in ('pointer', 'evidence'): return d.inventory(self.payload(scope))
        return self.record[scope+'_inventory']

    def payload(self, scope):
        if scope == 'pointer': return self.root/'finalization/pointer-payload'
        if scope == 'evidence': return self.root/'evidence-payload'
        return self.bundle/scope

    def phase_root(self, scope):
        return self.root/scope/str(self.phase(scope).get('generation', 0))

    def plan_root(self, scope):
        return self.root/'finalization/pointer-plan' if scope == 'pointer' else self.phase_root(scope)/'plan'

    def operation(self, scope):
        return d.load(self.plan_root(scope)/'OPERATION.json')

    def api(self, scope, suffix):
        return 'https://api.github.com/repos/'+self.destination(scope)['repository']+suffix

    def issue(self, scope, step, tool, args, *, mutation=False, expected=None, payload=None):
        action = {'id': str(uuid.uuid4()), 'scope': scope, 'step': step,
                  'tool': PREFIX+tool, 'args': args, 'mutation': mutation}
        if expected is not None: action['expected'] = expected
        if payload is not None: action['payload'] = payload
        immutable(self.root/'actions'/action['id']/'INTENT.json', action)
        self.state['pending'] = action
        self.save()
        return {'status': 'action', 'action': action}

    def read(self, scope, step, suffix):
        return self.issue(scope, step, 'fetch', {'url': self.api(scope, suffix)})

    def pause(self, message, **more):
        return {'status': 'paused', 'reason': message, **more}

    def check_commit(self, scope, commit):
        operation = self.operation(scope)
        require(g.oid(commit['sha'], 'commit') != operation['baseline_commit'], 'commit equals baseline')
        require(commit['tree']['sha'] == operation['candidate_tree_sha'], 'commit tree association mismatch')
        require([p['sha'] for p in commit['parents']] == [operation['baseline_commit']], 'commit parent association mismatch')

    def validate_remote_tree(self, scope, tree):
        operation = self.operation(scope)
        g.verify(self.phase(scope)['baseline_tree'], tree, d.load(self.plan_root(scope)/'change-plan.json'),
                 baseline_tree_sha=operation['baseline_tree_sha'], candidate_tree_sha=operation['candidate_tree_sha'])
        items = {row['path']: row for row in tree['tree']}
        for row in self.rows(scope):
            item = items.get(row['path'], {})
            require(item.get('sha') == row['git_blob_sha'] and item.get('size') == row['bytes'] and item.get('mode') == row['mode'], 'immutable tree payload metadata mismatch: '+row['path'])

    def make_plan(self, scope):
        p = self.phase(scope)
        root = self.phase_root(scope)
        root.mkdir(parents=True, exist_ok=True)
        immutable(root/'baseline-tree.json', p['baseline_tree'])
        if scope == 'evidence':
            path = self.request['evidence_path']
            result = d.load(self.root/'finalization/OUTCOMES.json')
            receipt = {'schema': 'lumen.delivery-remote-outcome/v1', 'release_id': self.record['request']['release_id'],
                       'edition': self.record['edition'], 'review': self.record['request']['review'],
                       'bundle_sha256': self.request['bundle_sha256'], 'outcomes': result,
                       'public_inventory': self.record['public_inventory'], 'private_inventory': self.record['private_inventory'],
                       'pages': d.load(self.root/'pages-VERIFIED.json') if self.request.get('pages_url') else {'status': 'not-requested'}}
            immutable(self.payload(scope)/path, receipt)
            rows = self.rows(scope); before = tree_files(p['baseline_tree']); after = dict(before)
            require(path not in before, 'outcome receipt already exists; reopen the original run journal')
            new = {'mode': rows[0]['mode'], 'type': 'blob', 'sha': rows[0]['git_blob_sha']}
            after[path] = new; candidate = d.recursive_tree(after, 40)
            change_plan = {'schema_version': 1, 'baseline_tree_sha': p['baseline_tree']['sha'], 'candidate_tree_sha': candidate['sha'],
                           'changes': [{'path': path, 'before': None, 'after': new}]}
            g.verify(p['baseline_tree'], candidate, change_plan, baseline_tree_sha=p['baseline_tree']['sha'], candidate_tree_sha=candidate['sha'])
            operation = {'schema': 'lumen.delivery-operation/v1', 'destination': self.destination(scope),
                         'release_id': self.record['request']['release_id'], 'review': self.record['request']['review'],
                         'baseline_commit': p['baseline_commit']['sha'], 'baseline_tree_sha': p['baseline_tree']['sha'],
                         'candidate_tree_sha': candidate['sha'], 'payload_inventory_sha256': d.sha(d.encoded(rows))}
            for name, value in [('OPERATION.json', operation), ('change-plan.json', change_plan), ('candidate-tree.json', candidate)]:
                immutable(self.plan_root(scope)/name, value)
        elif scope != 'pointer':
            d.plan(argparse.Namespace(bundle=str(self.bundle), scope=scope, baseline=str(root/'baseline-tree.json'),
                   baseline_tree_sha=p['baseline_commit']['tree']['sha'], baseline_commit=p['baseline_commit']['sha'], output=str(self.plan_root(scope))))
        op = self.operation(scope)
        require(op['baseline_commit'] == p['baseline_commit']['sha'] and op['baseline_tree_sha'] == p['baseline_tree']['sha'], 'pointer baseline moved; stop for reviewed reconciliation')
        changes = d.load(self.plan_root(scope)/'change-plan.json')['changes']
        # A fresh journal must never create a second/no-op publication for an
        # immutable ID already present. Existing journals reuse their evidence.
        prefix = self.destination(scope)['prefix']+'/'+self.record['request']['release_id']+'/'
        before = tree_files(p['baseline_tree'])
        if scope in ('private', 'public') and any(path.startswith(prefix) for path in before):
            p['blocked'] = 'stable release ID already exists; retain/reopen its original run journal or import reviewed original evidence'
        require(changes or p.get('blocked'), 'empty candidate must not create a commit')
        p['planned'] = True
        self.save()

    def finish_phase(self, scope):
        p = self.phase(scope)
        observation = {key: p[key] for key in ('repository', 'baseline_commit', 'baseline_tree', 'commit', 'ref', 'tree')}
        root = self.phase_root(scope)
        immutable(root/'OBSERVATION.json', observation)
        verified = d.verify_observation(observation, self.operation(scope), d.load(self.plan_root(scope)/'change-plan.json'),
                             self.rows(scope), root/'returned', private=scope != 'public')
        if scope == 'evidence': d.verified_evidence(self.root/'evidence-VERIFIED.json', verified)
        p['verified'] = True
        self.save()
        if scope != 'evidence': self.finalize()

    def finalize(self):
        private = self.phase('private')
        if not private.get('verified'): return
        args = dict(bundle=str(self.bundle), private_plan=str(self.plan_root('private')),
                    private_observation=str(self.phase_root('private')/'OBSERVATION.json'),
                    private_returned=str(self.phase_root('private')/'returned'), project_id=self.request['project_id'],
                    pointer_path=self.request['pointer_path'], output=str(self.root/'finalization'))
        for scope in ('public', 'pointer'):
            args[scope+'_observation'] = str(self.phase_root(scope)/'OBSERVATION.json') if self.phase(scope).get('verified') else None
            args[scope+'_returned'] = str(self.phase_root(scope)/'returned') if self.phase(scope).get('verified') else None
        args['public_plan'] = str(self.plan_root('public')) if self.phase('public').get('verified') else None
        result = d.finalize(argparse.Namespace(**args))
        require(not any(result[s]['status'] == 'verification-failed' for s in ('public', 'pointer')), 'finalization evidence verification failed')
        return result

    def validate_completed(self, scope):
        """Recheck saved evidence without rewriting completed receipts."""
        p = self.phase(scope)
        if scope == 'pages':
            require(d.inventory(self.root/'pages/live-returned') == self.rows(scope), 'saved live bytes changed')
            expected = {'status': 'live-bytes-verified', 'commit': self.phase('public')['commit']['sha'],
                        'base_url': self.request['pages_url'], 'workflow_id': p['workflow']['id'],
                        'workflow_url': p['workflow']['html_url'], 'files': self.rows(scope)}
            receipt = self.root/'pages-VERIFIED.json'
        else:
            observation = {key: p[key] for key in ('repository', 'baseline_commit', 'baseline_tree', 'commit', 'ref', 'tree')}
            require(d.regular(self.phase_root(scope)/'OBSERVATION.json') == d.encoded(observation), 'saved observation differs from phase evidence')
            expected = d.verify_observation(observation, self.operation(scope), d.load(self.plan_root(scope)/'change-plan.json'),
                                            self.rows(scope), self.phase_root(scope)/'returned', private=scope != 'public')
            if scope == 'private':
                expected.update(checkpoint_sha256=self.record['request']['checkpoint_sha256'],
                                content_identity_sha256=self.record['private_content_identity_sha256'], edition=self.record['edition'])
            receipt = self.root/'evidence-VERIFIED.json' if scope == 'evidence' else self.root/'finalization'/(scope+'-VERIFIED.json')
        require(receipt.exists(), 'missing completed verification receipt')
        verified = d.verified_evidence(receipt, expected)
        if scope in ('private', 'pointer', 'public'):
            require(d.load(self.root/'finalization/OUTCOMES.json')[scope] == verified, 'saved outcome differs from verified evidence')

    def next(self, stop_after=None):
        pending = self.state.get('pending')
        if pending:
            receipt = self.root/'actions'/pending['id']/'RESPONSE.json'
            partial = self.root/'actions'/pending['id']/'response.partial'
            for candidate in (receipt, partial):
                if candidate.exists():
                    try:
                        acknowledged = json.loads(d.regular(candidate))
                    except (ValueError, OSError):
                        continue
                    if isinstance(acknowledged, dict) and not acknowledged.get('isError') and 'host_error' not in acknowledged:
                        accepted = self.accept(pending['id'], acknowledged)
                        if accepted['status'] == 'accepted': return self.next(stop_after)
                        return accepted
            # Never replay an issued mutation. A caller can re-read harmless
            # actions, or reconcile a known content address/ref before continuing.
            return self.reconcile(pending)
        if self.state.get('unresolved'):
            return self.pause('unresolved mutation requires explicit reconciliation; no new mutation will be issued')
        for scope in self.scopes:
            p = self.phase(scope)
            if scope == 'pages':
                if p.get('verified'):
                    self.validate_completed(scope)
                    continue
                result = self.pages_next()
                if result is not None: return result
                continue
            if p.get('verified'):
                # A crash can occur after phase verification but before its
                # finalizer. Repair only a missing phase, never rewrite a
                # completed finalization on ordinary replay.
                outcome_path = self.root/'finalization/OUTCOMES.json'
                outcomes = d.load(outcome_path) if outcome_path.exists() else {}
                if scope != 'evidence' and outcomes.get(scope, {}).get('status') != 'returned-bytes-verified':
                    self.finalize()
                self.validate_completed(scope)
                if stop_after == scope: return {'status': 'boundary', 'scope': scope, 'outcomes': self.summary()}
                continue
            if p.get('blocked'): return self.pause(p['blocked'], scope=scope)
            if 'repository' not in p: return self.read(scope, 'repository', '')
            if scope == 'pointer' and 'baseline_commit' not in p:
                prior = self.phase('private')
                p['baseline_commit'] = prior['commit']; p['baseline_tree'] = prior['tree']
                self.save()
            if 'baseline_ref' not in p: return self.read(scope, 'baseline_ref', '/git/ref/heads/'+self.destination(scope)['branch'])
            if 'baseline_commit' not in p: return self.read(scope, 'baseline_commit', '/git/commits/'+p['baseline_ref']['object']['sha'])
            if 'baseline_tree' not in p: return self.read(scope, 'baseline_tree', '/git/trees/'+p['baseline_commit']['tree']['sha']+'?recursive=1')
            if not p.get('planned'):
                self.make_plan(scope)
                if p.get('blocked'): return self.pause(p['blocked'], scope=scope)
            op = self.operation(scope)
            changes = d.load(self.plan_root(scope)/'change-plan.json')['changes']
            uploaded = p.setdefault('blobs', [])
            for change in changes:
                oid = change['after']['sha']
                if oid in uploaded: continue
                # Whole-tree membership proves identical blobs already exist;
                # aliases and repeated payload identities upload exactly once.
                if any(row['sha'] == oid for row in p['baseline_tree']['tree'] if row['type'] == 'blob'):
                    uploaded.append(oid); self.save(); continue
                row = next(row for row in self.rows(scope) if row['path'] == change['path'])
                return self.issue(scope, 'blob', 'create_blob', {'repository_full_name': self.destination(scope)['repository'], 'encoding': 'base64'},
                                  mutation=True, expected=oid, payload={'path': row['path'], 'bytes': row['bytes']})
            if 'created_tree' not in p:
                entries = [dict(path=c['path'], **c['after']) for c in changes]
                return self.issue(scope, 'created_tree', 'create_tree', {'repository_full_name': self.destination(scope)['repository'],
                                  'base_tree_sha': op['baseline_tree_sha'], 'tree_elements': entries}, mutation=True, expected=op['candidate_tree_sha'])
            if 'candidate_checked' not in p: return self.read(scope, 'candidate_checked', '/git/trees/'+op['candidate_tree_sha']+'?recursive=1')
            if 'created_commit' not in p:
                return self.issue(scope, 'created_commit', 'create_commit', {'repository_full_name': self.destination(scope)['repository'],
                                  'tree_sha': op['candidate_tree_sha'], 'parent_sha': op['baseline_commit'],
                                  'message': 'Lumen delivery '+self.record['request']['release_id']+' ['+scope+']\n\nInventory-SHA256: '+op['payload_inventory_sha256']}, mutation=True)
            if 'commit' not in p: return self.read(scope, 'commit', '/git/commits/'+p['created_commit'])
            if 'pre_ref' not in p: return self.read(scope, 'pre_ref', '/git/ref/heads/'+self.destination(scope)['branch'])
            if 'update_ack' not in p:
                return self.issue(scope, 'update_ack', 'update_ref', {'repository_full_name': self.destination(scope)['repository'],
                                  'branch_name': self.destination(scope)['branch'], 'sha': p['commit']['sha'], 'force': False}, mutation=True, expected=p['commit']['sha'])
            if 'ref' not in p: return self.read(scope, 'ref', '/git/ref/heads/'+self.destination(scope)['branch'])
            if 'tree' not in p: return self.read(scope, 'tree', '/git/trees/'+p['commit']['tree']['sha']+'?recursive=1')
            for row in self.rows(scope):
                target = self.phase_root(scope)/'returned'/row['path']
                if target.exists():
                    require(d.record(row['path'], d.regular(target), row['mode']) == row and (target.stat().st_mode & 0o777) == int(row['mode'][-3:], 8), 'returned evidence changed')
                    continue
                if scope == 'public' and row['bytes'] >= 1000000:
                    return self.issue(scope, 'returned', 'PUBLIC_RAW', {}, expected=row, payload={'path': row['path']})
                return self.issue(scope, 'returned', 'fetch_file', {'repository_full_name': self.destination(scope)['repository'],
                                  'path': row['path'], 'ref': p['commit']['sha'], 'encoding': 'base64'}, expected=row)
            self.finish_phase(scope)
            if stop_after == scope: return {'status': 'boundary', 'scope': scope, 'outcomes': self.summary()}
        return {'status': 'complete', 'outcomes': self.summary()}

    def summary(self):
        return {scope: {'status': ('live-bytes-verified' if scope == 'pages' else 'returned-bytes-verified') if self.phase(scope).get('verified') else 'pending',
                        'commit': self.phase(scope).get('commit', {}).get('sha')} for scope in self.scopes}

    def reconcile(self, action):
        if not action['mutation']:
            if action.get('failed'): return self.pause('read failed; explicit retry-read is required after resolving the reported blocker', action_id=action['id'])
            return {'status': 'action', 'action': action}
        if action.get('reconciling'): return self.pause('mutation acknowledgement remains unresolved; do not repeat it', action_id=action['id'])
        step = action['step']; scope = action['scope']
        if step == 'created_commit':
            return self.pause('commit acknowledgement lost/failed; supply its exact SHA using adopt-commit. Never create a replacement commit speculatively.', action_id=action['id'])
        if action.get('failed'):
            return self.pause('mutation failed or needs approval; resolve the blocker before reconcile. No automatic mutation retry.', action_id=action['id'])
        # Interrupted/lost result with a known immutable identity or desired ref:
        # perform one read, retaining the original unresolved mutation intent.
        self.state['unresolved'] = action
        self.state['pending'] = None
        if step == 'blob': return self.read(scope, 'reconcile_blob', '/git/blobs/'+action['expected'])
        if step == 'created_tree': return self.read(scope, 'reconcile_tree', '/git/trees/'+action['expected']+'?recursive=1')
        if step == 'update_ack': return self.read(scope, 'reconcile_ref', '/git/ref/heads/'+self.destination(scope)['branch'])
        raise d.DeliveryError('unsupported mutation reconciliation')

    def accept(self, action_id, result):
        action = self.state.get('pending')
        require(action and action['id'] == action_id, 'stale or duplicate action acknowledgement')
        immutable(self.root/'actions'/action_id/'RESPONSE.json', result)
        if result.get('isError') or 'host_error' in result:
            action['failed'] = True
            self.save()
            return self.pause('connector/host action failed; response retained, no automatic retry', action_id=action_id)
        scope = action['scope']; step = action['step']; p = self.phase(scope)
        value = unwrap(result, file=step == 'returned' and action['tool'].endswith('fetch_file'))
        if step == 'pages_workflow':
            selected = [run for run in value['workflow_runs'] if run.get('head_sha') == self.phase('public')['commit']['sha']
                        and run.get('head_branch') == self.destination('public')['branch']
                        and run.get('path') == 'dynamic/pages/pages-build-deployment']
            latest = max(selected, key=lambda run: (run.get('run_number', 0), run.get('run_attempt', 0), run.get('id', 0))) if selected else None
            if latest and latest.get('status') == 'completed' and latest.get('conclusion') == 'success':
                p['workflow'] = latest
            else:
                p['report'] = {'status': 'pending' if not latest or latest.get('status') != 'completed' else 'deployment-failed',
                               'reason': 'Matching Pages workflow has not succeeded; Git/private results are retained.',
                               'workflow': latest, 'outcomes': self.summary()}
        elif step == 'pages_returned':
            if not value.get('matches'):
                p['report'] = {'status': 'pending', 'reason': 'Live Pages bytes do not yet match the frozen primary; re-invoke to check again.', 'outcomes': self.summary()}
            else:
                row = action['expected']; data = d.regular(self.root/'actions'/action_id/'RAW')
                require(d.record(row['path'], data, row['mode']) == row, 'live bytes mismatch')
                target = self.root/'pages/live-returned'/row['path']; target.parent.mkdir(parents=True, exist_ok=True)
                d.evidence_file(target, data); target.chmod(int(row['mode'][-3:], 8))
        elif step.startswith('reconcile_'):
            original = self.state['unresolved']
            if step == 'reconcile_ref':
                require(value['object']['sha'] == original['expected'], 'ref outcome unresolved or branch moved; stop for reconciliation')
                p['update_ack'] = original['expected']; p['ref'] = value
            elif step == 'reconcile_blob':
                require(value['sha'] == original['expected'], 'reconciled blob hash mismatch')
                require(value.get('encoding') == 'base64', 'blob reconciliation requires exact returned content')
                data = base64.b64decode(''.join(value['content'].split()), validate=True)
                require(d.blob(data) == original['expected'], 'reconciled blob bytes mismatch')
                p.setdefault('blobs', []).append(original['expected'])
            else:
                self.validate_remote_tree(scope, value)
                p['created_tree'] = original['expected']
            self.state.pop('unresolved', None)
        elif step == 'repository':
            require(value['full_name'] == self.destination(scope)['repository'] and value['private'] is (scope != 'public'), 'repository identity/visibility differs from explicit profile')
            p[step] = value
        elif step == 'baseline_ref':
            require(value['ref'] == 'refs/heads/'+self.destination(scope)['branch'] and value['object']['type'] == 'commit', 'wrong branch ref')
            if scope == 'pointer': require(value['object']['sha'] == p['baseline_commit']['sha'], 'private branch moved before pointer; reviewed replan needed')
            p[step] = value
        elif step == 'baseline_commit':
            require(value['sha'] == p['baseline_ref']['object']['sha'], 'baseline commit/ref mismatch'); p[step] = value
        elif step == 'baseline_tree':
            require(value['sha'] == p['baseline_commit']['tree']['sha'], 'baseline tree/commit mismatch'); tree_files(value); p[step] = value
        elif step == 'blob':
            require(value['sha'] == action['expected'], 'uploaded blob hash mismatch'); p.setdefault('blobs', []).append(value['sha'])
        elif step == 'created_tree':
            require(value['sha'] == action['expected'], 'created tree hash mismatch'); p[step] = value['sha']
        elif step in ('candidate_checked', 'tree'):
            self.validate_remote_tree(scope, value); p[step] = value
        elif step == 'created_commit':
            # The real connector returns only SHA here. Association is checked
            # by the mandatory authenticated immutable commit read next.
            p[step] = g.oid(value['sha'], 'created commit')
        elif step == 'commit':
            self.check_commit(scope, value); require(value['sha'] == p['created_commit'], 'immutable commit differs from acknowledged SHA'); p[step] = value
        elif step == 'pre_ref':
            require(value['ref'] == 'refs/heads/'+self.destination(scope)['branch'], 'wrong pre-update branch')
            if value['object']['sha'] != self.operation(scope)['baseline_commit']:
                p['blocked'] = 'concurrent branch advance; stop and explicitly replan the unchanged frozen bundle'
            p[step] = value
        elif step == 'update_ack':
            require(value.get('success') is True or value.get('object', {}).get('sha') == action['expected'], 'ref update was not acknowledged')
            # This acknowledges dispatch only; the mandatory ref read below is
            # the actual branch association evidence.
            p[step] = action['expected']
        elif step == 'ref':
            require(value['ref'] == 'refs/heads/'+self.destination(scope)['branch'] and value['object']['type'] == 'commit' and value['object']['sha'] == p['commit']['sha'], 'post-update branch moved or unknown; reconcile before claiming success'); p[step] = value
        elif step == 'returned':
            if action['tool'].endswith('PUBLIC_RAW'):
                data = d.regular(self.root/'actions'/action_id/'RAW')
            else:
                require(value.get('sha') == action['expected']['git_blob_sha'], 'returned file Git identity mismatch')
                data = base64.b64decode(''.join(value['content'].split()), validate=True)
            row = action['expected']
            require(d.record(row['path'], data, row['mode']) == row, 'returned immutable bytes/hash/length mismatch')
            target = self.phase_root(scope)/'returned'/row['path']
            target.parent.mkdir(parents=True, exist_ok=True)
            d.evidence_file(target, data); target.chmod(int(row['mode'][-3:], 8))
        elif step == 'adopt_commit':
            self.check_commit(scope, value)
            original = self.state.pop('unresolved')
            require(value['message'].strip() == original['args']['message'].strip(), 'adopted commit has different stable release message')
            p['created_commit'] = value['sha']; p['commit'] = value
        else: raise d.DeliveryError('unsupported response step')
        self.state['pending'] = None
        self.save()
        return {'status': 'accepted', 'action_id': action_id}

    def pages_next(self):
        p = self.phase('pages')
        if p.get('report'):
            report = p.pop('report'); self.save(); return report
        if 'workflow' not in p:
            return self.read('pages', 'pages_workflow', '/actions/runs?head_sha='+self.phase('public')['commit']['sha']+'&per_page=100')
        for row in self.rows('pages'):
            target = self.root/'pages/live-returned'/row['path']
            if target.exists():
                require(d.record(row['path'], d.regular(target), row['mode']) == row, 'live byte evidence changed')
                continue
            return self.issue('pages', 'pages_returned', 'PAGES_LIVE', {}, expected=row)
        result = {'status': 'live-bytes-verified', 'commit': self.phase('public')['commit']['sha'],
                  'base_url': self.request['pages_url'], 'workflow_id': p['workflow']['id'],
                  'workflow_url': p['workflow']['html_url'], 'files': self.rows('pages')}
        d.verified_evidence(self.root/'pages-VERIFIED.json', result)
        p['verified'] = True; p['commit'] = self.phase('public')['commit']; self.save()
        return None

    def live_download(self, action_id):
        action = self.state.get('pending')
        require(action and action['id'] == action_id and action['step'] == 'pages_returned', 'not a selected live Pages download')
        self.validate_remote_tree('public', self.phase('public')['tree'])
        row = action['expected']
        from urllib.parse import quote
        url = self.request['pages_url']+'/'+quote(row['path'], safe='/')
        data = self.download_exact_limit(url, row['bytes'])
        matches = d.record(row['path'], data, row['mode']) == row
        if matches: d.evidence_file(self.root/'actions'/action_id/'RAW', data)
        return {'structuredContent': {'matches': matches, 'bytes': len(data), 'sha256': d.sha(data)}}

    @staticmethod
    def download_exact_limit(url, size):
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *args, **kwargs): raise d.DeliveryError('public download redirect refused')
        with urllib.request.build_opener(NoRedirect).open(url, timeout=60) as response:
            return response.read(size+1)

    def raw_download(self, action_id):
        action = self.state.get('pending')
        require(action and action['id'] == action_id and action['tool'] == PREFIX+'PUBLIC_RAW' and action['scope'] == 'public', 'not a selected public download')
        p = self.phase('public'); self.validate_remote_tree('public', p['tree'])
        path = action['expected']['path']; g.path_name(path)
        from urllib.parse import quote
        url = 'https://raw.githubusercontent.com/'+self.destination('public')['repository']+'/'+p['commit']['sha']+'/'+quote(path, safe='/')
        data = self.download_exact_limit(url, action['expected']['bytes'])
        require(d.record(path, data, action['expected']['mode']) == action['expected'], 'public immutable download hash mismatch')
        target = self.root/'actions'/action_id/'RAW'
        d.evidence_file(target, data)
        return {'structuredContent': {'downloaded': True, 'sha256': d.sha(data)}}


def init_run(root, bundle, project_id, pointer_path, pages_url=None):
    root = d.local_path(root); bundle = d.local_path(bundle)
    d.no_symlink_path(root); d.no_symlink_path(bundle)
    require(not root.is_relative_to(bundle) and not bundle.is_relative_to(root), 'run and frozen bundle must be disjoint')
    require(project_id.strip(), 'project ID required'); g.path_name(pointer_path)
    if pages_url is not None:
        from urllib.parse import urlsplit
        parsed = urlsplit(pages_url)
        owner = d.load(bundle/'DELIVERY.json')['request']['profile']['public']['repository'].split('/')[0].lower()
        require(parsed.scheme == 'https' and parsed.netloc == owner+'.github.io' and parsed.path in ('', '/') and not parsed.query and not parsed.fragment, 'Pages URL must be the explicitly selected repository owner HTTPS github.io origin')
        pages_url = pages_url.rstrip('/')
    root.mkdir(parents=True, exist_ok=True)
    request = {'schema': 'lumen.github-delivery-run/v1', 'bundle': str(bundle), 'bundle_sha256': d.sha(d.regular(bundle/'DELIVERY.json')),
               'project_id': project_id, 'pointer_path': pointer_path, 'pages_url': pages_url,
               'evidence_path': d.load(bundle/'DELIVERY.json')['request']['profile']['private']['prefix']+'/'+d.load(bundle/'DELIVERY.json')['request']['release_id']+'/DELIVERY-OUTCOME.json'}
    immutable(root/'REQUEST.json', request)
    if not (root/'STATE.json').exists(): write(root/'STATE.json', {'phases': {}, 'pending': None})
    return {'status': 'initialized', 'run': str(root)}


def rpc(root, request):
    command = request['command']
    if command == 'init': return init_run(root, request['bundle'], request['project_id'], request.get('pointer_path', 'recovery/field-notes-current.json'), request.get('pages_url'))
    runner = Runner(root)
    if command == 'begin':
        # A preflight observed in an older pump invocation is not fresh enough
        # to dispatch a new ref write. Preserve every original action receipt;
        # never touch an already-issued uncertain mutation.
        pending = runner.state.get('pending')
        changed = False
        if pending and pending['step'] == 'pre_ref' and not pending['mutation'] and not pending.get('failed'):
            runner.state['pending'] = None; changed = True
            pending = None
        if pending is None:
            for phase in runner.state['phases'].values():
                if not phase.get('update_ack') and 'pre_ref' in phase:
                    phase.pop('pre_ref'); changed = True
        if changed: runner.save()
        return {'status': 'ready'}
    if command == 'next': return runner.next(request.get('stop_after'))
    if command == 'status': return {'status': 'status', 'outcomes': runner.summary(), 'pending': runner.state.get('pending')}
    if command == 'chunk':
        action = runner.state.get('pending'); require(action and action['id'] == request['action_id'] and action['step'] == 'blob', 'no pending blob upload')
        data = d.regular(runner.payload(action['scope'])/action['payload']['path'])
        require(d.blob(data) == action['expected'], 'upload payload changed')
        content = base64.b64encode(data).decode()
        offset = request['offset']; require(type(offset) is int and offset >= 0, 'invalid chunk offset')
        return {'content': content[offset:offset+16384], 'total': len(content)}
    if command == 'response-chunk':
        action = runner.state.get('pending'); require(action and action['id'] == request['action_id'], 'no matching pending response')
        path = runner.root/'actions'/action['id']/'response.partial'
        d.no_symlink_path(path)
        data = request['data'].encode(); offset = request['offset']
        previous = d.regular(path) if path.exists() else b''
        require(type(offset) is int and offset >= 0 and offset <= len(previous), 'invalid response chunk offset')
        if offset < len(previous): require(previous[offset:offset+len(data)] == data, 'divergent response chunk replay')
        else: d.atomic_save(path, previous+data)
        return {'status': 'chunk-accepted', 'offset': offset+len(data)}
    if command == 'accept':
        response = request.get('result')
        if response is None:
            response = json.loads(d.regular(runner.root/'actions'/request['action_id']/'response.partial'))
        return runner.accept(request['action_id'], response)
    if command == 'raw-download': return runner.raw_download(request['action_id'])
    if command == 'live-download': return runner.live_download(request['action_id'])
    if command == 'retry-read':
        action = runner.state.get('pending'); require(action and not action['mutation'], 'only a harmless read can be retried here')
        runner.state['pending'] = None
        # Reissue the same read atomically, retaining any unresolved mutation.
        runner.issue(action['scope'], action['step'], action['tool'][len(PREFIX):], action['args'], expected=action.get('expected'), payload=action.get('payload'))
        return {'status': 'read-retry-enabled'}
    if command == 'reconcile':
        action = runner.state.get('pending'); require(action and action['mutation'], 'no pending mutation')
        action.pop('failed', None); runner.save(); return runner.reconcile(action)
    if command == 'adopt-commit':
        action = runner.state.get('pending')
        if action and action['step'] == 'adopt_commit': action = runner.state.get('unresolved')
        require(action and action['step'] == 'created_commit', 'no unacknowledged commit creation')
        sha = g.oid(request['sha'], 'adopted commit')
        runner.state['unresolved'] = action; runner.state['pending'] = None
        return runner.read(action['scope'], 'adopt_commit', '/git/commits/'+sha)
    if command == 'retry-confirmed-unexecuted':
        action = runner.state.get('unresolved') or runner.state.get('pending')
        require(action and action['mutation'] and action['id'] == request['action_id'], 'exact unresolved mutation ID required')
        require(request.get('confirmed_not_applied') is True and isinstance(request.get('resolution_reference'), str) and request['resolution_reference'].strip(), 'explicit operator resolution of nonexecution is required; timeout/unknown outcome is insufficient')
        immutable(runner.root/'actions'/action['id']/'OPERATOR-RESOLUTION.json', {'status': 'operator-confirmed-unexecuted', 'reference': request['resolution_reference'], 'not_network_proof': True})
        runner.state.pop('unresolved', None)
        runner.state['pending'] = None
        if action['step'] == 'update_ack': runner.phase(action['scope']).pop('pre_ref', None)
        runner.save()
        return {'status': 'retry-enabled', 'scope': action['scope'], 'step': action['step']}
    if command == 'replan':
        scope = request['scope']; require(scope in ('private','public','evidence'), 'pointer requires separate reviewed reconciliation')
        phase = runner.phase(scope)
        require(phase.get('blocked', '').startswith('concurrent branch advance') and not phase.get('update_ack') and not runner.state.get('pending'), 'only a confirmed pre-ref concurrency conflict may replan')
        generation = phase.get('generation', 0)+1
        immutable(runner.root/scope/str(generation-1)/'ABANDONED.json', phase)
        runner.state['phases'][scope] = {'generation': generation}
        runner.save(); return {'status': 'replan-enabled', 'scope': scope, 'generation': generation}
    raise d.DeliveryError('unknown runner command')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['rpc'])
    parser.add_argument('--run', required=True)
    args = parser.parse_args()
    root = d.local_path(args.run)
    root.mkdir(parents=True, exist_ok=True)
    lock = root/'LOCK'; d.no_symlink_path(lock)
    with lock.open('a') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        try:
            result = rpc(root, json.load(sys.stdin))
        except Exception as exc:
            result = {'status': 'blocked', 'error': str(exc), 'error_type': type(exc).__name__}
        print(json.dumps(result, ensure_ascii=False))
    return 1 if result.get('status') == 'blocked' else 0


if __name__ == '__main__':
    raise SystemExit(main())
