#!/usr/bin/env python3
"""Review and import missing notes from a separately verified legacy public index.

Offline only. A supplied commit is provenance metadata, not authenticated here.
Existing notes are never replaced. Default is read-only planning.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import html
from html.parser import HTMLParser
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
class Text(HTMLParser):
    def __init__(self):super().__init__();self.parts=[]
    def handle_data(self, value):self.parts.append(value)
def text(value):
    p=Text();p.feed(value);return ' '.join(' '.join(p.parts).split())
def prepare(source: Path, expected: str, commit: str):
    raw=source.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=expected:raise ValueError('Source SHA-256 mismatch')
    if not re.fullmatch('[0-9a-f]{40}|[0-9a-f]{64}',commit):raise ValueError('Full source commit required')
    existing={}
    for p in (ROOT/'content/pages/notes').glob('*.json'):
        d=json.loads(p.read_text());old=d.get('source',{}).get('path','')
        if old.startswith('index.html#'):existing[old.split('#',1)[1]]=d['url']
    articles=re.findall(r'<article\b([^>]*)>(.*?)</article>',raw.decode('utf-8'),re.S)
    plan=[];seen=set()
    for attrs,article in articles:
        match=re.search(r'\bid="([^"]+)"',attrs)
        if not match:continue
        anchor=match.group(1)
        if anchor in seen:raise ValueError('Duplicate source article ID')
        seen.add(anchor)
        if anchor in existing:continue
        if not re.fullmatch('[a-z0-9-]+',anchor):raise ValueError('Unsupported source article ID')
        date=re.search(r'data-publication-date="(\d{4}-\d{2}-\d{2})"',attrs)
        category=re.search(r'data-post-category="([a-z-]+)"',attrs)
        title=re.search(r'<h2>(.*?)</h2>',article,re.S)
        byline=re.search(r'<p class="byline">(.*?)</p>',article,re.S)
        number=re.search(r'Note (\d+) ',article)
        if not all([date,category,title,byline,number]):raise ValueError('Unrecognized source article framing')
        day=date.group(1);dt.date.fromisoformat(day)
        if day>dt.datetime.now(dt.timezone.utc).date().isoformat():raise ValueError('Future publication date refused')
        kind=category.group(1)
        if kind not in {'world','collaboration','deep-philosophy'}:raise ValueError('Unknown post category')
        body=article[byline.end():].strip()+'\n'
        original_text=text(body)
        for old,url in existing.items():body=body.replace('href="#'+old+'"','href="'+url+'"')
        if text(body)!=original_text:raise ValueError('Import changed prose')
        page_id='note-'+anchor
        metadata={'id':page_id,'url':'/notes/'+anchor+'/','kind':'note','status':'published','label':'Field note · '+kind,'number':number.group(1),'title':text(title.group(1)),'description':text(re.search(r'<p\b[^>]*>(.*?)</p>',body,re.S).group(1))[:190],'author':'Lumen','byline':text(byline.group(1)),'date':day,'body':anchor+'.html','tags':[kind],'related':[],'source':{'repository':'Sapient-Lumen/sapient-lumen.github.io','path':'index.html#'+anchor,'commit':commit,'source_file_sha256':expected,'url':'https://github.com/Sapient-Lumen/sapient-lumen.github.io/blob/'+commit+'/index.html','status':'Imported from previously published and separately verified public source; prose unchanged'},'limits':['Source hashes identify reviewed bytes, not the truth of the essay.']}
        plan.append({'anchor':anchor,'metadata':metadata,'body':body,'prose_sha256':hashlib.sha256(original_text.encode()).hexdigest()})
    return plan

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path);p.add_argument('--sha256',required=True);p.add_argument('--commit',required=True);p.add_argument('--apply',action='store_true');a=p.parse_args();plan=prepare(a.source,a.sha256,a.commit)
    if a.apply:
        history_path=ROOT/'content/data/edition-history.json';history=json.loads(history_path.read_text());edition=json.loads((ROOT/'config.json').read_text())['edition'];destination=ROOT/'content/pages/notes'
        # Preflight every target before writing any accepted source.
        for row in plan:
            for ext in ['.html','.json']:
                if (destination/(row['anchor']+ext)).exists():raise ValueError('Existing destination refused')
            if row['metadata']['id'] in history['notes']:raise ValueError('Existing history identity refused')
        for row in plan:
            d=row['metadata'];body=row['body'].encode();(destination/(row['anchor']+'.html')).write_bytes(body);(destination/(row['anchor']+'.json')).write_text(json.dumps(d,indent=2)+'\n')
            history['notes'][d['id']]={'published_at':d['date'],'revisions':[{'edition':edition,'date':dt.datetime.now(dt.timezone.utc).date().isoformat(),'summary':'Imported previously published essay; prose unchanged, legacy links resolved to existing routes','body_sha256':hashlib.sha256(body).hexdigest(),'body_bytes':len(body),'source_ref':d['source']['url']}]}
        history_path.write_text(json.dumps(history,indent=2)+'\n')
    print(json.dumps({'applied':a.apply,'source_sha256':a.sha256,'source_commit':a.commit,'imported':[{'id':r['metadata']['id'],'title':r['metadata']['title'],'prose_sha256':r['prose_sha256']} for r in plan]},indent=2))
if __name__=='__main__':main()
