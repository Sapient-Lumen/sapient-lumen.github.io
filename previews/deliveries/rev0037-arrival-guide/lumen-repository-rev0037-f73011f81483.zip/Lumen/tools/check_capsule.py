#!/usr/bin/env python3
"""Validate the browser-readable/extractable Lumen.html capsule."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import zipfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CAPSULE = ROOT / "dist" / "Lumen.html"
MANIFEST = "Lumen/CAPSULE-MANIFEST.json"
COMMENT = b"</script></body></html>\n"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def validate(path: Path) -> tuple[list[str], dict[str, Any] | None]:
    errors: list[str] = []
    if not path.is_file():
        return [f"capsule does not exist: {path}"], None
    raw = path.read_bytes()
    if not raw.startswith(b"<!doctype html>"):
        errors.append("capsule does not begin as HTML")
    if not zipfile.is_zipfile(path):
        errors.append("capsule is not recognized as ZIP")
        return errors, None
    try:
        with zipfile.ZipFile(path) as archive:
            if archive.comment != COMMENT:
                errors.append("ZIP comment does not close the browser document")
            bad = archive.testzip()
            if bad:
                errors.append(f"ZIP CRC failure: {bad}")
            names = archive.namelist()
            if MANIFEST not in names:
                errors.append(f"missing {MANIFEST}")
                return errors, None
            manifest = json.loads(archive.read(MANIFEST).decode("utf-8"))
            prefix_info = manifest.get("html_prefix", {})
            prefix_bytes = int(prefix_info.get("bytes", -1))
            if prefix_bytes <= 0 or prefix_bytes > len(raw):
                errors.append("manifest has invalid HTML prefix length")
            else:
                prefix = raw[:prefix_bytes]
                if sha256(prefix) != prefix_info.get("sha256"):
                    errors.append("HTML prefix SHA-256 disagrees with manifest")
                if not prefix.rstrip().endswith(b'<script type="application/x-lumen-archive" id="lumen-archive" aria-hidden="true">'):
                    errors.append("HTML prefix does not end at the archive data block")
            declared = {row.get("path"): row for row in manifest.get("members", [])}
            actual = set(names) - {MANIFEST, "Lumen/.capsule-padding"}
            if set(declared) != actual:
                errors.append(f"archive member set differs from manifest: missing={sorted(set(declared)-actual)}, extra={sorted(actual-set(declared))}")
            for name, row in declared.items():
                try:
                    data = archive.read(name)
                except KeyError:
                    continue
                if len(data) != row.get("bytes"):
                    errors.append(f"{name}: byte count disagrees with manifest")
                if sha256(data) != row.get("sha256"):
                    errors.append(f"{name}: SHA-256 disagrees with manifest")
            hypertext = manifest.get("hypertext", {})
            ledger_name = hypertext.get("path")
            if not ledger_name or ledger_name not in names:
                errors.append("capsule hypertext ledger is missing")
            else:
                ledger_bytes = archive.read(ledger_name)
                if sha256(ledger_bytes) != hypertext.get("sha256"):
                    errors.append("capsule hypertext ledger SHA-256 disagrees with manifest")
                try:
                    ledger = json.loads(ledger_bytes.decode("utf-8"))
                    counts = ledger.get("counts", {})
                    if counts.get("passages") != hypertext.get("passages"):
                        errors.append("capsule passage count disagrees with hypertext ledger")
                    if counts.get("typed_edges") != hypertext.get("typed_edges"):
                        errors.append("capsule typed-edge count disagrees with hypertext ledger")
                except (UnicodeDecodeError, json.JSONDecodeError):
                    errors.append("capsule hypertext ledger is not valid UTF-8 JSON")
            references = manifest.get("references", {})
            references_name = references.get("path")
            if not references_name or references_name not in names:
                errors.append("capsule reference ledger is missing")
            else:
                reference_bytes = archive.read(references_name)
                if sha256(reference_bytes) != references.get("sha256"):
                    errors.append("capsule reference ledger SHA-256 disagrees with manifest")
                try:
                    reference_ledger = json.loads(reference_bytes.decode("utf-8"))
                    counts = reference_ledger.get("counts", {})
                    for key in ("sources", "citations", "domains"):
                        if counts.get(key) != references.get(key):
                            errors.append(f"capsule {key} count disagrees with reference ledger")
                except (UnicodeDecodeError, json.JSONDecodeError):
                    errors.append("capsule reference ledger is not valid UTF-8 JSON")
            reading_paths = manifest.get("reading_paths", {})
            reading_paths_name = reading_paths.get("path")
            if not reading_paths_name or reading_paths_name not in names:
                errors.append("capsule reading-path ledger is missing")
            else:
                path_bytes = archive.read(reading_paths_name)
                if sha256(path_bytes) != reading_paths.get("sha256"):
                    errors.append("capsule reading-path ledger SHA-256 disagrees with manifest")
                try:
                    path_ledger = json.loads(path_bytes.decode("utf-8"))
                    counts = path_ledger.get("counts", {})
                    for key in ("paths", "steps", "passage_steps"):
                        if counts.get(key) != reading_paths.get(key):
                            errors.append(f"capsule {key} count disagrees with reading-path ledger")
                    if path_ledger.get("source_fingerprint_sha256") != manifest.get("source_fingerprint_sha256"):
                        errors.append("capsule reading-path source fingerprint disagrees with manifest")
                except (UnicodeDecodeError, json.JSONDecodeError):
                    errors.append("capsule reading-path ledger is not valid UTF-8 JSON")
            folios = manifest.get("portable_folios", {})
            folios_name = folios.get("path")
            if not folios_name or folios_name not in names:
                errors.append("capsule portable-folio ledger is missing")
            else:
                folio_bytes = archive.read(folios_name)
                if sha256(folio_bytes) != folios.get("sha256"):
                    errors.append("capsule portable-folio ledger SHA-256 disagrees with manifest")
                try:
                    folio_ledger = json.loads(folio_bytes.decode("utf-8"))
                    counts = folio_ledger.get("counts", {})
                    if counts.get("folios") != folios.get("folios"):
                        errors.append("capsule portable-folio count disagrees with folio ledger")
                    if counts.get("bytes") != folios.get("bytes"):
                        errors.append("capsule portable-folio byte total disagrees with folio ledger")
                    if folio_ledger.get("source_fingerprint_sha256") != manifest.get("source_fingerprint_sha256"):
                        errors.append("capsule portable-folio source fingerprint disagrees with manifest")
                    for row in folio_ledger.get("folios", []):
                        member = "Lumen/dist/" + str(row.get("file", ""))
                        if member not in names:
                            errors.append(f"capsule portable folio is missing: {member}")
                            continue
                        data = archive.read(member)
                        if len(data) != row.get("bytes") or sha256(data) != row.get("sha256"):
                            errors.append(f"capsule portable folio receipt disagrees: {member}")
                except (UnicodeDecodeError, json.JSONDecodeError):
                    errors.append("capsule portable-folio ledger is not valid UTF-8 JSON")
            path_folios = manifest.get("portable_path_folios", {})
            path_folios_name = path_folios.get("path")
            if not path_folios_name or path_folios_name not in names:
                errors.append("capsule portable reading-path folio ledger is missing")
            else:
                path_folio_bytes = archive.read(path_folios_name)
                if sha256(path_folio_bytes) != path_folios.get("sha256"):
                    errors.append("capsule portable reading-path folio ledger SHA-256 disagrees with manifest")
                try:
                    path_folio_ledger = json.loads(path_folio_bytes.decode("utf-8"))
                    counts = path_folio_ledger.get("counts", {})
                    for key in ("folios", "bytes", "steps"):
                        if counts.get(key) != path_folios.get(key):
                            errors.append(f"capsule portable reading-path {key} disagrees with ledger")
                    if path_folio_ledger.get("source_fingerprint_sha256") != manifest.get("source_fingerprint_sha256"):
                        errors.append("capsule portable reading-path source fingerprint disagrees with manifest")
                    for row in path_folio_ledger.get("folios", []):
                        member = "Lumen/dist/" + str(row.get("file", ""))
                        if member not in names:
                            errors.append(f"capsule portable reading-path folio is missing: {member}")
                            continue
                        data = archive.read(member)
                        if len(data) != row.get("bytes") or sha256(data) != row.get("sha256"):
                            errors.append(f"capsule portable reading-path folio receipt disagrees: {member}")
                except (UnicodeDecodeError, json.JSONDecodeError):
                    errors.append("capsule portable reading-path folio ledger is not valid UTF-8 JSON")
            if "Lumen/lumen" not in names:
                errors.append("cloudtainer launcher Lumen/lumen is missing")
            else:
                mode = (archive.getinfo("Lumen/lumen").external_attr >> 16) & 0o777
                if not mode & 0o111:
                    errors.append("Lumen/lumen is not executable in the archive")
            forbidden_parts = {"archive", "research", "evidence", "screenshots", ".lumen", ".git"}
            forbidden = [
                name for name in names
                if name.endswith("/Lumen.sh")
                or name.lower().endswith(".zip")
                or any(part.lower() in forbidden_parts for part in Path(name).parts)
            ]
            if forbidden:
                errors.append(f"excluded archive/private material crossed into capsule: {forbidden}")
            if raw[len(raw) - len(COMMENT):] != COMMENT:
                errors.append("capsule does not end with the HTML-closing ZIP comment")
            if raw[manifest["html_prefix"]["bytes"]:].lower().count(b"</script") != 1:
                errors.append("archive payload contains an ambiguous raw </script sequence")
            return errors, manifest
    except (OSError, zipfile.BadZipFile, UnicodeDecodeError, json.JSONDecodeError, KeyError, ValueError) as exc:
        errors.append(f"cannot validate capsule: {exc}")
        return errors, None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capsule", nargs="?", type=Path, default=DEFAULT_CAPSULE)
    args = parser.parse_args()
    errors, manifest = validate(args.capsule.resolve())
    if errors:
        print(f"Lumen capsule check failed with {len(errors)} error(s):", file=sys.stderr)
        for error in errors:
            print(f"  - {error}", file=sys.stderr)
        return 1
    with zipfile.ZipFile(args.capsule) as archive:
        print(
            f"Lumen capsule check passed: {args.capsule.stat().st_size:,} bytes, "
            f"{len(archive.namelist())} members, source {manifest['source_fingerprint_sha256'][:12]}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
