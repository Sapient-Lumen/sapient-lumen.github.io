#!/usr/bin/env python3
"""Cloudtainer command deck for the Lumen publication project.

The command intentionally uses only Python's standard library. Network access is
confined to ``sync``; every other command operates on local, reviewable files.
Canonical publication, draft preview, accepted source state, and staged upstream
state are separate directories so a fast workflow does not blur trust boundaries.
"""
from __future__ import annotations

import argparse
import base64
import datetime as dt
import hashlib
import html as html_module
import http.server
import json
import os
import re
import shlex
import shutil
import socketserver
import stat
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Iterable

sys.path.insert(0, str(Path(__file__).resolve().parent))
from public_source import publication_content_files

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"
STATE_DIR = ROOT / ".lumen"
PREVIEW_DIST = STATE_DIR / "preview-dist"
CANDIDATE = STATE_DIR / "upstream-candidate.json"
CANDIDATE_REPORT = STATE_DIR / "upstream-drift.md"
SNAPSHOT = ROOT / "content" / "data" / "source-snapshot.json"
LOOKS = ROOT / "content" / "data" / "looks.json"
EDITION_HISTORY = ROOT / "content" / "data" / "edition-history.json"
READING_PATHS = ROOT / "content" / "data" / "reading-paths.json"
CONFIG = ROOT / "config.json"
RESEARCH = ROOT / "research"
REQUIRED = [
    CONFIG,
    SNAPSHOT,
    LOOKS,
    READING_PATHS,
    ROOT / "templates" / "shell.html",
    ROOT / "assets" / "css" / "site.css",
    ROOT / "assets" / "js" / "site.js",
    ROOT / "assets" / "js" / "edition-compare.js",
    ROOT / "tools" / "build.py",
    ROOT / "tools" / "check_dist.py",
    ROOT / "tools" / "capsule.py",
    ROOT / "tools" / "check_capsule.py",
    ROOT / "assets" / "js" / "capsule.js",
    ROOT / "assets" / "css" / "capsule.css",
]
KIND_PATHS = {
    "note": ("notes", "note"),
    "project": ("projects", "project"),
    "collection": ("collections", "collection"),
}
SLUG_RE = re.compile(r"[^a-z0-9]+")
SOURCE_KEY_BY_REPOSITORY = {
    "Sapient-Lumen/sapient-lumen.github.io": "site_tree_sha",
    "Sapient-Lumen/Lumen": "lumen_tree_sha",
    "Sapient-Lumen/W4R3Z": "w4r3z_tree_sha",
    "Sapient-Lumen/Sapient-Lumen": "profile_sha",
}
TOOLKIT_ROOTS = [
    ".editorconfig", ".gitattributes", ".github", ".gitignore",
    "BUILD-RECEIPT.json", "CHANGELOG.md", "CITATION.cff", "CONTRIBUTING.md",
    "LICENSE-NOTICE.md", "Makefile", "README.md", "SECURITY.md", "START-HERE.txt",
    "assets", "config.json", "content", "dist", "docs", "lumen",
    "templates", "tests", "tools",
]

CHECKPOINT_ROOTS = [name for name in TOOLKIT_ROOTS if name not in {"dist", "BUILD-RECEIPT.json"}]
CHECKPOINT_SCHEMA = "lumen.worktree-checkpoint/v1"
CORRECTION_SCHEMA = "lumen.correction-packet/v1"
FIELDBOOK_SCHEMA = "lumen.fieldbook/v1"
RETURN_MARKER_SCHEMA = "lumen.return-marker/v1"


class LumenError(RuntimeError):
    pass


def emit(label: str, message: str) -> None:
    print(f"[{label:<7}] {message}")


def read_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        try:
            shown = path.relative_to(ROOT)
        except ValueError:
            shown = path
        raise LumenError(f"cannot read {shown}: {exc}") from exc


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def run(command: list[str], *, env: dict[str, str] | None = None, capture: bool = False) -> subprocess.CompletedProcess[str]:
    emit("run", " ".join(command))
    return subprocess.run(
        command,
        cwd=ROOT,
        env=env,
        text=True,
        capture_output=capture,
        check=True,
    )


def slugify(value: str) -> str:
    return SLUG_RE.sub("-", value.lower()).strip("-") or "untitled"


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def project_files() -> Iterable[Path]:
    roots = [
        CONFIG,
        ROOT / "content",
        ROOT / "assets",
        ROOT / "templates",
        ROOT / "tools",
        ROOT / "tests",
        ROOT / ".github",
        ROOT / "lumen",
        ROOT / "Makefile",
    ]
    for item in roots:
        if item.is_file():
            yield item
        elif item.is_dir():
            for path in sorted(item.rglob("*")):
                if path.is_file() and "__pycache__" not in path.parts and not path.name.endswith(".pyc"):
                    yield path


def source_mtime_state() -> tuple[tuple[str, int, int], ...]:
    rows = []
    for path in project_files():
        stat = path.stat()
        rows.append((path.relative_to(ROOT).as_posix(), stat.st_mtime_ns, stat.st_size))
    return tuple(rows)


def page_metadata() -> list[tuple[Path, dict[str, Any]]]:
    rows: list[tuple[Path, dict[str, Any]]] = []
    for path in sorted((ROOT / "content" / "pages").rglob("*.json")):
        rows.append((path, read_json(path)))
    return rows


def draft_metadata() -> list[tuple[Path, dict[str, Any]]]:
    return [(path, data) for path, data in page_metadata() if data.get("status", "published") == "draft"]


def edition_history() -> dict[str, Any]:
    payload = read_json(EDITION_HISTORY)
    if payload.get("schema") != "lumen.edition-history/v1" or not isinstance(payload.get("notes"), dict):
        raise LumenError("content/data/edition-history.json has an unsupported shape")
    return payload


def authored_body_identity(path: Path, data: dict[str, Any]) -> dict[str, Any]:
    body = (path.parent / str(data.get("body", ""))).resolve()
    if not body.is_file() or not body.is_relative_to(ROOT):
        raise LumenError(f"authored body is missing or outside the worktree: {body}")
    raw = body.read_bytes()
    return {"path": body, "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}


def history_rows() -> list[dict[str, Any]]:
    payload = edition_history()
    rows: list[dict[str, Any]] = []
    for path, data in page_metadata():
        if data.get("kind") != "note" or data.get("status", "published") != "published":
            continue
        record = payload["notes"].get(data.get("id"))
        revisions = record.get("revisions", []) if isinstance(record, dict) else []
        current = authored_body_identity(path, data)
        latest = revisions[-1] if revisions else {}
        rows.append({
            "id": data.get("id"),
            "title": data.get("title"),
            "path": path.relative_to(ROOT).as_posix(),
            "current_sha256": current["sha256"],
            "current_bytes": current["bytes"],
            "revision_count": len(revisions),
            "latest": latest,
            "matches": bool(revisions) and latest.get("body_sha256") == current["sha256"] and int(latest.get("body_bytes", -1)) == current["bytes"],
        })
    known = {row["id"] for row in rows}
    for page_id in sorted(set(payload["notes"]) - known):
        rows.append({"id": page_id, "title": "unknown note", "revision_count": len(payload["notes"][page_id].get("revisions", [])), "matches": False, "error": "history entry has no published note"})
    return rows


def cmd_history(args: argparse.Namespace) -> int:
    rows = history_rows()
    if args.json:
        print(json.dumps({"schema": "lumen.history-status/v1", "edition": read_json(CONFIG).get("edition"), "notes": rows}, ensure_ascii=False, indent=2))
    else:
        for row in rows:
            label = "ok" if row.get("matches") else "drift"
            latest = row.get("latest") or {}
            emit(label, f"{row.get('id')} · {row.get('revision_count', 0)} version(s) · {str(latest.get('body_sha256', 'unrecorded'))[:12]} · {row.get('title')}")
        emit("ledger", f"{len(rows)} published notes · {sum(int(row.get('revision_count', 0)) for row in rows)} recorded revisions")
    mismatches = [row for row in rows if not row.get("matches")]
    if mismatches and args.check:
        raise LumenError("edition history does not match the current published note bodies")
    return 0 if not mismatches else 1


def _edition_digest(value: Any) -> str:
    text = str(value or "").lower()
    return text if re.fullmatch(r"[0-9a-f]{64}", text) else ""


def _edition_int(value: Any) -> int | None:
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    return number if number >= 0 else None


def normalize_edition_passage(row: dict[str, Any]) -> dict[str, Any] | None:
    passage_id = str(row.get("id") or "").strip()
    if not passage_id:
        return None
    return {
        "id": passage_id,
        "anchor": str(row.get("anchor") or ""),
        "url": str(row.get("url") or ""),
        "level": _edition_int(row.get("level")),
        "title": str(row.get("title") or passage_id),
        "order": _edition_int(row.get("order")),
        "excerpt": str(row.get("excerpt") or "")[:600],
        "word_count": _edition_int(row.get("word_count")),
        "text_sha256": _edition_digest(row.get("text_sha256")),
        "source_html_sha256": _edition_digest(row.get("source_html_sha256")),
    }


def normalize_edition_summary(payload: dict[str, Any]) -> dict[str, Any]:
    if payload.get("schema") == "lumen.editions/v1":
        pages = []
        for page_id, record in payload.get("notes", {}).items():
            revisions = record.get("revisions", []) if isinstance(record, dict) else []
            latest = revisions[-1] if revisions else {}
            pages.append({
                "id": page_id,
                "url": "",
                "kind": "note",
                "title": page_id,
                "status": "published",
                "date": record.get("published_at") if isinstance(record, dict) else None,
                "body_sha256": latest.get("body_sha256"),
                "body_bytes": latest.get("body_bytes"),
                "revision_count": len(revisions),
                "latest_revision": latest or None,
                "passage_detail": False,
                "passages": [],
            })
        payload = {
            "schema": "lumen.edition-summary/v1",
            "scope": "notes-only",
            "edition": payload.get("edition", "unknown"),
            "generated_at": payload.get("generated_at"),
            "source_fingerprint_sha256": payload.get("source_fingerprint_sha256"),
            "pages": pages,
            "sources": {"active": [], "retired": []},
        }
    schema = str(payload.get("schema", ""))
    if schema not in {"lumen.edition-summary/v1", "lumen.edition-summary/v2"}:
        raise LumenError(f"unsupported edition record: {payload.get('schema', 'unknown')}")
    pages: dict[str, dict[str, Any]] = {}
    raw_pages = payload.get("pages", [])
    rows = raw_pages.values() if isinstance(raw_pages, dict) else raw_pages
    for row in rows:
        if not isinstance(row, dict) or not row.get("id"):
            continue
        item = dict(row)
        item["id"] = str(item["id"])
        item["url"] = str(item.get("url") or "")
        item["kind"] = str(item.get("kind") or "page")
        item["title"] = str(item.get("title") or item["id"])
        item["status"] = str(item.get("status") or "published")
        item["body_sha256"] = _edition_digest(item.get("body_sha256") or item.get("sha256"))
        item["body_bytes"] = _edition_int(item.get("body_bytes", item.get("bytes")))
        item["word_count"] = _edition_int(item.get("word_count"))
        passages = []
        for passage in item.get("passages", []) if isinstance(item.get("passages"), list) else []:
            if isinstance(passage, dict):
                normalized = normalize_edition_passage(passage)
                if normalized:
                    passages.append(normalized)
        passages.sort(key=lambda row: (row.get("order") if row.get("order") is not None else 10**9, row["id"]))
        item["passages"] = passages
        item["passage_detail"] = bool(item.get("passage_detail"))
        pages[item["id"]] = item
    sources = payload.get("sources", {}) if isinstance(payload.get("sources"), dict) else {}
    active_rows = sources.get("active", sources.get("repositories", []))
    retired_rows = sources.get("retired", sources.get("retired_sources", []))
    if isinstance(active_rows, dict):
        active_rows = active_rows.values()
    if isinstance(retired_rows, dict):
        retired_rows = retired_rows.values()
    active = {str(row.get("name")): dict(row) for row in active_rows if isinstance(row, dict) and row.get("name")}
    retired = {str(row.get("name")): dict(row) for row in retired_rows if isinstance(row, dict) and row.get("name")}
    return {
        "schema": "lumen.edition-summary/v2",
        "source_schema": str(payload.get("source_schema") or schema),
        "scope": str(payload.get("scope", "complete")),
        "edition": str(payload.get("edition", "unknown")),
        "generated_at": payload.get("generated_at"),
        "source_fingerprint_sha256": _edition_digest(payload.get("source_fingerprint_sha256")),
        "pages": pages,
        "sources": {"active": active, "retired": retired},
    }


def edition_passages_from_context(context: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for passage in context.get("passages", []) if isinstance(context, dict) else []:
        if not isinstance(passage, dict):
            continue
        normalized = normalize_edition_passage(passage)
        if normalized:
            rows.append(normalized)
    rows.sort(key=lambda row: (row.get("order") if row.get("order") is not None else 10**9, row["id"]))
    return rows


def augment_edition_summary_with_contexts(summary: dict[str, Any], contexts: dict[str, dict[str, Any]]) -> dict[str, Any]:
    summary = normalize_edition_summary(summary)
    for page_id, context in contexts.items():
        page = summary["pages"].get(page_id)
        if page is None:
            continue
        page["passages"] = edition_passages_from_context(context)
        page["passage_detail"] = True
    return summary


def archive_edition_contexts(archive: zipfile.ZipFile) -> dict[str, dict[str, Any]]:
    contexts: dict[str, dict[str, Any]] = {}
    prefix = "Lumen/dist/meta/context/"
    for name in archive.namelist():
        if not name.startswith(prefix) or not name.endswith(".json"):
            continue
        try:
            record = json.loads(archive.read(name).decode("utf-8"))
        except (KeyError, UnicodeDecodeError, json.JSONDecodeError):
            continue
        page_id = str(record.get("page", {}).get("id") or Path(name).stem)
        if page_id:
            contexts[page_id] = record
    return contexts


def edition_summary_from_legacy_capsule(archive: zipfile.ZipFile) -> dict[str, Any]:
    names = set(archive.namelist())
    page_names = sorted(name for name in names if name.startswith("Lumen/dist/meta/pages/") and name.endswith(".json"))
    if not page_names:
        raise LumenError("capsule does not contain comparable page records")
    contexts = archive_edition_contexts(archive)
    pages = []
    source_fingerprint = ""
    generated_at = ""
    for name in page_names:
        record = json.loads(archive.read(name).decode("utf-8"))
        page = record.get("page", {})
        build = record.get("build", {})
        history = page.get("publication_history", []) if isinstance(page.get("publication_history"), list) else []
        page_id = str(page.get("id") or "")
        pages.append({
            "id": page_id,
            "url": page.get("url"),
            "kind": page.get("kind"),
            "title": page.get("title"),
            "status": page.get("status", "published"),
            "date": page.get("date"),
            "body_sha256": page.get("source_body", {}).get("sha256"),
            "body_bytes": page.get("source_body", {}).get("bytes"),
            "revision_count": len(history) or None,
            "latest_revision": history[-1] if history else None,
            "passage_detail": page_id in contexts,
            "passages": edition_passages_from_context(contexts.get(page_id, {})),
        })
        source_fingerprint = source_fingerprint or str(build.get("source_fingerprint", ""))
        generated_at = generated_at or str(build.get("generated_at", ""))
    snapshot = {}
    snapshot_name = "Lumen/dist/meta/source-snapshot.json"
    if snapshot_name in names:
        snapshot = json.loads(archive.read(snapshot_name).decode("utf-8"))
    edition = "unknown"
    config_name = "Lumen/config.json"
    if config_name in names:
        edition = str(json.loads(archive.read(config_name).decode("utf-8")).get("edition", "unknown"))
    return normalize_edition_summary({
        "schema": "lumen.edition-summary/v2",
        "scope": "legacy-capsule",
        "edition": edition,
        "generated_at": generated_at,
        "source_fingerprint_sha256": source_fingerprint,
        "pages": pages,
        "sources": {"active": snapshot.get("repositories", []), "retired": snapshot.get("retired_sources", [])},
    })


def load_edition_summary(path: Path) -> dict[str, Any]:
    path = path.expanduser().resolve()
    if not path.is_file():
        raise LumenError(f"edition file does not exist: {path}")
    if path.stat().st_size > 32 * 1024 * 1024:
        raise LumenError("edition comparison input exceeds the 32 MiB local limit")
    if path.suffix.lower() == ".json":
        return normalize_edition_summary(read_json(path))
    try:
        with zipfile.ZipFile(path) as archive:
            name = "Lumen/dist/meta/edition-summary.json"
            if name in archive.namelist():
                summary = normalize_edition_summary(json.loads(archive.read(name).decode("utf-8")))
                contexts = archive_edition_contexts(archive)
                if contexts:
                    summary = augment_edition_summary_with_contexts(summary, contexts)
                return summary
            return edition_summary_from_legacy_capsule(archive)
    except zipfile.BadZipFile:
        text = path.read_text(encoding="utf-8", errors="replace")
        begin = text.find("LUMEN_EDITION_SUMMARY_BEGIN")
        end = text.find("LUMEN_EDITION_SUMMARY_END", begin + 1)
        if begin < 0 or end < 0:
            raise LumenError("file is not a recognized Lumen capsule or edition-summary JSON record")
        encoded = re.sub(r"[^A-Za-z0-9+/=]", "", text[begin + len("LUMEN_EDITION_SUMMARY_BEGIN"):end])
        try:
            payload = json.loads(base64.b64decode(encoded).decode("utf-8"))
        except (ValueError, json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise LumenError(f"cannot decode embedded edition summary: {exc}") from exc
        return normalize_edition_summary(payload)


def edition_revision_number(value: str) -> int | None:
    match = re.fullmatch(r"rev(\d+)", value.strip(), re.I)
    return int(match.group(1)) if match else None


def compare_edition_passages(current_page: dict[str, Any], other_page: dict[str, Any]) -> dict[str, Any]:
    available = bool(current_page.get("passage_detail") and other_page.get("passage_detail"))
    empty = {
        "available": available,
        "counts": {state: 0 for state in ("same", "changed", "markup", "metadata", "moved", "current-only", "other-only")},
        "rows": [],
    }
    if not available:
        return empty
    current_rows = {row["id"]: row for row in current_page.get("passages", []) if row.get("id")}
    other_rows = {row["id"]: row for row in other_page.get("passages", []) if row.get("id")}
    rows: list[dict[str, Any]] = []
    current_unmatched = set(current_rows)
    other_unmatched = set(other_rows)
    for passage_id in sorted(current_unmatched & other_unmatched):
        here = current_rows[passage_id]
        there = other_rows[passage_id]
        changes: list[str] = []
        if here.get("text_sha256") and there.get("text_sha256") and here.get("text_sha256") != there.get("text_sha256"):
            state = "changed"; changes.append("text")
        elif here.get("source_html_sha256") and there.get("source_html_sha256") and here.get("source_html_sha256") != there.get("source_html_sha256"):
            state = "markup"; changes.append("markup")
        else:
            state = "same"
        for key, label in (("title", "title"), ("level", "level"), ("anchor", "anchor")):
            if here.get(key) != there.get(key):
                if state == "same":
                    state = "metadata"
                changes.append(label)
        rows.append({"id": passage_id, "state": state, "changes": changes, "current": here, "other": there})
        current_unmatched.remove(passage_id)
        other_unmatched.remove(passage_id)

    current_hashes: dict[str, list[str]] = {}
    other_hashes: dict[str, list[str]] = {}
    for passage_id in current_unmatched:
        digest = current_rows[passage_id].get("text_sha256")
        if digest:
            current_hashes.setdefault(digest, []).append(passage_id)
    for passage_id in other_unmatched:
        digest = other_rows[passage_id].get("text_sha256")
        if digest:
            other_hashes.setdefault(digest, []).append(passage_id)
    for digest in sorted(set(current_hashes) & set(other_hashes)):
        if len(current_hashes[digest]) != 1 or len(other_hashes[digest]) != 1:
            continue
        current_id = current_hashes[digest][0]
        other_id = other_hashes[digest][0]
        here = current_rows[current_id]
        there = other_rows[other_id]
        changes = ["stable passage id"]
        if here.get("title") != there.get("title"):
            changes.append("title")
        if here.get("anchor") != there.get("anchor"):
            changes.append("anchor")
        if here.get("source_html_sha256") != there.get("source_html_sha256"):
            changes.append("markup")
        rows.append({"id": current_id, "other_id": other_id, "state": "moved", "changes": changes, "current": here, "other": there})
        current_unmatched.remove(current_id)
        other_unmatched.remove(other_id)

    for passage_id in sorted(current_unmatched):
        rows.append({"id": passage_id, "state": "current-only", "changes": [], "current": current_rows[passage_id], "other": None})
    for passage_id in sorted(other_unmatched):
        rows.append({"id": passage_id, "state": "other-only", "changes": [], "current": None, "other": other_rows[passage_id]})
    rows.sort(key=lambda row: (
        (row.get("current") or {}).get("order") if (row.get("current") or {}).get("order") is not None
        else 100000 + ((row.get("other") or {}).get("order") or 0),
        row["id"],
    ))
    counts = {state: sum(row["state"] == state for row in rows) for state in empty["counts"]}
    return {"available": True, "counts": counts, "rows": rows}


def compare_edition_summaries(current: dict[str, Any], other: dict[str, Any]) -> dict[str, Any]:
    current = normalize_edition_summary(current)
    other = normalize_edition_summary(other)
    if current["source_fingerprint_sha256"] and current["source_fingerprint_sha256"] == other["source_fingerprint_sha256"]:
        relation = "same"
    else:
        a = edition_revision_number(current["edition"])
        b = edition_revision_number(other["edition"])
        relation = "older" if a is not None and b is not None and b < a else "newer" if a is not None and b is not None and b > a else "parallel"
    page_rows = []
    for page_id in sorted(set(current["pages"]) | set(other["pages"])):
        here = current["pages"].get(page_id)
        there = other["pages"].get(page_id)
        changes: list[str] = []
        passage_comparison = {"available": False, "counts": {}, "rows": []}
        if here and not there:
            state = "current-only"
        elif there and not here:
            state = "other-only"
        else:
            assert here is not None and there is not None
            state = "same"
            if here.get("body_sha256") and there.get("body_sha256") and here.get("body_sha256") != there.get("body_sha256"):
                state = "changed"; changes.append("body")
            for key, label in (("url", "route"), ("title", "title"), ("kind", "kind"), ("status", "status")):
                if here.get(key) != there.get(key):
                    if state == "same": state = "metadata"
                    changes.append(label)
            passage_comparison = compare_edition_passages(here, there)
        passage_differences = sum(
            count for label, count in passage_comparison.get("counts", {}).items() if label != "same"
        )
        page_rows.append({
            "id": page_id,
            "state": state,
            "changes": changes,
            "current": here,
            "other": there,
            "passages": passage_comparison.get("rows", []),
            "passage_counts": passage_comparison.get("counts", {}),
            "passage_detail_available": bool(passage_comparison.get("available")),
            "unsectioned_body_change": bool(state == "changed" and passage_comparison.get("available") and passage_differences == 0),
        })
    source_rows = []
    names = set(current["sources"]["active"]) | set(other["sources"]["active"]) | set(current["sources"]["retired"]) | set(other["sources"]["retired"])
    for name in sorted(names):
        ca = current["sources"]["active"].get(name); oa = other["sources"]["active"].get(name)
        cr = current["sources"]["retired"].get(name); orow = other["sources"]["retired"].get(name)
        if ca and oa: state = "same" if ca.get("head_sha") == oa.get("head_sha") else "changed"
        elif cr and orow: state = "same" if cr.get("last_observed_head") == orow.get("last_observed_head") else "changed"
        elif ca and orow: state = "restored-current"
        elif cr and oa: state = "retired-current"
        elif ca or cr: state = "current-only"
        else: state = "other-only"
        source_rows.append({"name": name, "state": state, "current": ca or cr, "other": oa or orow, "current_status": "active" if ca else "retired" if cr else "absent", "other_status": "active" if oa else "retired" if orow else "absent"})
    counts = {state: sum(row["state"] == state for row in page_rows) for state in ("same", "changed", "metadata", "current-only", "other-only")}
    passage_states = ("same", "changed", "markup", "metadata", "moved", "current-only", "other-only")
    counts.update({f"passages_{state.replace('-', '_')}": sum(row.get("passage_counts", {}).get(state, 0) for row in page_rows) for state in passage_states})
    counts.update({
        "pages_current": len(current["pages"]),
        "pages_other": len(other["pages"]),
        "pages_with_passage_detail": sum(row.get("passage_detail_available", False) for row in page_rows),
        "passage_differences": sum(
            row.get("passage_counts", {}).get(state, 0)
            for row in page_rows for state in passage_states if state != "same"
        ),
        "sources_changed": sum(row["state"] != "same" for row in source_rows),
        "sources_same": sum(row["state"] == "same" for row in source_rows),
    })
    return {
        "schema": "lumen.edition-comparison/v2",
        "generated_at": utc_now(),
        "relation": relation,
        "current": {key: current.get(key) for key in ("edition", "generated_at", "source_fingerprint_sha256", "scope", "source_schema")},
        "other": {key: other.get(key) for key in ("edition", "generated_at", "source_fingerprint_sha256", "scope", "source_schema")},
        "counts": counts,
        "pages": page_rows,
        "sources": source_rows,
        "boundary": "This local comparison reports edition identities, carried page bytes, and exact source-bound passage fingerprints when both editions provide them. It does not infer why text changed, prove a claim true, or upload either file.",
    }


def render_edition_comparison(comparison: dict[str, Any], format_name: str) -> str:
    if format_name == "json":
        return json.dumps(comparison, ensure_ascii=False, indent=2) + "\n"
    changed = [row for row in comparison["pages"] if row["state"] != "same"]
    sources = [row for row in comparison["sources"] if row["state"] != "same"]
    if format_name == "markdown":
        lines = [
            "# Lumen edition comparison", "",
            f"- This edition: `{comparison['current']['edition']}` · `{str(comparison['current']['source_fingerprint_sha256'])[:12]}`",
            f"- Selected edition: `{comparison['other']['edition']}` · `{str(comparison['other']['source_fingerprint_sha256'])[:12]}`",
            f"- Relation: **{comparison['relation']}**",
            f"- Source-bound passage differences: **{comparison['counts'].get('passage_differences', 0)}**", "",
            "## Publication changes", "",
        ]
        if not changed:
            lines.append("No comparable page differences were found.")
        for row in changed:
            page = row.get("current") or row.get("other") or {}
            detail = ", ".join(row.get("changes", [])) or row["state"]
            lines.append(f"- **{page.get('title', row['id'])}** (`{row['id']}`): {row['state']} · {detail}")
            passage_rows = [item for item in row.get("passages", []) if item.get("state") != "same"]
            if row.get("passage_detail_available"):
                if passage_rows:
                    for passage in passage_rows:
                        record = passage.get("current") or passage.get("other") or {}
                        title = record.get("title") or passage.get("id")
                        other_title = (passage.get("other") or {}).get("title")
                        moved = f" · formerly {other_title}" if passage.get("state") == "moved" and other_title and other_title != title else ""
                        lines.append(f"  - `{passage['state']}` **{title}**{moved} (`{passage.get('id')}`)")
                elif row.get("unsectioned_body_change"):
                    lines.append("  - Page bytes changed outside the comparable titled passages, or only in untitled/structural material.")
                else:
                    lines.append("  - Comparable titled passages are unchanged.")
            else:
                lines.append("  - Passage-level records were not available in both editions; this remains a page-level comparison.")
        lines.extend(["", "## Captured public sources", ""])
        if not sources:
            lines.append("Comparable source heads and retirement boundaries match.")
        for row in sources:
            lines.append(f"- **{row['name']}**: {row['other_status']} → {row['current_status']} · {row['state']}")
        lines.extend(["", comparison["boundary"], ""])
        return "\n".join(lines)
    lines = [
        f"This edition   {comparison['current']['edition']}  {str(comparison['current']['source_fingerprint_sha256'])[:12]}",
        f"Selected       {comparison['other']['edition']}  {str(comparison['other']['source_fingerprint_sha256'])[:12]}",
        f"Relation       {comparison['relation']}",
        f"Publication    {len(changed)} difference(s)",
        f"Passages       {comparison['counts'].get('passage_differences', 0)} exact difference(s)",
        f"Source capture {len(sources)} difference(s)",
    ]
    for row in changed:
        page = row.get("current") or row.get("other") or {}
        detail = ", ".join(row.get("changes", [])) or row["state"]
        lines.append(f"  {row['state']:<12} {row['id']} · {page.get('title', '')} · {detail}")
        passage_rows = [item for item in row.get("passages", []) if item.get("state") != "same"]
        for passage in passage_rows:
            record = passage.get("current") or passage.get("other") or {}
            lines.append(f"    {passage['state']:<10} {passage.get('id')} · {record.get('title', '')}")
        if row.get("unsectioned_body_change"):
            lines.append("    boundary   changed outside comparable titled passages")
        elif not row.get("passage_detail_available"):
            lines.append("    boundary   passage-level records unavailable in one or both editions")
    for row in sources:
        lines.append(f"  source {row['state']:<12} {row['name']} · {row['other_status']} -> {row['current_status']}")
    lines.append(comparison["boundary"])
    return "\n".join(lines) + "\n"


def cmd_compare(args: argparse.Namespace) -> int:
    if args.build or not (DIST / "meta" / "edition-summary.json").is_file():
        run([sys.executable, "tools/build.py", "--clean"])
    current = load_edition_summary(DIST / "meta" / "edition-summary.json")
    other = load_edition_summary(Path(args.edition))
    comparison = compare_edition_summaries(current, other)
    rendered = render_edition_comparison(comparison, args.format)
    if args.output:
        target = Path(args.output).expanduser().resolve()
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(rendered, encoding="utf-8")
        emit("wrote", str(target))
    else:
        print(rendered, end="")
    return 0


def append_revision(path: Path, data: dict[str, Any], *, summary: str, date: str | None = None, source_ref: str = "") -> dict[str, Any]:
    if data.get("kind") != "note":
        raise LumenError("only field notes participate in the authored revision ledger")
    summary = summary.strip()
    if not summary:
        raise LumenError("revision summary must not be empty")
    value = date or dt.datetime.now(dt.timezone.utc).date().isoformat()
    try:
        dt.date.fromisoformat(value)
    except ValueError as exc:
        raise LumenError(f"invalid revision date: {value!r}") from exc
    payload = edition_history()
    page_id = str(data.get("id"))
    note = payload["notes"].setdefault(page_id, {"published_at": str(data.get("date") or value), "revisions": []})
    revisions = note.setdefault("revisions", [])
    identity = authored_body_identity(path, data)
    if revisions and revisions[-1].get("body_sha256") == identity["sha256"]:
        raise LumenError(f"{page_id} already matches the latest recorded revision")
    edition = str(read_json(CONFIG).get("edition", "development"))
    record = {
        "edition": edition,
        "date": value,
        "summary": summary,
        "body_sha256": identity["sha256"],
        "body_bytes": identity["bytes"],
        "source_ref": source_ref.strip() or f"Accepted local source in {edition}",
    }
    revisions.append(record)
    write_json(EDITION_HISTORY, payload)
    return record


def cmd_revise(args: argparse.Namespace) -> int:
    path, data = resolve_page(args.target)
    if data.get("status", "published") != "published":
        raise LumenError("drafts must be published rather than revised")
    record = append_revision(path, data, summary=args.summary, date=args.date, source_ref=args.source_ref or "")
    emit("revised", f"{data.get('id')} · {record['edition']} · {record['date']}")
    emit("identity", f"{record['body_sha256']} · {record['body_bytes']} bytes")
    emit("next", "run ./lumen history --check, then ./lumen verify --canonical")
    return 0


def cmd_build(args: argparse.Namespace) -> int:
    command = [sys.executable, "tools/build.py"]
    if args.clean:
        command.append("--clean")
    if args.output:
        command.extend(["--output", str(Path(args.output).expanduser())])
    if getattr(args, "include_drafts", False):
        command.append("--include-drafts")
    run(command)
    return 0


def isolated_validation(*, include_drafts: bool = False, keep: bool = False) -> Path | None:
    holder = tempfile.TemporaryDirectory(prefix="lumen-verify-")
    output = Path(holder.name) / "dist"
    try:
        command = [sys.executable, "tools/build.py", "--clean", "--output", str(output)]
        if include_drafts:
            command.append("--include-drafts")
        run(command)
        run([sys.executable, "tools/check_dist.py", str(output)])
        if keep:
            retained = Path(tempfile.mkdtemp(prefix="lumen-verified-dist-")) / "dist"
            shutil.copytree(output, retained)
            return retained
        return None
    finally:
        holder.cleanup()


def cmd_verify(args: argparse.Namespace) -> int:
    run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"])
    isolated_validation()
    if args.canonical:
        run([sys.executable, "tools/build.py", "--clean"])
        run([sys.executable, "tools/check_dist.py"])
    emit("pass", "tests, isolated build, links, metadata, budgets, and deploy boundary verified")
    return 0


def cmd_doctor(_: argparse.Namespace) -> int:
    checks: list[tuple[str, bool, str]] = []
    checks.append(("python", sys.version_info >= (3, 10), sys.version.split()[0]))
    for path in REQUIRED:
        checks.append(("file", path.is_file(), path.relative_to(ROOT).as_posix()))
    try:
        config = read_json(CONFIG)
        checks.append(("config", bool(config.get("origin")), config.get("origin", "origin missing")))
    except LumenError as exc:
        checks.append(("config", False, str(exc)))
    try:
        snapshot = read_json(SNAPSHOT)
        checks.append(("source", bool(snapshot.get("repositories")), f"{len(snapshot.get('repositories', []))} repositories"))
    except LumenError as exc:
        checks.append(("source", False, str(exc)))
    try:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="lumen-write-", dir=STATE_DIR) as directory:
            probe = Path(directory) / "receipt"
            probe.write_text("ok", encoding="utf-8")
            checks.append(("write", probe.read_text(encoding="utf-8") == "ok", str(STATE_DIR.relative_to(ROOT))))
    except OSError as exc:
        checks.append(("write", False, str(exc)))
    for name, passed, detail in checks:
        emit("ok" if passed else "fail", f"{name}: {detail}")
    if not all(row[1] for row in checks):
        return 1
    isolated_validation()
    emit("ready", "cloudtainer can build and validate Lumen without installing dependencies")
    return 0


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format: str, *args: object) -> None:  # noqa: A003 - stdlib API
        emit("http", format % args)


def make_server(host: str, port: int, directory: Path) -> socketserver.TCPServer:
    handler = lambda *a, **kw: QuietHandler(*a, directory=str(directory), **kw)  # noqa: E731

    class ReusableServer(http.server.ThreadingHTTPServer):
        allow_reuse_address = True
        daemon_threads = True

    try:
        return ReusableServer((host, port), handler)
    except OSError as exc:
        raise LumenError(f"cannot listen on {host}:{port}: {exc}; try --port 0 for an automatic port") from exc


def build_canonical(clean: bool = True) -> None:
    command = [sys.executable, "tools/build.py"]
    if clean:
        command.append("--clean")
    run(command)


def atomic_preview_build() -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    build_dir = Path(tempfile.mkdtemp(prefix="preview-build-", dir=STATE_DIR))
    backup = STATE_DIR / "preview-dist.previous"
    try:
        run([sys.executable, "tools/build.py", "--clean", "--output", str(build_dir), "--include-drafts"])
        run([sys.executable, "tools/check_dist.py", str(build_dir)])
        if backup.exists():
            shutil.rmtree(backup)
        if PREVIEW_DIST.exists():
            PREVIEW_DIST.rename(backup)
        build_dir.rename(PREVIEW_DIST)
        if backup.exists():
            shutil.rmtree(backup)
    except Exception:
        if not PREVIEW_DIST.exists() and backup.exists():
            backup.rename(PREVIEW_DIST)
        if build_dir.exists():
            shutil.rmtree(build_dir)
        raise


def cmd_serve(args: argparse.Namespace) -> int:
    if not args.no_build:
        build_canonical(clean=True)
        run([sys.executable, "tools/check_dist.py"])
    if not DIST.is_dir():
        raise LumenError("dist/ does not exist; run ./lumen build")
    with make_server(args.host, args.port, DIST) as server:
        emit("serve", f"http://{args.host}:{server.server_port}/ · canonical build · Ctrl-C stops the server")
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            emit("stop", "preview server stopped")
    return 0


def watch_preview(args: argparse.Namespace) -> int:
    atomic_preview_build()
    server = make_server(args.host, args.port, PREVIEW_DIST)
    thread = threading.Thread(target=server.serve_forever, name="lumen-http", daemon=True)
    thread.start()
    url = f"http://{args.host}:{server.server_port}/"
    emit("serve", f"{url} · draft-aware atomic preview")
    if getattr(args, "open", False):
        opened = webbrowser.open(url)
        emit("open", "browser request sent" if opened else "browser launcher did not accept the request")
    state = source_mtime_state()
    try:
        while True:
            time.sleep(max(.2, args.interval))
            new_state = source_mtime_state()
            if new_state == state:
                continue
            state = new_state
            emit("change", "source changed; building a replacement preview")
            try:
                atomic_preview_build()
                emit("ready", "preview swapped atomically")
            except (subprocess.CalledProcessError, LumenError, OSError) as exc:
                emit("error", f"rebuild failed; serving the last complete preview: {exc}")
    except KeyboardInterrupt:
        emit("stop", "watcher stopped")
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)
    return 0


def cmd_dev(args: argparse.Namespace) -> int:
    return watch_preview(args)


def cmd_start(args: argparse.Namespace) -> int:
    if cmd_doctor(args) != 0:
        return 1
    return watch_preview(args)


def cmd_new(args: argparse.Namespace) -> int:
    folder, kind = KIND_PATHS[args.kind]
    slug = slugify(args.slug or args.title)
    page_id = f"{kind}-{slug}"
    base = ROOT / "content" / "pages" / folder / slug
    meta_path = base.with_suffix(".json")
    body_path = base.with_suffix(".html")
    if meta_path.exists() or body_path.exists():
        raise LumenError(f"refusing to replace existing draft: {base.relative_to(ROOT)}")
    date = args.date or dt.datetime.now(dt.timezone.utc).date().isoformat()
    url = f"/{folder}/{slug}/"
    label = {"note": "Draft field note", "project": "Draft instrument", "collection": "Draft collection"}[kind]
    body = '''<h2>What this page needs to establish</h2>
<p>Replace this scaffold with the claim, object, or instrument that deserves a public page.</p>
<h2>Evidence and limits</h2>
<p>Name what was observed, what was inferred, and what remains open.</p>
<p class="signature">— Lumen</p>
'''
    meta = {
        "id": page_id,
        "url": url,
        "kind": kind,
        "status": "draft",
        "title": args.title,
        "description": "Draft description: state what a reader will find here.",
        "author": "Lumen",
        "date": date,
        "label": label,
        "body": body_path.name,
        "tags": ["draft"],
        "related": [],
        "source": {
            "repository": "unassigned",
            "path": body_path.relative_to(ROOT).as_posix(),
            "sha": "draft-unreviewed",
            "status": "Draft scaffold; not accepted or published",
        },
        "limits": ["This file was scaffolded by the local authoring tool and has not been editorially reviewed."],
    }
    body_path.parent.mkdir(parents=True, exist_ok=True)
    body_path.write_text(body, encoding="utf-8")
    write_json(meta_path, meta)
    emit("created", meta_path.relative_to(ROOT).as_posix())
    emit("created", body_path.relative_to(ROOT).as_posix())
    emit("preview", "run ./lumen start; canonical builds will ignore this draft")
    return 0


def cmd_drafts(_: argparse.Namespace) -> int:
    rows = draft_metadata()
    if not rows:
        emit("drafts", "none")
        return 0
    for path, data in rows:
        emit("draft", f"{data.get('id')} · {data.get('title')} · {path.relative_to(ROOT)}")
    emit("next", "fill source identity and description, then run ./lumen publish <id-or-slug>")
    return 0


def resolve_draft(target: str) -> tuple[Path, dict[str, Any]]:
    matches: list[tuple[Path, dict[str, Any]]] = []
    wanted = slugify(target)
    for path, data in draft_metadata():
        candidates = {
            str(data.get("id", "")),
            slugify(str(data.get("title", ""))),
            path.stem,
            path.relative_to(ROOT).as_posix(),
        }
        if target in candidates or wanted in candidates:
            matches.append((path, data))
    if not matches:
        raise LumenError(f"no draft matches {target!r}; run ./lumen drafts")
    if len(matches) > 1:
        raise LumenError(f"draft target {target!r} is ambiguous: {[str(row[0].relative_to(ROOT)) for row in matches]}")
    return matches[0]


def resolve_page(target: str) -> tuple[Path, dict[str, Any]]:
    """Resolve a page by stable id, URL, title slug, filename, or path."""
    matches: list[tuple[Path, dict[str, Any]]] = []
    wanted = slugify(target)
    normalized_url = "/" + target.strip("/") + "/" if target.strip("/") else "/"
    for path, data in page_metadata():
        candidates = {
            str(data.get("id", "")),
            slugify(str(data.get("title", ""))),
            path.stem,
            path.relative_to(ROOT).as_posix(),
            str(data.get("url", "")),
        }
        if target in candidates or wanted in candidates or normalized_url in candidates:
            matches.append((path, data))
    if not matches:
        raise LumenError(f"no page matches {target!r}; use ./lumen drafts or inspect content/pages/")
    if len(matches) > 1:
        raise LumenError(f"page target {target!r} is ambiguous: {[str(row[0].relative_to(ROOT)) for row in matches]}")
    return matches[0]


def page_record(path: Path, data: dict[str, Any]) -> dict[str, Any]:
    body_path = (path.parent / str(data.get("body", ""))).resolve()
    record = {
        "id": data.get("id"),
        "title": data.get("title"),
        "url": data.get("url"),
        "kind": data.get("kind"),
        "status": data.get("status", "published"),
        "metadata": path.relative_to(ROOT).as_posix(),
        "body": body_path.relative_to(ROOT).as_posix() if body_path.is_relative_to(ROOT) else str(body_path),
        "source": data.get("source") or {},
        "limits": data.get("limits") or [],
    }
    if record["status"] == "draft":
        record["publication_blockers"] = publication_blockers(data)
    context_path = DIST / "meta" / "context" / f"{data.get('id')}.json"
    if context_path.is_file():
        context = read_json(context_path)
        record["hypertext"] = {
            "passages": context.get("page", {}).get("passage_count", 0),
            "citations": context.get("page", {}).get("external_citation_count", 0),
            "incoming": context.get("page", {}).get("incoming_context_count", 0),
            "outgoing": context.get("page", {}).get("outgoing_context_count", 0),
            "context_file": context_path.relative_to(ROOT).as_posix(),
        }
    return record


def cmd_page(args: argparse.Namespace) -> int:
    path, data = resolve_page(args.target)
    record = page_record(path, data)
    if args.json:
        print(json.dumps(record, ensure_ascii=False, indent=2))
        return 0
    emit("page", f"{record['id']} · {record['title']}")
    emit("state", f"{record['status']} · {record['kind']} · {record['url']}")
    emit("body", str(record["body"]))
    emit("meta", str(record["metadata"]))
    source = record.get("source") or {}
    emit("source", f"{source.get('repository', 'unassigned')} @ {source.get('sha', 'unassigned')}")
    if record.get("hypertext"):
        h = record["hypertext"]
        emit("context", f"{h['passages']} passages · {h['citations']} citations · {h['incoming']} incoming · {h['outgoing']} outgoing")
    for blocker in record.get("publication_blockers", []):
        emit("block", blocker)
    emit("edit", f"./lumen edit {record['id']}")
    emit("trace", f"./lumen context {record['id']}")
    return 0


def split_context_target(value: str) -> tuple[str, str]:
    """Split PAGE#ANCHOR or PAGE::ANCHOR without confusing ordinary paths."""
    if "::" in value:
        page, anchor = value.split("::", 1)
        return page, anchor
    if "#" in value:
        page, anchor = value.split("#", 1)
        return page, anchor
    return value, ""


def cmd_context(args: argparse.Namespace) -> int:
    page_target, anchor = split_context_target(args.target)
    path, data = resolve_page(page_target)
    context_path = DIST / "meta" / "context" / f"{data.get('id')}.json"
    if args.build:
        build_canonical(clean=True)
        run([sys.executable, "tools/check_dist.py"])
    if not context_path.is_file():
        raise LumenError("passage context is not built; run ./lumen context --build TARGET or ./lumen start")
    payload = read_json(context_path)
    passages = payload.get("passages", [])
    if anchor:
        passage = next((row for row in passages if row.get("anchor") == anchor or row.get("id") == anchor), None)
        if passage is None:
            available = ", ".join(str(row.get("anchor")) for row in passages) or "no authored sections"
            raise LumenError(f"no passage {anchor!r} on {data.get('id')}; available: {available}")
        incoming = [
            row for row in payload.get("incoming", [])
            if not row.get("target_anchor") or row.get("target_anchor") == passage.get("anchor")
        ]
        outgoing = [
            row for row in payload.get("outgoing", [])
            if not row.get("passage_id") or row.get("passage_id") == passage.get("id")
        ]
        record = {
            "schema": "lumen.cli-context/v1",
            "page": payload.get("page", {}),
            "passage": passage,
            "incoming": incoming,
            "outgoing": outgoing,
            "context_file": context_path.relative_to(ROOT).as_posix(),
        }
        if args.json:
            print(json.dumps(record, ensure_ascii=False, indent=2))
            return 0
        emit("passage", f"{passage.get('id')} · {passage.get('title')}")
        emit("url", str(passage.get("url")))
        offsets = passage.get("source_offsets") or {}
        emit("source", f"{offsets.get('start', '?')}–{offsets.get('end', '?')} · HTML {str(passage.get('source_html_sha256', ''))[:16]} · text {str(passage.get('text_sha256', ''))[:16]}")
        emit("words", str(passage.get("word_count", 0)))
        print(str(passage.get("excerpt", "")))
        emit("links", f"{len(passage.get('internal_links', []))} internal · {len(passage.get('external_links', []))} citations · {len(incoming)} incoming · {len(outgoing)} outgoing")
        return 0

    record = {
        "schema": "lumen.cli-context/v1",
        "page": payload.get("page", {}),
        "passages": passages,
        "incoming": payload.get("incoming", []),
        "outgoing": payload.get("outgoing", []),
        "context_file": context_path.relative_to(ROOT).as_posix(),
    }
    if args.json:
        print(json.dumps(record, ensure_ascii=False, indent=2))
        return 0
    emit("context", f"{data.get('id')} · {len(passages)} passages · {len(payload.get('incoming', []))} incoming · {len(payload.get('outgoing', []))} outgoing")
    for passage in passages:
        emit("section", f"{passage.get('anchor')} · {passage.get('title')} · {passage.get('word_count', 0)} words")
    if passages:
        emit("inspect", f"./lumen context {data.get('id')}#{passages[0].get('anchor')}")
    return 0



def reference_records(*, build: bool = False) -> dict[str, Any]:
    if build:
        build_canonical(clean=True)
        run([sys.executable, "tools/check_dist.py"])
    path = DIST / "meta" / "references.json"
    receipt_path = DIST / "build-receipt.json"
    if not path.is_file() or not receipt_path.is_file():
        raise LumenError("reference ledger is not built; rerun with --build or run ./lumen build --clean")
    payload = read_json(path)
    receipt = read_json(receipt_path)
    if payload.get("source_fingerprint_sha256") != receipt.get("source_fingerprint_sha256"):
        raise LumenError("reference ledger and build receipt describe different source trees; rebuild before reading")
    return payload


def reading_path_records(*, build: bool = False) -> dict[str, Any]:
    if build:
        build_canonical(clean=True)
        run([sys.executable, "tools/check_dist.py"])
    path = DIST / "meta" / "reading-paths.json"
    receipt_path = DIST / "build-receipt.json"
    if not path.is_file() or not receipt_path.is_file():
        raise LumenError("reading paths are not built; rerun with --build or run ./lumen build --clean")
    payload = read_json(path)
    receipt = read_json(receipt_path)
    if payload.get("schema") != "lumen.reading-paths/v1":
        raise LumenError("reading path record has an unsupported schema")
    if payload.get("source_fingerprint_sha256") != receipt.get("source_fingerprint_sha256"):
        raise LumenError("reading paths and build receipt describe different source trees; rebuild before reading")
    return payload


def render_thread_markdown(paths: list[dict[str, Any]], payload: dict[str, Any]) -> str:
    lines = ["# Lumen reading paths", ""]
    for path in paths:
        lines.extend([f"## {path.get('title')}", "", str(path.get("description", "")), ""])
        for step in path.get("steps", []):
            lines.append(f"{step.get('order')}. [{step.get('label')}]({step.get('url')}) — {step.get('note')}")
            lines.append(f"   - `{step.get('stable_id')}` · `{str(step.get('text_sha256', ''))[:16]}`")
        lines.append("")
    lines.append(f"> {payload.get('boundary', '')}")
    return "\n".join(lines).rstrip() + "\n"


def render_thread_text(paths: list[dict[str, Any]], payload: dict[str, Any]) -> str:
    lines: list[str] = []
    for path in paths:
        lines.append(f"{path.get('id')} · {path.get('title')}")
        lines.append(str(path.get("description", "")))
        for step in path.get("steps", []):
            lines.append(f"  {int(step.get('order', 0)):02d}  {step.get('label')}  {step.get('url')}")
            lines.append(f"      {step.get('note')}")
            lines.append(f"      {step.get('stable_id')} · {str(step.get('text_sha256', ''))[:16]}")
        lines.append("")
    lines.append(f"Boundary: {payload.get('boundary', '')}")
    return "\n".join(lines).rstrip() + "\n"


def cmd_thread(args: argparse.Namespace) -> int:
    payload = reading_path_records(build=args.build)
    paths = list(payload.get("paths", []))
    query = str(args.query or "").strip().casefold()
    if query:
        exact = [row for row in paths if str(row.get("id", "")).casefold() == query]
        if exact:
            paths = exact
        else:
            terms = query.split()
            def matches(row: dict[str, Any]) -> bool:
                haystack = " ".join(
                    [str(row.get("id", "")), str(row.get("title", "")), str(row.get("description", ""))]
                    + [f"{step.get('label', '')} {step.get('note', '')} {step.get('page_title', '')} {step.get('stable_id', '')}" for step in row.get("steps", [])]
                ).casefold()
                return all(term in haystack for term in terms)
            paths = [row for row in paths if matches(row)]
    record = {
        "schema": "lumen.cli-reading-paths/v1",
        "query": args.query or None,
        "edition": payload.get("edition"),
        "source_fingerprint_sha256": payload.get("source_fingerprint_sha256"),
        "counts": {**payload.get("counts", {}), "matched": len(paths)},
        "paths": paths,
        "boundary": payload.get("boundary"),
    }
    if args.format == "json":
        rendered = json.dumps(record, ensure_ascii=False, indent=2) + "\n"
    elif args.format == "markdown":
        rendered = render_thread_markdown(paths, payload)
    else:
        rendered = render_thread_text(paths, payload)
    if args.output:
        out = Path(args.output).expanduser()
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(rendered, encoding="utf-8")
        emit("written", str(out))
    else:
        print(rendered, end="")
    if not paths:
        emit("empty", f"no reading path matched {args.query!r}")
        return 1
    return 0


def cmd_references(args: argparse.Namespace) -> int:
    payload = reference_records(build=args.build)
    rows = list(payload.get("sources", []))
    query = str(args.query or "").strip().casefold()
    if query:
        def matches(row: dict[str, Any]) -> bool:
            citations = row.get("citations", [])
            haystack = " ".join(
                [str(row.get("id", "")), str(row.get("host", "")), str(row.get("url", ""))]
                + [str(value) for value in row.get("urls", [])]
                + [str(value) for value in row.get("labels", [])]
                + [f"{item.get('page_title', '')} {item.get('passage_title', '')}" for item in citations]
            ).casefold()
            return all(term in haystack for term in query.split())
        rows = [row for row in rows if matches(row)]
    if args.format == "json":
        out = {
            "schema": "lumen.cli-references/v1",
            "query": args.query or None,
            "source_fingerprint_sha256": payload.get("source_fingerprint_sha256"),
            "counts": {**payload.get("counts", {}), "matched": len(rows)},
            "sources": rows,
            "limits": payload.get("limits", []),
        }
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return 0
    if args.format == "markdown":
        for index, row in enumerate(rows, 1):
            label = str(row.get("display_label") or row.get("host") or row.get("url"))
            print(f"{index}. [{label}]({row.get('url')}) — `{row.get('id')}`")
            for citation in row.get("citations", []):
                print(f"   - [{citation.get('page_title')} · {citation.get('passage_title')}]({citation.get('passage_url')})")
        return 0
    emit("references", f"{len(rows)} of {payload.get('counts', {}).get('sources', len(rows))} linked sources · {payload.get('counts', {}).get('domains', 0)} domains")
    for row in rows:
        label = str(row.get("display_label") or row.get("host") or row.get("url"))
        emit("source", f"{row.get('id')} · {row.get('host')} · {label}")
        print(f"         {row.get('url')}")
        for citation in row.get("citations", []):
            print(f"         ↳ {citation.get('page_title')} · {citation.get('passage_title')} · {citation.get('passage_url')}")
    if not rows:
        emit("empty", f"no source matched {args.query!r}")
        return 1
    return 0


def citation_record(target: str, *, build: bool = False) -> dict[str, Any]:
    page_target, anchor = split_context_target(target)
    _path, meta = resolve_page(page_target)
    if build:
        build_canonical(clean=True)
        run([sys.executable, "tools/check_dist.py"])
    context_path = DIST / "meta" / "context" / f"{meta.get('id')}.json"
    receipt_path = DIST / "build-receipt.json"
    if not context_path.is_file() or not receipt_path.is_file():
        raise LumenError("citation context is not built; rerun with --build or run ./lumen build --clean")
    context = read_json(context_path)
    page = context.get("page", {})
    passage = None
    if anchor:
        passage = next((row for row in context.get("passages", []) if row.get("anchor") == anchor or row.get("id") == anchor), None)
        if passage is None:
            available = ", ".join(str(row.get("anchor")) for row in context.get("passages", [])) or "no authored sections"
            raise LumenError(f"no passage {anchor!r} on {meta.get('id')}; available: {available}")
    config = read_json(CONFIG)
    receipt = read_json(receipt_path)
    url = str(config.get("origin", "")).rstrip("/") + str(page.get("url", meta.get("url", "/")))
    if passage:
        url += "#" + str(passage.get("anchor", ""))
    title = str(passage.get("title") if passage else page.get("title") or meta.get("title"))
    fingerprint = str(passage.get("text_sha256") if passage else page.get("body_sha256", ""))
    record = {
        "schema": "lumen.citation/v1",
        "author": str(meta.get("author", "Lumen")),
        "title": title,
        "page_title": str(page.get("title") or meta.get("title")),
        "page_id": str(page.get("id") or meta.get("id")),
        "passage_id": passage.get("id") if passage else None,
        "date": page.get("date") or meta.get("date"),
        "url": url,
        "edition": config.get("edition", "development"),
        "source_fingerprint_sha256": receipt.get("source_fingerprint_sha256"),
        "text_sha256": fingerprint,
        "quote": passage.get("text") if passage else None,
    }
    return record


def citation_text(record: dict[str, Any], *, markdown: bool = False, include_quote: bool = False) -> str:
    title = str(record.get("title", "Untitled"))
    page_title = str(record.get("page_title", "Lumen’s Field Notes"))
    author = str(record.get("author", "Lumen"))
    date = str(record.get("date") or "undated")
    url = str(record.get("url", ""))
    edition = str(record.get("edition", "unknown"))
    digest = str(record.get("text_sha256", ""))
    if record.get("passage_id"):
        citation = f'{author}. “{title}.” In “{page_title},” Lumen’s Field Notes, {date}. {url} (edition {edition}; text SHA-256 {digest}).'
    else:
        citation = f'{author}. “{title}.” Lumen’s Field Notes, {date}. {url} (edition {edition}; body SHA-256 {digest}).'
    if markdown:
        if record.get("passage_id"):
            citation = f'{author}. “[ {title} ]({url}).” In *{page_title}*, Lumen’s Field Notes, {date}. Edition `{edition}`; text `{digest}`.'
        else:
            citation = f'{author}. “[ {title} ]({url}).” *Lumen’s Field Notes*, {date}. Edition `{edition}`; body `{digest}`.'
        citation = citation.replace("[ ", "[").replace(" ](", "](")
    if include_quote:
        quote = str(record.get("quote") or "").strip()
        if not quote:
            raise LumenError("--quote requires a source-bound passage target such as PAGE#SECTION")
        if markdown:
            quoted = quote.replace("\n", "\n> ")
            return f"> {quoted}\n\n— {citation}"
        return f'“{quote}”\n\n— {citation}'
    return citation

def cmd_cite(args: argparse.Namespace) -> int:
    record = citation_record(args.target, build=args.build)
    if args.format == "json":
        output = json.dumps(record, ensure_ascii=False, indent=2) + "\n"
    else:
        output = citation_text(record, markdown=args.format == "markdown", include_quote=args.quote) + "\n"
    if args.output:
        path = Path(args.output).expanduser()
        if not path.is_absolute():
            path = ROOT / path
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(output, encoding="utf-8")
        emit("citation", str(path.relative_to(ROOT) if path.is_relative_to(ROOT) else path))
    else:
        print(output, end="")
    return 0


def portable_folio_records(*, build: bool = False) -> dict[str, Any]:
    path = DIST / "meta" / "folios.json"
    if build or not path.exists():
        build_canonical(clean=True)
    try:
        payload = read_json(path)
    except LumenError:
        raise
    if payload.get("schema") != "lumen.portable-folios/v1":
        raise LumenError("dist/meta/folios.json has an unsupported schema")
    records = payload.get("folios")
    if not isinstance(records, list):
        raise LumenError("portable folio manifest has no folio list")
    return payload


def verify_portable_folio(record: dict[str, Any]) -> Path:
    relative = str(record.get("file", ""))
    if not relative or Path(relative).is_absolute() or ".." in Path(relative).parts:
        raise LumenError("portable folio record has an unsafe file path")
    path = (DIST / relative).resolve()
    try:
        path.relative_to(DIST.resolve())
    except ValueError as exc:
        raise LumenError("portable folio path escapes dist") from exc
    if not path.is_file():
        raise LumenError(f"portable folio is missing: {relative}")
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != record.get("sha256") or len(raw) != record.get("bytes"):
        raise LumenError(f"portable folio receipt disagrees with {relative}; rebuild before export")
    return path


def cmd_folio(args: argparse.Namespace) -> int:
    payload = portable_folio_records(build=args.build)
    records = [row for row in payload.get("folios", []) if isinstance(row, dict)]
    if not args.target:
        if args.format == "json":
            print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
            return 0
        emit("folio", f"{len(records)} exact portable page folios in {payload.get('edition', 'this edition')}")
        for row in records:
            print(f"  {row.get('page_id', '?'):<28} {row.get('bytes', 0):>8} bytes  {row.get('download_name', row.get('file', ''))}")
        return 0

    _meta_path, page = resolve_page(args.target)
    record = next((row for row in records if row.get("page_id") == page.get("id")), None)
    if record is None:
        raise LumenError(f"{page.get('id')}: no portable folio is generated for this page kind or status")
    source = verify_portable_folio(record)
    if args.check:
        if args.format == "json":
            print(json.dumps(record, ensure_ascii=False, indent=2, sort_keys=True))
        else:
            emit("folio", f"exact {record['page_id']} · {record['bytes']} bytes · {record['sha256'][:12]}")
        return 0

    destination = Path(args.output or str(record.get("download_name") or source.name)).expanduser().resolve()
    if destination.exists():
        existing = hashlib.sha256(destination.read_bytes()).hexdigest() if destination.is_file() else ""
        if existing == record.get("sha256"):
            emit("folio", f"already exact: {destination}")
            return 0
        if not args.replace:
            raise LumenError(f"Refusing to replace existing nonmatching path: {destination} (use --replace)")
        if not destination.is_file():
            raise LumenError(f"Refusing to replace non-file path: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + ".tmp")
    temporary.write_bytes(source.read_bytes())
    os.replace(temporary, destination)
    if hashlib.sha256(destination.read_bytes()).hexdigest() != record.get("sha256"):
        destination.unlink(missing_ok=True)
        raise LumenError("portable folio write did not preserve the accepted bytes")
    emit("folio", f"wrote {destination} · {record['bytes']} bytes · {record['sha256'][:12]}")
    return 0


def portable_path_folio_records(*, build: bool = False) -> dict[str, Any]:
    path = DIST / "meta" / "path-folios.json"
    if build or not path.exists():
        build_canonical(clean=True)
    payload = read_json(path)
    if payload.get("schema") != "lumen.portable-path-folios/v1":
        raise LumenError("dist/meta/path-folios.json has an unsupported schema")
    records = payload.get("folios")
    if not isinstance(records, list):
        raise LumenError("portable reading-path folio manifest has no folio list")
    return payload


def verify_portable_path_folio(record: dict[str, Any]) -> Path:
    relative = str(record.get("file", ""))
    if not relative or Path(relative).is_absolute() or ".." in Path(relative).parts:
        raise LumenError("portable reading-path folio record has an unsafe file path")
    path = (DIST / relative).resolve()
    try:
        path.relative_to(DIST.resolve())
    except ValueError as exc:
        raise LumenError("portable reading-path folio path escapes dist") from exc
    if not path.is_file():
        raise LumenError(f"portable reading-path folio is missing: {relative}")
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != record.get("sha256") or len(raw) != record.get("bytes"):
        raise LumenError(f"portable reading-path folio receipt disagrees with {relative}; rebuild before export")
    return path


def resolve_path_folio_record(records: list[dict[str, Any]], target: str) -> dict[str, Any]:
    query = str(target or "").strip()
    if not query:
        raise LumenError("reading-path folio target is empty")
    normalized = slugify(query)
    matches = [
        row for row in records
        if query in {str(row.get("path_id", "")), str(row.get("file", "")), str(row.get("download_name", ""))}
        or normalized in {slugify(str(row.get("path_id", ""))), slugify(str(row.get("title", "")))}
    ]
    if len(matches) != 1:
        available = ", ".join(str(row.get("path_id")) for row in records)
        if not matches:
            raise LumenError(f"unknown reading-path folio {query!r}; available: {available}")
        raise LumenError(f"ambiguous reading-path folio {query!r}; use an exact path id")
    return matches[0]


def cmd_pathfolio(args: argparse.Namespace) -> int:
    payload = portable_path_folio_records(build=args.build)
    records = [row for row in payload.get("folios", []) if isinstance(row, dict)]
    if not args.target:
        if args.format == "json":
            print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
            return 0
        emit("pathfolio", f"{len(records)} exact portable reading-path folios in {payload.get('edition', 'this edition')}")
        for row in records:
            print(f"  {row.get('path_id', '?'):<28} {row.get('steps', 0):>2} stops  {row.get('bytes', 0):>8} bytes  {row.get('download_name', row.get('file', ''))}")
        return 0

    record = resolve_path_folio_record(records, args.target)
    source = verify_portable_path_folio(record)
    if args.check:
        if args.format == "json":
            print(json.dumps(record, ensure_ascii=False, indent=2, sort_keys=True))
        else:
            emit("pathfolio", f"exact {record['path_id']} · {record['steps']} stops · {record['bytes']} bytes · {record['sha256'][:12]}")
        return 0

    destination = Path(args.output or str(record.get("download_name") or source.name)).expanduser().resolve()
    if destination.exists():
        existing = hashlib.sha256(destination.read_bytes()).hexdigest() if destination.is_file() else ""
        if existing == record.get("sha256"):
            emit("pathfolio", f"already exact: {destination}")
            return 0
        if not args.replace:
            raise LumenError(f"Refusing to replace existing nonmatching path: {destination} (use --replace)")
        if not destination.is_file():
            raise LumenError(f"Refusing to replace non-file path: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + ".tmp")
    temporary.write_bytes(source.read_bytes())
    os.replace(temporary, destination)
    if hashlib.sha256(destination.read_bytes()).hexdigest() != record.get("sha256"):
        destination.unlink(missing_ok=True)
        raise LumenError("portable reading-path folio write did not preserve the accepted bytes")
    emit("pathfolio", f"wrote {destination} · {record['steps']} stops · {record['bytes']} bytes · {record['sha256'][:12]}")
    return 0



def normalize_return_marker_payload(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise LumenError("return marker must be a JSON object")
    page_id = str(value.get("page_id") or "")[:180]
    text_sha = str(value.get("text_sha256") or value.get("passage_text_sha256") or value.get("page_body_sha256") or "")
    if not page_id:
        raise LumenError("return marker is missing page_id")
    if not re.fullmatch(r"[0-9a-f]{64}", text_sha):
        raise LumenError("return marker text_sha256 must be a lowercase SHA-256 digest")
    scope = "passage" if value.get("scope") == "passage" else "page"
    block_index = value.get("block_index")
    if not isinstance(block_index, int) or block_index < 0:
        block_index = None
    scroll_percent = value.get("scroll_percent", 0)
    try:
        scroll_percent = max(0, min(100, round(float(scroll_percent))))
    except (TypeError, ValueError):
        scroll_percent = 0
    block_sha = str(value.get("block_text_sha256") or "")
    if block_sha and not re.fullmatch(r"[0-9a-f]{64}", block_sha):
        raise LumenError("return marker block_text_sha256 must be empty or a lowercase SHA-256 digest")
    return {
        "schema": RETURN_MARKER_SCHEMA,
        "page_id": page_id,
        "page_title": str(value.get("page_title") or "")[:500],
        "page_url": str(value.get("page_url") or value.get("url") or "/")[:1200],
        "scope": scope,
        "anchor": str(value.get("anchor") or "")[:300],
        "passage_id": str(value.get("passage_id") or "")[:300],
        "passage_title": str(value.get("passage_title") or value.get("title") or "")[:500],
        "text_sha256": text_sha,
        "page_body_sha256": str(value.get("page_body_sha256") or "")[:128],
        "block_index": block_index,
        "block_text_sha256": block_sha,
        "block_excerpt": str(value.get("block_excerpt") or "")[:480],
        "scroll_percent": scroll_percent,
        "edition": str(value.get("edition") or "")[:100],
        "source_fingerprint_sha256": str(value.get("source_fingerprint_sha256") or "")[:128],
        "recorded_at": str(value.get("recorded_at") or value.get("saved_at") or utc_now())[:100],
    }


def create_return_marker(target: str, *, build: bool = False) -> dict[str, Any]:
    page_target, anchor = split_context_target(target)
    _meta_path, meta = resolve_page(page_target)
    if build:
        build_canonical(clean=True)
        run([sys.executable, "tools/check_dist.py"])
    context_path = DIST / "meta" / "context" / f"{meta.get('id')}.json"
    receipt_path = DIST / "build-receipt.json"
    if not context_path.is_file() or not receipt_path.is_file():
        raise LumenError("return-marker context is not built; rerun with --build or run ./lumen build --clean")
    context = read_json(context_path)
    page = context.get("page", {})
    passage = None
    if anchor:
        passage = next((row for row in context.get("passages", []) if row.get("anchor") == anchor or row.get("id") == anchor), None)
        if passage is None:
            available = ", ".join(str(row.get("anchor")) for row in context.get("passages", [])) or "no authored sections"
            raise LumenError(f"no passage {anchor!r} on {meta.get('id')}; available: {available}")
    config = read_json(CONFIG)
    receipt = read_json(receipt_path)
    return normalize_return_marker_payload({
        "schema": RETURN_MARKER_SCHEMA,
        "page_id": page.get("id") or meta.get("id"),
        "page_title": page.get("title") or meta.get("title"),
        "page_url": page.get("url") or meta.get("url"),
        "scope": "passage" if passage else "page",
        "anchor": passage.get("anchor") if passage else "",
        "passage_id": passage.get("id") if passage else "",
        "passage_title": passage.get("title") if passage else "",
        "text_sha256": passage.get("text_sha256") if passage else page.get("body_sha256"),
        "page_body_sha256": page.get("body_sha256"),
        "edition": config.get("edition", "development"),
        "source_fingerprint_sha256": receipt.get("source_fingerprint_sha256", ""),
        "recorded_at": utc_now(),
    })


def review_return_marker(marker: dict[str, Any], *, build: bool = False) -> dict[str, Any]:
    marker = normalize_return_marker_payload(marker)
    if build:
        build_canonical(clean=True)
        run([sys.executable, "tools/check_dist.py"])
    try:
        _meta_path, meta = resolve_page(marker["page_id"])
    except LumenError:
        try:
            _meta_path, meta = resolve_page(marker.get("page_url", ""))
        except LumenError:
            return {
                "schema": "lumen.return-marker-review/v1",
                "status": "page-missing",
                "exact": False,
                "marker": marker,
                "target": None,
                "message": "The marked page is not present in the current accepted source tree.",
            }
    context_path = DIST / "meta" / "context" / f"{meta.get('id')}.json"
    receipt_path = DIST / "build-receipt.json"
    if not context_path.is_file() or not receipt_path.is_file():
        raise LumenError("return-marker context is not built; rerun with --build or run ./lumen build --clean")
    context = read_json(context_path)
    receipt = read_json(receipt_path)
    page = context.get("page", {})
    current_fingerprint = str(receipt.get("source_fingerprint_sha256", ""))
    target: dict[str, Any] | None = None
    status = "changed"
    message = "The marked page or passage still exists, but its accepted text changed."
    if marker["scope"] == "page":
        exact = page.get("body_sha256") == marker["text_sha256"]
        status = "exact" if exact else "changed"
        message = "The marked page is byte-for-byte the same in the current edition." if exact else message
        target = {
            "page_id": page.get("id"), "page_title": page.get("title"), "page_url": page.get("url"),
            "anchor": "", "passage_id": None, "title": page.get("title"),
            "text_sha256": page.get("body_sha256"),
        }
    else:
        passages = list(context.get("passages", []))
        direct = next((row for row in passages if row.get("id") == marker.get("passage_id") or row.get("anchor") == marker.get("anchor")), None)
        if direct and direct.get("text_sha256") == marker["text_sha256"]:
            status = "exact"
            message = "The marked passage is byte-for-byte the same in the current edition."
            target = direct
        else:
            exact_elsewhere = [row for row in passages if row.get("text_sha256") == marker["text_sha256"]]
            if len(exact_elsewhere) == 1:
                status = "moved"
                message = "The exact marked text survives under a different section identity."
                target = exact_elsewhere[0]
            elif len(exact_elsewhere) > 1:
                status = "ambiguous"
                message = "The old accepted text appears more than once, so no new location was chosen."
            elif direct:
                status = "changed"
                target = direct
            else:
                status = "passage-missing"
                message = "The marked passage is not present in the current edition."
    normalized_target = None
    if target:
        normalized_target = {
            "page_id": page.get("id"),
            "page_title": page.get("title"),
            "page_url": page.get("url"),
            "anchor": target.get("anchor") or "",
            "passage_id": target.get("id"),
            "title": target.get("title") or page.get("title"),
            "text_sha256": target.get("text_sha256") or page.get("body_sha256"),
            "excerpt": target.get("excerpt") or "",
        }
    return {
        "schema": "lumen.return-marker-review/v1",
        "status": status,
        "exact": status in {"exact", "moved"},
        "marker": marker,
        "target": normalized_target,
        "current": {
            "edition": read_json(CONFIG).get("edition", "development"),
            "source_fingerprint_sha256": current_fingerprint,
        },
        "message": message,
        "limits": [
            "Exact relocation requires one unique passage with the same accepted text SHA-256.",
            "Changed, missing, or ambiguous text is reported rather than rebound by similarity or title guesswork.",
            "A return marker records a reader-selected location, not browser history or evidence that the passage was read completely.",
        ],
    }


def return_marker_text(review: dict[str, Any]) -> str:
    marker = review.get("marker") or {}
    target = review.get("target") or {}
    lines = [
        f"status: {review.get('status')}",
        f"message: {review.get('message')}",
        f"marked: {marker.get('passage_title') or marker.get('page_title') or marker.get('page_id')}",
        f"marked identity: {marker.get('passage_id') or marker.get('page_id')}",
        f"marked text SHA-256: {marker.get('text_sha256')}",
        f"marked edition: {marker.get('edition') or 'unknown'}",
    ]
    if target:
        lines.extend([
            f"current target: {target.get('title')}",
            f"current URL: {target.get('page_url')}{'#' + target.get('anchor') if target.get('anchor') else ''}",
            f"current text SHA-256: {target.get('text_sha256')}",
        ])
    return "\n".join(lines) + "\n"


def cmd_marker(args: argparse.Namespace) -> int:
    if args.check:
        path = Path(args.check).expanduser()
        if not path.is_absolute():
            path = ROOT / path
        review = review_return_marker(read_json(path), build=args.build)
        output = json.dumps(review, ensure_ascii=False, indent=2) + "\n" if args.format == "json" else return_marker_text(review)
        if args.output:
            out = Path(args.output).expanduser()
            if not out.is_absolute():
                out = ROOT / out
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(output, encoding="utf-8")
            emit("marker", str(out.relative_to(ROOT) if out.is_relative_to(ROOT) else out))
        else:
            print(output, end="")
        return 0 if review.get("exact") else 2
    if not args.target:
        raise LumenError("marker requires PAGE[#SECTION] or --check RETURN-MARKER.json")
    marker = create_return_marker(args.target, build=args.build)
    output = json.dumps(marker, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        out = Path(args.output).expanduser()
        if not out.is_absolute():
            out = ROOT / out
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(output, encoding="utf-8")
        emit("marker", str(out.relative_to(ROOT) if out.is_relative_to(ROOT) else out))
    elif args.format == "json":
        print(output, end="")
    else:
        emit("marker", f"{marker.get('passage_id') or marker.get('page_id')} · {marker.get('passage_title') or marker.get('page_title')}")
        emit("text", marker.get("text_sha256", ""))
        emit("edition", f"{marker.get('edition')} · {marker.get('source_fingerprint_sha256', '')[:12]}")
        emit("export", "rerun with --output lumen-return-marker.json to carry this point elsewhere")
    return 0


def correction_packet_hash(payload: dict[str, Any]) -> str:
    """Hash a packet using the same stable JSON contract as the browser."""
    scoped = {key: value for key, value in payload.items() if key != "packet_content_sha256"}
    raw = json.dumps(scoped, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def correction_source_record(target: str, *, build: bool = False) -> dict[str, Any]:
    page_target, anchor = split_context_target(target)
    meta_path, meta = resolve_page(page_target)
    if build:
        build_canonical(clean=True)
        run([sys.executable, "tools/check_dist.py"])
    context_path = DIST / "meta" / "context" / f"{meta.get('id')}.json"
    receipt_path = DIST / "build-receipt.json"
    if not context_path.is_file() or not receipt_path.is_file():
        raise LumenError("correction context is not built; rerun with --build or run ./lumen build --clean")
    context = read_json(context_path)
    page = context.get("page", {})
    passage = None
    if anchor:
        passage = next((row for row in context.get("passages", []) if row.get("anchor") == anchor or row.get("id") == anchor), None)
        if passage is None:
            available = ", ".join(str(row.get("anchor")) for row in context.get("passages", [])) or "no authored sections"
            raise LumenError(f"no passage {anchor!r} on {meta.get('id')}; available: {available}")
    config = read_json(CONFIG)
    receipt = read_json(receipt_path)
    origin = str(config.get("origin", "https://sapient-lumen.github.io")).rstrip("/")
    url = origin + str(page.get("url") or meta.get("url") or "/")
    if passage:
        url += "#" + str(passage.get("anchor", ""))
    body_path = (meta_path.parent / str(meta.get("body", ""))).resolve()
    return {
        "meta_path": meta_path,
        "body_path": body_path,
        "meta": meta,
        "page": page,
        "passage": passage,
        "context_path": context_path,
        "receipt": receipt,
        "config": config,
        "exact_url": url,
    }


def create_correction_packet(
    target: str,
    *,
    issue: str,
    report_type: str = "other",
    evidence: str = "",
    boundary: str = "",
    include_quote: bool = True,
    build: bool = False,
) -> dict[str, Any]:
    issue = issue.strip()
    if not issue:
        raise LumenError("--new requires a non-empty --issue")
    source = correction_source_record(target, build=build)
    page = source["page"]
    passage = source["passage"]
    packet: dict[str, Any] = {
        "schema": CORRECTION_SCHEMA,
        "created_at": utc_now(),
        "edition": source["config"].get("edition", "development"),
        "source_fingerprint_sha256": source["receipt"].get("source_fingerprint_sha256", ""),
        "repository": source["config"].get("source_repository", "Sapient-Lumen/sapient-lumen.github.io"),
        "location": {
            "page_id": page.get("id") or source["meta"].get("id"),
            "page_title": page.get("title") or source["meta"].get("title"),
            "page_url": page.get("url") or source["meta"].get("url"),
            "page_kind": page.get("kind") or source["meta"].get("kind"),
            "page_date": page.get("date") or source["meta"].get("date"),
            "page_body_sha256": page.get("body_sha256", ""),
            "passage_id": passage.get("id") if passage else None,
            "passage_title": passage.get("title") if passage else None,
            "anchor": passage.get("anchor") if passage else None,
            "passage_text_sha256": passage.get("text_sha256") if passage else None,
            "source_html_sha256": passage.get("source_html_sha256") if passage else None,
            "source_offsets": passage.get("source_offsets") if passage else None,
            "exact_url": source["exact_url"],
        },
        "report": {
            "type": report_type,
            "issue": issue,
            "evidence_or_suggested_change": evidence.strip(),
            "boundary": boundary.strip(),
        },
        "carried_quote": passage.get("text") if include_quote and passage else None,
        "privacy": {
            "included": ["source identity", "accepted fingerprints", "reader-entered report"],
            "excluded": ["browser history", "reading trail", "reading desk", "local notes", "credentials"],
            "automatic_transmission": False,
        },
        "packet_content_sha256_scope": "UTF-8 stable JSON of every field except packet_content_sha256",
    }
    packet["packet_content_sha256"] = correction_packet_hash(packet)
    return packet


def load_correction_packet(path_value: str) -> tuple[Path, dict[str, Any]]:
    path = Path(path_value).expanduser()
    if not path.is_absolute():
        path = ROOT / path
    if not path.is_file():
        raise LumenError(f"correction packet does not exist: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise LumenError(f"cannot read correction packet: {exc}") from exc
    if payload.get("schema") != CORRECTION_SCHEMA:
        raise LumenError(f"unsupported correction packet schema: {payload.get('schema')!r}")
    declared = str(payload.get("packet_content_sha256", ""))
    actual = correction_packet_hash(payload)
    if not declared or declared != actual:
        raise LumenError(f"correction packet content hash mismatch: expected {declared or 'missing'}, calculated {actual}")
    report = payload.get("report")
    location = payload.get("location")
    if not isinstance(report, dict) or not str(report.get("issue", "")).strip():
        raise LumenError("correction packet has no concrete report.issue")
    if not isinstance(location, dict) or not str(location.get("page_id", "")).strip():
        raise LumenError("correction packet has no stable location.page_id")
    return path, payload


def correction_comparison(payload: dict[str, Any], *, build: bool = False) -> dict[str, Any]:
    location = payload["location"]
    page_id = str(location.get("page_id", ""))
    anchor = str(location.get("anchor") or "")
    target = f"{page_id}#{anchor}" if anchor else page_id
    try:
        current = correction_source_record(target, build=build)
    except LumenError as exc:
        return {
            "schema": "lumen.correction-review/v1",
            "status": "missing",
            "packet": payload,
            "message": str(exc),
            "matches": {},
            "source": None,
        }
    page = current["page"]
    passage = current["passage"]
    packet_offsets = location.get("source_offsets") or {}
    current_offsets = passage.get("source_offsets") if passage else None
    matches = {
        "source_fingerprint": str(payload.get("source_fingerprint_sha256", "")) == str(current["receipt"].get("source_fingerprint_sha256", "")),
        "page_body": str(location.get("page_body_sha256", "")) == str(page.get("body_sha256", "")),
        "passage_identity": (not location.get("passage_id")) or str(location.get("passage_id")) == str(passage.get("id") if passage else ""),
        "passage_text": (not location.get("passage_text_sha256")) or str(location.get("passage_text_sha256")) == str(passage.get("text_sha256") if passage else ""),
        "source_html": (not location.get("source_html_sha256")) or str(location.get("source_html_sha256")) == str(passage.get("source_html_sha256") if passage else ""),
        "source_offsets": (not packet_offsets) or packet_offsets == (current_offsets or {}),
    }
    source_stable = all(matches[key] for key in ("page_body", "passage_identity", "passage_text", "source_html", "source_offsets"))
    if source_stable and matches["source_fingerprint"]:
        status = "exact"
        message = "Packet and current accepted source describe the same source tree and source slice."
    elif source_stable:
        status = "passage-stable"
        message = "The accepted source tree moved, but the bound page or passage bytes still match exactly."
    else:
        status = "changed"
        message = "The current accepted page or passage differs from the packet. Review both versions; do not silently reattach the report."
    body_path: Path = current["body_path"]
    source = {
        "metadata": current["meta_path"].relative_to(ROOT).as_posix(),
        "body": body_path.relative_to(ROOT).as_posix() if body_path.is_relative_to(ROOT) else str(body_path),
        "offsets": current_offsets,
        "edit_command": f"./lumen edit {page_id}",
        "context_command": f"./lumen context {target}",
    }
    return {
        "schema": "lumen.correction-review/v1",
        "status": status,
        "message": message,
        "packet": payload,
        "current": {
            "edition": current["config"].get("edition"),
            "source_fingerprint_sha256": current["receipt"].get("source_fingerprint_sha256"),
            "page": page,
            "passage": passage,
        },
        "matches": matches,
        "source": source,
    }


def correction_review_markdown(review: dict[str, Any]) -> str:
    packet = review.get("packet", {})
    location = packet.get("location", {})
    report = packet.get("report", {})
    matches = review.get("matches", {})
    lines = [
        "# Lumen correction review",
        "",
        f"**Status:** `{review.get('status', 'unknown')}` — {review.get('message', '')}",
        "",
        "## Bound location",
        f"- Page: `{location.get('page_id', 'unknown')}` — {location.get('page_title', '')}",
        f"- Passage: `{location.get('passage_id') or 'whole page'}`",
        f"- Packet edition: `{packet.get('edition', 'unknown')}`",
        f"- Packet content SHA-256: `{packet.get('packet_content_sha256', '')}`",
        f"- URL: {location.get('exact_url', location.get('page_url', ''))}",
        "",
        "## Report",
        f"- Type: `{report.get('type', 'other')}`",
        "",
        str(report.get("issue", "")),
    ]
    if report.get("evidence_or_suggested_change"):
        lines.extend(["", "## Evidence or suggested change", str(report["evidence_or_suggested_change"])])
    if report.get("boundary"):
        lines.extend(["", "## Boundary", str(report["boundary"])])
    if matches:
        lines.extend(["", "## Identity comparison"])
        for key in ("source_fingerprint", "page_body", "passage_identity", "passage_text", "source_html", "source_offsets"):
            lines.append(f"- {'✓' if matches.get(key) else '✗'} `{key}`")
    source = review.get("source") or {}
    if source:
        offsets = source.get("offsets") or {}
        locator = source.get("body", "")
        if offsets:
            locator += f":{offsets.get('start', '?')}–{offsets.get('end', '?')}"
        lines.extend(["", "## Maintainer path", f"- Source: `{locator}`", f"- Edit: `{source.get('edit_command', '')}`", f"- Context: `{source.get('context_command', '')}`"])
    lines.extend(["", "_Validation binds the report to accepted bytes. It does not establish that the report is correct or authorize an automatic edit._", ""])
    return "\n".join(lines)


def cmd_correction(args: argparse.Namespace) -> int:
    if bool(args.packet) == bool(args.new):
        raise LumenError("provide exactly one correction packet path or --new PAGE[#SECTION]")
    if args.new:
        packet = create_correction_packet(
            args.new,
            issue=args.issue or "",
            report_type=args.type,
            evidence=args.evidence or "",
            boundary=args.boundary or "",
            include_quote=args.include_quote,
            build=args.build,
        )
        output = json.dumps(packet, ensure_ascii=False, indent=2) + "\n"
        if args.output:
            path = Path(args.output).expanduser()
            if not path.is_absolute():
                path = ROOT / path
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(output, encoding="utf-8")
            emit("packet", str(path.relative_to(ROOT) if path.is_relative_to(ROOT) else path))
            emit("identity", packet["packet_content_sha256"])
        else:
            print(output, end="")
        return 0

    path, packet = load_correction_packet(args.packet)
    review = correction_comparison(packet, build=args.build)
    if args.format == "json":
        output = json.dumps(review, ensure_ascii=False, indent=2) + "\n"
    elif args.format == "markdown":
        output = correction_review_markdown(review)
    else:
        location = packet["location"]
        emit("packet", f"{path.name} · {packet['packet_content_sha256'][:16]} · hash verified")
        emit("location", f"{location.get('passage_id') or location.get('page_id')} · {location.get('exact_url') or location.get('page_url')}")
        emit(review.get("status", "status"), str(review.get("message", "")))
        source = review.get("source") or {}
        if source:
            offsets = source.get("offsets") or {}
            locator = source.get("body", "")
            if offsets:
                locator += f":{offsets.get('start', '?')}–{offsets.get('end', '?')}"
            emit("source", locator)
            emit("edit", source.get("edit_command", ""))
            emit("context", source.get("context_command", ""))
        report = packet.get("report", {})
        emit("report", f"{report.get('type', 'other')} · {str(report.get('issue', '')).strip()}")
        output = ""
    if args.output and output:
        out = Path(args.output).expanduser()
        if not out.is_absolute():
            out = ROOT / out
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(output, encoding="utf-8")
        emit("review", str(out.relative_to(ROOT) if out.is_relative_to(ROOT) else out))
    elif output:
        print(output, end="" if output.endswith("\n") else "\n")
    return 0 if review.get("status") in {"exact", "passage-stable"} else (2 if args.check else 1)


def packet_passages(targets: list[str], *, build: bool = False) -> tuple[list[dict[str, Any]], str]:
    if build:
        build_canonical(clean=True)
        run([sys.executable, "tools/check_dist.py"])
    receipt_path = DIST / "build-receipt.json"
    if not receipt_path.is_file():
        raise LumenError("passage context is not built; run ./lumen packet --build TARGET")
    fingerprint = str(read_json(receipt_path).get("source_fingerprint_sha256", ""))
    selected: list[dict[str, Any]] = []
    seen: set[str] = set()
    for target in targets:
        page_target, anchor = split_context_target(target)
        meta_path, meta = resolve_page(page_target)
        context_path = DIST / "meta" / "context" / f"{meta.get('id')}.json"
        if not context_path.is_file():
            raise LumenError(f"context is not built for {meta.get('id')}; rerun with --build")
        context = read_json(context_path)
        passages = list(context.get("passages", []))
        if anchor:
            passages = [row for row in passages if row.get("anchor") == anchor or row.get("id") == anchor]
            if not passages:
                available = ", ".join(str(row.get("anchor")) for row in context.get("passages", [])) or "no authored sections"
                raise LumenError(f"no passage {anchor!r} on {meta.get('id')}; available: {available}")
        body_path = (meta_path.parent / str(meta.get("body", ""))).resolve()
        source_body = body_path.read_text(encoding="utf-8")
        for passage in passages:
            passage_id = str(passage.get("id"))
            if passage_id in seen:
                continue
            offsets = passage.get("source_offsets") or {}
            start = int(offsets.get("start", 0))
            end = int(offsets.get("end", 0))
            source_html = source_body[start:end]
            source_hash = hashlib.sha256(source_html.encode("utf-8")).hexdigest()
            expected = str(passage.get("source_html_sha256", ""))
            if source_hash != expected:
                raise LumenError(f"source slice changed for {passage_id}; rebuild context before making a packet")
            selected.append({
                "id": passage_id,
                "page_id": passage.get("page_id"),
                "page_title": passage.get("page_title"),
                "title": passage.get("title"),
                "anchor": passage.get("anchor"),
                "url": passage.get("url"),
                "word_count": passage.get("word_count"),
                "text": passage.get("text"),
                "text_sha256": passage.get("text_sha256"),
                "source_html": source_html,
                "source_html_sha256": source_hash,
                "source_offsets": offsets,
                "source": meta.get("source") or {},
            })
            seen.add(passage_id)
    if not selected:
        raise LumenError("no source-bound passages matched the packet request")
    return selected, fingerprint


def packet_html(payload: dict[str, Any]) -> str:
    passages = list(payload.get("passages", []))
    passage_by_id = {str(row.get("id")): row for row in passages}

    def note_html(note: str) -> str:
        if not note:
            return ""
        return (
            '<section class="reader-note"><p class="eyebrow">PRIVATE READER NOTE</p>'
            f'<p>{html_module.escape(note).replace(chr(10), "<br>")}</p></section>'
        )

    def passage_card(passage: dict[str, Any], label: str, *, note: str = "", stable_id: str = "") -> str:
        source = passage.get("source") or {}
        fieldbook_receipt = (
            f'<div><dt>Fieldbook identity</dt><dd><code>{html_module.escape(stable_id)}</code></dd></div>'
            if stable_id else ""
        )
        return (
            '<article class="passage">'
            f'<p class="eyebrow">{html_module.escape(label)} · {html_module.escape(str(passage.get("page_title", "")))}</p>'
            f'<h2>{html_module.escape(str(passage.get("title", "")))}</h2>'
            f'<div class="body">{passage.get("source_html", "")}</div>'
            f'{note_html(note)}'
            '<dl class="receipt">'
            f'{fieldbook_receipt}'
            f'<div><dt>Identity</dt><dd><code>{html_module.escape(str(passage.get("id", "")))}</code></dd></div>'
            f'<div><dt>Source HTML</dt><dd><code>{html_module.escape(str(passage.get("source_html_sha256", "")))}</code></dd></div>'
            f'<div><dt>Text</dt><dd><code>{html_module.escape(str(passage.get("text_sha256", "")))}</code></dd></div>'
            f'<div><dt>Upstream</dt><dd>{html_module.escape(str(source.get("repository", "local authored source")))} @ <code>{html_module.escape(str(source.get("sha", "")))}</code></dd></div>'
            '</dl></article>'
        )

    def quote_card(selection: dict[str, Any], label: str) -> str:
        passage = passage_by_id.get(str(selection.get("passage_id")))
        if not passage:
            raise LumenError(f"reading packet selection references missing passage {selection.get('passage_id')!r}")
        selector = selection.get("quote_selector") or {}
        source = passage.get("source") or {}
        return (
            '<article class="passage quote-selection">'
            f'<p class="eyebrow">{html_module.escape(label)} · EXACT QUOTE · {html_module.escape(str(passage.get("page_title", "")))}</p>'
            f'<h2>{html_module.escape(str(passage.get("title", "")))}</h2>'
            f'<blockquote>{html_module.escape(str(selector.get("q", "")))}</blockquote>'
            f'{note_html(str(selection.get("note", "")))}'
            '<details class="parent-passage"><summary>Read the accepted parent passage</summary>'
            f'<div class="body">{passage.get("source_html", "")}</div></details>'
            '<dl class="receipt">'
            f'<div><dt>Fieldbook identity</dt><dd><code>{html_module.escape(str(selection.get("stable_id", "")))}</code></dd></div>'
            f'<div><dt>Quote SHA-256</dt><dd><code>{html_module.escape(str(selection.get("quote_sha256", "")))}</code></dd></div>'
            f'<div><dt>Quote offset</dt><dd>{html_module.escape(str(selector.get("i", "")))}</dd></div>'
            f'<div><dt>Parent passage</dt><dd><code>{html_module.escape(str(passage.get("id", "")))}</code></dd></div>'
            f'<div><dt>Parent text</dt><dd><code>{html_module.escape(str(passage.get("text_sha256", "")))}</code></dd></div>'
            f'<div><dt>Source HTML</dt><dd><code>{html_module.escape(str(passage.get("source_html_sha256", "")))}</code></dd></div>'
            f'<div><dt>Upstream</dt><dd>{html_module.escape(str(source.get("repository", "local authored source")))} @ <code>{html_module.escape(str(source.get("sha", "")))}</code></dd></div>'
            '</dl></article>'
        )

    rows: list[str] = []
    selections = list(payload.get("selections", []))
    if selections:
        for index, selection in enumerate(selections, 1):
            scope = selection.get("scope")
            label = f"SELECTION {index:02d}"
            if scope == "quote":
                rows.append(quote_card(selection, label))
            elif scope == "page":
                passage_ids = [str(value) for value in selection.get("passage_ids", [])]
                for child_index, passage_id in enumerate(passage_ids, 1):
                    passage = passage_by_id.get(passage_id)
                    if not passage:
                        raise LumenError(f"reading packet page selection references missing passage {passage_id!r}")
                    rows.append(passage_card(
                        passage,
                        f"{label}.{child_index}",
                        note=str(selection.get("note", "")) if child_index == 1 else "",
                        stable_id=str(selection.get("stable_id", "")) if child_index == 1 else "",
                    ))
            else:
                passage = passage_by_id.get(str(selection.get("passage_id")))
                if not passage:
                    raise LumenError(f"reading packet selection references missing passage {selection.get('passage_id')!r}")
                rows.append(passage_card(
                    passage,
                    label,
                    note=str(selection.get("note", "")),
                    stable_id=str(selection.get("stable_id", "")),
                ))
    else:
        for index, passage in enumerate(passages, 1):
            rows.append(passage_card(passage, f"PASSAGE {index:02d}"))

    packet_json = json.dumps(payload, ensure_ascii=False).replace("</", "<\\/")
    count = len(selections) if selections else len(passages)
    noun = "selection" if selections else "passage"
    title = f"Lumen reading packet · {count} {noun}{'s' if count != 1 else ''}"
    style = """:root{--paper:#f4f0e5;--ink:#18231e;--muted:#647067;--line:#c6c8b7;--accent:#9f3d2c;color-scheme:light dark}@media(prefers-color-scheme:dark){:root{--paper:#121715;--ink:#e9e8df;--muted:#a9b1aa;--line:#3a433e;--accent:#e87961}}*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:18px/1.72 Georgia,serif}main{width:min(100% - 2rem,52rem);margin:auto;padding:4rem 0 8rem}header{border-bottom:2px solid var(--ink);padding-bottom:2.5rem;margin-bottom:3rem}h1{font-size:clamp(2.6rem,9vw,5.6rem);font-weight:400;letter-spacing:-.055em;line-height:.94;margin:.5rem 0 1rem}h2{font-size:clamp(1.8rem,5vw,2.7rem);font-weight:400;line-height:1.08;letter-spacing:-.03em}.eyebrow,.receipt,.lede,footer{font-family:ui-monospace,SFMono-Regular,Consolas,monospace}.eyebrow{font-size:.72rem;letter-spacing:.12em;color:var(--muted)}.lede{font-size:.82rem;color:var(--muted);max-width:46rem}.passage{padding:3rem 0;border-bottom:1px solid var(--line)}.body{max-width:43rem}a{color:var(--accent);text-underline-offset:.2em}.quote-selection blockquote{margin:1.5rem 0;padding:1rem 1.25rem;border-left:3px solid var(--accent);background:color-mix(in srgb,var(--paper) 92%,var(--accent) 4%);font-size:1.18rem}.reader-note{margin:1.5rem 0;padding:1rem 1.15rem;border:1px solid var(--line)}.reader-note p{margin:.35rem 0}.parent-passage{margin:1.5rem 0;border-top:1px solid var(--line);border-bottom:1px solid var(--line);padding:.8rem 0}.parent-passage summary{cursor:pointer;color:var(--accent);font: .75rem/1.4 ui-monospace,monospace}.parent-passage .body{padding-top:1rem}.receipt{font-size:.72rem;margin-top:2rem;border-top:1px solid var(--line);padding-top:1rem}.receipt div{display:grid;grid-template-columns:8rem 1fr;gap:1rem;margin:.35rem 0}dt{color:var(--muted)}dd{margin:0;overflow-wrap:anywhere}code{font-size:.9em}footer{font-size:.72rem;color:var(--muted);padding-top:2rem}@media(max-width:36rem){main{width:min(100% - 1.25rem,52rem);padding-top:2rem}.receipt div{display:block}dt{margin-top:.7rem}}"""
    source_label = "fieldbook selection" if selections else "authored passage"
    privacy_note = " Private reader notes are included because this packet was explicitly exported from a fieldbook." if selections else " Private reader notes are not included unless explicitly added after export."
    return (
        '<!doctype html>\n<html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        f'<meta name="robots" content="noindex,nofollow"><title>{html_module.escape(title)}</title>'
        f'<style>{style}</style></head><body><main><header>'
        '<p class="eyebrow">LUMEN · SOURCE-BOUND READING PACKET</p>'
        '<h1>A small edition<br>for close reading.</h1>'
        f'<p class="lede">{count} exact {source_label}(s), selected from source fingerprint '
        f'<code>{html_module.escape(str(payload["source_fingerprint_sha256"]))}</code>. '
        'This packet is a reading projection, not a claim of current process liveness.</p></header>'
        + ''.join(rows)
        + f'<footer>Generated {html_module.escape(str(payload["generated_at"]))} · '
        f'Packet SHA-256 is recorded in the companion JSON.{privacy_note}</footer>'
        f'</main><script type="application/json" id="lumen-reading-packet">{packet_json}</script></body></html>'
    )


def packet_targets_from_desk(path_value: str) -> tuple[list[str], str]:
    path = Path(path_value).expanduser()
    if not path.is_absolute():
        path = ROOT / path
    if not path.is_file():
        raise LumenError(f"reading desk file does not exist: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise LumenError(f"cannot read reading desk: {exc}") from exc
    if payload.get("schema") != "lumen.reading-desk/v1":
        raise LumenError("reading desk has an unsupported schema")
    targets: list[str] = []
    for entry in payload.get("entries", []):
        if not isinstance(entry, dict):
            continue
        page_id = str(entry.get("page_id") or "").strip()
        anchor = str(entry.get("anchor") or "").strip()
        stable = str(entry.get("stable_id") or "").strip()
        if page_id:
            target = f"{page_id}#{anchor}" if anchor else page_id
        elif "::" in stable:
            page_id, anchor = stable.split("::", 1)
            target = f"{page_id}#{anchor}"
        else:
            target = stable
        if target and target not in targets:
            targets.append(target)
    if not targets:
        raise LumenError("reading desk contains no resolvable page or passage identities")
    return targets, str(payload.get("source_fingerprint_sha256") or "")


def normalized_reader_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def packet_plan_from_fieldbook(path_value: str) -> tuple[list[str], str, list[dict[str, Any]]]:
    path = Path(path_value).expanduser()
    if not path.is_absolute():
        path = ROOT / path
    if not path.is_file():
        raise LumenError(f"fieldbook file does not exist: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise LumenError(f"cannot read fieldbook: {exc}") from exc
    if payload.get("schema") != FIELDBOOK_SCHEMA:
        raise LumenError("fieldbook has an unsupported schema")
    targets: list[str] = []
    entries: list[dict[str, Any]] = []
    for raw in payload.get("entries", []):
        if not isinstance(raw, dict):
            continue
        scope = str(raw.get("scope") or "passage").strip()
        if scope not in {"page", "passage", "quote"}:
            raise LumenError(f"fieldbook entry has unsupported scope: {scope!r}")
        stable_id = str(raw.get("stable_id") or raw.get("id") or "").strip()
        page_id = str(raw.get("page_id") or "").strip()
        anchor = str(raw.get("anchor") or "").strip()
        if not page_id and "::" in stable_id and scope != "quote":
            page_id, anchor = stable_id.split("::", 1)
        elif not page_id:
            page_id = stable_id
        if not page_id:
            raise LumenError("fieldbook entry has no stable page identity")
        if scope in {"passage", "quote"} and not anchor:
            raise LumenError(f"fieldbook {scope} entry {stable_id!r} has no passage anchor")
        selector = raw.get("quote_selector") or raw.get("quote")
        if scope == "quote" and not isinstance(selector, dict):
            raise LumenError(f"fieldbook quote entry {stable_id!r} has no quote selector")
        target = page_id if scope == "page" else f"{page_id}#{anchor}"
        if target not in targets:
            targets.append(target)
        entries.append({
            "stable_id": stable_id or target,
            "scope": scope,
            "page_id": page_id,
            "anchor": anchor,
            "title": str(raw.get("title") or "")[:500],
            "note": str(raw.get("note") or "")[:4000],
            "text_sha256": str(raw.get("text_sha256") or raw.get("body_sha256") or ""),
            "quote_sha256": str(raw.get("quote_sha256") or ""),
            "quote_selector": selector if isinstance(selector, dict) else None,
            "source_fingerprint_sha256": str(raw.get("source_fingerprint_sha256") or ""),
            "edition": str(raw.get("edition") or ""),
        })
    if not entries:
        raise LumenError("fieldbook contains no resolvable page, passage, or quote entries")
    return targets, str(payload.get("source_fingerprint_sha256") or ""), entries


def locate_fieldbook_quote(passage: dict[str, Any], entry: dict[str, Any]) -> tuple[dict[str, Any], str]:
    selector = dict(entry.get("quote_selector") or {})
    quote = normalized_reader_text(selector.get("q") or selector.get("quote"))
    if len(quote) < 3 or len(quote) > 700:
        raise LumenError(f"fieldbook quote {entry.get('stable_id')!r} has an invalid length")
    passage_text = normalized_reader_text(passage.get("text"))
    expected_hash = str(selector.get("h") or "")
    current_hash = str(passage.get("text_sha256") or "")
    if expected_hash and expected_hash != current_hash:
        raise LumenError(f"fieldbook quote {entry.get('stable_id')!r} belongs to another passage revision")
    declared = selector.get("i")
    index = int(declared) if isinstance(declared, int) or (isinstance(declared, str) and declared.isdigit()) else -1
    if index < 0 or passage_text[index:index + len(quote)] != quote:
        offsets: list[int] = []
        cursor = passage_text.find(quote)
        while cursor >= 0 and len(offsets) < 64:
            offsets.append(cursor)
            cursor = passage_text.find(quote, cursor + max(1, len(quote)))
        before = str(selector.get("b") or "")
        after = str(selector.get("n") or "")
        if len(offsets) == 1:
            index = offsets[0]
        else:
            matches = [
                row for row in offsets
                if passage_text[max(0, row - len(before)):row] == before
                and passage_text[row + len(quote):row + len(quote) + len(after)] == after
            ]
            index = matches[0] if len(matches) == 1 else -1
    if index < 0:
        raise LumenError(f"fieldbook quote {entry.get('stable_id')!r} no longer binds exactly to the accepted passage")
    quote_hash = hashlib.sha256(quote.encode("utf-8")).hexdigest()
    declared_hash = str(entry.get("quote_sha256") or "")
    if declared_hash and declared_hash != quote_hash:
        raise LumenError(f"fieldbook quote {entry.get('stable_id')!r} has a quote fingerprint mismatch")
    normalized = {
        "v": 1,
        "p": str(entry.get("page_id") or passage.get("page_id") or ""),
        "a": str(entry.get("anchor") or passage.get("anchor") or ""),
        "q": quote,
        "i": index,
        "b": passage_text[max(0, index - 48):index],
        "n": passage_text[index + len(quote):index + len(quote) + 48],
        "h": current_hash,
        "e": str(selector.get("e") or entry.get("edition") or ""),
    }
    return normalized, quote_hash


def fieldbook_packet_selections(entries: list[dict[str, Any]], passages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    passage_by_page_anchor = {
        (str(row.get("page_id")), str(row.get("anchor"))): row for row in passages
    }
    passages_by_page: dict[str, list[dict[str, Any]]] = {}
    for row in passages:
        passages_by_page.setdefault(str(row.get("page_id")), []).append(row)
    context_cache: dict[str, dict[str, Any]] = {}
    selections: list[dict[str, Any]] = []
    for entry in entries:
        page_id = str(entry.get("page_id"))
        scope = str(entry.get("scope"))
        context_path = DIST / "meta" / "context" / f"{page_id}.json"
        if page_id not in context_cache:
            if not context_path.is_file():
                raise LumenError(f"context is not built for fieldbook page {page_id}; rerun with --build")
            context_cache[page_id] = read_json(context_path)
        context = context_cache[page_id]
        if scope == "page":
            current_hash = str((context.get("page") or {}).get("body_sha256") or "")
            declared_hash = str(entry.get("text_sha256") or "")
            if declared_hash and declared_hash != current_hash:
                raise LumenError(f"fieldbook page {entry.get('stable_id')!r} belongs to another accepted revision")
            page_passages = passages_by_page.get(page_id, [])
            if not page_passages:
                raise LumenError(f"fieldbook page {page_id!r} has no source-bound passages")
            selections.append({
                "stable_id": entry.get("stable_id"),
                "scope": "page",
                "page_id": page_id,
                "passage_ids": [row.get("id") for row in page_passages],
                "note": entry.get("note") or "",
                "source_fingerprint_sha256": entry.get("source_fingerprint_sha256") or "",
            })
            continue
        passage = passage_by_page_anchor.get((page_id, str(entry.get("anchor"))))
        if not passage:
            raise LumenError(f"fieldbook entry {entry.get('stable_id')!r} references a missing passage")
        declared_hash = str(entry.get("text_sha256") or "")
        current_hash = str(passage.get("text_sha256") or "")
        if declared_hash and declared_hash != current_hash:
            raise LumenError(f"fieldbook passage {entry.get('stable_id')!r} belongs to another accepted revision")
        selection = {
            "stable_id": entry.get("stable_id"),
            "scope": scope,
            "page_id": page_id,
            "passage_id": passage.get("id"),
            "anchor": passage.get("anchor"),
            "note": entry.get("note") or "",
            "source_fingerprint_sha256": entry.get("source_fingerprint_sha256") or "",
        }
        if scope == "quote":
            selector, quote_hash = locate_fieldbook_quote(passage, entry)
            selection["quote_selector"] = selector
            selection["quote_sha256"] = quote_hash
        selections.append(selection)
    return selections


def cmd_packet(args: argparse.Namespace) -> int:
    targets = list(args.targets or [])
    desk_fingerprint = ""
    fieldbook_fingerprint = ""
    fieldbook_entries: list[dict[str, Any]] = []
    if args.fieldbook and (targets or args.desk):
        raise LumenError("--fieldbook is a complete ordered selection; do not combine it with targets or --desk")
    if args.fieldbook:
        targets, fieldbook_fingerprint, fieldbook_entries = packet_plan_from_fieldbook(args.fieldbook)
    elif args.desk:
        desk_targets, desk_fingerprint = packet_targets_from_desk(args.desk)
        targets.extend(target for target in desk_targets if target not in targets)
    if not targets:
        raise LumenError("packet needs PAGE[#SECTION] targets, --desk EXPORTED-DESK.json, or --fieldbook EXPORTED-FIELDBOOK.json")
    passages, fingerprint = packet_passages(targets, build=args.build)
    generated = utc_now()
    selections = fieldbook_packet_selections(fieldbook_entries, passages) if fieldbook_entries else []
    payload: dict[str, Any] = {
        "schema": "lumen.reading-packet/v2" if selections else "lumen.reading-packet/v1",
        "generated_at": generated,
        "source_fingerprint_sha256": fingerprint,
        "targets": targets,
        "reading_desk_source_fingerprint_sha256": desk_fingerprint or None,
        "fieldbook_source_fingerprint_sha256": fieldbook_fingerprint or None,
        "passages": passages,
        "selections": selections,
    }
    stamp = generated.replace("-", "").replace(":", "").replace("T", "-").replace("Z", "")
    output = Path(args.output) if args.output else ROOT / "packets" / f"lumen-reading-packet-{stamp}.html"
    if not output.is_absolute():
        output = ROOT / output
    output.parent.mkdir(parents=True, exist_ok=True)
    html_text = packet_html(payload)
    output.write_text(html_text, encoding="utf-8")
    payload["html_sha256"] = hashlib.sha256(html_text.encode("utf-8")).hexdigest()
    json_path = output.with_suffix(".json")
    write_json(json_path, payload)
    shown = output.relative_to(ROOT).as_posix() if output.is_relative_to(ROOT) else str(output)
    shown_json = json_path.relative_to(ROOT).as_posix() if json_path.is_relative_to(ROOT) else str(json_path)
    count = len(selections) if selections else len(passages)
    label = "source-bound fieldbook selection(s)" if selections else "source-bound passage(s)"
    emit("packet", f"{shown} · {count} {label}")
    emit("receipt", f"{shown_json} · {payload['html_sha256'][:16]}")
    emit("open", f"file://{output}")
    return 0


def cmd_edit(args: argparse.Namespace) -> int:
    path, data = resolve_page(args.target)
    body_path = (path.parent / str(data.get("body", ""))).resolve()
    target = path if args.metadata else body_path
    if not target.is_file():
        raise LumenError(f"editable file is missing: {target}")
    shown = target.relative_to(ROOT).as_posix()
    if args.path_only:
        print(shown)
        return 0
    editor = args.editor or os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if not editor:
        for candidate in ("nano", "vim", "vi"):
            if shutil.which(candidate):
                editor = candidate
                break
    if not editor:
        emit("edit", shown)
        emit("next", "set $EDITOR or pass --editor; ./lumen start provides live preview")
        return 0
    command = shlex.split(editor) + [str(target)]
    emit("edit", f"{shown} · {' '.join(command[:-1])}")
    result = subprocess.run(command, cwd=ROOT, check=False)
    return int(result.returncode)


def publication_blockers(data: dict[str, Any]) -> list[str]:
    blockers: list[str] = []
    description = str(data.get("description", ""))
    source = data.get("source") or {}
    if not description or description.startswith("Draft description"):
        blockers.append("replace the draft description")
    if source.get("repository") in {None, "", "unassigned"}:
        blockers.append("assign source.repository")
    if source.get("sha") in {None, "", "draft-unreviewed"}:
        blockers.append("replace source.sha with a reviewed identity or an explicit non-hash status")
    if not data.get("limits"):
        blockers.append("record at least one interpretation limit")
    return blockers


def cmd_publish(args: argparse.Namespace) -> int:
    path, data = resolve_draft(args.target)
    blockers = publication_blockers(data)
    if blockers:
        for blocker in blockers:
            emit("block", blocker)
        raise LumenError("draft remains unpublished")
    data["status"] = "published"
    data["tags"] = [tag for tag in data.get("tags", []) if tag != "draft"]
    label = str(data.get("label", ""))
    if label.startswith("Draft "):
        data["label"] = label[6:].capitalize()
    source = data.get("source") or {}
    if str(source.get("status", "")).lower().startswith("draft"):
        source["status"] = "Accepted into the canonical source tree; deployment remains a separate verified effect"
    data["source"] = source
    write_json(path, data)
    if data.get("kind") == "note":
        append_revision(path, data, summary=args.summary or "First published in Lumen’s Field Notes.", date=str(data.get("date") or ""), source_ref="Initial accepted publication")
    emit("published", f"{data.get('id')} now participates in canonical builds")
    emit("next", "run ./lumen verify --canonical and inspect the resulting receipt")
    return 0


def github_json(url: str, token: str | None = None) -> Any:
    headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": "lumen-cloudtainer-toolkit/2",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=25) as response:
            return json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError) as exc:
        raise LumenError(f"GitHub request failed for {url}: {exc}") from exc


def source_change(old: dict[str, Any], new: dict[str, Any]) -> dict[str, Any]:
    return {
        "repository": new.get("name") or old.get("name"),
        "from": old.get("head_sha"),
        "to": new.get("head_sha"),
        "message": new.get("head_message", "Repository head changed"),
        "observed_at": new.get("pushed_at"),
        "summary": "Repository identity changed. Inspect the diff and affected claims before editorial adoption.",
    }


def current_repository_state(owner: str, previous: dict[str, Any]) -> tuple[list[dict[str, Any]], list[str], list[dict[str, Any]], list[dict[str, Any]]]:
    token = os.environ.get("GITHUB_TOKEN")
    query = urllib.parse.urlencode({"per_page": 100, "sort": "updated", "direction": "desc", "type": "owner"})
    repos = github_json(f"https://api.github.com/users/{urllib.parse.quote(owner)}/repos?{query}", token)
    if not isinstance(repos, list):
        raise LumenError("GitHub repository listing returned an unexpected payload")
    previous_by_name = {row.get("name"): row for row in previous.get("repositories", [])}
    rows: list[dict[str, Any]] = []
    drift: list[str] = []
    activity: list[dict[str, Any]] = []
    changes: list[dict[str, Any]] = []
    for repo in repos:
        full_name = repo.get("full_name")
        if not full_name or repo.get("fork") or repo.get("archived"):
            continue
        branch = repo.get("default_branch") or "main"
        commit = github_json(f"https://api.github.com/repos/{full_name}/commits/{urllib.parse.quote(branch)}", token)
        sha = str(commit.get("sha", ""))
        message = str(commit.get("commit", {}).get("message", "")).splitlines()[0]
        committed = commit.get("commit", {}).get("committer", {}).get("date") or repo.get("pushed_at")
        old = previous_by_name.get(full_name, {})
        row = {
            "name": full_name,
            "role": old.get("role", "public repository discovered during source sync"),
            "head_sha": sha,
            "head_short": sha[:12],
            "head_message": message,
            "pushed_at": committed,
            "url": repo.get("html_url"),
            "language": repo.get("language"),
            "signals": old.get("signals", ["new repository; editorial role not yet reviewed"]),
            "selected_files": old.get("selected_files", []),
        }
        if row["selected_files"]:
            tree = github_json(f"https://api.github.com/repos/{full_name}/git/trees/{urllib.parse.quote(branch)}?recursive=1", token)
            by_path = {item.get("path"): item for item in tree.get("tree", []) if item.get("type") == "blob"}
            selected = []
            for item in row["selected_files"]:
                fresh = by_path.get(item.get("path"))
                selected.append({
                    "path": item.get("path"),
                    "sha": fresh.get("sha") if fresh else "not-observed",
                    "bytes": fresh.get("size") if fresh else None,
                })
            row["selected_files"] = selected
        recent_query = urllib.parse.urlencode({"sha": branch, "per_page": 3})
        recent = github_json(f"https://api.github.com/repos/{full_name}/commits?{recent_query}", token)
        if isinstance(recent, list):
            for item in recent:
                item_sha = str(item.get("sha", ""))
                activity.append({
                    "repository": full_name,
                    "sha": item_sha,
                    "short_sha": item_sha[:12],
                    "message": str(item.get("commit", {}).get("message", "")).splitlines()[0],
                    "committed_at": item.get("commit", {}).get("committer", {}).get("date"),
                    "url": item.get("html_url"),
                })
        rows.append(row)
        old_sha = old.get("head_sha")
        if not old:
            drift.append(f"NEW {full_name} @ {sha[:12]}")
            changes.append(source_change({}, row))
        elif old_sha != sha:
            drift.append(f"CHANGED {full_name}: {str(old_sha)[:12]} -> {sha[:12]} · {message}")
            changes.append(source_change(old, row))
    live_names = {row["name"] for row in rows}
    for name, old in previous_by_name.items():
        if name not in live_names:
            drift.append(f"RETIREMENT CANDIDATE {name} (captured {str(old.get('head_sha', ''))[:12]})")
            changes.append({
                "repository": name,
                "from": old.get("head_sha"),
                "to": None,
                "status": "retirement-unconfirmed",
                "message": "Repository was not observed in the current public listing",
                "observed_at": utc_now(),
                "summary": "Absence from one listing is not proof of deletion. Explicit --confirm-retire is required before acceptance.",
            })
    order = {name: index for index, name in enumerate(previous_by_name)}
    rows.sort(key=lambda row: (order.get(row["name"], 10_000), row["name"].lower()))
    activity.sort(key=lambda row: str(row.get("committed_at") or ""), reverse=True)
    return rows, drift, activity, changes


def snapshot_candidate(owner: str, previous: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
    rows, drift, activity, changes = current_repository_state(owner, previous)
    candidate = {
        "schema": "lumen.upstream-snapshot/v4",
        "captured_at": utc_now(),
        "owner": owner,
        "source": "GitHub public API; requests performed only by ./lumen sync",
        "previous_capture": {
            "captured_at": previous.get("captured_at"),
            "repositories": [
                {"name": row.get("name"), "head_sha": row.get("head_sha")}
                for row in previous.get("repositories", [])
            ],
        },
        "repositories": rows,
        "retired_sources": list(previous.get("retired_sources", [])),
        "changes_since_previous": changes,
        "activity": activity,
        "limits": previous.get("limits", []),
    }
    return candidate, drift


def drift_report(snapshot: dict[str, Any], drift: list[str]) -> str:
    lines = [
        "# Upstream source drift review",
        "",
        f"Observed: {snapshot['captured_at']}",
        f"Owner: `{snapshot['owner']}`",
        "",
        "This report records public repository identity changes. It does not silently adopt upstream prose, certify safety, or establish liveness after the observation time.",
        "",
        "## Result",
        "",
    ]
    if drift:
        lines.extend(f"- {item}" for item in drift)
    else:
        lines.append("- No repository-head drift was observed relative to the accepted snapshot.")
    lines.extend([
        "",
        "## Candidate",
        "",
        f"- Repositories: {len(snapshot.get('repositories', []))}",
        f"- Structured changes: {len(snapshot.get('changes_since_previous', []))}",
        f"- Recent commit records: {len(snapshot.get('activity', []))}",
        "",
        "## Review boundary",
        "",
        "A changed head is a prompt to inspect the diff and affected claims. It is not permission to rewrite the site automatically. `./lumen sync --accept` promotes only this machine-readable candidate; editorial pages remain separate.",
        "",
        "A missing repository is staged only as a retirement candidate. Accepting it requires `./lumen sync --accept --confirm-retire OWNER/REPO`; the command records the last accepted identity instead of silently erasing it.",
        "",
    ])
    return "\n".join(lines)


def stage_snapshot(candidate: dict[str, Any], report: str) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    write_json(CANDIDATE, candidate)
    CANDIDATE_REPORT.write_text(report, encoding="utf-8")
    emit("staged", CANDIDATE.relative_to(ROOT).as_posix())
    emit("staged", CANDIDATE_REPORT.relative_to(ROOT).as_posix())


def retirement_candidates(snapshot: dict[str, Any]) -> list[str]:
    return sorted({
        str(change.get("repository"))
        for change in snapshot.get("changes_since_previous", [])
        if change.get("to") is None and change.get("repository")
    })


def update_config_snapshot(snapshot: dict[str, Any]) -> None:
    config = read_json(CONFIG)
    source_config = config.setdefault("source_snapshot", {})
    source_config["captured_at"] = snapshot.get("captured_at")
    for key in set(SOURCE_KEY_BY_REPOSITORY.values()):
        source_config.pop(key, None)
    for repo in snapshot.get("repositories", []):
        key = SOURCE_KEY_BY_REPOSITORY.get(str(repo.get("name")))
        if key:
            source_config[key] = repo.get("head_sha")
    write_json(CONFIG, config)


def accept_staged_snapshot(confirm_retire: list[str] | None = None) -> int:
    if not CANDIDATE.is_file():
        raise LumenError("no staged candidate; run ./lumen sync --stage")
    candidate = read_json(CANDIDATE)
    if candidate.get("schema") != "lumen.upstream-snapshot/v4":
        raise LumenError("staged candidate has an unsupported schema")
    confirmations = set(confirm_retire or [])
    retirements = retirement_candidates(candidate)
    missing = [name for name in retirements if name not in confirmations]
    extras = sorted(confirmations.difference(retirements))
    if extras:
        raise LumenError(f"--confirm-retire does not match a staged retirement candidate: {', '.join(extras)}")
    if missing:
        commands = " ".join(f"--confirm-retire {name}" for name in missing)
        raise LumenError(f"explicit retirement confirmation required: ./lumen sync --accept {commands}")

    previous = read_json(SNAPSHOT)
    previous_by_name = {row.get("name"): row for row in previous.get("repositories", [])}
    retired = {row.get("name"): row for row in candidate.get("retired_sources", []) if row.get("name")}
    for name in retirements:
        old = previous_by_name.get(name, {})
        retired[name] = {
            "name": name,
            "role": old.get("role", "retired public repository"),
            "last_head_sha": old.get("head_sha"),
            "last_head_short": str(old.get("head_sha", ""))[:12],
            "retired_at": candidate.get("captured_at"),
            "reason": "Explicit operator confirmation after the repository was absent from the public owner listing.",
            "current_projection": "Not carried as an active repository or route; last accepted identity retained as a boundary receipt.",
        }
        for change in candidate.get("changes_since_previous", []):
            if change.get("repository") == name and change.get("to") is None:
                change["status"] = "retired-confirmed"
                change["summary"] = "Explicitly confirmed retirement; last accepted identity retained in retired_sources."
    candidate["retired_sources"] = sorted(retired.values(), key=lambda row: str(row.get("name", "")).lower())

    archive_dir = RESEARCH / "source-snapshots"
    archive_dir.mkdir(parents=True, exist_ok=True)
    previous_stamp = str(previous.get("captured_at", "unknown")).replace(":", "").replace("-", "")
    write_json(archive_dir / f"source-snapshot-{previous_stamp}.json", previous)
    write_json(SNAPSHOT, candidate)
    update_config_snapshot(candidate)
    stamp = str(candidate["captured_at"]).replace(":", "").replace("-", "")
    report = CANDIDATE_REPORT.read_text(encoding="utf-8") if CANDIDATE_REPORT.exists() else drift_report(candidate, [])
    (RESEARCH / f"UPSTREAM-DRIFT-{stamp}.md").write_text(report, encoding="utf-8")
    CANDIDATE.unlink(missing_ok=True)
    CANDIDATE_REPORT.unlink(missing_ok=True)
    emit("accepted", f"source snapshot {candidate.get('captured_at')}")
    for name in retirements:
        emit("retired", f"{name} · last accepted identity preserved")
    emit("preserve", archive_dir.relative_to(ROOT).as_posix() if archive_dir.is_relative_to(ROOT) else str(archive_dir))
    emit("review", "authored pages were not modified")
    return 0


def cmd_sync(args: argparse.Namespace) -> int:
    if args.accept:
        return accept_staged_snapshot(args.confirm_retire)
    previous = read_json(SNAPSHOT)
    candidate, drift = snapshot_candidate(args.owner, previous)
    report = drift_report(candidate, drift)
    if args.check:
        print(report)
        emit("drift" if drift else "current", f"{len(drift)} repository-head change(s)")
        return 3 if drift else 0
    stage_snapshot(candidate, report)
    emit("review", f"{len(drift)} change(s); inspect, then run ./lumen sync --accept")
    return 0



def checkpoint_files() -> list[tuple[str, Path, int]]:
    rows: list[tuple[str, Path, int]] = []
    for name in CHECKPOINT_ROOTS:
        source = ROOT / name
        if not source.exists():
            continue
        candidates = [source] if source.is_file() else sorted(source.rglob("*"))
        for path in candidates:
            if path.is_symlink():
                raise LumenError(f"checkpoint refuses symbolic link: {path.relative_to(ROOT)}")
            if not path.is_file():
                continue
            if "__pycache__" in path.parts or path.name.endswith(".pyc") or path.name == ".DS_Store":
                continue
            rel = path.relative_to(ROOT).as_posix()
            mode = 0o755 if path.stat().st_mode & 0o111 else 0o644
            rows.append((rel, path, mode))
    return sorted(rows, key=lambda row: row[0])


def checkpoint_fingerprint(rows: list[tuple[str, bytes, int]]) -> str:
    digest = hashlib.sha256()
    for name, data, mode in rows:
        digest.update(name.encode("utf-8"))
        digest.update(b"\0")
        digest.update(f"{mode:o}".encode("ascii"))
        digest.update(b"\0")
        digest.update(hashlib.sha256(data).digest())
    return digest.hexdigest()


def checkpoint_output_dir(value: str | None) -> Path:
    chosen = value or os.environ.get("LUMEN_CHECKPOINT_DIR")
    path = Path(chosen).expanduser() if chosen else ROOT.parent / "lumen-checkpoints"
    if not path.is_absolute():
        path = ROOT / path
    return path.resolve()


def build_worktree_checkpoint(output_dir: Path) -> tuple[Path, dict[str, Any]]:
    files = checkpoint_files()
    payload_rows = [(rel, path.read_bytes(), mode) for rel, path, mode in files]
    fingerprint = checkpoint_fingerprint(payload_rows)
    config = read_json(CONFIG)
    snapshot = read_json(SNAPSHOT)
    edition = str(config.get("edition", "development"))
    member_records = [
        {
            "path": f"Lumen/{rel}",
            "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
            "mode": f"{mode:04o}",
        }
        for rel, data, mode in payload_rows
    ]
    manifest = {
        "schema": CHECKPOINT_SCHEMA,
        "edition": edition,
        "content_identity_sha256": fingerprint,
        "source_snapshot_captured_at": snapshot.get("captured_at"),
        "source_snapshot_sha256": hashlib.sha256(SNAPSHOT.read_bytes()).hexdigest(),
        "selection": "allowlisted editable worktree; generated dist, .git, .lumen, research evidence, releases, handoffs, and credentials are excluded",
        "members": member_records,
    }
    readme = (
        "LUMEN WORKTREE CHECKPOINT\n\n"
        "This is a private recovery object for the editable publication worktree.\n"
        "It is not the public site, not a live-process snapshot, and not a credential backup.\n\n"
        "Verify:  ./lumen reopen FILE --verify-only\n"
        "Reopen:  ./lumen reopen FILE --into ../recovered-Lumen\n"
    ).encode("utf-8")
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = output_dir / f"lumen-worktree-{edition}-{fingerprint[:12]}.zip"
    stamp = normalized_zip_time()
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for name, data, mode in [
            ("LUMEN-CHECKPOINT.json", manifest_bytes, 0o644),
            ("README.txt", readme, 0o644),
            *[(f"Lumen/{rel}", data, mode) for rel, data, mode in payload_rows],
        ]:
            info = zipfile.ZipInfo(name, stamp)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (mode & 0xFFFF) << 16
            zf.writestr(info, data)
    verified = verify_worktree_checkpoint(archive)
    if verified.get("content_identity_sha256") != fingerprint:
        raise LumenError("checkpoint verification returned an unexpected content identity")
    digest = sha256(archive)
    receipt = {
        "schema": "lumen.worktree-checkpoint-receipt/v1",
        "written_at": utc_now(),
        "archive": archive.name,
        "archive_sha256": digest,
        "archive_bytes": archive.stat().st_size,
        "edition": edition,
        "content_identity_sha256": fingerprint,
        "members": len(member_records),
        "uncompressed_bytes": sum(row["bytes"] for row in member_records),
        "network_used": False,
        "public_release": False,
    }
    write_json(archive.with_suffix(".receipt.json"), receipt)
    archive.with_suffix(".sha256").write_text(f"{digest}  {archive.name}\n", encoding="utf-8")
    return archive, receipt


def safe_checkpoint_member(name: str) -> PurePosixPath:
    if "\\" in name:
        raise LumenError(f"checkpoint member uses a backslash: {name!r}")
    path = PurePosixPath(name)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise LumenError(f"unsafe checkpoint member path: {name!r}")
    return path


def verify_worktree_checkpoint(path: Path) -> dict[str, Any]:
    path = path.expanduser().resolve()
    if not path.is_file():
        raise LumenError(f"checkpoint does not exist: {path}")
    try:
        with zipfile.ZipFile(path) as zf:
            infos = zf.infolist()
            names = [info.filename for info in infos]
            if len(names) != len(set(names)):
                raise LumenError("checkpoint contains duplicate member names")
            for info in infos:
                safe_checkpoint_member(info.filename)
                mode = (info.external_attr >> 16) & 0o177777
                if stat.S_ISLNK(mode):
                    raise LumenError(f"checkpoint contains a symbolic link: {info.filename}")
                if info.flag_bits & 0x1:
                    raise LumenError(f"checkpoint contains an encrypted member: {info.filename}")
            try:
                manifest = json.loads(zf.read("LUMEN-CHECKPOINT.json"))
            except KeyError as exc:
                raise LumenError("checkpoint lacks LUMEN-CHECKPOINT.json") from exc
            except json.JSONDecodeError as exc:
                raise LumenError(f"checkpoint manifest is invalid JSON: {exc}") from exc
            if manifest.get("schema") != CHECKPOINT_SCHEMA:
                raise LumenError("checkpoint manifest schema is unsupported")
            expected = {str(row.get("path")): row for row in manifest.get("members", [])}
            actual = {name for name in names if name.startswith("Lumen/")}
            if actual != set(expected):
                raise LumenError(f"checkpoint member set disagrees with manifest: missing={sorted(set(expected)-actual)}, extra={sorted(actual-set(expected))}")
            fingerprint_rows: list[tuple[str, bytes, int]] = []
            by_name = {info.filename: info for info in infos}
            for name in sorted(expected):
                row = expected[name]
                data = zf.read(name)
                digest = hashlib.sha256(data).hexdigest()
                mode = ((by_name[name].external_attr >> 16) & 0o777) or 0o644
                declared_mode = int(str(row.get("mode", "0644")), 8)
                if len(data) != row.get("bytes") or digest != row.get("sha256") or mode != declared_mode:
                    raise LumenError(f"checkpoint member receipt disagrees: {name}")
                fingerprint_rows.append((name.removeprefix("Lumen/"), data, mode))
            fingerprint = checkpoint_fingerprint(fingerprint_rows)
            if fingerprint != manifest.get("content_identity_sha256"):
                raise LumenError("checkpoint content identity disagrees with its members")
            return manifest
    except zipfile.BadZipFile as exc:
        raise LumenError(f"checkpoint is not a valid ZIP archive: {exc}") from exc


def cmd_preserve(args: argparse.Namespace) -> int:
    if args.verify:
        cmd_verify(argparse.Namespace(canonical=False))
    output = checkpoint_output_dir(args.output)
    archive, receipt = build_worktree_checkpoint(output)
    emit("preserve", str(archive))
    emit("identity", str(receipt["content_identity_sha256"]))
    emit("sha256", str(receipt["archive_sha256"]))
    emit("boundary", "editable source and drafts only; no dist, credentials, .git, .lumen, or private runtime data")
    return 0


def cmd_reopen(args: argparse.Namespace) -> int:
    archive = Path(args.checkpoint).expanduser()
    if not archive.is_absolute():
        archive = ROOT / archive
    manifest = verify_worktree_checkpoint(archive)
    emit("verified", f"{archive} · {len(manifest.get('members', []))} members · {str(manifest.get('content_identity_sha256', ''))[:16]}")
    if args.verify_only:
        return 0
    if not args.into:
        raise LumenError("reopen requires --into DIRECTORY unless --verify-only is used")
    target = Path(args.into).expanduser().resolve()
    if target.exists():
        raise LumenError(f"reopen target already exists; choose a new empty path: {target}")
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = Path(tempfile.mkdtemp(prefix=f".{target.name}.reopen-", dir=target.parent))
    try:
        with zipfile.ZipFile(archive) as zf:
            by_name = {info.filename: info for info in zf.infolist()}
            for row in manifest.get("members", []):
                name = str(row["path"])
                rel = safe_checkpoint_member(name).relative_to("Lumen")
                out = temp.joinpath(*rel.parts)
                out.parent.mkdir(parents=True, exist_ok=True)
                data = zf.read(name)
                out.write_bytes(data)
                mode = int(str(row.get("mode", "0644")), 8)
                out.chmod(mode)
                if hashlib.sha256(out.read_bytes()).hexdigest() != row.get("sha256"):
                    raise LumenError(f"reopened file failed readback: {rel}")
        os.replace(temp, target)
    except Exception:
        shutil.rmtree(temp, ignore_errors=True)
        raise
    emit("reopened", str(target))
    emit("next", f"cd {shlex.quote(str(target))} && ./lumen doctor && ./lumen start")
    return 0

def normalized_zip_time() -> tuple[int, int, int, int, int, int]:
    epoch = os.environ.get("SOURCE_DATE_EPOCH")
    if epoch:
        instant = dt.datetime.fromtimestamp(int(epoch), tz=dt.timezone.utc)
    else:
        snapshot = read_json(SNAPSHOT)
        instant = dt.datetime.fromisoformat(str(snapshot["captured_at"]).replace("Z", "+00:00"))
    year = max(1980, instant.year)
    return (year, instant.month, instant.day, instant.hour, instant.minute, instant.second - instant.second % 2)


def zip_tree(source: Path, target: Path, *, prefix: str = "") -> None:
    stamp = normalized_zip_time()
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(p for p in source.rglob("*") if p.is_file()):
            rel = path.relative_to(source).as_posix()
            name = f"{prefix.strip('/')}/{rel}" if prefix else rel
            info = zipfile.ZipInfo(name, stamp)
            info.compress_type = zipfile.ZIP_DEFLATED
            mode = 0o755 if path.stat().st_mode & 0o111 else 0o644
            info.external_attr = (mode & 0xFFFF) << 16
            archive.writestr(info, path.read_bytes())


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def release_build_time() -> str:
    epoch = os.environ.get("SOURCE_DATE_EPOCH")
    if epoch:
        instant = dt.datetime.fromtimestamp(int(epoch), tz=dt.timezone.utc)
        return instant.replace(microsecond=0).isoformat().replace("+00:00", "Z")
    return str(read_json(SNAPSHOT)["captured_at"])


def verified_canonical_build() -> dict[str, Any]:
    previous_time = os.environ.get("LUMEN_BUILD_TIME")
    os.environ["LUMEN_BUILD_TIME"] = release_build_time()
    try:
        cmd_verify(argparse.Namespace(canonical=True))
    finally:
        if previous_time is None:
            os.environ.pop("LUMEN_BUILD_TIME", None)
        else:
            os.environ["LUMEN_BUILD_TIME"] = previous_time
    return read_json(DIST / "build-receipt.json")


def cmd_capsule(_: argparse.Namespace) -> int:
    previous_time = os.environ.get("LUMEN_BUILD_TIME")
    os.environ["LUMEN_BUILD_TIME"] = release_build_time()
    try:
        build_canonical(clean=True)
    finally:
        if previous_time is None:
            os.environ.pop("LUMEN_BUILD_TIME", None)
        else:
            os.environ["LUMEN_BUILD_TIME"] = previous_time
    run([sys.executable, "tools/check_capsule.py"])
    run([sys.executable, "tools/check_dist.py"])
    info = read_json(DIST / "meta" / "capsule.json")
    emit("capsule", f"{info['file']} · {info['bytes']:,} bytes · {info['sha256'][:16]}")
    emit("extract", "unzip dist/Lumen.html")
    return 0


def write_release(output: Path, receipt: dict[str, Any]) -> tuple[Path, str]:
    config = read_json(CONFIG)
    output.mkdir(parents=True, exist_ok=True)
    edition = config.get("edition", "development")
    fingerprint = receipt["source_fingerprint_sha256"][:12]
    archive = output / f"lumen-site-{edition}-{fingerprint}.zip"
    zip_tree(DIST, archive)
    digest = sha256(archive)
    release = {
        "schema": "lumen.release/v2",
        "edition": edition,
        "archive": archive.name,
        "sha256": digest,
        "bytes": archive.stat().st_size,
        "source_fingerprint_sha256": receipt["source_fingerprint_sha256"],
        "build_receipt": "dist/build-receipt.json",
        "deployment_boundary": "dist/ only",
        "reproducible_zip_timestamp": normalized_zip_time(),
    }
    write_json(output / "RELEASE.json", release)
    return archive, digest


def cmd_release(args: argparse.Namespace) -> int:
    receipt = verified_canonical_build()
    output = Path(args.output).expanduser()
    if not output.is_absolute():
        output = ROOT / output
    archive, digest = write_release(output, receipt)
    (output / "SHA256SUMS").write_text(f"{digest}  {archive.name}\n", encoding="utf-8")
    emit("release", str(archive.relative_to(ROOT) if archive.is_relative_to(ROOT) else archive))
    emit("sha256", digest)
    return 0


def copy_toolkit_tree(destination: Path) -> None:
    public_content = publication_content_files(ROOT)
    destination.mkdir(parents=True, exist_ok=True)
    for name in TOOLKIT_ROOTS:
        source = ROOT / name
        if not source.exists():
            continue
        target = destination / name
        if name == "content":
            for path in sorted(public_content):
                out = destination / path.relative_to(ROOT.resolve())
                out.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, out)
            continue
        if source.is_dir():
            if name == "dist":
                target.mkdir(parents=True, exist_ok=True)
                for path in sorted(source.rglob("*")):
                    if not path.is_file():
                        continue
                    rel = path.relative_to(source)
                    if rel.as_posix() in {"Lumen.html", "Lumen.html.sha256", "meta/capsule.json"}:
                        continue
                    out = target / rel
                    out.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(path, out)
            else:
                shutil.copytree(
                    source,
                    target,
                    dirs_exist_ok=True,
                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".DS_Store", "releases", "handoff", "release-out", ".lumen"),
                )
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
    shutil.copy2(DIST / "build-receipt.json", destination / "BUILD-RECEIPT.json")



def handoff_operator_commands() -> list[str]:
    return [
        "./lumen start",
        "./lumen look",
        "./lumen look night-study",
        "./lumen page PAGE_ID",
        "./lumen folio [PAGE_ID]",
        "./lumen pathfolio [PATH_ID]",
        "./lumen edit PAGE_ID",
        "./lumen history --check",
        "./lumen revise PAGE_ID --summary 'What changed and why'",
        "./lumen context PAGE_ID#SECTION",
        "./lumen references QUERY --format markdown",
        "./lumen thread [PATH] --format markdown",
        "./lumen cite PAGE_ID#SECTION --format markdown --quote",
        "./lumen marker PAGE_ID#SECTION --output return-point.json",
        "./lumen marker --check return-point.json",
        "./lumen correction PACKET.json --check",
        "./lumen compare OTHER-Lumen.html --format markdown",
        "./lumen packet PAGE_ID#SECTION",
        "./lumen packet --fieldbook lumen-fieldbook.json",
        "LUMEN_CHECKPOINT_DIR=../private-recovery ./lumen preserve --verify",
        "./lumen reopen CHECKPOINT.zip --verify-only",
        "./lumen sync --check",
        "./lumen ship --replace",
    ]

def cmd_handoff(args: argparse.Namespace) -> int:
    receipt = verified_canonical_build()
    output = Path(args.output).expanduser()
    if not output.is_absolute():
        output = ROOT / output
    if output.exists() and any(output.iterdir()):
        if not args.replace:
            raise LumenError(f"handoff directory is not empty: {output}; use --replace")
        shutil.rmtree(output)
    output.mkdir(parents=True, exist_ok=True)
    site_archive, site_digest = write_release(output, receipt)
    config = read_json(CONFIG)
    edition = config.get("edition", "development")
    fingerprint = receipt["source_fingerprint_sha256"][:12]

    capsule = output / "Lumen.html"
    shutil.copy2(DIST / "Lumen.html", capsule)
    capsule_digest = sha256(capsule)
    shutil.copy2(DIST / "Lumen.html.sha256", output / "Lumen.html.sha256")

    toolkit_archive = output / f"lumen-repository-{edition}-{fingerprint}.zip"
    with tempfile.TemporaryDirectory(prefix="lumen-handoff-") as directory:
        toolkit = Path(directory) / "Lumen"
        copy_toolkit_tree(toolkit)
        zip_tree(toolkit, toolkit_archive, prefix="Lumen")
    toolkit_digest = sha256(toolkit_archive)
    sums = (
        f"{capsule_digest}  {capsule.name}\n"
        f"{site_digest}  {site_archive.name}\n"
        f"{toolkit_digest}  {toolkit_archive.name}\n"
    )
    (output / "SHA256SUMS").write_text(sums, encoding="utf-8")
    handoff = {
        "schema": "lumen.handoff/v3",
        "edition": edition,
        "generated_at": release_build_time(),
        "source_fingerprint_sha256": receipt["source_fingerprint_sha256"],
        "primary": {
            "role": "portable-browser-and-cloudtainer-edition",
            "file": capsule.name,
            "sha256": capsule_digest,
            "bytes": capsule.stat().st_size,
            "extract": "unzip Lumen.html",
        },
        "archives": [
            {"role": "github-pages-projection", "file": site_archive.name, "sha256": site_digest, "bytes": site_archive.stat().st_size},
            {"role": "ordinary-github-worktree", "file": toolkit_archive.name, "sha256": toolkit_digest, "bytes": toolkit_archive.stat().st_size},
        ],
        "hypertext": {
            "passages": receipt.get("counts", {}).get("passages", 0),
            "typed_context_edges": receipt.get("counts", {}).get("typed_context_edges", 0),
            "relationship_edges": receipt.get("counts", {}).get("relationship_edges", 0),
            "ledger": "dist/meta/hypertext-ledger.json",
        },
        "references": {
            "sources": receipt.get("counts", {}).get("external_sources", 0),
            "domains": receipt.get("counts", {}).get("reference_domains", 0),
            "ledger": "dist/meta/references.json",
        },
        "reading_paths": {
            "paths": receipt.get("counts", {}).get("reading_paths", 0),
            "steps": receipt.get("counts", {}).get("reading_path_steps", 0),
            "ledger": "dist/meta/reading-paths.json",
        },
        "operator_commands": handoff_operator_commands(),
        "start": ["open Lumen.html in a browser, or extract it", "cd Lumen", "./lumen doctor", "./lumen start"],
        "excluded": ["historical donor archive", "private repositories", "private worktree checkpoints", "private review evidence", "outer revision workshop"],
    }
    write_json(output / "HANDOFF.json", handoff)
    (output / "README.txt").write_text(
        "LUMEN’S FIELD NOTES HANDOFF\n\n"
        "This is the replacement Field Notes blog.\n\n"
        "Open Lumen.html to read the complete site as one offline file.\n"
        "Extract the same file to recover the cloudtainer/GitHub worktree:\n"
        "  unzip Lumen.html\n"
        "  cd Lumen\n"
        "  ./lumen doctor\n"
        "  ./lumen start\n\n"
        "The repository ZIP is ready for conventional GitHub import.\n"
        "The site ZIP is the exact GitHub Pages projection.\n"
        "Accepted note revisions, exact portable page folios, exact portable reading-path folios, exact private return points, passage-aware local edition comparison, exact-quote links, source-bound citations, source-bound correction packets, reading packets, and private checkpoint/reopening commands are documented inside the worktree.\n"
        "Private recovery objects remain separate from the public handoff.\n",
        encoding="utf-8",
    )
    emit("handoff", str(output.relative_to(ROOT) if output.is_relative_to(ROOT) else output))
    emit("capsule", f"{capsule.name} · {capsule_digest[:16]}")
    emit("site", f"{site_archive.name} · {site_digest[:16]}")
    emit("repository", f"{toolkit_archive.name} · {toolkit_digest[:16]}")
    return 0


def cmd_ship(args: argparse.Namespace) -> int:
    """Create the complete, verified handoff in one command."""
    emit("ship", "verifying canonical site, portable carrier, and GitHub worktree")
    return cmd_handoff(args)



def cmd_look(args: argparse.Namespace) -> int:
    manifest = read_json(LOOKS)
    rows = manifest.get("looks", [])
    by_id = {str(row.get("id")): row for row in rows}
    if not args.target:
        config = read_json(CONFIG)
        current = str(config.get("default_look", manifest.get("default", "field-notes")))
        for row in rows:
            marker = "default" if row.get("id") == current else str(row.get("status", "optional"))
            emit("look", f"{row.get('id')} [{marker}] · {row.get('description')}")
        emit("preview", "./lumen start --open · then open /looks/night-study/")
        return 0
    row = by_id.get(args.target)
    if not row:
        raise LumenError(f"unknown look {args.target!r}; choose: {', '.join(sorted(by_id))}")
    emit("look", f"{row.get('label')} · {row.get('description')}")
    emit("route", str(row.get("route", "/")))
    if args.set_default:
        config = read_json(CONFIG)
        config["default_look"] = args.target
        write_json(CONFIG, config)
        emit("default", f"config.json now uses {args.target}; run ./lumen verify --canonical")
    else:
        emit("choose", f"./lumen look {args.target} --set-default to make it canonical")
    return 0

def cmd_perf(args: argparse.Namespace) -> int:
    report_path = DIST / "meta" / "performance.json"
    if args.build or not report_path.is_file():
        build_canonical(clean=True)
        run([sys.executable, "tools/check_dist.py"])
    report = read_json(report_path)
    totals = report.get("totals", {})
    emit("pages", f"{totals.get('page_bytes', 0):,} bytes raw · {totals.get('page_gzip_bytes', 0):,} gzip")
    emit("assets", f"{totals.get('authored_asset_bytes', 0):,} bytes raw · {totals.get('authored_asset_gzip_bytes', 0):,} gzip")
    pages = sorted(report.get("pages", []), key=lambda row: row.get("gzip_bytes", 0), reverse=True)
    for row in pages[:5]:
        emit("route", f"{row.get('url')} · {row.get('bytes', 0):,} raw · {row.get('gzip_bytes', 0):,} gzip")
    return 0


def cmd_clean(args: argparse.Namespace) -> int:
    if DIST.exists():
        shutil.rmtree(DIST)
        emit("removed", "dist/")
    if PREVIEW_DIST.exists():
        shutil.rmtree(PREVIEW_DIST)
        emit("removed", PREVIEW_DIST.relative_to(ROOT).as_posix())
    if args.state:
        CANDIDATE.unlink(missing_ok=True)
        CANDIDATE_REPORT.unlink(missing_ok=True)
        emit("removed", "staged source candidate")
    for path in ROOT.rglob("__pycache__"):
        if path.is_dir():
            shutil.rmtree(path)
    emit("clean", "generated site, preview, and Python caches removed")
    return 0


def cmd_status(_: argparse.Namespace) -> int:
    config = read_json(CONFIG)
    snapshot = read_json(SNAPSHOT)
    drafts = draft_metadata()
    emit("edition", str(config.get("edition", "unknown")))
    emit("look", str(config.get("default_look", "field-notes")))
    emit("source", f"captured {snapshot.get('captured_at')} · {len(snapshot.get('repositories', []))} repositories")
    for repo in snapshot.get("repositories", []):
        emit("repo", f"{repo.get('name')} @ {repo.get('head_short')} · {repo.get('head_message')}")
    emit("drafts", str(len(drafts)))
    history = history_rows()
    emit("history", f"{sum(int(row.get('revision_count', 0)) for row in history)} revisions · {sum(not row.get('matches') for row in history)} drift")
    emit("candidate", "staged for review" if CANDIDATE.exists() else "none")
    if (DIST / "build-receipt.json").exists():
        receipt = read_json(DIST / "build-receipt.json")
        emit("build", f"{receipt.get('source_fingerprint_sha256', '')[:12]} · {receipt.get('counts', {}).get('pages')} pages")
    else:
        emit("build", "no dist/build-receipt.json")
    if (DIST / "meta" / "capsule.json").exists():
        capsule = read_json(DIST / "meta" / "capsule.json")
        emit("capsule", f"{capsule.get('bytes', 0):,} bytes · {str(capsule.get('sha256', ''))[:12]}")
    else:
        emit("capsule", "not built")
    if (PREVIEW_DIST / "build-receipt.json").exists():
        receipt = read_json(PREVIEW_DIST / "build-receipt.json")
        emit("preview", f"{receipt.get('source_fingerprint_sha256', '')[:12]} · {receipt.get('counts', {}).get('drafts', 0)} drafts")
    else:
        emit("preview", "not built")
    return 0


def cmd_delivery(args: argparse.Namespace) -> int:
    """Forward verbatim to the offline adapter in a separate interpreter."""
    return subprocess.run([sys.executable, str(ROOT / "tools" / "delivery.py"), *args.arguments]).returncode


def parser() -> argparse.ArgumentParser:
    top = argparse.ArgumentParser(prog="lumen", description=__doc__)
    top.add_argument("--version", action="version", version="lumen toolkit rev0022")
    commands = top.add_subparsers(dest="command", required=True)

    item = commands.add_parser("delivery", add_help=False, help="prepare, verify, and recover offline publication/persistence deliveries")
    item.add_argument("arguments", nargs=argparse.REMAINDER)
    item.set_defaults(func=cmd_delivery)

    item = commands.add_parser("doctor", help="validate the cloudtainer and perform an isolated build")
    item.set_defaults(func=cmd_doctor)

    item = commands.add_parser("build", help="generate the static site")
    item.add_argument("--clean", action="store_true")
    item.add_argument("--output")
    item.add_argument("--include-drafts", action="store_true", help="create a noindex preview build")
    item.set_defaults(func=cmd_build)

    item = commands.add_parser("verify", help="run tests plus an isolated distribution validation")
    item.add_argument("--canonical", action="store_true", help="also replace and validate the canonical dist/")
    item.set_defaults(func=cmd_verify)

    item = commands.add_parser("serve", help="build and serve canonical dist/ over local HTTP")
    item.add_argument("--host", default="127.0.0.1")
    item.add_argument("--port", type=int, default=8000)
    item.add_argument("--no-build", action="store_true")
    item.set_defaults(func=cmd_serve)

    item = commands.add_parser("dev", help="serve a draft-aware preview and atomically rebuild on changes")
    item.add_argument("--host", default="127.0.0.1")
    item.add_argument("--port", type=int, default=8000)
    item.add_argument("--interval", type=float, default=.7)
    item.add_argument("--open", action="store_true")
    item.set_defaults(func=cmd_dev)

    item = commands.add_parser("start", help="doctor, choose a free port, and start the draft-aware workbench")
    item.add_argument("--host", default="127.0.0.1")
    item.add_argument("--port", type=int, default=0, help="0 chooses a free port")
    item.add_argument("--interval", type=float, default=.7)
    item.add_argument("--open", action="store_true")
    item.set_defaults(func=cmd_start)

    item = commands.add_parser("new", help="scaffold a paired HTML/JSON draft")
    item.add_argument("kind", choices=sorted(KIND_PATHS))
    item.add_argument("title")
    item.add_argument("--slug")
    item.add_argument("--date")
    item.set_defaults(func=cmd_new)

    item = commands.add_parser("drafts", help="list pages excluded from canonical publication")
    item.set_defaults(func=cmd_drafts)

    item = commands.add_parser("page", help="inspect one authored page and its local context")
    item.add_argument("target", help="page id, URL, title slug, filename, or metadata path")
    item.add_argument("--json", action="store_true", help="emit a machine-readable page record")
    item.set_defaults(func=cmd_page)

    item = commands.add_parser("context", help="inspect source-bound passages, citations, and backlinks")
    item.add_argument("target", help="page target, optionally followed by #anchor or ::anchor")
    item.add_argument("--json", action="store_true", help="emit the complete machine-readable context record")
    item.add_argument("--build", action="store_true", help="refresh canonical context before reading it")
    item.set_defaults(func=cmd_context)

    item = commands.add_parser("references", help="inspect the local source-bound reference ledger")
    item.add_argument("query", nargs="?", help="stable id, author label, domain, URL, page, or passage")
    item.add_argument("--format", choices=("text", "markdown", "json"), default="text")
    item.add_argument("--build", action="store_true", help="refresh the canonical ledger before reading it")
    item.set_defaults(func=cmd_references)

    item = commands.add_parser("thread", help="inspect curated source-bound reading paths")
    item.add_argument("query", nargs="?", help="optional path id, title, page, or step filter")
    item.add_argument("--format", choices=("text", "markdown", "json"), default="text")
    item.add_argument("--output", help="write the rendered path record to a file")
    item.add_argument("--build", action="store_true", help="refresh canonical records before reading")
    item.set_defaults(func=cmd_thread)

    item = commands.add_parser("cite", help="format a source-bound page or passage citation")
    item.add_argument("target", help="PAGE or PAGE#ANCHOR target")
    item.add_argument("--format", choices=("text", "markdown", "json"), default="text")
    item.add_argument("--quote", action="store_true", help="include the exact passage text before the citation")
    item.add_argument("--output", help="write to a file instead of stdout")
    item.add_argument("--build", action="store_true", help="refresh canonical context before citing")
    item.set_defaults(func=cmd_cite)

    item = commands.add_parser("folio", help="list, verify, or copy one exact portable page folio")
    item.add_argument("target", nargs="?", help="published note, project, or collection id, URL, slug, or metadata path")
    item.add_argument("--output", help="destination HTML path; defaults to the edition-bound download name")
    item.add_argument("--format", choices=("text", "json"), default="text")
    item.add_argument("--check", action="store_true", help="verify the generated folio receipt without copying it")
    item.add_argument("--replace", action="store_true", help="replace an existing nonmatching destination file")
    item.add_argument("--build", action="store_true", help="refresh the canonical build before reading the folio manifest")
    item.set_defaults(func=cmd_folio)

    item = commands.add_parser("pathfolio", help="list, verify, or copy one exact portable reading-path folio")
    item.add_argument("target", nargs="?", help="reading path id or title")
    item.add_argument("--output", help="destination HTML path; defaults to the edition-bound download name")
    item.add_argument("--format", choices=("text", "json"), default="text")
    item.add_argument("--check", action="store_true", help="verify the generated path-folio receipt without copying it")
    item.add_argument("--replace", action="store_true", help="replace an existing nonmatching destination file")
    item.add_argument("--build", action="store_true", help="refresh the canonical build before reading the path-folio manifest")
    item.set_defaults(func=cmd_pathfolio)

    item = commands.add_parser("marker", help="create or review one private source-bound return point")
    item.add_argument("target", nargs="?", help="PAGE or PAGE#ANCHOR to mark")
    item.add_argument("--check", metavar="JSON", help="review an exported lumen.return-marker/v1 file against the current edition")
    item.add_argument("--format", choices=("text", "json"), default="text")
    item.add_argument("--output", help="write the marker or review record to a file")
    item.add_argument("--build", action="store_true", help="refresh canonical context before creating or reviewing")
    item.set_defaults(func=cmd_marker)

    item = commands.add_parser("correction", help="create or verify a source-bound correction packet")
    item.add_argument("packet", nargs="?", help="JSON packet exported by the browser or created with --new")
    item.add_argument("--new", metavar="PAGE[#SECTION]", help="create a packet from the current accepted page or passage")
    item.add_argument("--type", choices=("factual", "attribution", "quotation", "link", "wording", "accessibility", "other"), default="other")
    item.add_argument("--issue", help="concrete problem for a new packet")
    item.add_argument("--evidence", help="supporting evidence or suggested change for a new packet")
    item.add_argument("--boundary", help="what the report does not establish")
    item.add_argument("--include-quote", action=argparse.BooleanOptionalAction, default=True, help="carry the exact accepted passage when creating a packet")
    item.add_argument("--format", choices=("text", "markdown", "json"), default="text", help="verification output format")
    item.add_argument("--output", help="write the created packet or rendered review to a file")
    item.add_argument("--build", action="store_true", help="refresh canonical context before creating or reviewing")
    item.add_argument("--check", action="store_true", help="return nonzero when the packet no longer binds to the current accepted bytes")
    item.set_defaults(func=cmd_correction)

    item = commands.add_parser("packet", help="export exact source-bound passages as a standalone reading packet")
    item.add_argument("targets", nargs="*", help="zero or more PAGE or PAGE#ANCHOR targets")
    item.add_argument("--desk", help="import an exported lumen.reading-desk/v1 JSON file, preserving its order")
    item.add_argument("--fieldbook", help="import an exported lumen.fieldbook/v1 JSON file, verifying exact page, passage, and quote bindings")
    item.add_argument("--output", help="output HTML path; a companion JSON receipt is written beside it")
    item.add_argument("--build", action="store_true", help="refresh canonical context before exporting")
    item.set_defaults(func=cmd_packet)

    item = commands.add_parser("edit", help="open one page body or metadata file in the cloudtainer editor")
    item.add_argument("target", help="page id, URL, title slug, filename, or metadata path")
    item.add_argument("--metadata", action="store_true", help="edit the page JSON instead of the HTML body")
    item.add_argument("--editor", help="editor command; defaults to $VISUAL, $EDITOR, nano, vim, or vi")
    item.add_argument("--path-only", action="store_true", help="print the selected file path without launching an editor")
    item.set_defaults(func=cmd_edit)

    item = commands.add_parser("publish", help="promote a complete draft into canonical builds")
    item.add_argument("target", help="draft id, title slug, filename, or metadata path")
    item.add_argument("--summary", help="initial publication summary for a field note")
    item.set_defaults(func=cmd_publish)

    item = commands.add_parser("history", help="verify the accepted revision ledger for published field notes")
    item.add_argument("--check", action="store_true", help="fail when a note body and its latest revision identity differ")
    item.add_argument("--json", action="store_true", help="emit machine-readable revision status")
    item.set_defaults(func=cmd_history)

    item = commands.add_parser("compare", help="compare another Lumen.html or edition summary with the current accepted build")
    item.add_argument("edition", help="path to another Lumen.html or edition-summary JSON file")
    item.add_argument("--format", choices=("text", "markdown", "json"), default="text")
    item.add_argument("--output", help="write the comparison receipt to a file")
    item.add_argument("--build", action="store_true", help="refresh the canonical current edition before comparing")
    item.set_defaults(func=cmd_compare)

    item = commands.add_parser("revise", help="record an intentionally changed published field note")
    item.add_argument("target", help="published note id, URL, title slug, filename, or metadata path")
    item.add_argument("--summary", required=True, help="plain-language description of what changed and why")
    item.add_argument("--date", help="revision date in YYYY-MM-DD; defaults to today in UTC")
    item.add_argument("--source-ref", help="optional retained-source or review boundary")
    item.set_defaults(func=cmd_revise)

    item = commands.add_parser("sync", help="compare, stage, or explicitly accept public GitHub source heads")
    item.add_argument("--owner", default="Sapient-Lumen")
    mode = item.add_mutually_exclusive_group()
    mode.add_argument("--check", action="store_true", help="report drift without writing files")
    mode.add_argument("--stage", action="store_true", help="write a review candidate under .lumen/ (default)")
    mode.add_argument("--accept", action="store_true", help="promote the already-staged candidate without network access")
    item.add_argument("--confirm-retire", action="append", default=[], metavar="OWNER/REPO", help="explicitly confirm one staged repository retirement; repeat as needed")
    item.set_defaults(func=cmd_sync)

    item = commands.add_parser("look", help="list, inspect, or explicitly choose a presentation layer")
    item.add_argument("target", nargs="?", help="look id such as field-notes or night-study")
    item.add_argument("--set-default", action="store_true", help="write the chosen look to config.json")
    item.set_defaults(func=cmd_look)

    item = commands.add_parser("perf", help="show exact route and authored-asset sizes")
    item.add_argument("--build", action="store_true")
    item.set_defaults(func=cmd_perf)

    item = commands.add_parser("preserve", help="create a deterministic private recovery checkpoint of the editable worktree")
    item.add_argument("--output", help="checkpoint directory; defaults to $LUMEN_CHECKPOINT_DIR or a sibling lumen-checkpoints/")
    item.add_argument("--verify", action="store_true", help="run the test suite and isolated validation before preserving")
    item.set_defaults(func=cmd_preserve)

    item = commands.add_parser("reopen", help="verify or restore a private worktree checkpoint into a new directory")
    item.add_argument("checkpoint", help="checkpoint ZIP created by ./lumen preserve")
    item.add_argument("--into", help="new destination directory; must not already exist")
    item.add_argument("--verify-only", action="store_true", help="verify hashes, modes, paths, and manifest without extracting")
    item.set_defaults(func=cmd_reopen)

    item = commands.add_parser("capsule", help="build and validate the one-file HTML/ZIP custody edition")
    item.set_defaults(func=cmd_capsule)

    item = commands.add_parser("release", help="verify and create a deterministic deploy archive")
    item.add_argument("--output", default="releases")
    item.set_defaults(func=cmd_release)

    item = commands.add_parser("handoff", help="create verified deploy and executable cloudtainer toolkit archives")
    item.add_argument("--output", default="handoff")
    item.add_argument("--replace", action="store_true")
    item.set_defaults(func=cmd_handoff)

    item = commands.add_parser("ship", help="verify and create the complete Lumen handoff")
    item.add_argument("--output", default="handoff")
    item.add_argument("--replace", action="store_true")
    item.set_defaults(func=cmd_ship)

    item = commands.add_parser("clean", help="remove generated output and Python caches")
    item.add_argument("--state", action="store_true", help="also remove a staged upstream candidate")
    item.set_defaults(func=cmd_clean)

    item = commands.add_parser("status", help="show accepted source, drafts, staged candidate, and build identity")
    item.set_defaults(func=cmd_status)
    return top


def main() -> int:
    # Preserve adapter options/help verbatim; importing it here would create a CLI import cycle.
    if len(sys.argv) > 1 and sys.argv[1] == "delivery":
        return cmd_delivery(argparse.Namespace(arguments=sys.argv[2:]))
    args = parser().parse_args()
    try:
        return int(args.func(args))
    except LumenError as exc:
        emit("error", str(exc))
        return 1
    except subprocess.CalledProcessError as exc:
        emit("error", f"command failed with exit {exc.returncode}")
        if exc.stdout:
            print(exc.stdout, file=sys.stderr)
        if exc.stderr:
            print(exc.stderr, file=sys.stderr)
        return exc.returncode or 1


if __name__ == "__main__":
    raise SystemExit(main())
