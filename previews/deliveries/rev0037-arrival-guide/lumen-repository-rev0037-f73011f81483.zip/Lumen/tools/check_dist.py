#!/usr/bin/env python3
"""Validate Lumen's generated GitHub Pages directory.

The checks are deliberately dependency-free so the same command can run in
GitHub Actions before deployment.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import gzip
import json
import re
import sys
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit

from check_capsule import validate as validate_capsule

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DIST = ROOT / "dist"
EVENT_ATTR_RE = re.compile(r"^on[a-z]+$", re.I)
TOKEN_RE = re.compile(r"{{[A-Z0-9_]+}}")


@dataclass
class HtmlRecord:
    path: Path
    ids: list[str] = field(default_factory=list)
    links: list[tuple[str, str]] = field(default_factory=list)
    h1_count: int = 0
    lang: str | None = None
    page_id: str | None = None
    has_main: bool = False
    has_title: bool = False
    has_description: bool = False
    has_csp: bool = False
    csp: str | None = None
    robots: str | None = None
    has_inline_style: bool = False
    event_attributes: list[str] = field(default_factory=list)
    inline_scripts: int = 0
    structured_scripts: int = 0
    inline_styles: int = 0


class SiteHtmlParser(HTMLParser):
    def __init__(self, path: Path) -> None:
        super().__init__(convert_charrefs=True)
        self.record = HtmlRecord(path)
        self._in_title = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        data = {name.lower(): value for name, value in attrs}
        if tag == "html":
            self.record.lang = data.get("lang")
        if tag == "body":
            self.record.page_id = data.get("data-page-id")
        if tag == "main" and data.get("id") == "main":
            self.record.has_main = True
        if tag == "h1":
            self.record.h1_count += 1
        if tag == "title":
            self._in_title = True
        if ident := data.get("id"):
            self.record.ids.append(ident)
        for attr in ("href", "src", "action"):
            if value := data.get(attr):
                self.record.links.append((attr, value))
        if "style" in data:
            self.record.has_inline_style = True
        for name, _value in attrs:
            if EVENT_ATTR_RE.match(name):
                self.record.event_attributes.append(name)
        if tag == "script" and not data.get("src"):
            if data.get("type", "").lower() == "application/ld+json":
                self.record.structured_scripts += 1
            else:
                self.record.inline_scripts += 1
        if tag == "style":
            self.record.inline_styles += 1
        if tag == "meta" and data.get("name") == "description" and data.get("content"):
            self.record.has_description = True
        if tag == "meta" and data.get("http-equiv", "").lower() == "content-security-policy":
            self.record.csp = data.get("content")
            self.record.has_csp = bool(self.record.csp)
        if tag == "meta" and data.get("name", "").lower() == "robots":
            self.record.robots = data.get("content")

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "title":
            self._in_title = False

    def handle_data(self, data: str) -> None:
        if self._in_title and data.strip():
            self.record.has_title = True


def fail(errors: list[str], message: str) -> None:
    errors.append(message)


def url_target(dist: Path, source: Path, value: str) -> tuple[Path | None, str | None]:
    """Map a local URL/reference to an output path and fragment."""
    split = urlsplit(value)
    if split.scheme or split.netloc or value.startswith(("mailto:", "tel:", "data:", "javascript:")):
        return None, None
    path = unquote(split.path)
    fragment = unquote(split.fragment) or None
    if not path:
        return source, fragment
    if path.startswith("/"):
        relative = path.lstrip("/")
    else:
        relative = (source.parent.relative_to(dist) / path).as_posix()
    relative = relative.split("?", 1)[0]
    candidate = (dist / relative).resolve()
    try:
        candidate.relative_to(dist.resolve())
    except ValueError:
        return Path("/__ESCAPES_DIST__"), fragment
    if path.endswith("/") or candidate.is_dir():
        candidate = candidate / "index.html"
    elif not candidate.suffix:
        # Clean URLs without a trailing slash still map to directory indexes.
        candidate = candidate / "index.html"
    return candidate, fragment


def load_html_records(dist: Path, errors: list[str]) -> dict[Path, HtmlRecord]:
    records: dict[Path, HtmlRecord] = {}
    for path in sorted(dist.rglob("*.html")):
        if path.resolve() == (dist / "Lumen.html").resolve():
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError as exc:
            fail(errors, f"{path.relative_to(dist)} is not UTF-8: {exc}")
            continue
        if TOKEN_RE.search(text):
            fail(errors, f"{path.relative_to(dist)} contains an unresolved template token")
        parser = SiteHtmlParser(path)
        try:
            parser.feed(text)
            parser.close()
        except Exception as exc:  # HTMLParser errors are unusual but should be visible.
            fail(errors, f"Cannot parse {path.relative_to(dist)}: {exc}")
            continue
        record = parser.record
        records[path.resolve()] = record
        rel = path.relative_to(dist)
        is_page_folio = bool(rel.parts and rel.parts[0] == "folios")
        is_path_folio = bool(rel.parts and rel.parts[0] == "path-folios")
        is_folio = is_page_folio or is_path_folio
        duplicates = sorted({x for x in record.ids if record.ids.count(x) > 1})
        if duplicates:
            fail(errors, f"{rel} has duplicate ids: {duplicates}")
        if not record.lang:
            fail(errors, f"{rel} has no html[lang]")
        if not record.has_title:
            fail(errors, f"{rel} has no non-empty title")
        if not record.has_description:
            fail(errors, f"{rel} has no non-empty meta description")
        if not record.has_csp:
            fail(errors, f"{rel} has no Content-Security-Policy meta tag")
        if not record.robots:
            fail(errors, f"{rel} has no robots policy")
        if not record.has_main:
            fail(errors, f"{rel} has no main#main")
        if record.h1_count != 1:
            fail(errors, f"{rel} has {record.h1_count} h1 elements; expected exactly 1")
        if rel.name != "404.html" and not record.page_id:
            fail(errors, f"{rel} has no body[data-page-id]")
        if record.has_inline_style:
            fail(errors, f"{rel} contains an inline style attribute")
        if record.event_attributes:
            fail(errors, f"{rel} contains inline event attributes: {record.event_attributes}")
        if record.inline_scripts:
            fail(errors, f"{rel} contains {record.inline_scripts} executable inline script block(s)")
        if record.structured_scripts != 1:
            fail(errors, f"{rel} contains {record.structured_scripts} JSON-LD block(s); expected exactly 1")
        else:
            match = re.search(r'<script\s+type=["\']application/ld\+json["\']>(.*?)</script>', text, re.I | re.S)
            if not match:
                fail(errors, f"{rel} JSON-LD block could not be isolated")
            else:
                payload = match.group(1)
                try:
                    data = json.loads(payload)
                    if data.get("@context") != "https://schema.org" or not data.get("@type"):
                        fail(errors, f"{rel} JSON-LD lacks schema.org context or type")
                except json.JSONDecodeError as exc:
                    fail(errors, f"{rel} has invalid JSON-LD: {exc}")
                digest = base64.b64encode(hashlib.sha256(payload.encode("utf-8")).digest()).decode("ascii")
                if f"'sha256-{digest}'" not in (record.csp or ""):
                    fail(errors, f"{rel} CSP does not authorize its exact JSON-LD hash")
        if is_folio:
            expected_marker = 'data-lumen-folio="v1"' if is_page_folio else 'data-lumen-path-folio="v1"'
            expected_schema = "lumen.portable-folio/v1" if is_page_folio else "lumen.portable-path-folio/v1"
            if expected_marker not in text:
                fail(errors, f"{rel} does not identify itself as {expected_schema}")
            if record.inline_styles != 1:
                fail(errors, f"{rel} contains {record.inline_styles} inline style block(s); expected exactly one self-contained stylesheet")
            style_match = re.search(r"<style>(.*?)</style>", text, re.I | re.S)
            if not style_match:
                fail(errors, f"{rel} inline folio stylesheet could not be isolated")
            else:
                digest = base64.b64encode(hashlib.sha256(style_match.group(1).encode("utf-8")).digest()).decode("ascii")
                if f"'sha256-{digest}'" not in (record.csp or ""):
                    fail(errors, f"{rel} CSP does not authorize its exact inline stylesheet")
        elif record.inline_styles:
            fail(errors, f"{rel} contains {record.inline_styles} inline style block(s)")
    return records


def check_links(dist: Path, records: dict[Path, HtmlRecord], errors: list[str]) -> None:
    for source_key, record in records.items():
        source = Path(source_key)
        for attr, value in record.links:
            target, fragment = url_target(dist, source, value)
            if target is None:
                continue
            rel_source = source.relative_to(dist)
            if str(target) == "/__ESCAPES_DIST__":
                fail(errors, f"{rel_source}: {attr}={value!r} escapes dist")
                continue
            if not target.exists():
                fail(errors, f"{rel_source}: {attr}={value!r} resolves to missing {target.relative_to(dist)}")
                continue
            if fragment and target.suffix.lower() == ".html":
                target_record = records.get(target.resolve())
                if target_record is None:
                    fail(errors, f"{rel_source}: cannot inspect fragment target {target.relative_to(dist)}")
                elif fragment not in set(target_record.ids):
                    fail(errors, f"{rel_source}: fragment #{fragment} is missing in {target.relative_to(dist)}")


def check_json(dist: Path, errors: list[str]) -> None:
    for path in sorted(dist.rglob("*.json")):
        try:
            json.loads(path.read_text(encoding="utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            fail(errors, f"Invalid JSON {path.relative_to(dist)}: {exc}")
    feed_path = dist / "feed.json"
    try:
        feed = json.loads(feed_path.read_text(encoding="utf-8"))
        if feed.get("version") != "https://jsonfeed.org/version/1.1":
            fail(errors, "feed.json is not JSON Feed 1.1")
        if not feed.get("items"):
            fail(errors, "feed.json has no items")
        for item in feed.get("items", []):
            if not item.get("id") or not item.get("url") or not item.get("content_html"):
                fail(errors, f"feed.json has malformed item: {item.get('title', 'untitled')}")
    except (OSError, json.JSONDecodeError) as exc:
        fail(errors, f"Invalid JSON feed.json: {exc}")


def check_xml(dist: Path, errors: list[str]) -> None:
    parsed: dict[str, ET.Element] = {}
    for name in ("feed.xml", "rss.xml", "sitemap.xml"):
        path = dist / name
        try:
            parsed[name] = ET.parse(path).getroot()
        except (OSError, ET.ParseError) as exc:
            fail(errors, f"Invalid XML {name}: {exc}")
    feed = parsed.get("feed.xml")
    atom = "{http://www.w3.org/2005/Atom}"
    if feed is not None:
        if feed.tag != atom + "feed":
            fail(errors, "feed.xml root is not an Atom feed")
        author_name = feed.findtext(atom + "author/" + atom + "name")
        if not author_name:
            fail(errors, "feed.xml has no feed-level author name")
        if not feed.findall(atom + "entry"):
            fail(errors, "feed.xml has no entries")
    rss = parsed.get("rss.xml")
    if rss is not None:
        if rss.tag != "rss" or rss.get("version") != "2.0":
            fail(errors, "rss.xml root is not RSS 2.0")
        channel = rss.find("channel")
        if channel is None or not channel.findall("item"):
            fail(errors, "rss.xml has no channel items")
        elif not channel.findtext("title") or not channel.findtext("link"):
            fail(errors, "rss.xml channel lacks title or link")
    sitemap = parsed.get("sitemap.xml")
    if sitemap is not None and sitemap.tag != "{http://www.sitemaps.org/schemas/sitemap/0.9}urlset":
        fail(errors, "sitemap.xml root is not a sitemap urlset")


def check_receipts(dist: Path, records: dict[Path, HtmlRecord], errors: list[str]) -> None:
    receipt_path = dist / "build-receipt.json"
    try:
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        fail(errors, f"Cannot read build-receipt.json: {exc}")
        return
    pages = receipt.get("pages", [])
    if receipt.get("counts", {}).get("pages") != len(pages):
        fail(errors, "Build receipt page count does not equal its page list")
    page_ids: set[str] = set()
    for page in pages:
        page_id = page.get("id")
        output = page.get("output")
        if not page_id or not output:
            fail(errors, f"Malformed page receipt: {page}")
            continue
        if page_id in page_ids:
            fail(errors, f"Duplicate page id in build receipt: {page_id}")
        page_ids.add(page_id)
        target = (dist / output).resolve()
        if not target.exists():
            fail(errors, f"Receipt output missing: {output}")
        record = records.get(target)
        if record and record.page_id != page_id:
            fail(errors, f"Receipt page id {page_id} disagrees with body id {record.page_id} in {output}")
        for family in ("pages", "previews", "context"):
            if not (dist / "meta" / family / f"{page_id}.json").exists():
                fail(errors, f"Missing meta/{family}/{page_id}.json")
    try:
        search = json.loads((dist / "meta" / "search-index.json").read_text(encoding="utf-8"))
        records = search.get("records", [])
        search_ids = {item.get("id") for item in records if item.get("scope", "page") == "page"}
        passage_ids = [item.get("id") for item in records if item.get("scope") == "passage"]
        if search_ids != page_ids:
            fail(errors, f"Search page ids differ from page ids: missing={sorted(page_ids-search_ids)}, extra={sorted(search_ids-page_ids)}")
        if len(passage_ids) != len(set(passage_ids)):
            fail(errors, "Search index contains duplicate passage ids")
        if search.get("passage_count") != len(passage_ids):
            fail(errors, "Search index passage_count disagrees with passage records")
    except (OSError, json.JSONDecodeError) as exc:
        fail(errors, f"Cannot validate search index: {exc}")
    try:
        ledger_path = dist / "meta" / "hypertext-ledger.json"
        ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
        ledger_page_ids = {item.get("id") for item in ledger.get("pages", [])}
        if ledger_page_ids != page_ids:
            fail(errors, f"Hypertext ledger page ids differ: missing={sorted(page_ids-ledger_page_ids)}, extra={sorted(ledger_page_ids-page_ids)}")
        passage_ids = [item.get("id") for item in ledger.get("passages", [])]
        if len(passage_ids) != len(set(passage_ids)):
            fail(errors, "Hypertext ledger contains duplicate passage ids")
        if receipt.get("counts", {}).get("passages") != len(passage_ids):
            fail(errors, "Build receipt passage count disagrees with hypertext ledger")
        for item in ledger.get("pages", []):
            context_file = dist / str(item.get("context_file", ""))
            if not context_file.is_file():
                fail(errors, f"Hypertext context file is missing: {item.get('context_file')}")
                continue
            digest = hashlib.sha256(context_file.read_bytes()).hexdigest()
            if digest != item.get("context_file_sha256"):
                fail(errors, f"Hypertext context hash disagrees: {item.get('context_file')}")
    except (OSError, json.JSONDecodeError) as exc:
        fail(errors, f"Cannot validate hypertext ledger: {exc}")
    try:
        references = json.loads((dist / "meta" / "references.json").read_text(encoding="utf-8"))
        if references.get("schema") != "lumen.references/v1":
            fail(errors, "Reference ledger has an unsupported schema")
        sources = references.get("sources", [])
        source_ids = [row.get("id") for row in sources]
        if len(source_ids) != len(set(source_ids)):
            fail(errors, "Reference ledger contains duplicate source ids")
        counts = references.get("counts", {})
        if counts.get("sources") != len(sources):
            fail(errors, "Reference ledger source count disagrees with source records")
        citations = sum(len(row.get("citations", [])) for row in sources)
        if counts.get("citations") != citations:
            fail(errors, "Reference ledger citation count disagrees with source records")
        hosts = {row.get("host") for row in sources}
        if counts.get("domains") != len(hosts):
            fail(errors, "Reference ledger domain count disagrees with source records")
        receipt_counts = receipt.get("counts", {})
        if receipt_counts.get("external_sources") != counts.get("sources"):
            fail(errors, "Build receipt external source count disagrees with reference ledger")
        if receipt_counts.get("reference_domains") != counts.get("domains"):
            fail(errors, "Build receipt reference domain count disagrees with reference ledger")
        reference_records = [item for item in records if item.get("scope") == "reference"]
        if search.get("reference_count") != len(reference_records):
            fail(errors, "Search index reference_count disagrees with reference records")
        if {item.get("id") for item in reference_records} != set(source_ids):
            fail(errors, "Search reference ids disagree with reference ledger")
        for page_id in page_ids:
            context_path = dist / "meta" / "context" / f"{page_id}.json"
            context = json.loads(context_path.read_text(encoding="utf-8"))
            for passage in context.get("passages", []):
                for link in passage.get("external_links", []):
                    if link.get("reference_id") not in set(source_ids):
                        fail(errors, f"{page_id}: external link has unknown reference id")
    except (OSError, json.JSONDecodeError) as exc:
        fail(errors, f"Cannot validate reference ledger: {exc}")
    try:
        paths_payload = json.loads((dist / "meta" / "reading-paths.json").read_text(encoding="utf-8"))
        if paths_payload.get("schema") != "lumen.reading-paths/v1":
            fail(errors, "Reading paths have an unsupported schema")
        if paths_payload.get("source_fingerprint_sha256") != receipt.get("source_fingerprint_sha256"):
            fail(errors, "Reading paths and build receipt describe different source trees")
        paths = paths_payload.get("paths", [])
        path_ids = [row.get("id") for row in paths]
        if len(path_ids) != len(set(path_ids)):
            fail(errors, "Reading paths contain duplicate ids")
        path_steps = [step for row in paths for step in row.get("steps", [])]
        counts = paths_payload.get("counts", {})
        if counts.get("paths") != len(paths) or counts.get("steps") != len(path_steps):
            fail(errors, "Reading path counts disagree with records")
        if receipt.get("counts", {}).get("reading_paths") != len(paths):
            fail(errors, "Build receipt reading-path count disagrees with record")
        if receipt.get("counts", {}).get("reading_path_steps") != len(path_steps):
            fail(errors, "Build receipt reading-path-step count disagrees with record")
        for row in paths:
            targets: set[str] = set()
            for step in row.get("steps", []):
                page_id = step.get("page_id")
                stable_id = step.get("stable_id")
                if page_id not in page_ids:
                    fail(errors, f"Reading path {row.get('id')} names unknown page {page_id}")
                if stable_id in targets:
                    fail(errors, f"Reading path {row.get('id')} repeats target {stable_id}")
                targets.add(stable_id)
                if not re.fullmatch(r"[0-9a-f]{64}", str(step.get("text_sha256", ""))):
                    fail(errors, f"Reading path {row.get('id')} has invalid target digest")
        path_records = [item for item in records if item.get("scope") == "path"]
        if search.get("path_count") != len(path_records):
            fail(errors, "Search index path_count disagrees with path records")
        if {item.get("id") for item in path_records} != {f"path-{path_id}" for path_id in path_ids}:
            fail(errors, "Search reading-path ids disagree with reading-path ledger")
    except (OSError, json.JSONDecodeError) as exc:
        fail(errors, f"Cannot validate reading paths: {exc}")
    try:
        graph = json.loads((dist / "meta" / "graph.json").read_text(encoding="utf-8"))
        node_ids = {item.get("id") for item in graph.get("nodes", [])}
        if node_ids != page_ids:
            fail(errors, f"Graph node ids differ from page ids: missing={sorted(page_ids-node_ids)}, extra={sorted(node_ids-page_ids)}")
        for edge in graph.get("edges", []):
            if edge.get("from") not in node_ids or edge.get("to") not in node_ids:
                fail(errors, f"Graph edge references an unknown node: {edge}")
    except (OSError, json.JSONDecodeError) as exc:
        fail(errors, f"Cannot validate graph: {exc}")
    try:
        editions = json.loads((dist / "meta" / "editions.json").read_text(encoding="utf-8"))
        if editions.get("schema") != "lumen.editions/v1":
            fail(errors, "Edition ledger has an unsupported schema")
        note_ids: set[str] = set()
        inspections: dict[str, dict] = {}
        for page_id in page_ids:
            inspection_path = dist / "meta" / "pages" / f"{page_id}.json"
            inspection = json.loads(inspection_path.read_text(encoding="utf-8"))
            page_record = inspection.get("page", {})
            if page_record.get("kind") == "note" and page_record.get("status") == "draft":
                if receipt.get("mode") != "preview":
                    fail(errors, f"Canonical distribution contains draft note {page_id}")
                if page_record.get("publication_history"):
                    fail(errors, f"Draft note {page_id} claims accepted publication history")
            elif page_record.get("kind") == "note":
                note_ids.add(page_id)
                inspections[page_id] = page_record
        edition_notes = editions.get("notes", {})
        if set(edition_notes) != note_ids:
            fail(errors, f"Edition ledger note ids differ: missing={sorted(note_ids-set(edition_notes))}, extra={sorted(set(edition_notes)-note_ids)}")
        total_revisions = 0
        revised_notes = 0
        for page_id in sorted(note_ids):
            record = edition_notes.get(page_id, {})
            revisions = record.get("revisions", [])
            if not revisions:
                fail(errors, f"Edition ledger has no revisions for {page_id}")
                continue
            total_revisions += len(revisions)
            if len(revisions) > 1:
                revised_notes += 1
            latest = revisions[-1]
            source_body = inspections[page_id].get("source_body", {})
            if latest.get("body_sha256") != source_body.get("sha256"):
                fail(errors, f"Edition ledger latest SHA-256 disagrees with current body for {page_id}")
            if latest.get("body_bytes") != source_body.get("bytes"):
                fail(errors, f"Edition ledger latest byte count disagrees with current body for {page_id}")
            if inspections[page_id].get("publication_history") != revisions:
                fail(errors, f"Page inspection publication history disagrees with edition ledger for {page_id}")
        counts = receipt.get("counts", {})
        if counts.get("note_revisions") != total_revisions:
            fail(errors, "Build receipt note revision count disagrees with edition ledger")
        if counts.get("revised_notes") != revised_notes:
            fail(errors, "Build receipt revised-note count disagrees with edition ledger")
    except (OSError, json.JSONDecodeError) as exc:
        fail(errors, f"Cannot validate edition ledger: {exc}")


def check_edition_summary(dist: Path, errors: list[str]) -> None:
    try:
        summary = json.loads((dist / "meta" / "edition-summary.json").read_text(encoding="utf-8"))
        receipt = json.loads((dist / "build-receipt.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        fail(errors, f"Cannot validate edition summary: {exc}")
        return
    if summary.get("schema") != "lumen.edition-summary/v2":
        fail(errors, "Edition summary has an unsupported schema")
    if summary.get("scope") != "complete":
        fail(errors, "Canonical edition summary must have complete scope")
    if summary.get("edition") != receipt.get("capsule", {}).get("edition", summary.get("edition")):
        fail(errors, "Edition summary and capsule edition disagree")
    if summary.get("source_fingerprint_sha256") != receipt.get("source_fingerprint_sha256"):
        fail(errors, "Edition summary source fingerprint disagrees with build receipt")
    pages = summary.get("pages")
    if not isinstance(pages, list) or len(pages) != receipt.get("counts", {}).get("pages"):
        fail(errors, "Edition summary page count disagrees with build receipt")
        return
    counts = summary.get("counts", {})
    if counts.get("pages") != len(pages):
        fail(errors, "Edition summary internal page count disagrees with its page records")
    ids: set[str] = set()
    passage_ids: set[str] = set()
    passage_total = 0
    folio_total = 0
    for row in pages:
        if not isinstance(row, dict):
            fail(errors, "Edition summary contains a non-object page record")
            continue
        page_id = str(row.get("id", ""))
        if not page_id or page_id in ids:
            fail(errors, f"Edition summary has missing or duplicate page id: {page_id!r}")
        ids.add(page_id)
        body = str(row.get("body_sha256", ""))
        if not re.fullmatch(r"[0-9a-f]{64}", body):
            fail(errors, f"Edition summary has invalid body identity for {page_id}")
        if row.get("passage_detail") is not True:
            fail(errors, f"Edition summary page does not declare passage detail: {page_id}")
        folio = row.get("portable_folio")
        if folio is not None:
            if not isinstance(folio, dict):
                fail(errors, f"Edition summary portable folio is not an object for {page_id}")
            else:
                folio_total += 1
                if folio.get("page_id") != page_id:
                    fail(errors, f"Edition summary portable folio page identity disagrees for {page_id}")
                if not re.fullmatch(r"[0-9a-f]{64}", str(folio.get("sha256", ""))):
                    fail(errors, f"Edition summary portable folio has invalid SHA-256 for {page_id}")
        passages = row.get("passages")
        if not isinstance(passages, list):
            fail(errors, f"Edition summary passages are not a list for {page_id}")
            continue
        local_ids: set[str] = set()
        for passage in passages:
            if not isinstance(passage, dict):
                fail(errors, f"Edition summary contains a non-object passage for {page_id}")
                continue
            passage_id = str(passage.get("id", ""))
            if not passage_id or passage_id in local_ids:
                fail(errors, f"Edition summary has missing or duplicate passage id in {page_id}: {passage_id!r}")
            if passage_id in passage_ids:
                fail(errors, f"Edition summary repeats passage identity across pages: {passage_id}")
            local_ids.add(passage_id)
            passage_ids.add(passage_id)
            passage_total += 1
            for field in ("text_sha256", "source_html_sha256"):
                if not re.fullmatch(r"[0-9a-f]{64}", str(passage.get(field, ""))):
                    fail(errors, f"Edition summary has invalid {field} for passage {passage_id}")
            if not str(passage.get("title", "")).strip():
                fail(errors, f"Edition summary passage lacks a title: {passage_id}")
            if not str(passage.get("anchor", "")).strip():
                fail(errors, f"Edition summary passage lacks an anchor: {passage_id}")
            if not str(passage.get("url", "")).strip():
                fail(errors, f"Edition summary passage lacks a URL: {passage_id}")
            if not isinstance(passage.get("order"), int):
                fail(errors, f"Edition summary passage lacks an integer order: {passage_id}")
    expected_passages = receipt.get("counts", {}).get("passages")
    if passage_total != expected_passages or counts.get("passages") != expected_passages:
        fail(errors, "Edition summary passage count disagrees with build receipt")
    expected_folios = receipt.get("counts", {}).get("portable_folios")
    if folio_total != expected_folios or counts.get("portable_folios") != expected_folios:
        fail(errors, "Edition summary portable-folio count disagrees with build receipt")
    expected_path_folios = receipt.get("counts", {}).get("portable_path_folios")
    if counts.get("portable_path_folios") != expected_path_folios:
        fail(errors, "Edition summary portable reading-path folio count disagrees with build receipt")
    record = receipt.get("edition_summary", {})
    path = dist / str(record.get("path", ""))
    if path != dist / "meta" / "edition-summary.json" or not path.is_file():
        fail(errors, "Build receipt does not point to meta/edition-summary.json")
    elif hashlib.sha256(path.read_bytes()).hexdigest() != record.get("sha256"):
        fail(errors, "Edition summary SHA-256 disagrees with build receipt")


def check_portable_folios(dist: Path, html_records: dict[Path, HtmlRecord], errors: list[str]) -> None:
    try:
        manifest_path = dist / "meta" / "folios.json"
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
        receipt = json.loads((dist / "build-receipt.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        fail(errors, f"Cannot validate portable folios: {exc}")
        return
    if payload.get("schema") != "lumen.portable-folios/v1":
        fail(errors, "Portable folio manifest has an unsupported schema")
    if payload.get("source_fingerprint_sha256") != receipt.get("source_fingerprint_sha256"):
        fail(errors, "Portable folio manifest source fingerprint disagrees with build receipt")
    rows = payload.get("folios")
    if not isinstance(rows, list):
        fail(errors, "Portable folio manifest has no folio list")
        return
    counts = payload.get("counts", {})
    if counts.get("folios") != len(rows):
        fail(errors, "Portable folio manifest count disagrees with its records")
    if receipt.get("counts", {}).get("portable_folios") != len(rows):
        fail(errors, "Build receipt portable-folio count disagrees with manifest")
    seen_pages: set[str] = set()
    total_bytes = 0
    for row in rows:
        if not isinstance(row, dict):
            fail(errors, "Portable folio manifest contains a non-object record")
            continue
        page_id = str(row.get("page_id", ""))
        relative = str(row.get("file", ""))
        if not page_id or page_id in seen_pages:
            fail(errors, f"Portable folio manifest has missing or duplicate page id: {page_id!r}")
            continue
        seen_pages.add(page_id)
        if not relative.startswith("folios/") or ".." in Path(relative).parts:
            fail(errors, f"Portable folio has unsafe output path: {relative!r}")
            continue
        path = dist / relative
        if not path.is_file():
            fail(errors, f"Portable folio output is missing: {relative}")
            continue
        raw = path.read_bytes()
        total_bytes += len(raw)
        if len(raw) != row.get("bytes"):
            fail(errors, f"Portable folio byte count disagrees: {relative}")
        if hashlib.sha256(raw).hexdigest() != row.get("sha256"):
            fail(errors, f"Portable folio SHA-256 disagrees: {relative}")
        compressed = len(gzip.compress(raw, compresslevel=9, mtime=0))
        if compressed != row.get("gzip_bytes"):
            fail(errors, f"Portable folio gzip byte count disagrees: {relative}")
        record = html_records.get(path.resolve())
        if record is None:
            fail(errors, f"Portable folio was not parsed as HTML: {relative}")
        elif record.page_id != f"folio-{page_id}":
            fail(errors, f"Portable folio body identity disagrees for {page_id}")
        try:
            inspection = json.loads((dist / "meta" / "pages" / f"{page_id}.json").read_text(encoding="utf-8"))["page"]
        except (OSError, json.JSONDecodeError, KeyError) as exc:
            fail(errors, f"Cannot read page inspection for portable folio {page_id}: {exc}")
            continue
        if row.get("body_sha256") != inspection.get("source_body", {}).get("sha256"):
            fail(errors, f"Portable folio body identity disagrees with accepted page: {page_id}")
        if inspection.get("portable_folio", {}).get("sha256") != row.get("sha256"):
            fail(errors, f"Page inspection portable-folio receipt disagrees: {page_id}")
    if counts.get("bytes") != total_bytes:
        fail(errors, "Portable folio manifest total byte count disagrees")
    receipt_record = receipt.get("portable_folios", {})
    if receipt_record.get("path") != "meta/folios.json":
        fail(errors, "Build receipt does not point to meta/folios.json")
    elif hashlib.sha256(manifest_path.read_bytes()).hexdigest() != receipt_record.get("sha256"):
        fail(errors, "Portable folio manifest SHA-256 disagrees with build receipt")
    if receipt_record.get("folios") != len(rows) or receipt_record.get("bytes") != total_bytes:
        fail(errors, "Build receipt portable-folio totals disagree with manifest")


def check_portable_path_folios(dist: Path, html_records: dict[Path, HtmlRecord], errors: list[str]) -> None:
    try:
        manifest_path = dist / "meta" / "path-folios.json"
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
        receipt = json.loads((dist / "build-receipt.json").read_text(encoding="utf-8"))
        reading_paths = json.loads((dist / "meta" / "reading-paths.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        fail(errors, f"Cannot validate portable reading-path folios: {exc}")
        return
    if payload.get("schema") != "lumen.portable-path-folios/v1":
        fail(errors, "Portable reading-path folio manifest has an unsupported schema")
    if payload.get("source_fingerprint_sha256") != receipt.get("source_fingerprint_sha256"):
        fail(errors, "Portable reading-path folio source fingerprint disagrees with build receipt")
    rows = payload.get("folios")
    if not isinstance(rows, list):
        fail(errors, "Portable reading-path folio manifest has no folio list")
        return
    counts = payload.get("counts", {})
    if counts.get("folios") != len(rows):
        fail(errors, "Portable reading-path folio manifest count disagrees with its records")
    if receipt.get("counts", {}).get("portable_path_folios") != len(rows):
        fail(errors, "Build receipt portable reading-path folio count disagrees with manifest")
    paths_by_id = {str(row.get("id")): row for row in reading_paths.get("paths", []) if isinstance(row, dict)}
    seen_paths: set[str] = set()
    total_bytes = 0
    total_steps = 0
    total_page_steps = 0
    total_passage_steps = 0
    for row in rows:
        if not isinstance(row, dict):
            fail(errors, "Portable reading-path folio manifest contains a non-object record")
            continue
        path_id = str(row.get("path_id", ""))
        relative = str(row.get("file", ""))
        if not path_id or path_id in seen_paths:
            fail(errors, f"Portable reading-path folio has missing or duplicate path id: {path_id!r}")
            continue
        seen_paths.add(path_id)
        source_path = paths_by_id.get(path_id)
        if source_path is None:
            fail(errors, f"Portable reading-path folio names unknown path: {path_id}")
            continue
        if not relative.startswith("path-folios/") or ".." in Path(relative).parts:
            fail(errors, f"Portable reading-path folio has unsafe output path: {relative!r}")
            continue
        path = dist / relative
        if not path.is_file():
            fail(errors, f"Portable reading-path folio output is missing: {relative}")
            continue
        raw = path.read_bytes()
        total_bytes += len(raw)
        total_steps += int(row.get("steps", 0))
        total_page_steps += int(row.get("page_steps", 0))
        total_passage_steps += int(row.get("passage_steps", 0))
        if len(raw) != row.get("bytes"):
            fail(errors, f"Portable reading-path folio byte count disagrees: {relative}")
        if hashlib.sha256(raw).hexdigest() != row.get("sha256"):
            fail(errors, f"Portable reading-path folio SHA-256 disagrees: {relative}")
        compressed = len(gzip.compress(raw, compresslevel=9, mtime=0))
        if compressed != row.get("gzip_bytes"):
            fail(errors, f"Portable reading-path folio gzip byte count disagrees: {relative}")
        if not re.fullmatch(r"[0-9a-f]{64}", str(row.get("path_sha256", ""))):
            fail(errors, f"Portable reading-path folio has invalid path SHA-256: {path_id}")
        scoped = {
            "id": source_path.get("id"),
            "title": source_path.get("title"),
            "description": source_path.get("description"),
            "steps": source_path.get("steps", []),
            "boundary": reading_paths.get("boundary"),
        }
        expected_path_sha = hashlib.sha256(
            json.dumps(scoped, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        if row.get("path_sha256") != expected_path_sha:
            fail(errors, f"Portable reading-path folio record identity disagrees: {path_id}")
        source_steps = source_path.get("steps", [])
        if row.get("steps") != len(source_steps):
            fail(errors, f"Portable reading-path folio step count disagrees: {path_id}")
        if row.get("page_steps") != sum(step.get("scope") == "page" for step in source_steps):
            fail(errors, f"Portable reading-path page-step count disagrees: {path_id}")
        if row.get("passage_steps") != sum(step.get("scope") == "passage" for step in source_steps):
            fail(errors, f"Portable reading-path passage-step count disagrees: {path_id}")
        record = html_records.get(path.resolve())
        if record is None:
            fail(errors, f"Portable reading-path folio was not parsed as HTML: {relative}")
        elif record.page_id != f"path-folio-{path_id}":
            fail(errors, f"Portable reading-path folio body identity disagrees: {path_id}")
    for key, actual in (
        ("bytes", total_bytes),
        ("steps", total_steps),
        ("page_steps", total_page_steps),
        ("passage_steps", total_passage_steps),
    ):
        if counts.get(key) != actual:
            fail(errors, f"Portable reading-path folio manifest {key} total disagrees")
    receipt_record = receipt.get("portable_path_folios", {})
    if receipt_record.get("path") != "meta/path-folios.json":
        fail(errors, "Build receipt does not point to meta/path-folios.json")
    elif hashlib.sha256(manifest_path.read_bytes()).hexdigest() != receipt_record.get("sha256"):
        fail(errors, "Portable reading-path folio manifest SHA-256 disagrees with build receipt")
    if (
        receipt_record.get("folios") != len(rows)
        or receipt_record.get("bytes") != total_bytes
        or receipt_record.get("steps") != total_steps
    ):
        fail(errors, "Build receipt portable reading-path folio totals disagree with manifest")


def check_asset_receipts(dist: Path, errors: list[str]) -> None:
    try:
        receipt = json.loads((dist / "build-receipt.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        fail(errors, f"Cannot validate asset receipts: {exc}")
        return
    for family, record in receipt.get("assets", {}).items():
        relative = str(record.get("path", "")).lstrip("/")
        path = dist / relative
        if not relative or not path.is_file():
            fail(errors, f"Missing fingerprinted {family} asset declared by build receipt: {relative!r}")
            continue
        raw = path.read_bytes()
        sha256 = hashlib.sha256(raw).hexdigest()
        if sha256 != record.get("sha256"):
            fail(errors, f"{relative} SHA-256 disagrees with build receipt")
        sri = "sha384-" + base64.b64encode(hashlib.sha384(raw).digest()).decode("ascii")
        if sri != record.get("sri"):
            fail(errors, f"{relative} SRI disagrees with build receipt")
        if len(raw) != record.get("bytes"):
            fail(errors, f"{relative} byte count disagrees with build receipt")



def check_performance_report(dist: Path, errors: list[str]) -> None:
    path = dist / "meta" / "performance.json"
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        fail(errors, f"Cannot read performance report: {exc}")
        return
    if report.get("schema") != "lumen.performance/v1":
        fail(errors, "Performance report has an unsupported schema")
    for row in report.get("pages", []):
        output = dist / str(row.get("output", ""))
        if not output.is_file():
            fail(errors, f"Performance report output missing: {row.get('output')}")
            continue
        if output.stat().st_size != row.get("bytes"):
            fail(errors, f"Performance byte count disagrees for {row.get('output')}")
    receipt = json.loads((dist / "build-receipt.json").read_text(encoding="utf-8"))
    if receipt.get("performance", {}).get("report") != "meta/performance.json":
        fail(errors, "Build receipt does not point to meta/performance.json")


def check_public_boundary(dist: Path, errors: list[str]) -> None:
    for path in dist.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(dist)
        if path.name == "Lumen.sh" or path.suffix.lower() == ".zip":
            fail(errors, f"Private/archive artifact crossed deployment boundary: {relative}")
        if any(part.lower() in {"archive", "research", "evidence", "screenshots", ".lumen", ".git"} for part in relative.parts):
            fail(errors, f"Excluded state directory crossed deployment boundary: {relative}")
    # Site should be fast enough to be useful without making the benchmark a fetish.
    fixed_budgets = {
        "index.html": 110_000,
        "meta/search-index.json": 400_000,
        "meta/hypertext-ledger.json": 180_000,
        "meta/references.json": 120_000,
        "meta/edition-summary.json": 150_000,
        "meta/reading-paths.json": 64_000,
        "meta/folios.json": 64_000,
        "meta/path-folios.json": 48_000,
        "service-worker.js": 10_000,
        "Lumen.html": 12_000_000,
    }
    for relative, maximum in fixed_budgets.items():
        path = dist / relative
        if not path.exists():
            fail(errors, f"Budgeted output is missing: {relative}")
        elif path.stat().st_size > maximum:
            fail(errors, f"{relative} is {path.stat().st_size:,} bytes; budget is {maximum:,}")
    folios = sorted((dist / "folios").glob("*.html")) if (dist / "folios").is_dir() else []
    if not folios:
        fail(errors, "No portable folios were generated")
    elif sum(path.stat().st_size for path in folios) > 2_000_000:
        fail(errors, "Portable folio set exceeds the 2,000,000-byte custody budget")
    for path in folios:
        if path.stat().st_size > 300_000:
            fail(errors, f"{path.relative_to(dist)} exceeds the 300,000-byte single-folio budget")
    path_folios = sorted((dist / "path-folios").glob("*.html")) if (dist / "path-folios").is_dir() else []
    if not path_folios:
        fail(errors, "No portable reading-path folios were generated")
    elif sum(path.stat().st_size for path in path_folios) > 1_600_000:
        fail(errors, "Portable reading-path folio set exceeds the 1,600,000-byte custody budget")
    for path in path_folios:
        if path.stat().st_size > 600_000:
            fail(errors, f"{path.relative_to(dist)} exceeds the 600,000-byte single path-folio budget")
    # Raw size catches accidental payload dumps; deterministic gzip size better
    # approximates actual transfer cost for GitHub Pages and other static hosts.
    families = {"css": (85_000, 18_000), "js": (120_000, 29_000)}
    for family, (raw_maximum, gzip_maximum) in families.items():
        matches = sorted((dist / "assets" / family).glob(f"site.*.{family}"))
        if len(matches) != 1:
            fail(errors, f"Expected one fingerprinted {family} asset, found {len(matches)}")
            continue
        path = matches[0]
        raw = path.read_bytes()
        if len(raw) > raw_maximum:
            fail(errors, f"{path.relative_to(dist)} is {len(raw):,} bytes; raw budget is {raw_maximum:,}")
        compressed = len(gzip.compress(raw, compresslevel=9, mtime=0))
        if compressed > gzip_maximum:
            fail(errors, f"{path.relative_to(dist)} is {compressed:,} gzip bytes; transfer budget is {gzip_maximum:,}")


    compare_assets = sorted((dist / "assets" / "js").glob("edition-compare.*.js"))
    if len(compare_assets) != 1:
        fail(errors, f"Expected one lazy edition comparison asset, found {len(compare_assets)}")
    else:
        raw = compare_assets[0].read_bytes()
        if len(raw) > 34_000:
            fail(errors, f"{compare_assets[0].relative_to(dist)} is {len(raw):,} bytes; raw budget is 34,000")
        compressed = len(gzip.compress(raw, compresslevel=9, mtime=0))
        if compressed > 8_500:
            fail(errors, f"{compare_assets[0].relative_to(dist)} is {compressed:,} gzip bytes; transfer budget is 8,500")

def validate(dist: Path) -> list[str]:
    errors: list[str] = []
    if not dist.is_dir():
        return [f"Distribution directory does not exist: {dist}"]
    records = load_html_records(dist, errors)
    if not records:
        fail(errors, "No HTML pages were generated")
    check_links(dist, records, errors)
    check_json(dist, errors)
    check_xml(dist, errors)
    check_receipts(dist, records, errors)
    check_edition_summary(dist, errors)
    check_portable_folios(dist, records, errors)
    check_portable_path_folios(dist, records, errors)
    check_asset_receipts(dist, errors)
    check_performance_report(dist, errors)
    try:
        mode = json.loads((dist / "build-receipt.json").read_text(encoding="utf-8")).get("mode")
    except (OSError, json.JSONDecodeError):
        mode = None
    canonical = mode == "canonical"
    if canonical:
        capsule_errors, _manifest = validate_capsule(dist / "Lumen.html")
        errors.extend(f"Lumen.html: {message}" for message in capsule_errors)
    check_public_boundary(dist, errors)
    required = [".nojekyll", "robots.txt", "site.webmanifest", "feed.xml", "sitemap.xml", "404.html", "service-worker.js", "meta/source-snapshot.json", "meta/performance.json", "meta/hypertext-ledger.json", "meta/references.json", "meta/reading-paths.json", "meta/folios.json", "meta/path-folios.json", "meta/graph.json", "meta/editions.json"]
    if canonical:
        required.extend(["Lumen.html", "Lumen.html.sha256", "meta/capsule.json"])
    for name in required:
        if not (dist / name).exists():
            fail(errors, f"Required deployment file is missing: {name}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dist", nargs="?", type=Path, default=DEFAULT_DIST)
    args = parser.parse_args()
    errors = validate(args.dist.resolve())
    if errors:
        print(f"Lumen distribution check failed with {len(errors)} error(s):", file=sys.stderr)
        for error in errors:
            print(f"  - {error}", file=sys.stderr)
        return 1
    files = sum(1 for p in args.dist.rglob("*") if p.is_file())
    size = sum(p.stat().st_size for p in args.dist.rglob("*") if p.is_file())
    print(f"Lumen distribution check passed: {files} files, {size:,} bytes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
