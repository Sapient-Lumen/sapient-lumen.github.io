#!/usr/bin/env python3
"""Offline, fail-closed comparison of complete Git trees and an approved plan."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path


class GuardError(ValueError):
    """Input is incomplete, inconsistent, or outside the explicit change plan."""


MODES = {"100644": "blob", "100755": "blob", "120000": "blob",
         "040000": "tree", "160000": "commit"}


def fail(message: str) -> None:
    raise GuardError(message)


def oid(value: object, label: str, width: int | None = None) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{40}|[0-9a-f]{64}", value):
        fail(f"{label}: expected a full lowercase Git object ID")
    if set(value) == {"0"}:
        fail(f"{label}: null Git object ID is not permitted")
    if width is not None and len(value) != width:
        fail(f"{label}: mixed Git object ID algorithms")
    return value


def path_name(value: object) -> str:
    if not isinstance(value, str) or not value or any(
        part in ("", ".", "..") for part in value.split("/")
    ) or "\\" in value or any(ord(c) < 32 or ord(c) == 127 for c in value):
        fail("invalid repository-relative path")
    try:
        value.encode("utf-8", errors="strict")
    except UnicodeError:
        fail("path is not valid UTF-8")
    return value


def descriptor(value: object, label: str, width: int) -> dict:
    if not isinstance(value, dict) or set(value) != {"mode", "type", "sha"}:
        fail(f"{label}: expected exactly mode, type, sha")
    mode = value["mode"]
    if not isinstance(mode, str) or mode not in MODES or value["type"] != MODES[mode]:
        fail(f"{label}: invalid Git mode/type pair")
    oid(value["sha"], label, width)
    return dict(value)


def tree_hash(entries: list[tuple[str, dict]], width: int) -> str:
    """Compute Git's canonical tree object ID, including directory sort order."""
    entries = sorted(entries, key=lambda e: (e[0] + ("/" if e[1]["type"] == "tree" else "")).encode("utf-8"))
    body = b"".join(
        (entry["mode"].lstrip("0") + " " + name).encode("utf-8")
        + b"\0" + bytes.fromhex(entry["sha"]) for name, entry in entries
    )
    payload = b"tree " + str(len(body)).encode("ascii") + b"\0" + body
    return (hashlib.sha1(payload) if width == 40 else hashlib.sha256(payload)).hexdigest()


def complete_tree(data: object, expected: str, label: str) -> dict[str, dict]:
    if not isinstance(data, dict) or not {"sha", "tree", "truncated"} <= set(data):
        fail(f"{label}: missing full-tree response fields")
    if set(data) - {"sha", "tree", "truncated", "url"}:
        fail(f"{label}: unknown full-tree response fields")
    if data["truncated"] is not False:
        fail(f"{label}: truncated must be explicitly false")
    if oid(data["sha"], label, len(expected)) != expected:
        fail(f"{label}: tree identity does not match pin")
    if not isinstance(data["tree"], list):
        fail(f"{label}: tree must be an array")
    entries = {}
    children: dict[str, list[tuple[str, dict]]] = {"": []}
    for item in data["tree"]:
        if not isinstance(item, dict) or not {"path", "mode", "type", "sha"} <= set(item):
            fail(f"{label}: malformed tree entry")
        if set(item) - {"path", "mode", "type", "sha", "size", "url"}:
            fail(f"{label}: unknown tree entry fields")
        path = path_name(item["path"])
        if path in entries:
            fail(f"{label}: duplicate path {path!r}")
        entry = descriptor({key: item[key] for key in ("mode", "type", "sha")}, path, len(expected))
        if "size" in item and (type(item["size"]) is not int or item["size"] < 0 or entry["type"] != "blob"):
            fail(f"{label}: invalid blob size")
        if "url" in item and not isinstance(item["url"], str):
            fail(f"{label}: invalid entry URL")
        entries[path] = entry
        parent, _, name = path.rpartition("/")
        children.setdefault(parent, []).append((name, entry))
        if entry["type"] == "tree":
            children.setdefault(path, [])
    if "url" in data and not isinstance(data["url"], str):
        fail(f"{label}: invalid tree URL")
    for parent, members in children.items():
        if parent and (parent not in entries or entries[parent]["type"] != "tree"):
            fail(f"{label}: missing directory or file/directory collision at {parent!r}")
        if parent and not members:
            fail(f"{label}: empty subtree unsupported at {parent!r}")
        actual = tree_hash(members, len(expected))
        required = entries[parent]["sha"] if parent else expected
        if actual != required:
            fail(f"{label}: incomplete or inconsistent tree at {parent or '<root>'!r}")
    return {path: entry for path, entry in entries.items() if entry["type"] != "tree"}


def verify(baseline: object, candidate: object, manifest: object, *,
           baseline_tree_sha: str, candidate_tree_sha: str) -> dict:
    """Return a summary only if both complete trees exactly implement the plan."""
    base_pin = oid(baseline_tree_sha, "baseline pin")
    next_pin = oid(candidate_tree_sha, "candidate pin", len(base_pin))
    if not isinstance(manifest, dict) or set(manifest) != {
        "schema_version", "baseline_tree_sha", "candidate_tree_sha", "changes"
    }:
        fail("manifest: missing or unknown fields")
    if type(manifest["schema_version"]) is not int or manifest["schema_version"] != 1:
        fail("manifest: unsupported schema_version")
    if manifest["baseline_tree_sha"] != base_pin or manifest["candidate_tree_sha"] != next_pin:
        fail("manifest: tree identities do not match independent pins")
    before = complete_tree(baseline, base_pin, "baseline")
    after = complete_tree(candidate, next_pin, "candidate")
    if not isinstance(manifest["changes"], list):
        fail("manifest: changes must be an array")
    planned = set()
    for change in manifest["changes"]:
        if not isinstance(change, dict) or set(change) != {"path", "before", "after"}:
            fail("manifest: change requires exactly path, before, after")
        path = path_name(change["path"])
        if path in planned:
            fail(f"manifest: duplicate change {path!r}")
        planned.add(path)
        for side in ("before", "after"):
            value = change[side]
            if value is not None:
                value = descriptor(value, f"manifest {path} {side}", len(base_pin))
                if value["type"] == "tree":
                    fail("manifest: directory hashes are derived, not planned changes")
            actual = (before if side == "before" else after).get(path)
            if actual != value:
                fail(f"manifest: {side} does not match complete tree for {path!r}")
        if change["before"] == change["after"]:
            fail(f"manifest: no-op change {path!r}")
    changed = {path for path in before.keys() | after.keys() if before.get(path) != after.get(path)}
    unexpected = sorted(changed - planned)
    if unexpected:
        fail("unapproved additions, changes, or removals: " + ", ".join(repr(p) for p in unexpected))
    return {"status": "ok", "baseline_tree_sha": base_pin, "candidate_tree_sha": next_pin,
            "baseline_entries": len(before), "candidate_entries": len(after),
            "approved_changes": len(planned), "preserved_entries": len(before.keys() & after.keys() - planned)}


def unique_object(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            fail(f"duplicate JSON key {key!r}")
        result[key] = value
    return result


def load_json(path: str) -> object:
    def invalid_constant(value: str) -> None:
        fail(f"non-JSON constant {value}")
    return json.loads(Path(path).read_text(encoding="utf-8"), object_pairs_hook=unique_object,
                      parse_constant=invalid_constant)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", required=True, help="complete recursive baseline Git tree JSON")
    parser.add_argument("--candidate", required=True, help="complete recursive candidate Git tree JSON")
    parser.add_argument("--manifest", required=True, help="explicit reviewed change manifest JSON")
    parser.add_argument("--baseline-tree-sha", required=True)
    parser.add_argument("--candidate-tree-sha", required=True)
    args = parser.parse_args(argv)
    try:
        result = verify(load_json(args.baseline), load_json(args.candidate), load_json(args.manifest),
                        baseline_tree_sha=args.baseline_tree_sha, candidate_tree_sha=args.candidate_tree_sha)
    except (GuardError, OSError, UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        print(f"publication guard: REJECTED: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
