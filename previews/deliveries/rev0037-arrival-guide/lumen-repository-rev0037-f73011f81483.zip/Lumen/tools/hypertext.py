#!/usr/bin/env python3
"""Small, deterministic hypertext indexer for Lumen.

The public document remains ordinary HTML. This module derives a separate
passage ledger: section identities, exact source slices, typed links, backlinks,
and a page graph. The ledger is descriptive. It never rewrites authored prose
or infers semantic relationships beyond explicit metadata and actual links.
"""
from __future__ import annotations

import hashlib
import html
import re
from collections import defaultdict
from html.parser import HTMLParser
from typing import Any, Iterable
from urllib.parse import urljoin, urlparse, urlunparse

WORD_RE = re.compile(r"[\w’'\-]+", re.UNICODE)
SPACE_RE = re.compile(r"\s+")
NEXT_SECTION_PRELUDE_RE = re.compile(
    r'<(?:div|section|header)\b[^>]*class="[^"]*\bsection-heading\b[^"]*"[^>]*>\s*'
    r'<p\b[^>]*class="[^"]*\beyebrow\b[^"]*"[^>]*>.*?</p>\s*$',
    re.I | re.S,
)


class _TextExtractor(HTMLParser):
    """Extract authored prose while ignoring controls and empty UI state.

    Source fingerprints still cover the exact HTML slice. This reader-facing
    text projection omits buttons, diagrams, and lazy placeholders so search
    and excerpts do not mistake interface labels for an author's claim.
    """

    HIDDEN_TAGS = {"script", "style", "svg", "button", "dialog"}
    HIDDEN_CLASSES = {"network-ledger", "performance-receipt", "heading-tools"}
    BLOCK_TAGS = {"p", "li", "blockquote", "dd", "dt", "div", "section", "article", "header", "footer", "h2", "h3", "span", "strong", "code"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.hidden_tags: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = dict(attrs)
        classes = set((values.get("class") or "").split())
        hide = (
            tag in self.HIDDEN_TAGS
            or values.get("aria-hidden") == "true"
            or bool(classes & self.HIDDEN_CLASSES)
        )
        if hide:
            self.hidden_tags.append(tag)
        if tag == "br" and not self.hidden_tags:
            self.parts.append(" ")

    def handle_endtag(self, tag: str) -> None:
        if self.hidden_tags and self.hidden_tags[-1] == tag:
            self.hidden_tags.pop()
            return
        if tag in self.BLOCK_TAGS and not self.hidden_tags:
            self.parts.append(" ")

    def handle_data(self, data: str) -> None:
        if not self.hidden_tags:
            self.parts.append(data)


class _AnchorExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.links: list[dict[str, str]] = []
        self.current: dict[str, Any] | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag != "a" or self.current is not None:
            return
        values = dict(attrs)
        href = values.get("href")
        if href:
            self.current = {"href": href, "parts": []}

    def handle_data(self, data: str) -> None:
        if self.current is not None:
            self.current["parts"].append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag != "a" or self.current is None:
            return
        label = SPACE_RE.sub(" ", "".join(self.current["parts"])).strip()
        self.links.append({"href": str(self.current["href"]), "label": label})
        self.current = None


def text_of(fragment: str) -> str:
    parser = _TextExtractor()
    parser.feed(fragment)
    parser.close()
    return SPACE_RE.sub(" ", "".join(parser.parts)).strip()


def clip_text(value: str, limit: int = 280) -> str:
    clean = SPACE_RE.sub(" ", value).strip()
    if len(clean) <= limit:
        return clean
    shortened = clean[: limit + 1]
    cut = shortened.rfind(" ")
    if cut > limit * 0.62:
        shortened = shortened[:cut]
    return shortened.rstrip(" ,;:") + "…"


def _dedupe(records: Iterable[dict[str, Any]], keys: tuple[str, ...]) -> list[dict[str, Any]]:
    seen: set[tuple[Any, ...]] = set()
    out: list[dict[str, Any]] = []
    for record in records:
        identity = tuple(record.get(key) for key in keys)
        if identity in seen:
            continue
        seen.add(identity)
        out.append(record)
    return out


def classify_links(
    fragment: str,
    *,
    page_url: str,
    url_to_page: dict[str, dict[str, str]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    parser = _AnchorExtractor()
    parser.feed(fragment)
    parser.close()
    internal: list[dict[str, Any]] = []
    external: list[dict[str, Any]] = []
    for link in parser.links:
        href = html.unescape(link["href"]).strip()
        label = link["label"] or href
        parsed = urlparse(href)
        if parsed.scheme in {"http", "https"}:
            external.append({
                "url": href,
                "label": label,
                "host": parsed.netloc.lower(),
            })
            continue
        if parsed.scheme or href.startswith(("mailto:", "tel:", "javascript:")):
            continue
        absolute = urlparse(urljoin(page_url, href))
        route = absolute.path or page_url
        target = url_to_page.get(route)
        if target is None and route != "/":
            target = url_to_page.get(route.rstrip("/") + "/")
        if target is None:
            continue
        internal.append({
            "page_id": target["id"],
            "url": target["url"],
            "title": target["title"],
            "label": label,
            "anchor": absolute.fragment or None,
        })
    return (
        _dedupe(internal, ("page_id", "anchor", "label")),
        _dedupe(external, ("url", "label")),
    )


def build_passages(
    *,
    page_id: str,
    page_url: str,
    page_title: str,
    page_kind: str,
    source_html: str,
    toc: list[dict[str, Any]],
    url_to_page: dict[str, dict[str, str]],
) -> list[dict[str, Any]]:
    """Create passage records from heading offsets captured by the renderer.

    Each passage is the authored source between one h2/h3 heading and the next
    heading. The exact HTML slice and normalized text have separate hashes. This
    mirrors Hyperepo's source-bound identity without exposing editor authority in
    the public reader.
    """
    passages: list[dict[str, Any]] = []
    for index, heading in enumerate(toc):
        start = int(heading.get("_end", 0))
        end = int(toc[index + 1].get("_start", len(source_html))) if index + 1 < len(toc) else len(source_html)
        # Editorial landing pages place an eyebrow inside the wrapper that owns
        # the *next* heading. Keep that prelude with its own passage instead of
        # leaking it into the preceding excerpt and fingerprint.
        if index + 1 < len(toc):
            between = source_html[start:end]
            prelude = NEXT_SECTION_PRELUDE_RE.search(between)
            if prelude:
                end = start + prelude.start()
        if start < 0 or end < start or end > len(source_html):
            raise ValueError(f"{page_id}: invalid source offsets for {heading.get('id')}")
        exact_html = source_html[start:end]
        text = text_of(exact_html)
        canonical = SPACE_RE.sub(" ", f"{heading['label']}\n{text}").strip()
        internal, external = classify_links(exact_html, page_url=page_url, url_to_page=url_to_page)
        anchor = str(heading["id"])
        passage_id = f"{page_id}::{anchor}"
        passages.append({
            "id": passage_id,
            "page_id": page_id,
            "page_url": page_url,
            "page_title": page_title,
            "page_kind": page_kind,
            "anchor": anchor,
            "url": f"{page_url}#{anchor}",
            "level": int(heading["level"]),
            "title": str(heading["label"]),
            "order": index,
            "text": text,
            "excerpt": clip_text(text),
            "word_count": len(WORD_RE.findall(text)),
            "text_sha256": hashlib.sha256(canonical.encode("utf-8")).hexdigest(),
            "source_html_sha256": hashlib.sha256(exact_html.encode("utf-8")).hexdigest(),
            "source_offsets": {"start": start, "end": end},
            "internal_links": internal,
            "external_links": external,
        })
    return passages


def canonical_external_url(value: str) -> str:
    """Return a conservative, deterministic identity for an external URL.

    Fragments describe a location inside one remote document rather than a new
    source.  Host case and default ports are transport spelling.  Everything
    else, including the query string, remains exact: the index does not guess
    that two publisher URLs are semantically interchangeable.
    """
    parsed = urlparse(html.unescape(value).strip())
    scheme = parsed.scheme.lower()
    host = (parsed.hostname or "").lower()
    port = parsed.port
    if port and not ((scheme == "https" and port == 443) or (scheme == "http" and port == 80)):
        host = f"{host}:{port}"
    path = parsed.path or "/"
    return urlunparse((scheme, host, path, "", parsed.query, ""))


def reference_id_for(value: str) -> str:
    canonical = canonical_external_url(value)
    return "ref-" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16]


def build_reference_index(
    *,
    pages: list[dict[str, Any]],
    passages_by_page: dict[str, list[dict[str, Any]]],
    source_fingerprint: str,
    generated_at: str,
) -> dict[str, Any]:
    """Bind authored external links to a quiet, local reference ledger.

    The ledger records only what the published HTML actually says: exact URLs,
    authored labels, and source-bound passages.  It does not fetch titles,
    assess source quality, or turn a link into evidence for the surrounding
    claim.  ``reference_id`` is added to each passage link before page context
    files are emitted, so browser and cloudtainer views share one identity.
    """
    page_map = {str(row["id"]): row for row in pages}
    sources: dict[str, dict[str, Any]] = {}
    order: list[str] = []

    for page in pages:
        page_id = str(page["id"])
        for passage in passages_by_page.get(page_id, []):
            for link_order, link in enumerate(passage.get("external_links", [])):
                url = str(link.get("url", "")).strip()
                if not url:
                    continue
                canonical = canonical_external_url(url)
                ref_id = reference_id_for(url)
                link["reference_id"] = ref_id
                if ref_id not in sources:
                    parsed = urlparse(canonical)
                    sources[ref_id] = {
                        "id": ref_id,
                        "url": url,
                        "urls": [url],
                        "canonical_url": canonical,
                        "host": parsed.netloc.lower(),
                        "labels": [],
                        "citations": [],
                    }
                    order.append(ref_id)
                source = sources[ref_id]
                if url not in source["urls"]:
                    source["urls"].append(url)
                label = str(link.get("label") or url).strip()
                if label and label not in source["labels"]:
                    source["labels"].append(label)
                citation = {
                    "page_id": page_id,
                    "page_title": page.get("title"),
                    "page_url": page.get("url"),
                    "page_kind": page.get("kind"),
                    "date": page.get("date"),
                    "passage_id": passage.get("id"),
                    "passage_title": passage.get("title"),
                    "passage_url": passage.get("url"),
                    "label": label,
                    "url": url,
                    "text_sha256": passage.get("text_sha256"),
                    "source_html_sha256": passage.get("source_html_sha256"),
                    "passage_order": passage.get("order"),
                    "link_order": link_order,
                }
                identity = (citation["passage_id"], citation["label"], citation["url"])
                if not any((row.get("passage_id"), row.get("label"), row.get("url")) == identity for row in source["citations"]):
                    source["citations"].append(citation)

    rows: list[dict[str, Any]] = []
    for ref_id in order:
        source = sources[ref_id]
        page_ids = []
        for citation in source["citations"]:
            if citation["page_id"] not in page_ids:
                page_ids.append(citation["page_id"])
        source["citation_count"] = len(source["citations"])
        source["page_count"] = len(page_ids)
        source["page_ids"] = page_ids
        source["display_label"] = source["labels"][0] if source["labels"] else source["host"]
        rows.append(source)

    rows.sort(key=lambda row: (str(row.get("display_label", "")).casefold(), str(row.get("canonical_url", ""))))
    domains: list[dict[str, Any]] = []
    by_host: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_host[str(row.get("host") or "unknown")].append(row)
    for host, host_rows in sorted(by_host.items(), key=lambda item: item[0]):
        domains.append({
            "host": host,
            "source_count": len(host_rows),
            "citation_count": sum(int(row.get("citation_count", 0)) for row in host_rows),
        })

    return {
        "schema": "lumen.references/v1",
        "source_fingerprint_sha256": source_fingerprint,
        "generated_at": generated_at,
        "sources": rows,
        "domains": domains,
        "counts": {
            "sources": len(rows),
            "citations": sum(int(row.get("citation_count", 0)) for row in rows),
            "pages": len({page_id for row in rows for page_id in row.get("page_ids", [])}),
            "domains": len(domains),
        },
        "limits": [
            "Titles are authored link labels, not remotely fetched bibliographic metadata.",
            "A citation record establishes that a link appears in a source-bound passage; it does not establish that the link supports the surrounding claim.",
            "No external source is contacted while building, searching, or opening the local reference room.",
        ],
    }


def build_context_ledger(
    *,
    pages: list[dict[str, Any]],
    passages_by_page: dict[str, list[dict[str, Any]]],
    explicit_related: dict[str, list[str]],
    source_fingerprint: str,
    generated_at: str,
) -> tuple[dict[str, Any], dict[str, dict[str, Any]], dict[str, Any]]:
    """Return global ledger, per-page context files, and a page graph."""
    page_map = {row["id"]: row for row in pages}
    outgoing: dict[str, list[dict[str, Any]]] = defaultdict(list)
    incoming: dict[str, list[dict[str, Any]]] = defaultdict(list)
    graph_edges_raw: list[dict[str, Any]] = []

    for page_id, related in explicit_related.items():
        for target_id in related:
            if target_id not in page_map:
                continue
            edge = {
                "from": page_id,
                "to": target_id,
                "type": "editorial-related",
                "passage_id": None,
                "anchor": None,
                "label": "Editorial relationship",
            }
            outgoing[page_id].append(edge)
            incoming[target_id].append(edge)
            graph_edges_raw.append(edge)

    for page_id, passages in passages_by_page.items():
        for passage in passages:
            for link in passage.get("internal_links", []):
                target_id = link.get("page_id")
                if not target_id or target_id not in page_map or target_id == page_id:
                    continue
                edge = {
                    "from": page_id,
                    "to": target_id,
                    "type": "links-to",
                    "passage_id": passage["id"],
                    "anchor": passage["anchor"],
                    "label": link.get("label") or page_map[target_id]["title"],
                    "target_anchor": link.get("anchor"),
                }
                outgoing[page_id].append(edge)
                incoming[target_id].append(edge)
                graph_edges_raw.append(edge)

    # Keep provenance of every explicit link in context files while aggregating
    # the visual page graph to one typed edge per page pair.
    graph_groups: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for edge in graph_edges_raw:
        graph_groups[(edge["from"], edge["to"], edge["type"])].append(edge)
    graph_edges = []
    for (source, target, kind), rows in sorted(graph_groups.items()):
        graph_edges.append({
            "from": source,
            "to": target,
            "type": kind,
            "count": len(rows),
            "passages": [row["passage_id"] for row in rows if row.get("passage_id")],
        })

    per_page: dict[str, dict[str, Any]] = {}
    page_ledger: list[dict[str, Any]] = []
    passage_ledger: list[dict[str, Any]] = []
    for page in pages:
        page_id = page["id"]
        passages = passages_by_page.get(page_id, [])
        ext_count = sum(len(row.get("external_links", [])) for row in passages)
        page_words = int(page.get("word_count", 0))
        contextual_incoming = []
        for edge in _dedupe(incoming.get(page_id, []), ("from", "to", "type", "passage_id", "target_anchor")):
            source = page_map[edge["from"]]
            item = {
                **edge,
                "from_title": source["title"],
                "from_url": source["url"],
            }
            if edge.get("passage_id"):
                source_passage = next((p for p in passages_by_page.get(edge["from"], []) if p["id"] == edge["passage_id"]), None)
                if source_passage:
                    item["from_passage"] = {
                        "title": source_passage["title"],
                        "url": source_passage["url"],
                        "excerpt": source_passage["excerpt"],
                        "text_sha256": source_passage["text_sha256"],
                    }
            contextual_incoming.append(item)

        contextual_outgoing = []
        for edge in _dedupe(outgoing.get(page_id, []), ("from", "to", "type", "passage_id", "target_anchor")):
            target = page_map[edge["to"]]
            contextual_outgoing.append({
                **edge,
                "to_title": target["title"],
                "to_url": target["url"],
            })

        record = {
            "schema": "lumen.page-context/v1",
            "source_fingerprint_sha256": source_fingerprint,
            "generated_at": generated_at,
            "page": {
                **page,
                "passage_count": len(passages),
                "word_count": page_words,
                "external_citation_count": ext_count,
                "incoming_context_count": len(contextual_incoming),
                "outgoing_context_count": len(contextual_outgoing),
            },
            "passages": passages,
            "incoming": contextual_incoming,
            "outgoing": contextual_outgoing,
        }
        per_page[page_id] = record
        page_ledger.append({
            "id": page_id,
            "url": page["url"],
            "kind": page["kind"],
            "title": page["title"],
            "body_sha256": page.get("body_sha256"),
            "body_bytes": page.get("body_bytes"),
            "word_count": page_words,
            "passage_count": len(passages),
            "external_citation_count": ext_count,
            "incoming_context_count": len(contextual_incoming),
            "outgoing_context_count": len(contextual_outgoing),
        })
        for passage in passages:
            passage_ledger.append({
                key: passage[key]
                for key in (
                    "id", "page_id", "page_url", "page_title", "page_kind", "anchor",
                    "url", "level", "title", "order", "word_count", "text_sha256",
                    "source_html_sha256", "source_offsets",
                )
            })

    ledger = {
        "schema": "lumen.hypertext-ledger/v1",
        "source_fingerprint_sha256": source_fingerprint,
        "generated_at": generated_at,
        "pages": page_ledger,
        "passages": passage_ledger,
        "counts": {
            "pages": len(page_ledger),
            "passages": len(passage_ledger),
            "typed_edges": len(graph_edges_raw),
            "graph_edges": len(graph_edges),
            "external_citations": sum(row["external_citation_count"] for row in page_ledger),
        },
    }
    graph = {
        "schema": "lumen.graph/v2",
        "source_fingerprint_sha256": source_fingerprint,
        "nodes": [
            {key: page[key] for key in ("id", "url", "kind", "title", "status") if key in page}
            for page in pages
        ],
        "edges": graph_edges,
        "legend": {
            "editorial-related": "Declared reading relationship",
            "links-to": "An authored internal link",
        },
    }
    return ledger, per_page, graph
