"""Select publication content explicitly; private recovery has a separate policy."""
from __future__ import annotations

import json
from pathlib import Path

PUBLIC_DATA = frozenset({
    'edition-history.json', 'looks.json', 'reading-paths.json', 'source-snapshot.json',
})


def publication_content_files(root: Path) -> set[Path]:
    root = root.resolve()
    content = root / 'content'
    pages = content / 'pages'
    selected: set[Path] = set()
    body_owners: dict[Path, set[str]] = {}
    for metadata in sorted(pages.rglob('*.json')):
        if metadata.is_symlink() or any(p.is_symlink() for p in metadata.parents if p != root):
            raise ValueError('Public content must not use symbolic links')
        data = json.loads(metadata.read_text(encoding='utf-8'))
        status = data.get('status', 'published')
        if status not in {'published', 'draft'}:
            raise ValueError('Unknown publication status')
        body_name = data.get('body')
        if not isinstance(body_name, str) or not body_name:
            raise ValueError('Page must name its body')
        candidate = metadata.parent / body_name
        if candidate.is_symlink() or any(p.is_symlink() for p in candidate.parents if p != root):
            raise ValueError('Public content must not use symbolic links')
        body = candidate.resolve()
        if pages.resolve() not in body.parents or not body.is_file():
            raise ValueError('Page body must be a file inside content/pages')
        body_owners.setdefault(body, set()).add(status)
        if status == 'published':
            selected.update({metadata.resolve(), body})
    if any(len(statuses) > 1 for statuses in body_owners.values()):
        raise ValueError('One body cannot be both public and draft')
    for name in sorted(PUBLIC_DATA):
        path = content / 'data' / name
        if not path.is_file() or path.is_symlink():
            raise ValueError('Required public data record missing or symbolic')
        selected.add(path.resolve())
    return selected
