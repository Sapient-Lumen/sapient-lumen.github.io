/* Reviewed, dependency-free host pump. Works in functions.exec and Node mocks.
 * Evaluate with new Function(source + '\nreturn runGitHubDelivery;')().
 * No eval of remote data, filesystem/network APIs, auth, or background loop.
 */
async function runGitHubDelivery(tools, options) {
  'use strict';
  const allowed = new Set(['mcp__codex_apps__github_fetch',
    'mcp__codex_apps__github_fetch_file', 'mcp__codex_apps__github_create_blob',
    'mcp__codex_apps__github_create_tree', 'mcp__codex_apps__github_create_commit',
    'mcp__codex_apps__github_update_ref']);
  const quote = text => "'" + String(text).replace(/'/g, "'\\''") + "'";
  const helper = options.helper;
  const run = options.run;
  if (!helper || !run) throw new Error('Explicit helper and private run paths required');
  const rpc = async request => {
    // A quoted heredoc transports JSON without shell expansion. JSON.stringify
    // escapes embedded newlines, so content cannot insert the delimiter.
    const json = JSON.stringify(request);
    if (json.length > 90000) throw new Error('RPC chunk too large');
    let result = await tools.exec_command({
      cmd: 'python3 ' + quote(helper) + ' rpc --run ' + quote(run) + " <<'LUMEN_DELIVERY_RPC'\n" + json + '\nLUMEN_DELIVERY_RPC',
      max_output_tokens: 22000, yield_time_ms: 10000
    });
    let output = result.output || '';
    while (result.session_id) {
      if (typeof tools.write_stdin !== 'function') {
        return {status: 'paused', reason: 'Local host is still running; poll this exact session before resuming.', session_id: result.session_id};
      }
      result = await tools.write_stdin({session_id: result.session_id, chars: '', yield_time_ms: 1000, max_output_tokens: 22000});
      output += result.output || '';
    }
    let data;
    try { data = JSON.parse(output); }
    catch (_) { throw new Error('Missing/truncated host JSON; do not repeat a mutation. Resume the durable run.'); }
    if (data.status === 'blocked') return data;
    if (result.exit_code !== 0) throw new Error('Local host failed without a structured blocker');
    return data;
  };
  const persistResponse = async (id, result) => {
    const text = JSON.stringify(result);
    let offset = 0;
    // Offsets use UTF-8 bytes on disk. Slicing avoids splitting surrogate pairs.
    for (let index = 0; index < text.length;) {
      let end = Math.min(index + 16000, text.length);
      if (end < text.length && /[\uD800-\uDBFF]/.test(text[end - 1])) end--;
      const data = text.slice(index, end);
      const saved = await rpc({command: 'response-chunk', action_id: id, offset, data});
      if (saved.status !== 'chunk-accepted') return saved;
      offset = saved.offset; index = end;
    }
    return rpc({command: 'accept', action_id: id});
  };
  if (options.bundle) {
    const initialized = await rpc({command: 'init', bundle: options.bundle,
      project_id: options.projectId, pointer_path: options.pointerPath || 'recovery/field-notes-current.json', pages_url: options.pagesUrl || null});
    if (initialized.status !== 'initialized') return initialized;
  }
  const beginning = await rpc({command: 'begin'});
  if (beginning.status !== 'ready') return beginning;
  let last;
  const limit = options.maxActions === undefined ? 200 : options.maxActions;
  if (!Number.isInteger(limit) || limit < 1 || limit > 10000) throw new Error('maxActions must be 1..10000');
  for (let count = 0; count < limit; count++) {
    const next = await rpc({command: 'next', stop_after: options.stopAfter});
    if (next.status !== 'action') return next;
    const action = next.action;
    let result;
    try {
      if (action.tool === 'mcp__codex_apps__github_PUBLIC_RAW' || action.tool === 'mcp__codex_apps__github_PAGES_LIVE') {
        result = await rpc({command: action.step === 'pages_returned' ? 'live-download' : 'raw-download', action_id: action.id});
        if (result.status === 'paused') return result;
        if (result.status === 'blocked') result = {isError: true, host_error: result.error};
      } else {
        if (!allowed.has(action.tool) || typeof tools[action.tool] !== 'function') {
          throw new Error('Required allowlisted connector action unavailable: ' + action.tool);
        }
        const args = {...action.args};
        if (action.step === 'blob') {
          let content = '';
          for (;;) {
            const chunk = await rpc({command: 'chunk', action_id: action.id, offset: content.length});
            if (chunk.status === 'blocked') return chunk;
            if (typeof chunk.content !== 'string' || !Number.isInteger(chunk.total) || (!chunk.content && content.length < chunk.total)) {
              throw new Error('Invalid/truncated upload chunk');
            }
            content += chunk.content;
            if (content.length === chunk.total) break;
            if (content.length > chunk.total) throw new Error('Upload chunk overrun');
          }
          args.content = content;
        }
        result = await tools[action.tool](args);
      }
    } catch (_) {
      // Do not write exception strings, which might include credentials or
      // arbitrary transport detail. The original tool error is the operator's
      // diagnostic; the journal records only that completion is unconfirmed.
      result = {isError: true, host_error: 'Host/connector call did not complete with an acknowledged result; inspect original tool response.'};
    }
    last = await persistResponse(action.id, result);
    if (last.status !== 'accepted') return last;
    if (options.onProgress) await options.onProgress({scope: action.scope, step: action.step, actionId: action.id});
  }
  return {status: 'boundary', reason: 'maxActions reached at an acknowledged durable boundary', last};
}
if (typeof module !== 'undefined') module.exports = {runGitHubDelivery};
