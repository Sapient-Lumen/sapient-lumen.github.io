## Effect

Describe the user-visible or tooling effect.

## Evidence

- [ ] `./lumen verify --canonical` passes
- [ ] changed source claims identify their captured revision
- [ ] observation, inference, and unknowns remain distinct
- [ ] no archive, secret, native source artifact, or unrelated workspace file enters `dist/`
- [ ] accessibility and no-JavaScript reading remain intact
- [ ] passage IDs, citations, backlinks, and typed relationships remain truthful to authored source
- [ ] any cited correction packet was checked with `./lumen correction PACKET.json --check`; changed bytes were reviewed rather than silently reattached
- [ ] changed published note prose has a reviewed `./lumen revise … --summary …` entry and `./lumen history --check` passes

## Limits

State the strongest conclusion this change does **not** support.
