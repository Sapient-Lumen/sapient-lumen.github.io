from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import shutil
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_cli():
    spec = importlib.util.spec_from_file_location("lumen_cli", ROOT / "tools" / "lumen_cli.py")
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class LumenCliTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.cli = load_cli()
        cls.cli.STATE_DIR.mkdir(parents=True, exist_ok=True)
        cls.build_fixture = tempfile.TemporaryDirectory(
            prefix="cli-test-fixture-", dir=cls.cli.STATE_DIR
        )
        cls.addClassCleanup(cls.build_fixture.cleanup)
        cls.cli.DIST = Path(cls.build_fixture.name) / "dist"
        cls.cli.run([
            sys.executable, "tools/build.py", "--clean", "--output", str(cls.cli.DIST)
        ])

    def test_build_fixture_is_isolated_from_canonical_dist(self) -> None:
        self.assertNotEqual(self.cli.DIST, ROOT / "dist")
        self.assertTrue((self.cli.DIST / "meta" / "folios.json").is_file())

    def test_slugify_is_stable_and_shell_safe(self) -> None:
        self.assertEqual(self.cli.slugify("A Light / Through Evidence"), "a-light-through-evidence")
        self.assertEqual(self.cli.slugify("***"), "untitled")

    def test_command_parser_exposes_cloudtainer_workflow(self) -> None:
        parser = self.cli.parser()
        for argv, command in [
            (["doctor"], "doctor"),
            (["build", "--clean"], "build"),
            (["dev", "--port", "9000"], "dev"),
            (["start"], "start"),
            (["new", "note", "Test"], "new"),
            (["drafts"], "drafts"),
            (["page", "home"], "page"),
            (["context", "lab#every-section-keeps-its-place"], "context"),
            (["references", "arxiv", "--format", "json"], "references"),
            (["thread", "continuity-and-return", "--format", "markdown"], "thread"),
            (["cite", "lab#every-section-keeps-its-place"], "cite"),
            (["folio", "note-place-return", "--check"], "folio"),
            (["pathfolio", "continuity-and-return", "--check"], "pathfolio"),
            (["marker", "lab#every-section-keeps-its-place"], "marker"),
            (["marker", "--check", "return-point.json"], "marker"),
            (["correction", "--new", "lab#every-section-keeps-its-place", "--issue", "Check this sentence"], "correction"),
            (["packet", "lab#every-section-keeps-its-place"], "packet"),
            (["packet", "--desk", "reading-desk.json"], "packet"),
            (["packet", "--fieldbook", "lumen-fieldbook.json"], "packet"),
            (["edit", "home", "--path-only"], "edit"),
            (["publish", "note-test"], "publish"),
            (["history", "--check"], "history"),
            (["compare", "older-Lumen.html"], "compare"),
            (["revise", "note-test", "--summary", "Clarified wording"], "revise"),
            (["sync", "--check"], "sync"),
            (["perf"], "perf"),
            (["preserve"], "preserve"),
            (["reopen", "checkpoint.zip", "--verify-only"], "reopen"),
            (["capsule"], "capsule"),
            (["release"], "release"),
            (["handoff"], "handoff"),
            (["ship"], "ship"),
        ]:
            with self.subTest(argv=argv):
                self.assertEqual(parser.parse_args(argv).command, command)

    def test_handoff_operator_surface_names_portable_folios(self) -> None:
        commands = self.cli.handoff_operator_commands()
        self.assertIn("./lumen folio [PAGE_ID]", commands)
        self.assertIn("./lumen pathfolio [PATH_ID]", commands)
        self.assertEqual(len(commands), len(set(commands)))

    def test_portable_folio_export_copies_exact_manifest_bound_bytes(self) -> None:
        payload = self.cli.portable_folio_records()
        self.assertEqual(payload["schema"], "lumen.portable-folios/v1")
        record = next(row for row in payload["folios"] if row["page_id"] == "note-place-return")
        source = self.cli.verify_portable_folio(record)
        with tempfile.TemporaryDirectory(prefix="lumen-folio-test-") as temp:
            destination = Path(temp) / "kept.html"
            args = argparse.Namespace(
                target="note-place-return",
                output=str(destination),
                format="text",
                check=False,
                replace=False,
                build=False,
            )
            self.assertEqual(self.cli.cmd_folio(args), 0)
            self.assertEqual(destination.read_bytes(), source.read_bytes())
            self.assertEqual(hashlib.sha256(destination.read_bytes()).hexdigest(), record["sha256"])

    def test_portable_path_folio_export_copies_exact_manifest_bound_bytes(self) -> None:
        payload = self.cli.portable_path_folio_records()
        self.assertEqual(payload["schema"], "lumen.portable-path-folios/v1")
        record = next(row for row in payload["folios"] if row["path_id"] == "continuity-and-return")
        source = self.cli.verify_portable_path_folio(record)
        with tempfile.TemporaryDirectory(prefix="lumen-path-folio-test-") as temp:
            destination = Path(temp) / "continuity.html"
            args = argparse.Namespace(
                target="Continuity and return",
                output=str(destination),
                format="text",
                check=False,
                replace=False,
                build=False,
            )
            self.assertEqual(self.cli.cmd_pathfolio(args), 0)
            self.assertEqual(destination.read_bytes(), source.read_bytes())
            self.assertEqual(hashlib.sha256(destination.read_bytes()).hexdigest(), record["sha256"])

    def test_context_target_accepts_hash_and_stable_passage_identity(self) -> None:
        self.assertEqual(
            self.cli.split_context_target("lab#every-section-keeps-its-place"),
            ("lab", "every-section-keeps-its-place"),
        )
        self.assertEqual(
            self.cli.split_context_target("lab::every-section-keeps-its-place"),
            ("lab", "every-section-keeps-its-place"),
        )
        self.assertEqual(self.cli.split_context_target("lab"), ("lab", ""))

    def test_return_marker_is_source_bound_and_refuses_changed_text(self) -> None:
        marker = self.cli.create_return_marker(
            "note-concern-control#1-i-will-not-collapse-the-predicates"
        )
        self.assertEqual(marker["schema"], "lumen.return-marker/v1")
        self.assertEqual(marker["scope"], "passage")
        self.assertRegex(marker["text_sha256"], r"^[0-9a-f]{64}$")
        exact = self.cli.review_return_marker(marker)
        self.assertEqual(exact["schema"], "lumen.return-marker-review/v1")
        self.assertEqual(exact["status"], "exact")
        self.assertTrue(exact["exact"])
        self.assertEqual(exact["target"]["passage_id"], marker["passage_id"])

        changed = json.loads(json.dumps(marker))
        changed["text_sha256"] = "0" * 64
        review = self.cli.review_return_marker(changed)
        self.assertEqual(review["status"], "changed")
        self.assertFalse(review["exact"])
        self.assertIn("rather than rebound", " ".join(review["limits"]))

        normalized = self.cli.normalize_return_marker_payload({
            **marker,
            "block_index": 2,
            "block_text_sha256": "1" * 64,
            "block_excerpt": "A bounded exact prose block.",
            "scroll_percent": 41.7,
        })
        self.assertEqual(normalized["block_index"], 2)
        self.assertEqual(normalized["scroll_percent"], 42)

    def test_page_resolver_accepts_stable_identity_and_url(self) -> None:
        path_by_id, page_by_id = self.cli.resolve_page("note-concern-control")
        path_by_url, page_by_url = self.cli.resolve_page("/notes/concern-and-control/")
        self.assertEqual(path_by_id, path_by_url)
        self.assertEqual(page_by_id["id"], page_by_url["id"])
        record = self.cli.page_record(path_by_id, page_by_id)
        self.assertEqual(record["status"], "published")
        self.assertIn("body", record)
        self.assertIn("metadata", record)

    def test_snapshot_is_machine_readable_and_has_unique_repositories(self) -> None:
        snapshot = json.loads((ROOT / "content" / "data" / "source-snapshot.json").read_text(encoding="utf-8"))
        names = [row["name"] for row in snapshot["repositories"]]
        self.assertEqual(len(names), len(set(names)))
        self.assertIn("Sapient-Lumen/W4R3Z", names)
        self.assertEqual(snapshot["schema"], "lumen.upstream-snapshot/v4")
        self.assertEqual(len(snapshot["repositories"]), 4)
        self.assertEqual(len(snapshot["retired_sources"]), 1)
        self.assertIsInstance(snapshot["changes_since_previous"], list)
        self.assertGreaterEqual(len(snapshot["activity"]), 7)
        for row in snapshot["repositories"]:
            self.assertRegex(row["head_sha"], r"^[0-9a-f]{40}$")


    def test_edition_history_matches_current_published_bodies(self) -> None:
        rows = self.cli.history_rows()
        self.assertEqual({r["id"] for r in rows}, set(self.cli.edition_history()["notes"]))
        self.assertTrue(all(row["matches"] for row in rows))
        self.assertEqual(sum(row["revision_count"] for row in rows), sum(len(r["revisions"]) for r in self.cli.edition_history()["notes"].values()))
        continuity = next(row for row in rows if row["id"] == "note-continuity-evidence")
        self.assertEqual(continuity["revision_count"], 2)

    def test_edition_comparison_reads_capsules_and_reports_exact_differences(self) -> None:
        # Build the carrier in an isolated directory so the repository handoff is
        # testable from a fresh extraction with no pre-existing canonical dist/.
        with tempfile.TemporaryDirectory(prefix="lumen-edition-test-") as temp:
            output = Path(temp) / "dist"
            self.cli.run([
                sys.executable,
                "tools/build.py",
                "--clean",
                "--output",
                str(output),
            ])
            current = self.cli.load_edition_summary(output / "Lumen.html")
        same = self.cli.compare_edition_summaries(current, current)
        self.assertEqual(same["schema"], "lumen.edition-comparison/v2")
        self.assertEqual(same["relation"], "same")
        self.assertEqual(same["counts"]["changed"], 0)
        self.assertEqual(same["counts"]["current-only"], 0)
        self.assertEqual(same["counts"]["passage_differences"], 0)
        self.assertEqual(same["counts"]["sources_same"], len(current["sources"]["active"]) + len(current["sources"]["retired"]))
        modified = json.loads(json.dumps({
            "schema": "lumen.edition-summary/v2",
            "scope": current["scope"],
            "edition": "rev0001",
            "generated_at": current["generated_at"],
            "source_fingerprint_sha256": "0" * 64,
            "pages": list(current["pages"].values()),
            "sources": {
                "active": list(current["sources"]["active"].values()),
                "retired": list(current["sources"]["retired"].values()),
            },
        }))
        page_with_passages = next(row for row in modified["pages"] if row.get("passages"))
        page_with_passages["body_sha256"] = "f" * 64
        page_with_passages["passages"][0]["text_sha256"] = "e" * 64
        page_with_passages["passages"][0]["excerpt"] = "A deliberately changed passage excerpt for comparison testing."
        removed_id = next(row["id"] for row in reversed(modified["pages"]) if row["id"] != page_with_passages["id"])
        modified["pages"] = [row for row in modified["pages"] if row["id"] != removed_id]
        comparison = self.cli.compare_edition_summaries(current, modified)
        self.assertEqual(comparison["relation"], "older")
        self.assertEqual(comparison["counts"]["changed"], 1)
        self.assertEqual(comparison["counts"]["current-only"], 1)
        self.assertEqual(comparison["counts"]["passages_changed"], 1)
        self.assertEqual(comparison["counts"]["passage_differences"], 1)
        changed_page = next(row for row in comparison["pages"] if row["id"] == page_with_passages["id"])
        self.assertTrue(changed_page["passage_detail_available"])
        self.assertEqual(next(row for row in changed_page["passages"] if row["state"] != "same")["state"], "changed")
        rendered = self.cli.render_edition_comparison(comparison, "markdown")
        self.assertIn("Lumen edition comparison", rendered)
        self.assertIn("Publication changes", rendered)
        self.assertIn("Source-bound passage differences", rendered)

    def test_v1_summary_without_context_stays_page_level_after_normalization(self) -> None:
        payload = {
            "schema": "lumen.edition-summary/v1",
            "scope": "complete",
            "edition": "rev0001",
            "source_fingerprint_sha256": "1" * 64,
            "pages": [{
                "id": "note-old",
                "url": "/notes/old/",
                "kind": "note",
                "title": "Old note",
                "status": "published",
                "body_sha256": "2" * 64,
                "body_bytes": 12,
            }],
            "sources": {"active": [{"name": "Sapient-Lumen/Lumen", "head_sha": "3" * 64}], "retired": []},
        }
        first = self.cli.normalize_edition_summary(payload)
        second = self.cli.normalize_edition_summary(first)
        self.assertEqual(second["source_schema"], "lumen.edition-summary/v1")
        self.assertFalse(second["pages"]["note-old"]["passage_detail"])
        self.assertIn("Sapient-Lumen/Lumen", second["sources"]["active"])

    def test_drift_report_never_claims_automatic_adoption(self) -> None:
        text = self.cli.drift_report({"captured_at": "2026-10-01T00:00:00Z", "owner": "Sapient-Lumen"}, ["CHANGED x"])
        self.assertIn("does not silently adopt", text)
        self.assertIn("CHANGED x", text)

    def test_correction_packet_binds_exact_source_and_rejects_tampering(self) -> None:
        packet = self.cli.create_correction_packet(
            "note-concern-control#1-i-will-not-collapse-the-predicates",
            issue="The sentence needs verification.",
            report_type="factual",
            evidence="Check the cited source.",
        )
        self.assertEqual(packet["schema"], "lumen.correction-packet/v1")
        self.assertRegex(packet["packet_content_sha256"], r"^[0-9a-f]{64}$")
        self.assertEqual(packet["location"]["page_id"], "note-concern-control")
        self.assertIn("source_offsets", packet["location"])
        review = self.cli.correction_comparison(packet)
        self.assertEqual(review["status"], "exact")
        self.assertTrue(all(review["matches"].values()))

        changed = json.loads(json.dumps(packet))
        changed["location"]["passage_text_sha256"] = "0" * 64
        changed["packet_content_sha256"] = self.cli.correction_packet_hash(changed)
        self.assertEqual(self.cli.correction_comparison(changed)["status"], "changed")

        with tempfile.TemporaryDirectory(prefix="lumen-correction-") as directory:
            path = Path(directory) / "packet.json"
            path.write_text(json.dumps(packet), encoding="utf-8")
            loaded_path, loaded = self.cli.load_correction_packet(str(path))
            self.assertEqual(loaded_path, path)
            self.assertEqual(loaded["packet_content_sha256"], packet["packet_content_sha256"])
            loaded["report"]["issue"] = "Altered after hashing"
            path.write_text(json.dumps(loaded), encoding="utf-8")
            with self.assertRaises(self.cli.LumenError):
                self.cli.load_correction_packet(str(path))

    def test_release_zip_is_deterministic_for_same_tree(self) -> None:
        with tempfile.TemporaryDirectory(prefix="lumen-cli-test-") as directory:
            root = Path(directory)
            source = root / "site"
            source.mkdir()
            (source / "b.txt").write_text("beta\n", encoding="utf-8")
            (source / "a.txt").write_text("alpha\n", encoding="utf-8")
            first = root / "one.zip"
            second = root / "two.zip"
            old = os.environ.get("SOURCE_DATE_EPOCH")
            os.environ["SOURCE_DATE_EPOCH"] = "1790900668"
            try:
                self.cli.zip_tree(source, first)
                self.cli.zip_tree(source, second)
            finally:
                if old is None:
                    os.environ.pop("SOURCE_DATE_EPOCH", None)
                else:
                    os.environ["SOURCE_DATE_EPOCH"] = old
            self.assertEqual(hashlib.sha256(first.read_bytes()).digest(), hashlib.sha256(second.read_bytes()).digest())
            with zipfile.ZipFile(first) as archive:
                self.assertEqual(archive.namelist(), ["a.txt", "b.txt"])

    def test_release_build_time_uses_accepted_snapshot(self) -> None:
        old_epoch = os.environ.pop("SOURCE_DATE_EPOCH", None)
        try:
            expected = json.loads((ROOT / "content" / "data" / "source-snapshot.json").read_text(encoding="utf-8"))["captured_at"]
            self.assertEqual(self.cli.release_build_time(), expected)
        finally:
            if old_epoch is not None:
                os.environ["SOURCE_DATE_EPOCH"] = old_epoch

    def test_sync_is_the_only_cli_function_with_github_transport(self) -> None:
        source = (ROOT / "tools" / "lumen_cli.py").read_text(encoding="utf-8")
        self.assertIn("Network access is", source)
        self.assertEqual(source.count("api.github.com"), 4)

    def test_publication_gate_names_incomplete_fields(self) -> None:
        blockers = self.cli.publication_blockers({
            "description": "Draft description: fill me",
            "source": {"repository": "unassigned", "sha": "draft-unreviewed"},
            "limits": [],
        })
        self.assertIn("replace the draft description", blockers)
        self.assertIn("assign source.repository", blockers)
        self.assertTrue(any("source.sha" in item for item in blockers))

    def test_staged_snapshot_acceptance_archives_previous_state(self) -> None:
        with tempfile.TemporaryDirectory(prefix="lumen-sync-accept-") as directory:
            root = Path(directory)
            state = root / ".lumen"
            research = root / "research"
            snapshot = root / "snapshot.json"
            config = root / "config.json"
            candidate = state / "candidate.json"
            report = state / "report.md"
            previous = {"schema": "lumen.upstream-snapshot/v4", "captured_at": "2026-10-01T00:00:00Z", "repositories": []}
            accepted = {
                "schema": "lumen.upstream-snapshot/v4",
                "captured_at": "2026-10-01T01:00:00Z",
                "repositories": [{"name": "Sapient-Lumen/Lumen", "head_sha": "a" * 40}],
                "retired_sources": [],
                "changes_since_previous": [],
            }
            snapshot.write_text(json.dumps(previous), encoding="utf-8")
            config.write_text(json.dumps({"source_snapshot": {}}), encoding="utf-8")
            state.mkdir()
            candidate.write_text(json.dumps(accepted), encoding="utf-8")
            report.write_text("review\n", encoding="utf-8")
            original = (self.cli.SNAPSHOT, self.cli.CONFIG, self.cli.RESEARCH, self.cli.STATE_DIR, self.cli.CANDIDATE, self.cli.CANDIDATE_REPORT)
            self.cli.SNAPSHOT, self.cli.CONFIG, self.cli.RESEARCH = snapshot, config, research
            self.cli.STATE_DIR, self.cli.CANDIDATE, self.cli.CANDIDATE_REPORT = state, candidate, report
            try:
                self.assertEqual(self.cli.accept_staged_snapshot(), 0)
                self.assertEqual(json.loads(snapshot.read_text())["captured_at"], accepted["captured_at"])
                self.assertTrue(any((research / "source-snapshots").glob("*.json")))
                self.assertFalse(candidate.exists())
            finally:
                (self.cli.SNAPSHOT, self.cli.CONFIG, self.cli.RESEARCH, self.cli.STATE_DIR, self.cli.CANDIDATE, self.cli.CANDIDATE_REPORT) = original

    def test_retirement_requires_exact_confirmation(self) -> None:
        candidate = {
            "schema": "lumen.upstream-snapshot/v4",
            "changes_since_previous": [{"repository": "Sapient-Lumen/Old", "to": None}],
        }
        self.assertEqual(self.cli.retirement_candidates(candidate), ["Sapient-Lumen/Old"])

    def test_packet_export_preserves_source_slice_hash(self) -> None:
        passages, fingerprint = self.cli.packet_passages(["lab#every-section-keeps-its-place"])
        self.assertEqual(len(passages), 1)
        passage = passages[0]
        self.assertEqual(hashlib.sha256(passage["source_html"].encode()).hexdigest(), passage["source_html_sha256"])
        self.assertRegex(fingerprint, r"^[0-9a-f]{64}$")
        payload = {"schema": "lumen.reading-packet/v1", "generated_at": "2026-10-02T00:00:00Z", "source_fingerprint_sha256": fingerprint, "passages": passages}
        html = self.cli.packet_html(payload)
        self.assertIn("SOURCE-BOUND READING PACKET", html)
        self.assertIn(passage["source_html_sha256"], html)

    def test_reading_desk_export_resolves_ordered_packet_targets(self) -> None:
        with tempfile.TemporaryDirectory(prefix="lumen-desk-test-") as directory:
            path = Path(directory) / "desk.json"
            path.write_text(json.dumps({
                "schema": "lumen.reading-desk/v1",
                "source_fingerprint_sha256": "a" * 64,
                "entries": [
                    {"stable_id": "lab::every-section-keeps-its-place", "page_id": "lab", "anchor": "every-section-keeps-its-place"},
                    {"stable_id": "note-concern-control", "page_id": "note-concern-control", "anchor": ""},
                    {"stable_id": "lab::every-section-keeps-its-place", "page_id": "lab", "anchor": "every-section-keeps-its-place"},
                ],
            }), encoding="utf-8")
            targets, fingerprint = self.cli.packet_targets_from_desk(str(path))
        self.assertEqual(targets, ["lab#every-section-keeps-its-place", "note-concern-control"])
        self.assertEqual(fingerprint, "a" * 64)

    def test_fieldbook_packet_verifies_exact_quote_and_carries_private_note(self) -> None:
        passages, fingerprint = self.cli.packet_passages(["lab#every-section-keeps-its-place"])
        passage = passages[0]
        normalized = self.cli.normalized_reader_text(passage["text"])
        quote = "Headings receive stable passage identities"
        index = normalized.index(quote)
        quote_sha = hashlib.sha256(quote.encode("utf-8")).hexdigest()
        fieldbook = {
            "schema": "lumen.fieldbook/v1",
            "source_fingerprint_sha256": fingerprint,
            "entries": [{
                "stable_id": f"{passage['id']}::q:{quote_sha[:24]}:{index}",
                "scope": "quote",
                "page_id": passage["page_id"],
                "anchor": passage["anchor"],
                "title": passage["title"],
                "text_sha256": passage["text_sha256"],
                "quote_sha256": quote_sha,
                "quote_selector": {
                    "v": 1,
                    "p": passage["page_id"],
                    "a": passage["anchor"],
                    "q": quote,
                    "i": index,
                    "b": normalized[max(0, index - 48):index],
                    "n": normalized[index + len(quote):index + len(quote) + 48],
                    "h": passage["text_sha256"],
                    "e": "rev0018",
                },
                "note": "This sentence names the invariant I want to keep.",
            }],
        }
        with tempfile.TemporaryDirectory(prefix="lumen-fieldbook-test-") as directory:
            fieldbook_path = Path(directory) / "fieldbook.json"
            fieldbook_path.write_text(json.dumps(fieldbook), encoding="utf-8")
            targets, imported_fingerprint, entries = self.cli.packet_plan_from_fieldbook(str(fieldbook_path))
            self.assertEqual(targets, ["lab#every-section-keeps-its-place"])
            self.assertEqual(imported_fingerprint, fingerprint)
            selections = self.cli.fieldbook_packet_selections(entries, passages)
        self.assertEqual(selections[0]["scope"], "quote")
        self.assertEqual(selections[0]["quote_sha256"], quote_sha)
        self.assertEqual(selections[0]["quote_selector"]["q"], quote)
        payload = {
            "schema": "lumen.reading-packet/v2",
            "generated_at": "2026-10-02T00:00:00Z",
            "source_fingerprint_sha256": fingerprint,
            "passages": passages,
            "selections": selections,
        }
        html = self.cli.packet_html(payload)
        self.assertIn("EXACT QUOTE", html)
        self.assertIn(quote, html)
        self.assertIn("This sentence names the invariant", html)
        changed = json.loads(json.dumps(entries))
        changed[0]["quote_selector"]["h"] = "0" * 64
        with self.assertRaises(self.cli.LumenError):
            self.cli.fieldbook_packet_selections(changed, passages)

    def test_reference_ledger_command_filters_without_network(self) -> None:
        parser = self.cli.parser()
        args = parser.parse_args(["references", "arxiv", "--format", "json", "--build"])
        self.assertEqual(args.func.__name__, "cmd_references")
        with tempfile.TemporaryDirectory(prefix="lumen-reference-cli-") as directory:
            old_dist = self.cli.DIST
            self.cli.DIST = Path(directory) / "dist"
            try:
                self.cli.run([sys.executable, "tools/build.py", "--clean", "--output", str(self.cli.DIST)])
                payload = self.cli.reference_records()
                rows = payload["sources"]
                self.assertEqual(len(rows), payload["counts"]["sources"])
                self.assertTrue(any(row["host"] == "arxiv.org" for row in rows))
            finally:
                self.cli.DIST = old_dist

    def test_citation_is_source_bound_and_can_include_exact_quote(self) -> None:
        record = self.cli.citation_record("note-concern-control#1-i-will-not-collapse-the-predicates")
        self.assertEqual(record["schema"], "lumen.citation/v1")
        self.assertRegex(record["text_sha256"], r"^[0-9a-f]{64}$")
        self.assertIn("#1-i-will-not-collapse-the-predicates", record["url"] )
        citation = self.cli.citation_text(record)
        quoted = self.cli.citation_text(record, markdown=True, include_quote=True)
        self.assertIn("text SHA-256", citation)
        self.assertTrue(quoted.startswith("> Let F denote"))
        self.assertIn(record["text_sha256"], quoted)

    def test_private_worktree_checkpoint_is_deterministic_guarded_and_reopenable(self) -> None:
        with tempfile.TemporaryDirectory(prefix="lumen-checkpoint-test-") as directory:
            root = Path(directory)
            first_dir = root / "first"
            second_dir = root / "second"
            first, receipt = self.cli.build_worktree_checkpoint(first_dir)
            second, _ = self.cli.build_worktree_checkpoint(second_dir)
            self.assertEqual(hashlib.sha256(first.read_bytes()).hexdigest(), hashlib.sha256(second.read_bytes()).hexdigest())
            manifest = self.cli.verify_worktree_checkpoint(first)
            self.assertEqual(manifest["schema"], self.cli.CHECKPOINT_SCHEMA)
            names = {row["path"] for row in manifest["members"]}
            self.assertIn("Lumen/lumen", names)
            self.assertFalse(any(name.startswith("Lumen/dist/") or "/.lumen/" in name or name.startswith("Lumen/research/") for name in names))
            self.assertEqual(receipt["network_used"], False)
            destination = root / "reopened"
            args = type("Args", (), {"checkpoint": str(first), "into": str(destination), "verify_only": False})()
            self.assertEqual(self.cli.cmd_reopen(args), 0)
            self.assertEqual((destination / "lumen").read_bytes(), (ROOT / "lumen").read_bytes())
            self.assertTrue((destination / "lumen").stat().st_mode & 0o111)
            with self.assertRaises(self.cli.LumenError):
                self.cli.cmd_reopen(args)

    def test_zip_tree_preserves_executable_bit(self) -> None:
        with tempfile.TemporaryDirectory(prefix="lumen-zip-mode-") as directory:
            root = Path(directory)
            source = root / "source"
            source.mkdir()
            command = source / "lumen"
            command.write_text("#!/bin/sh\n", encoding="utf-8")
            command.chmod(0o755)
            target = root / "out.zip"
            self.cli.zip_tree(source, target)
            with zipfile.ZipFile(target) as archive:
                mode = archive.getinfo("lumen").external_attr >> 16
            self.assertEqual(mode & 0o111, 0o111)


    def test_look_command_lists_and_selects_without_network(self) -> None:
        parser = self.cli.parser()
        args = parser.parse_args(["look"])
        self.assertEqual(args.func.__name__, "cmd_look")
        args = parser.parse_args(["look", "night-study"])
        self.assertEqual(args.target, "night-study")
        manifest = self.cli.read_json(self.cli.LOOKS)
        self.assertEqual(manifest["default"], "field-notes")
        self.assertIn("night-study", {row["id"] for row in manifest["looks"]})


    def test_thread_command_reads_exact_generated_paths_without_network(self) -> None:
        parser = self.cli.parser()
        args = parser.parse_args(["thread", "continuity-and-return", "--format", "json"])
        self.assertEqual(args.func.__name__, "cmd_thread")
        payload = self.cli.reading_path_records()
        self.assertEqual(payload["schema"], "lumen.reading-paths/v1")
        self.assertEqual(payload["counts"]["paths"], 3)
        path = next(row for row in payload["paths"] if row["id"] == "continuity-and-return")
        self.assertEqual(len(path["steps"]), 4)
        self.assertTrue(any(step["scope"] == "passage" for step in path["steps"]))
        rendered = self.cli.render_thread_markdown([path], payload)
        self.assertIn("## Continuity and return", rendered)
        self.assertIn("note-continuity-evidence::the-unit-of-trust-is-an-effect", rendered)


if __name__ == "__main__":
    unittest.main()
