"""Synthetic desktop reader capacity checks for both portable and routed JS."""
from pathlib import Path
import shutil
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[1]
HARNESS = r'''
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(process.argv[1], 'utf8');
function extract(name) {
 const start = source.search(new RegExp('^(?:async )?function ' + name + '\\(', 'm'));
 assert.ok(start >= 0, name);
 return source.slice(start, source.indexOf('\n}',start)+2);
}
vm.runInThisContext(['safeField','emptyDesk','normalizeDeskEntry','loadDesk',
 'deskEntryFromContext','toggleDeskPassage'].map(extract).join('\n'));
global.fieldbookFingerprint = 'a'.repeat(64);
global.fieldbookEdition = 'synthetic-edition';
global.DESK_KEY = 'synthetic-desk';
global.deskStorageAvailable = true;
global.document = {querySelector:() => null};
global.persistDesk = () => {};
global.renderDesk = () => {};
global.pageIdForAnchor = () => 'synthetic';
global.deskState = emptyDesk();
global.localStorage = {getItem:() => JSON.stringify(deskState)};
function entry(id) {
 return normalizeDeskEntry({stable_id:id, page_id:id, page_url:'/'+id+'/',
  title:'Synthetic Ω', text:'T'.repeat(24000), excerpt:'E'.repeat(1400),
  opened_at:'2026-01-01T00:00:00Z', text_sha256:'b'.repeat(64),
  source_fingerprint_sha256:'c'.repeat(64), edition:'synthetic-old'});
}
'''


@unittest.skipUnless(shutil.which('node'), 'Node.js is required for executable desk tests')
class ReaderDeskCapacityTests(unittest.TestCase):
    def run_reader(self, body):
        for name in ('site.js', 'capsule.js'):
            with self.subTest(runtime=name):
                result = subprocess.run(['node', '-e', HARNESS + '\n(async () => {\n' + body +
                    '\n})().catch(error => {console.error(error); process.exitCode=1;});',
                    str(ROOT / 'assets/js' / name)], capture_output=True, text=True, cwd=ROOT)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_full_desk_refuses_new_item_preserves_existing_and_allows_refresh_remove(self):
        self.run_reader(r'''
deskState.entries = Array.from({length:64}, (_,i) => entry('desk-'+i));
const before = JSON.stringify(deskState.entries);
global.fieldbookContextProvider = async () => ({page:{id:'overflow',title:'Overflow'}});
await assert.rejects(toggleDeskPassage('',{pageId:'overflow'}), /64/);
assert.equal(JSON.stringify(deskState.entries), before);
assert.deepEqual(loadDesk().entries, deskState.entries);
fieldbookContextProvider = async () => ({page:{id:'desk-0',title:'Refreshed'}});
await toggleDeskPassage('',{pageId:'desk-0',forceAdd:true});
assert.equal(deskState.entries.length,64);
assert.equal(deskState.entries[0].title,'Refreshed');
await toggleDeskPassage('',{pageId:'desk-0'});
assert.equal(deskState.entries.length,63);
assert.deepEqual(deskState.entries.map(row=>row.stable_id),Array.from({length:63},(_,i)=>'desk-'+(i+1)));
''')

    def test_last_available_slot_roundtrips_full_text(self):
        self.run_reader(r'''
deskState.entries = Array.from({length:63}, (_,i) => entry('desk-'+i));
global.fieldbookContextProvider = async () => ({page:{id:'last-page',title:'Last page'},
 passages:[{id:'last-page::passage',anchor:'passage',title:'Last passage',
 text:'Ω'.repeat(24000),excerpt:'E'.repeat(1400),text_sha256:'b'.repeat(64)}]});
await toggleDeskPassage('passage',{pageId:'last-page'});
assert.equal(deskState.entries.length,64);
assert.equal(deskState.entries[63].text.length,24000);
assert.deepEqual(loadDesk().entries,deskState.entries);
''')

    def test_context_save_button_reports_capacity_without_unhandled_rejection(self):
        self.run_reader(r'''
vm.runInThisContext(['findDeskEntry','makeDeskSaveButton'].map(extract).join('\n'));
deskState.entries = Array.from({length:64}, (_,i) => entry('desk-'+i));
const payload = {page:{id:'overflow', title:'Overflow'}};
global.fieldbookContextProvider = async () => payload;
let click, status;
global.setDeskStatus = message => {status=message;};
document.createElement = () => ({setAttribute(){},addEventListener(event,fn){assert.equal(event,'click');click=fn;}});
const button = makeDeskSaveButton(payload);
await click();
assert.match(status,/64/); assert.equal(button.textContent,status);
assert.equal(deskState.entries.length,64);
''')
