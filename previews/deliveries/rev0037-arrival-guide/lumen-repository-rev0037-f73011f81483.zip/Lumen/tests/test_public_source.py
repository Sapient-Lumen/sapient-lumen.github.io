from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('publication_selector', ROOT / 'tools/public_source.py')
selector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(selector)

class PublicSelectionTests(unittest.TestCase):
    def fixture(self, root):
        (root / 'content/pages').mkdir(parents=True)
        (root / 'content/data').mkdir()
        for name in selector.PUBLIC_DATA:
            (root / 'content/data' / name).write_text('{}')
        for name, status in [('accepted', 'published'), ('unfinished', 'draft')]:
            (root / 'content/pages' / (name + '.html')).write_text('<p>Fixture text</p>')
            (root / 'content/pages' / (name + '.json')).write_text(json.dumps({'body':name+'.html','status':status}))
        (root / 'content/pages/orphan.txt').write_text('Not selected')
        (root / 'content/data/unlisted.json').write_text('{}')

    def test_only_accepted_page_pairs_and_named_data_are_selected(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.fixture(root)
            paths={p.relative_to(root).as_posix() for p in selector.publication_content_files(root)}
            self.assertEqual(paths, {'content/pages/accepted.html','content/pages/accepted.json'} | {'content/data/'+n for n in selector.PUBLIC_DATA})

    def test_unknown_status_refuses_public_selection(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.fixture(root)
            (root/'content/pages/unfinished.json').write_text('{"body":"unfinished.html","status":"unreviewed"}')
            with self.assertRaises(ValueError):selector.publication_content_files(root)

    def test_shared_public_and_draft_body_refused(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.fixture(root)
            (root/'content/pages/unfinished.json').write_text('{"body":"accepted.html","status":"draft"}')
            with self.assertRaises(ValueError):selector.publication_content_files(root)

    def test_both_public_packagers_use_selection(self):
        for name in ['capsule.py','lumen_cli.py']:
            self.assertIn('public_content = publication_content_files(ROOT)', (ROOT/'tools'/name).read_text())

    @unittest.skipUnless(shutil.which('node'), 'Optional pure JavaScript check requires Node')
    def test_browser_source_comparison_preserves_git_identifiers(self):
        source=(ROOT/'assets/js/edition-compare.js').read_text()
        parts=[]
        for name in ['safeString','normalizeHex','normalizeGitOid','compareGitOids','normalizeSources','compareSources']:
            start=source.index('  function '+name+'(')
            end=source.find('\n  function ',start+1)
            parts.append(source[start:end])
        test='''
const assert = require('node:assert/strict');
const wrap=(head)=>({sources:normalizeSources({active:[{name:'sample/project',head_sha:head}]})});
assert.equal(normalizeHex('a'.repeat(40)), '');
assert.equal(normalizeGitOid('a'.repeat(40)), 'a'.repeat(40));
assert.equal(normalizeGitOid('b'.repeat(64)), 'b'.repeat(64));
assert.equal(compareSources(wrap('a'.repeat(40)),wrap('b'.repeat(40)))[0].state,'changed');
assert.equal(compareSources(wrap('a'.repeat(40)),wrap('a'.repeat(40)))[0].state,'same');
assert.equal(compareSources(wrap('invalid'),wrap('invalid'))[0].state,'unknown');
'''
        subprocess.run(['node','-e','\n'.join(parts)+test],check=True,capture_output=True,text=True)

    @unittest.skipUnless(shutil.which('node'), 'Optional pure JavaScript check requires Node')
    def test_capsule_preserves_legacy_home_fragments(self):
        source=(ROOT/'assets/js/capsule.js').read_text()
        parts=[]
        for name in ['normalizeRoute','routeState']:
            start=source.index('function '+name+'(')
            end=source.find('\nfunction ',start+1)
            parts.append(source[start:end])
        test='''
const assert=require('node:assert/strict');
let location={hash:'#concern-is-not-sovereignty'};
assert.deepEqual(routeState(),{route:'/',anchor:'concern-is-not-sovereignty',quote:''});
location.hash='#/notes/concern-and-control/?anchor=one';
assert.deepEqual(routeState(),{route:'/notes/concern-and-control/',anchor:'one',quote:''});
location.hash='';assert.equal(routeState().route,'/');
location.hash='#%ZZ';assert.equal(routeState().anchor,'%ZZ');
'''
        subprocess.run(['node','-e','\n'.join(parts)+test],check=True,capture_output=True,text=True)

    @unittest.skipUnless(shutil.which('node'), 'Optional pure JavaScript check requires Node')
    def test_local_navigation_closes_only_its_origin_dialog(self):
        source=(ROOT/'assets/js/capsule.js').read_text()
        start=source.index('function closeReaderDialogForLink(')
        end=source.index('\ndocument.addEventListener',start)
        test='''
const assert=require('node:assert/strict');let closed=0;
closeReaderDialogForLink({closest:(selector)=>{assert.equal(selector,'dialog[open]');return {close:()=>closed++};}});
assert.equal(closed,1);closeReaderDialogForLink({closest:()=>null});assert.equal(closed,1);
'''
        subprocess.run(['node','-e',source[start:end]+test],check=True,capture_output=True,text=True)
        self.assertIn('if (href.startsWith("#/")) { closeReaderDialogForLink(link); return; }',source)

    @unittest.skipUnless(shutil.which('node'), 'Optional pure JavaScript check requires Node')
    def test_fieldbook_import_preserves_local_notes_and_reports_conflicts(self):
        for filename in ['site.js','capsule.js']:
            source=(ROOT/'assets/js'/filename).read_text();parts=[]
            for name in ['validateFieldbookImport','mergeFieldbookEntries']:
                start=source.index('function '+name+'(');end=source.find('\nfunction ',start+1);parts.append(source[start:end])
            test='''
const assert=require('node:assert/strict');
const local={stable_id:'page-one',note:'Keep this local note'};
const incoming={stable_id:'page-one',note:'Different imported note'};
const result=mergeFieldbookEntries([local],[incoming,{stable_id:'page-two',note:'New'}]);
assert.equal(result.entries[0].note,local.note);assert.equal(result.conflicts,1);assert.equal(result.added,1);
assert.equal(mergeFieldbookEntries([local],[local]).unchanged,1);
assert.equal(mergeFieldbookEntries([local],[{stable_id:'page-two'}],1).full,1);
assert.throws(()=>validateFieldbookImport({schema:'unrecognized',entries:[]}));
assert.throws(()=>validateFieldbookImport({schema:'lumen.fieldbook/v1',entries:[local,local]}));
assert.throws(()=>validateFieldbookImport({schema:'lumen.fieldbook/v1',entries:Array.from({length:251},(_,i)=>({stable_id:String(i)}))}));
assert.equal(validateFieldbookImport({schema:'lumen.fieldbook/v1',entries:[local]}).entries.length,1);
'''
            subprocess.run(['node','-e','\n'.join(parts)+test],check=True,capture_output=True,text=True)
