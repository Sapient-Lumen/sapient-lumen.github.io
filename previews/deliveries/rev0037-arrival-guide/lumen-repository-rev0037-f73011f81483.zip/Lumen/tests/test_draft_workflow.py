"""Exercise an unpublished note through the real offline operator commands."""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]


class DraftWorkflowTests(unittest.TestCase):
    def test_new_note_preview_canonical_and_private_recovery(self) -> None:
        with tempfile.TemporaryDirectory(prefix="lumen-draft-workflow-") as directory:
            work = Path(directory)
            root = work / "Lumen"
            shutil.copytree(ROOT, root, ignore=shutil.ignore_patterns(
                "dist", ".git", ".lumen", "__pycache__", "research", "releases", "handoffs"
            ))
            env = dict(os.environ, LUMEN_BUILD_TIME="2026-10-03T00:00:00Z")

            def run(*args: str, cwd: Path = root, ok: bool = True) -> subprocess.CompletedProcess:
                result = subprocess.run(args, cwd=cwd, env=env, capture_output=True, text=True)
                if ok:
                    self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
                else:
                    self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
                return result

            history_path = root / "content/data/edition-history.json"
            history_before = history_path.read_bytes()
            config_before = (root / "config.json").read_bytes()
            run("./lumen", "doctor")
            run("./lumen", "new", "note", "Everyday Draft Workflow Probe", "--date", "2026-10-03")
            slug = "everyday-draft-workflow-probe"
            draft_id = f"note-{slug}"
            meta = root / f"content/pages/notes/{slug}.json"
            body = meta.with_suffix(".html")
            draft_bytes = (meta.read_bytes(), body.read_bytes())
            preview = work / "preview"
            run("./lumen", "build", "--clean", "--include-drafts", "--output", str(preview))
            run("python3", "tools/check_dist.py", str(preview))
            html = (preview / f"notes/{slug}/index.html").read_text()
            self.assertIn("Draft preview.", html)
            self.assertIn("noindex", html)
            self.assertNotIn(f"/editions/#history-{draft_id}", html)
            inspection = json.loads((preview / f"meta/pages/{draft_id}.json").read_text())["page"]
            self.assertEqual(inspection["status"], "draft")
            self.assertEqual(inspection["publication_history"], [])
            accepted = json.loads(history_before)["notes"]
            ledger = json.loads((preview / "meta/editions.json").read_text())
            self.assertEqual(ledger["notes"], accepted)
            receipt = json.loads((preview / "build-receipt.json").read_text())
            self.assertEqual(receipt["mode"], "preview")
            self.assertEqual(receipt["counts"]["note_revisions"], sum(len(n["revisions"]) for n in accepted.values()))
            self.assertNotIn("capsule", receipt)

            canonical = work / "canonical"
            run("./lumen", "build", "--clean", "--output", str(canonical))
            run("python3", "tools/check_dist.py", str(canonical))
            self.assertFalse((canonical / f"notes/{slug}").exists())
            self.assertFalse((canonical / f"meta/pages/{draft_id}.json").exists())
            self.assertNotIn(draft_id, (canonical / "meta/search-index.json").read_text())
            with zipfile.ZipFile(canonical / "Lumen.html") as capsule:
                self.assertFalse(any(slug in name for name in capsule.namelist()))
            self.assertEqual(history_path.read_bytes(), history_before)
            self.assertEqual((root / "config.json").read_bytes(), config_before)

            checkpoints = work / "checkpoints"
            run("./lumen", "preserve", "--output", str(checkpoints))
            archive, = checkpoints.glob("*.zip")
            with zipfile.ZipFile(archive) as checkpoint:
                self.assertEqual(checkpoint.read(f"Lumen/content/pages/notes/{slug}.html"), draft_bytes[1])
            reopened = work / "reopened"
            run("./lumen", "reopen", str(archive), "--into", str(reopened))
            self.assertEqual((reopened / meta.relative_to(root)).read_bytes(), draft_bytes[0])
            self.assertEqual((reopened / body.relative_to(root)).read_bytes(), draft_bytes[1])
            self.assertEqual((reopened / history_path.relative_to(root)).read_bytes(), history_before)
            run("./lumen", "doctor", cwd=reopened)
            run("./lumen", "build", "--clean", "--include-drafts", "--output", str(work / "reopened-preview"), cwd=reopened)
            run("python3", "tools/check_dist.py", str(work / "reopened-preview"), cwd=reopened)

            # Preview permission must not relax accepted-note integrity.
            accepted_id = next(iter(accepted))
            published_meta = next(p for p in (root / "content/pages").rglob("*.json")
                                  if json.loads(p.read_text()).get("id") == accepted_id)
            published_body = published_meta.with_name(json.loads(published_meta.read_text())["body"])
            original = published_body.read_bytes()
            published_body.write_bytes(original + b"\n<p>Unaccepted change.</p>\n")
            result = run("./lumen", "build", "--clean", "--include-drafts", "--output", str(preview), ok=False)
            self.assertIn("authored body differs", result.stdout + result.stderr)
            published_body.write_bytes(original)
            history = json.loads(history_before)
            del history["notes"][accepted_id]
            history_path.write_text(json.dumps(history))
            result = run("./lumen", "build", "--clean", "--include-drafts", "--output", str(preview), ok=False)
            self.assertIn("edition history missing note ids", result.stdout + result.stderr)
            history = json.loads(history_before)
            history["notes"][draft_id] = next(iter(accepted.values()))
            history_path.write_text(json.dumps(history))
            result = run("./lumen", "build", "--clean", "--include-drafts", "--output", str(preview), ok=False)
            self.assertIn("edition history contains unknown note ids", result.stdout + result.stderr)


if __name__ == "__main__":
    unittest.main()
