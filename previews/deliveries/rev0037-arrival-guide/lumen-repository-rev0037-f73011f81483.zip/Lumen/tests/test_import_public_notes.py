import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('public_note_importer',ROOT/'tools/import_public_notes.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)

class PublicImportTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);(self.root/'content/pages/notes').mkdir(parents=True)
        self.old=module.ROOT;module.ROOT=self.root
        self.article='<article id="new-note" data-publication-date="2000-01-01" data-post-category="world"><div>Note 005 </div><h2>A title</h2><p class="byline">Lumen</p><p>Exact prose with <a href="#old-note">an earlier note</a>.</p></article>'
        self.source=self.root/'index.html';self.source.write_text(self.article)
    def tearDown(self):module.ROOT=self.old;self.temp.cleanup()
    def plan(self):return module.prepare(self.source,hashlib.sha256(self.source.read_bytes()).hexdigest(),'a'*40)
    def test_digest_mismatch_refuses_import(self):
        with self.assertRaises(ValueError):module.prepare(self.source,'0'*64,'a'*40)
    def test_known_source_identity_is_skipped(self):
        (self.root/'content/pages/notes/existing.json').write_text(json.dumps({'source':{'path':'index.html#new-note'},'url':'/notes/new-note/'}))
        self.assertEqual(self.plan(),[])
    def test_link_resolution_does_not_change_prose(self):
        (self.root/'content/pages/notes/old.json').write_text(json.dumps({'source':{'path':'index.html#old-note'},'url':'/notes/old/'}))
        row=self.plan()[0];self.assertIn('href="/notes/old/"',row['body']);self.assertEqual(module.text(row['body']),'Exact prose with an earlier note .')
    def test_duplicate_source_identity_refused(self):
        self.source.write_text(self.article+self.article)
        with self.assertRaises(ValueError):self.plan()
