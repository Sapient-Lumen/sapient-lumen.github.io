"""Executable synthetic reader-state regressions; no browser or network required."""
from pathlib import Path
import shutil
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[1]

HARNESS = r'''
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const filename = process.argv[1];
const source = fs.readFileSync(filename, 'utf8');
function extract(name) {
  const re = new RegExp('^(?:async )?function ' + name + '\\(', 'm');
  const start = source.search(re);
  assert.ok(start >= 0, name);
  const end = source.indexOf('\n}', start);
  assert.ok(end > start, name);
  return source.slice(start, end + 2);
}
const names = ['emptyFieldbook', 'safeField', 'normalizedQuoteText', 'normalizeQuoteSelector',
  'normalizeFieldbookEntry', 'validateFieldbookImport', 'mergeFieldbookEntries',
  'normalizeFieldbook', 'fieldbookExportPayload', 'escapeFieldbookHtml', 'fieldbookPacketHtml',
  'fieldbookEntryHref', 'fieldbookRouteHref', 'encodeQuotePayload', 'entryFromContext',
  'toggleFieldbookPassage', 'saveFieldbookQuoteFromSelection', 'downloadFieldbookFile'];
if (filename.endsWith('capsule.js')) names.push('capsuleHref', 'normalizeRoute');
vm.runInThisContext(names.map(extract).join('\n'));
global.fieldbookFingerprint = 'a'.repeat(64);
global.fieldbookEdition = 'synthetic-edition';
global.allowedReadingSizes = new Set(['compact', 'standard', 'large']);
global.allowedReadingMeasures = new Set(['narrow', 'standard', 'wide']);
global.location = filename.endsWith('capsule.js')
  ? {protocol: 'file:', origin: 'null', href: 'file:///tmp/Lumen.html#/'}
  : {protocol: 'https:', origin: 'https://example.test', href: 'https://example.test/'};
global.fieldbookState = emptyFieldbook();
global.renderFieldbook = () => {};
global.persistFieldbook = () => {};
global.pageIdForAnchor = () => 'synthetic';
global.pendingSelection = null;
function entry(id = 'synthetic::passage') {
  return normalizeFieldbookEntry({stable_id:id, scope:'passage', page_id:'synthetic',
    page_url:'/synthetic/', page_title:'Synthetic Ω', title:'A < B & C', anchor:'passage',
    excerpt:'First line\nSecond line', note:'Private synthetic note\n"<& Ω 🧪',
    text_sha256:'b'.repeat(64), source_html_sha256:'c'.repeat(64),
    source_fingerprint_sha256:'d'.repeat(64), edition:'old-edition',
    source_offsets:{start:12,end:48}, word_count:5, saved_at:'2026-01-01T00:00:00Z'});
}
function imported(payload) {
  const parsed = validateFieldbookImport(JSON.parse(JSON.stringify(payload)));
  const normalized = normalizeFieldbook(parsed);
  if (normalized.entries.length !== parsed.entries.length) throw Error('colliding identities');
  return normalized;
}
'''


@unittest.skipUnless(shutil.which('node'), 'Node.js is required for executable reader tests')
class ReaderRoundtripTests(unittest.TestCase):
    def run_reader(self, body):
        for runtime in ('site.js', 'capsule.js'):
            with self.subTest(runtime=runtime):
                result = subprocess.run(
                    ['node', '-e', HARNESS + '\n(async () => {\n' + body +
                     '\n})().catch(error => { console.error(error); process.exitCode = 1; });',
                     str(ROOT / 'assets/js' / runtime)],
                    capture_output=True, text=True, cwd=ROOT)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_export_roundtrip_preserves_all_normalized_entry_fields(self):
        self.run_reader(r'''
const quote = entry('synthetic::passage::q:synthetic:12');
quote.scope = 'quote'; quote.quote_sha256 = 'e'.repeat(64);
quote.quote_selector = normalizeQuoteSelector({p:'synthetic', a:'passage', q:'Exact Ω quote',
  i:12, b:'before ', n:' after', h:'b'.repeat(64), e:'old-edition'});
fieldbookState.entries = [entry('synthetic'), entry(), quote];
fieldbookState.preferences = {size:'large', measure:'wide'};
const payload = fieldbookExportPayload();
const restored = imported(payload);
assert.deepEqual(restored, fieldbookState);
assert.deepEqual(imported({...payload, entries:restored.entries}), restored);
assert.equal(payload.exported_from.location, location.protocol === 'file:' ? 'local Lumen.html' : location.origin);
''')

    def test_ui_note_and_quote_limits_roundtrip_without_truncation(self):
        self.run_reader(r'''
const item = entry(); item.note = '🧪'.repeat(2000);
const quote = {...entry('boundary-quote'), scope:'quote', excerpt:'Q'.repeat(700),
  quote_sha256:'e'.repeat(64), quote_selector:normalizeQuoteSelector({p:'synthetic',
  a:'passage', q:'Q'.repeat(700), i:0})};
fieldbookState.entries = [item, quote];
assert.equal(item.note.length,4000); assert.equal(quote.quote_selector.q.length,700);
assert.deepEqual(imported(fieldbookExportPayload()).entries, fieldbookState.entries);
assert.ok(source.includes('area.maxLength = 4000;'));
assert.ok(source.includes('entry.note = area.value.slice(0, 4000);'));
assert.ok(source.includes('quote.length < 3 || quote.length > 700'));
''')

    def test_merge_keeps_local_notes_and_reports_capacity(self):
        self.run_reader(r'''
const local = entry(); const conflict = {...local, note:'incoming differs'};
assert.deepEqual(mergeFieldbookEntries([local], [local, conflict, entry('new')]), {
 entries:[local, entry('new')], added:1, conflicts:1, unchanged:1, full:0});
const full = Array.from({length:250}, (_, i) => entry('entry-'+i));
const result = mergeFieldbookEntries(full, [entry('overflow')]);
assert.deepEqual(result.entries, full); assert.equal(result.full, 1);
assert.deepEqual(imported({...fieldbookExportPayload(), entries:full}).entries, full);
assert.throws(() => imported({...fieldbookExportPayload(), entries:[...full, entry('overflow')]}), /250/);
assert.throws(() => imported({...fieldbookExportPayload(), entries:[local, local]}), /distinct/);
''')

    def test_packet_preserves_notes_receipts_and_route_specific_locators(self):
        self.run_reader(r'''
const item = entry(); fieldbookState.entries = [item];
const html = fieldbookPacketHtml();
for (const value of [item.stable_id, item.note.split('\n')[0], item.text_sha256, item.source_fingerprint_sha256,
  escapeFieldbookHtml(item.title), escapeFieldbookHtml(item.note).replace(/\n/g, '<br>'),
  escapeFieldbookHtml(fieldbookEntryHref(item))]) assert.ok(html.includes(value), value);
const quote = {...item, scope:'quote', quote_sha256:'e'.repeat(64),
 quote_selector:normalizeQuoteSelector({p:'synthetic', a:'passage', q:'Ω exact', i:12})};
fieldbookState.entries = [quote];
assert.ok(fieldbookPacketHtml().includes(quote.quote_sha256));
const href = fieldbookEntryHref(quote);
const params = filename.endsWith('capsule.js')
 ? new URLSearchParams(href.split('?')[1]) : new URL(href).searchParams;
const decoded = JSON.parse(Buffer.from(params.get('lq'), 'base64url').toString('utf8'));
assert.deepEqual(decoded, quote.quote_selector);
''')

    def test_download_helper_hands_exact_utf8_bytes_to_blob_and_anchor(self):
        self.run_reader(r'''
let downloaded, clicked = false, removed = false, revoked, timer;
const anchor = {click(){clicked=true;}, remove(){removed=true;}};
global.document = {createElement:tag => {assert.equal(tag,'a'); return anchor;}, body:{append:a => assert.equal(a,anchor)}};
URL.createObjectURL = blob => {downloaded=blob; return 'blob:synthetic';};
URL.revokeObjectURL = url => {revoked=url;};
global.setTimeout = (fn, delay) => {assert.equal(delay,1000); timer=fn;};
fieldbookState.entries = [entry()];
for (const [name, body, type] of [['trail.json',JSON.stringify(fieldbookExportPayload(),null,2)+'\n','application/json'],
 ['packet.html',fieldbookPacketHtml(),'text/html']]) {
 downloadFieldbookFile(name,body,type);
 assert.equal(await downloaded.text(),body); assert.equal(downloaded.type,type);
 assert.equal(anchor.download,name); assert.equal(anchor.href,'blob:synthetic');
 assert.ok(clicked && removed); timer(); assert.equal(revoked,'blob:synthetic');
}
''')

    def test_full_fieldbook_refuses_new_passages_without_losing_existing_entries(self):
        self.run_reader(r'''
fieldbookState.entries = Array.from({length:250}, (_,i) => entry('entry-'+i));
const before = JSON.stringify(fieldbookState.entries);
global.fieldbookContextProvider = async () => ({page:{id:'overflow',title:'Overflow',url:'/overflow/'}});
await assert.rejects(toggleFieldbookPassage('', {pageId:'overflow'}), /250/);
assert.equal(JSON.stringify(fieldbookState.entries), before);
assert.deepEqual(imported(fieldbookExportPayload()).entries, fieldbookState.entries);
// Refresh and removal remain available at the limit.
fieldbookContextProvider = async () => ({page:{id:'entry-0',title:'Refreshed'}});
await toggleFieldbookPassage('', {pageId:'entry-0',forceSave:true});
assert.equal(fieldbookState.entries.length,250);
assert.equal(fieldbookState.entries[0].note, entry('entry-0').note);
await toggleFieldbookPassage('', {pageId:'entry-0'});
assert.equal(fieldbookState.entries.length,249);
''')

    def test_full_fieldbook_refuses_new_quotes_but_allows_refresh(self):
        self.run_reader(r'''
fieldbookState.entries = Array.from({length:250}, (_,i) => entry('entry-'+i));
const before = JSON.stringify(fieldbookState.entries);
global.fieldbookQuoteEntryFromSelection = async () => entry('overflow-quote');
await assert.rejects(saveFieldbookQuoteFromSelection({}), /250/);
assert.equal(JSON.stringify(fieldbookState.entries), before);
fieldbookQuoteEntryFromSelection = async () => ({...entry('entry-0'), note:'replacement'});
await saveFieldbookQuoteFromSelection({});
assert.equal(fieldbookState.entries.length,250);
assert.equal(fieldbookState.entries[0].note, entry('entry-0').note);
''')

    def test_context_save_button_reports_capacity_without_unhandled_rejection(self):
        self.run_reader(r'''
vm.runInThisContext(['findFieldbookEntry','makeFieldbookSaveButton'].map(extract).join('\n'));
fieldbookState.entries = Array.from({length:250}, (_,i) => entry('entry-'+i));
const payload = {page:{id:'overflow',title:'Overflow'}};
global.fieldbookContextProvider = async () => payload;
let click, status;
global.setFieldbookStatus = message => {status=message;};
global.document = {createElement:() => ({setAttribute(){},addEventListener(event,fn){assert.equal(event,'click');click=fn;}})};
const button = makeFieldbookSaveButton(payload);
await click();
assert.match(status,/250/); assert.match(button.textContent,/250/);
assert.equal(fieldbookState.entries.length,250);
assert.equal(button.textContent,'The reading trail is full (250 items). Export a backup and remove an item before saving another.');
''')
