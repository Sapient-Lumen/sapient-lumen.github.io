"""Reject lossy external reader imports atomically in both shipping runtimes."""
import shutil
import subprocess
import unittest

from test_reader_roundtrips import HARNESS, ROOT


@unittest.skipUnless(shutil.which('node'), 'Node.js is required for executable reader tests')
class ReaderImportLimitTests(unittest.TestCase):
    def run_reader(self, body):
        for runtime in ('site.js', 'capsule.js'):
            with self.subTest(runtime=runtime):
                result = subprocess.run(
                    ['node', '-e', HARNESS + '\n(async () => {\n' + body +
                     '\n})().catch(error => { console.error(error); process.exitCode = 1; });',
                     str(ROOT / 'assets/js' / runtime)],
                    capture_output=True, text=True, cwd=ROOT)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_over_limit_notes_and_quotes_refuse_entire_import_without_mutation(self):
        self.run_reader(r'''
let change, status, writes = 0, renders = 0;
global.fieldbookImport = {value:'selected', files:[], addEventListener(event, callback) {
  assert.equal(event,'change'); change=callback;
}};
global.setFieldbookStatus = message => {status=message;};
global.persistFieldbook = () => {writes++;};
global.renderFieldbook = () => {renders++;};
const marker = 'fieldbookImport?.addEventListener("change", async () => {';
const start = source.indexOf(marker);
assert.ok(start >= 0);
vm.runInThisContext(source.slice(start, source.indexOf('\n});',start) + 4));
const longQuote = 'Q'.repeat(699) + ' X'; // 701; slicing at 700 leaves trailing whitespace.
const invalidEntries = [
 {...entry('oversize-note'), note:'N'.repeat(4001)},
 {...entry('oversize-unicode'), note:'🧪'.repeat(2000)+'X'},
 {...entry('oversize-quote'), scope:'quote', quote_selector:{q:longQuote}},
 {...entry('alias-quote'), scope:'quote', quote:{quote:longQuote}},
 {...entry('nested-alias'), scope:'quote', quote_selector:{quote:longQuote}},
];
for (const invalid of invalidEntries) {
 const local = entry(); fieldbookState.entries = [local];
 const before = JSON.stringify(fieldbookState);
 const payload = {...fieldbookExportPayload(), entries:[entry('valid-new'),
   {...local,note:'conflicting incoming note'}, invalid]};
 const original = JSON.stringify(payload);
 fieldbookImport.value = 'selected';
 fieldbookImport.files = [{size:original.length,text:async () => original}];
 await change();
 assert.match(status,/Import refused: A (note|quote) exceeds the (4000|700)-character limit/);
 assert.match(status,/no items were imported/);
 assert.equal(JSON.stringify(fieldbookState), before);
 assert.equal(JSON.stringify(payload), original);
 assert.equal(writes,0); assert.equal(renders,0);
 assert.equal(fieldbookImport.value,'');
}
''')

    def test_supported_boundaries_aliases_and_merge_remain_backward_compatible(self):
        self.run_reader(r'''
const local = entry();
const exactNote = {...entry('boundary-note'),note:'🧪'.repeat(2000)};
const exactQuote = {...entry('boundary-quote'),scope:'quote',quote_selector:{q:'Q'.repeat(700)}};
const aliasQuote = {...entry('legacy-alias'),scope:'quote',quote:{quote:'Q'.repeat(700)}};
const spacedQuote = {...entry('whitespace'),scope:'quote',quote_selector:{q:'  '+ 'Q'.repeat(700)+'\n  '}};
const payload = {...fieldbookExportPayload(),entries:[exactNote,exactQuote,aliasQuote,spacedQuote,
 {...local,note:'incoming conflict'}]};
const normalized = imported(payload);
assert.equal(normalized.entries[0].note,exactNote.note);
for (const item of normalized.entries.slice(1,4)) assert.equal(item.quote_selector.q,'Q'.repeat(700));
assert.deepEqual(normalizeFieldbook(JSON.parse(JSON.stringify(normalized))),normalized);
const merged = mergeFieldbookEntries([local],normalized.entries);
assert.equal(merged.conflicts,1); assert.equal(merged.added,4);
assert.equal(merged.entries[0].note,local.note);
fieldbookState.entries=merged.entries;
assert.deepEqual(imported(fieldbookExportPayload()).entries,merged.entries);
''')

    def test_legacy_local_storage_normalization_is_explicitly_unchanged(self):
        self.run_reader(r'''
const legacy = {...entry(),scope:'quote',note:'N'.repeat(4001),
 quote_selector:{q:'Q'.repeat(699)+' X'}};
// Local-storage loading still uses normalization directly, not import validation.
const once = normalizeFieldbook({entries:[legacy]});
const twice = normalizeFieldbook(JSON.parse(JSON.stringify(once)));
assert.equal(once.entries[0].note.length,4000);
assert.equal(once.entries[0].quote_selector.q.length,700);
assert.equal(twice.entries[0].quote_selector.q.length,699);
''')
