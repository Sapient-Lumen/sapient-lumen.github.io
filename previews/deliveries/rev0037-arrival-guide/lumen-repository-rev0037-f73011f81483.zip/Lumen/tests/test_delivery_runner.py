"""Local safety contracts for the credential-free connector host."""
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'tools'))
import delivery as d
import delivery_runner as r
import test_delivery as fixtures


class RunnerContracts(unittest.TestCase):
    def setUp(self):
        self.fixture = fixtures.DeliveryTests()
        self.fixture.setUp()
        self.fixture.args.part_bytes = 160000
        self.fixture.prepare()
        self.root = self.fixture.root/'run'
        self.bundle = self.fixture.root/'bundle'
        r.init_run(self.root, self.bundle, 'test', 'recovery/current.json')

    def tearDown(self):
        self.fixture.tearDown()

    def test_run_replay_uses_normalized_location(self):
        (self.fixture.root/'alias').mkdir()
        r.init_run(self.fixture.root/'alias/../run', self.fixture.root/'alias/../bundle', 'test', 'recovery/current.json')
        self.assertEqual(r.Runner(self.root).request['bundle'], str(self.bundle))

    def test_symlink_cancelled_by_parent_refused(self):
        (self.fixture.root/'link').symlink_to(self.fixture.root/'bundle', target_is_directory=True)
        with self.assertRaises(d.DeliveryError):
            r.init_run(self.fixture.root/'link/../other', self.bundle, 'test', 'recovery/current.json')

    def test_modified_frozen_payload_refused_before_network(self):
        next((self.bundle/'public').rglob('Lumen.html')).write_text('changed')
        with self.assertRaises(d.DeliveryError): r.Runner(self.root)

    def test_run_bundle_must_be_disjoint(self):
        with self.assertRaises(d.DeliveryError): r.init_run(self.bundle/'run', self.bundle, 'test', 'recovery/current.json')

    def test_visibility_is_authenticated_not_inferred(self):
        runner=r.Runner(self.root); action=runner.next()['action']
        with self.assertRaises(d.DeliveryError):
            runner.accept(action['id'], {'structuredContent': {'content': json.dumps({'full_name':'example/private','private':False})}})

    def test_unresolved_mutation_cannot_advance(self):
        runner=r.Runner(self.root)
        action=runner.next()['action']
        runner.state['unresolved']=action;runner.state['pending']=None;runner.save()
        self.assertEqual(r.Runner(self.root).next()['status'],'paused')

    def test_failed_read_keeps_a_durable_action(self):
        runner=r.Runner(self.root); action=runner.next()['action']
        runner.accept(action['id'], {'isError': True})
        self.assertEqual(r.Runner(self.root).next()['status'],'paused')
        r.rpc(self.root, {'command':'retry-read'})
        next_action=r.Runner(self.root).next()['action']
        self.assertNotEqual(next_action['id'],action['id'])
        self.assertEqual(next_action['args'],action['args'])

    def test_known_complete_response_recovers_before_state_save(self):
        runner=r.Runner(self.root);action=runner.next()['action']
        response={'structuredContent': {'content': json.dumps({'full_name':'example/private','private':True})}}
        d.save(self.root/'actions'/action['id']/'response.partial', json.dumps(response).encode())
        result=r.Runner(self.root).next()
        self.assertEqual(result['action']['step'],'baseline_ref')

    def test_response_chunk_divergence_refused(self):
        action=r.Runner(self.root).next()['action']
        r.rpc(self.root, {'command':'response-chunk','action_id':action['id'],'offset':0,'data':'original'})
        with self.assertRaises(d.DeliveryError):
            r.rpc(self.root, {'command':'response-chunk','action_id':action['id'],'offset':0,'data':'changed'})

    def test_pending_intent_drift_refused_before_chunk_or_dispatch(self):
        runner=r.Runner(self.root)
        row=runner.record['public_inventory'][0]
        action=runner.issue('public','blob','create_blob',{'repository_full_name':'example/public','encoding':'base64'},mutation=True,expected=row['git_blob_sha'],payload={'path':row['path'],'bytes':row['bytes']})['action']
        state=d.load(self.root/'STATE.json')
        secret=runner.record['private_inventory'][0]
        state['pending'].update(scope='private',expected=secret['git_blob_sha'],payload={'path':secret['path'],'bytes':secret['bytes']})
        r.write(self.root/'STATE.json',state)
        for command in ({'command':'next'}, {'command':'chunk','action_id':action['id'],'offset':0}):
            with self.assertRaisesRegex(d.DeliveryError,'immutable intent'):
                r.rpc(self.root,command)

    def test_unresolved_intent_drift_refused(self):
        runner=r.Runner(self.root);action=runner.next()['action']
        runner.state['unresolved']=dict(action,args={'url':'https://example.invalid'})
        runner.save()
        with self.assertRaisesRegex(d.DeliveryError,'immutable intent'): r.Runner(self.root)

    def test_large_binary_upload_chunks_are_exact_and_bounded(self):
        import os, base64
        data=os.urandom(100000)
        record=d.load(self.bundle/'DELIVERY.json')
        row=next(row for row in record['public_inventory'] if row['path'].endswith('site.zip'))
        target=self.bundle/'public'/row['path'];d.save(target,data)
        record['public_inventory']=d.inventory(self.bundle/'public')
        record['public_inventory_sha256']=d.sha(d.encoded(record['public_inventory']))
        r.write(self.bundle/'DELIVERY.json',record)
        request=d.load(self.root/'REQUEST.json');request['bundle_sha256']=d.sha(d.regular(self.bundle/'DELIVERY.json'));r.write(self.root/'REQUEST.json',request)
        runner=r.Runner(self.root)
        row=next(row for row in record['public_inventory'] if row['path'].endswith('site.zip'))
        action=runner.issue('public','blob','create_blob',{'repository_full_name':'example/public','encoding':'base64'},mutation=True,expected=row['git_blob_sha'],payload={'path':row['path'],'bytes':row['bytes']})['action']
        content=''
        while True:
            chunk=r.rpc(self.root,{'command':'chunk','action_id':action['id'],'offset':len(content)})
            self.assertLessEqual(len(chunk['content']),16384)
            content+=chunk['content']
            if len(content)==chunk['total']:break
        self.assertEqual(base64.b64decode(content),data)

    def test_js_host_contract_in_isolated_v8(self):
        import shutil, subprocess
        node=shutil.which('node')
        self.assertIsNotNone(node, 'Node is required for the JS host smoke gate; no host validation was run')
        source=Path(__file__).resolve().parents[1]/'tools/github_delivery_runner.js'
        program=r"""
const assert=require('node:assert/strict'), fs=require('node:fs'), vm=require('node:vm');
const run=vm.runInNewContext(fs.readFileSync(process.argv[1],'utf8')+'; runGitHubDelivery',{});
let mutations=0, received='';
const tools={exec_command:async args=>{
  const request=JSON.parse(args.cmd.split('\n')[1]);let value;
  if(request.command==='begin') value={status:'ready'};
  else if(request.command==='next') value={status:'action',action:{id:'test',scope:'private',step:'created_commit',tool:'mcp__codex_apps__github_create_commit',args:{repository_full_name:'example/private'}}};
  else if(request.command==='response-chunk'){received+=request.data;value={status:'chunk-accepted',offset:Buffer.byteLength(received)};}
  else if(request.command==='accept'){assert.equal(JSON.parse(received).structuredContent.sha,'a'.repeat(40));value={status:'accepted'};}
  else throw new Error('unexpected host request');
  return {exit_code:0,output:JSON.stringify(value)};
},mcp__codex_apps__github_create_commit:async args=>{mutations++;assert.equal(args.repository_full_name,'example/private');return {structuredContent:{sha:'a'.repeat(40)}};}};
run(tools,{helper:'/reviewed/helper.py',run:'/private/run',maxActions:1}).then(result=>{assert.equal(result.status,'boundary');assert.equal(mutations,1);console.log('host-smoke-ok');}).catch(error=>{console.error(error);process.exitCode=1;});
"""
        result=subprocess.run([node,'-e',program,str(source)],capture_output=True,text=True,timeout=15)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        self.assertEqual(result.stdout.strip(),'host-smoke-ok')

    def test_begin_does_not_retry_a_known_failed_preflight(self):
        runner=r.Runner(self.root)
        action=runner.read('private','pre_ref','/git/ref/heads/main')['action']
        runner.accept(action['id'], {'isError': True})
        self.assertEqual(r.rpc(self.root,{'command':'begin'})['status'],'ready')
        result=r.rpc(self.root,{'command':'next'})
        self.assertEqual(result['status'],'paused')
        self.assertEqual(result['action_id'],action['id'])
        self.assertTrue(r.Runner(self.root).state['pending']['failed'])

    def test_real_connector_json_wrapper(self):
        self.assertEqual(r.unwrap({'structuredContent':{'content':'{"sha":"abc"}','title':'main'}}), {'sha':'abc'})
        value={'encoding':'base64','content':'AP8=','sha':'abc'}
        self.assertEqual(r.unwrap({'structuredContent':value},file=True),value)


if __name__ == '__main__': unittest.main()
