"""Source-level arrival checks; these do not claim interactive browser acceptance."""
from __future__ import annotations

import hashlib
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import build
import capsule
import check_capsule


class CommentProbe(HTMLParser):
    def __init__(self):
        super().__init__()
        self.comments = []
        self.tags = []
        self.data = []

    def handle_comment(self, data):
        self.comments.append(data)

    def handle_starttag(self, tag, attrs):
        self.tags.append(tag)

    def handle_data(self, data):
        self.data.append(data)


class ArrivalCommentTests(unittest.TestCase):
    def test_comment_framing_is_literal_and_nonexecuting(self):
        for text in ("Use --clean and --canonical.\n", ">text", "->text", "text<!-",
                     '<script>alert("inert")</script> & <style>inert</style>'):
            with self.subTest(text=text):
                probe = CommentProbe()
                probe.feed(capsule.arrival_guide_comment(text))
                probe.close()
                self.assertEqual(probe.comments, ["\n" + text + "\n"])
                self.assertEqual(probe.tags, [])
                self.assertEqual(probe.data, [])

    def test_unsafe_comment_content_is_refused(self):
        for token in ("<!--", "-->", "--!>", "\x00"):
            with self.subTest(token=token):
                with self.assertRaisesRegex(ValueError, "unsafe HTML comment"):
                    capsule.arrival_guide_comment("before " + token + " after")

    def test_guide_is_a_fingerprinted_template_input(self):
        guide = ROOT / "templates" / "capsule-arrival.txt"
        original_read = Path.read_bytes
        before = build.stable_source_hash()
        with mock.patch.object(Path, "read_bytes", autospec=True, side_effect=lambda path:
                               original_read(path) + (b"changed guide\n" if path == guide else b"")):
            self.assertNotEqual(build.stable_source_hash(), before)


class CapsuleArrivalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix="lumen-arrival-")
        cls.root = Path(cls.temp.name)
        cls.dist = cls.root / "first"
        cls.env = os.environ.copy()
        cls.env["LUMEN_BUILD_TIME"] = "2026-10-01T21:30:00Z"
        cls.run_build(ROOT, cls.dist)
        cls.raw = (cls.dist / "Lumen.html").read_bytes()
        cls.guide = (ROOT / "templates" / "capsule-arrival.txt").read_bytes()

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    @classmethod
    def run_build(cls, source, output):
        subprocess.run([sys.executable, str(source / "tools" / "build.py"), "--clean",
                        "--output", str(output)], cwd=source, env=cls.env, check=True,
                       capture_output=True, text=True)

    def test_guide_is_first_head_comment_after_early_charset_and_before_styles(self):
        marker = b'<meta charset="utf-8">'
        charset_end = self.raw.index(marker) + len(marker)
        self.assertLessEqual(charset_end, 1024)
        comment = capsule.arrival_guide_comment(self.guide.decode("utf-8")).encode("utf-8")
        self.assertEqual(self.raw[charset_end:charset_end + len(comment) + 1], b"\n" + comment)
        guide_end = charset_end + len(comment) + 1
        self.assertLessEqual(guide_end, 4096)
        self.assertLess(guide_end, self.raw.index(b"<style>"))
        probe = CommentProbe()
        probe.feed(self.raw[:guide_end].decode("utf-8"))
        probe.close()
        self.assertEqual(probe.tags, ["html", "head", "meta"])
        self.assertEqual(probe.comments, ["\n" + self.guide.decode("utf-8") + "\n"])
        self.assertTrue(all(not value.strip() for value in probe.data))

    def test_manifest_receipts_bind_the_guide_and_reject_prefix_tampering(self):
        errors, manifest = check_capsule.validate(self.dist / "Lumen.html")
        self.assertEqual(errors, [])
        prefix = self.raw[:manifest["html_prefix"]["bytes"]]
        self.assertEqual(hashlib.sha256(prefix).hexdigest(), manifest["html_prefix"]["sha256"])
        guide_name = "Lumen/templates/capsule-arrival.txt"
        row = next(row for row in manifest["members"] if row["path"] == guide_name)
        self.assertEqual(row["bytes"], len(self.guide))
        self.assertEqual(row["sha256"], hashlib.sha256(self.guide).hexdigest())
        with zipfile.ZipFile(self.dist / "Lumen.html") as archive:
            self.assertEqual(archive.read(guide_name), self.guide)
            self.assertFalse(any(name.endswith("/Lumen.sh") for name in archive.namelist()))
        digest = hashlib.sha256(self.raw).hexdigest()
        receipt = json.loads((self.dist / "meta" / "capsule.json").read_text())
        self.assertEqual(receipt["sha256"], digest)
        self.assertEqual((self.dist / "Lumen.html.sha256").read_text(), digest + "  Lumen.html\n")
        altered = self.root / "altered.html"
        altered.write_bytes(self.raw.replace(b"ARRIVAL GUIDE", b"ALTERED GUIDE", 1))
        errors, _ = check_capsule.validate(altered)
        self.assertIn("HTML prefix SHA-256 disagrees with manifest", errors)

    def test_rebuild_is_deterministic_and_standard_extraction_round_trips_exactly(self):
        second = self.root / "second"
        self.run_build(ROOT, second)
        self.assertEqual((second / "Lumen.html").read_bytes(), self.raw)
        fresh = self.root / "fresh-workspace"
        fresh.mkdir()
        subprocess.run([sys.executable, "-m", "zipfile", "-e", str(self.dist / "Lumen.html"),
                        str(fresh)], check=True, capture_output=True, text=True)
        with zipfile.ZipFile(self.dist / "Lumen.html") as archive:
            self.assertIsNone(archive.testzip())
            for member in archive.namelist():
                self.assertEqual((fresh / member).read_bytes(), archive.read(member), member)
        extracted = fresh / "Lumen"
        self.assertEqual((extracted / "templates" / "capsule-arrival.txt").read_bytes(), self.guide)
        # Match the documented Python-extraction fallback before packaging again.
        launcher = extracted / "lumen"
        launcher.chmod(launcher.stat().st_mode | 0o111)
        self.run_build(extracted, extracted / "dist")
        self.assertEqual((extracted / "dist" / "Lumen.html").read_bytes(), self.raw)
        errors, _ = check_capsule.validate(extracted / "dist" / "Lumen.html")
        self.assertEqual(errors, [])


if __name__ == "__main__":
    unittest.main()
