from __future__ import annotations

import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKFLOWS = ROOT / ".github" / "workflows"


class GitHubSurfaceTests(unittest.TestCase):
    def test_external_actions_are_commit_pinned(self) -> None:
        pattern = re.compile(r"^\s*-?\s*uses:\s*([^@\s]+)@([^\s#]+)", re.MULTILINE)
        found = []
        for path in sorted(WORKFLOWS.glob("*.yml")):
            text = path.read_text(encoding="utf-8")
            for action, revision in pattern.findall(text):
                if action.startswith("./"):
                    continue
                found.append((path.name, action, revision))
                self.assertRegex(revision, r"^[0-9a-f]{40}$", f"{path}: {action} is not commit pinned")
        self.assertGreaterEqual(len(found), 10)

    def test_workflows_are_bounded_and_least_privilege(self) -> None:
        for path in sorted(WORKFLOWS.glob("*.yml")):
            text = path.read_text(encoding="utf-8")
            self.assertIn("permissions:", text, path)
            self.assertNotIn("write-all", text, path)
            self.assertIn("timeout-minutes:", text, path)
        pages = (WORKFLOWS / "pages.yml").read_text(encoding="utf-8")
        self.assertIn("path: dist", pages)
        self.assertNotIn("path: .", pages)

    def test_pull_request_preview_is_review_only(self) -> None:
        preview = (WORKFLOWS / "pr-preview.yml").read_text(encoding="utf-8")
        self.assertIn("pull_request:", preview)
        self.assertIn("--include-drafts", preview)
        self.assertIn("/tmp/lumen-pr-preview", preview)
        self.assertIn("actions/upload-artifact@", preview)
        self.assertIn("retention-days: 14", preview)
        self.assertNotIn("deploy-pages", preview)
        self.assertNotIn("pages: write", preview)

    def test_maintenance_files_preserve_review_boundaries(self) -> None:
        dependabot = (ROOT / ".github" / "dependabot.yml").read_text(encoding="utf-8")
        self.assertIn("package-ecosystem: github-actions", dependabot)
        self.assertIn("@Sapient-Lumen", (ROOT / ".github" / "CODEOWNERS").read_text(encoding="utf-8"))
        for name in ["bug.yml", "source-drift.yml"]:
            text = (ROOT / ".github" / "ISSUE_TEMPLATE" / name).read_text(encoding="utf-8")
            self.assertIn("description:", text)
        drift = (ROOT / ".github" / "ISSUE_TEMPLATE" / "source-drift.yml").read_text(encoding="utf-8")
        self.assertIn("not treated the changed head as automatic editorial adoption", drift)
        github_doc = (ROOT / "docs" / "GITHUB.md").read_text(encoding="utf-8")
        self.assertIn("does not enumerate, copy, summarize, or publish private repositories", github_doc)
        self.assertIn("Private worktree checkpoints", github_doc)
        correction = (ROOT / ".github" / "ISSUE_TEMPLATE" / "correction.yml").read_text(encoding="utf-8")
        self.assertIn("stable page or passage identity", correction)
        self.assertIn("source fingerprint", correction)
        self.assertIn("does not establish", correction)


if __name__ == "__main__":
    unittest.main()
