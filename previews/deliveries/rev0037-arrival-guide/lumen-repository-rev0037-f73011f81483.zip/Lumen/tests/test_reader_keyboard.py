"""Execute both readers' keyboard handlers with a synthetic DOM in Node.js."""
from pathlib import Path
import shutil
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[1]
HARNESS = r'''
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(process.argv[1], 'utf8');
const listenerStart = source.search(/^(?:document\.)?addEventListener\("keydown", \(event\) => \{/m);
assert.ok(listenerStart >= 0, 'reader keyboard listener');
const listenerEnd = source.indexOf('\n});', listenerStart);
assert.ok(listenerEnd > listenerStart, 'reader keyboard listener end');
const resolverStart = source.indexOf('function pageIdForAnchor(');
assert.ok(resolverStart >= 0, 'page/anchor resolver');
const resolverEnd = source.indexOf('\n}', resolverStart);
assert.ok(resolverEnd > resolverStart, 'page/anchor resolver end');
class Element {
  constructor(pageId = '') { this.dataset = {pageId}; }
  closest(selector) {
    assert.equal(selector, '[data-page-id]');
    return this.dataset.pageId ? this : null;
  }
}
global.Element = Element;
global.HTMLInputElement = class extends Element {};
global.HTMLTextAreaElement = class extends Element {};
let keydown;
const register = (type, callback) => {
  assert.equal(type, 'keydown');
  assert.equal(keydown, undefined, 'one reader keyboard listener');
  keydown = callback;
};
global.document = {
  addEventListener: register,
  body: new Element('current-page'),
  getElementById: anchor => anchor === 'active-passage' ? new Element('passage-page') : null,
};
global.addEventListener = register;
global.byId = () => null;
for (const name of ['searchDialog', 'inspectDialog', 'contextDialog', 'correctionDialog',
  'returnDialog', 'fieldbookDialog', 'editionCompareDialog', 'capsuleDialog',
  'appearanceDialog', 'deskDialog', 'focusSheetDialog']) global[name] = null;
global.activePassageAnchor = 'active-passage';
const calls = [];
global.toggleFieldbookPassage = async (anchor, options) => calls.push(['trail', anchor, options.pageId]);
global.toggleDeskPassage = async (anchor, options) => calls.push(['desk', anchor, options.pageId]);
global.openDesk = () => calls.push(['open-desk']);
global.setFieldbookStatus = message => calls.push(['trail-status', message]);
global.setDeskStatus = message => calls.push(['desk-status', message]);
vm.runInThisContext(source.slice(resolverStart, resolverEnd + 2));
vm.runInThisContext(source.slice(listenerStart, listenerEnd + 4));
function press(key, {shiftKey = false, target = new Element('focused-other-page')} = {}) {
  let prevented = false;
  keydown({key, shiftKey, target, metaKey: false, ctrlKey: false,
    preventDefault() { prevented = true; }});
  return prevented;
}
'''


@unittest.skipUnless(shutil.which('node'), 'Node.js is required for executable keyboard tests')
class ReaderKeyboardTests(unittest.TestCase):
    def run_reader(self, body):
        for name in ('site.js', 'capsule.js'):
            with self.subTest(runtime=name):
                result = subprocess.run(
                    ['node', '-e', HARNESS + '\n(async () => {\n' + body +
                     '\n})().catch(error => {console.error(error); process.exitCode=1;});',
                     str(ROOT / 'assets/js' / name)],
                    capture_output=True, text=True, cwd=ROOT)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_s_saves_active_passage_not_focused_elements_page(self):
        self.run_reader(r'''
for (const key of ['s', 'S']) {
  calls.length = 0;
  assert.equal(press(key), true);
  assert.deepEqual(calls, [['trail', 'active-passage', 'passage-page']]);
}
''')

    def test_shift_d_saves_active_passage_not_focused_elements_page(self):
        self.run_reader(r'''
for (const key of ['d', 'D']) {
  calls.length = 0;
  assert.equal(press(key, {shiftKey: true}), true);
  assert.deepEqual(calls, [['desk', 'active-passage', 'passage-page']]);
}
''')

    def test_save_shortcuts_fall_back_to_current_page(self):
        self.run_reader(r'''
for (const anchor of ['', 'missing-passage']) {
  activePassageAnchor = anchor;
  calls.length = 0;
  assert.equal(press('s'), true);
  assert.equal(press('D', {shiftKey: true}), true);
  assert.deepEqual(calls, [['trail', anchor, 'current-page'], ['desk', anchor, 'current-page']]);
}
''')

    def test_editable_targets_suppress_save_and_desk_shortcuts(self):
        self.run_reader(r'''
const editable = new Element();
editable.isContentEditable = true;
for (const target of [new HTMLInputElement(), new HTMLTextAreaElement(), editable]) {
  for (const [key, shiftKey] of [['s', false], ['S', true], ['D', true], ['d', false]]) {
    assert.equal(press(key, {shiftKey, target}), false);
    assert.deepEqual(calls, []);
  }
}
''')

    def test_unshifted_d_opens_desk_without_saving(self):
        self.run_reader(r'''
assert.equal(press('d'), true);
assert.deepEqual(calls, [['open-desk']]);
''')

    def test_save_rejections_reach_status_handlers(self):
        self.run_reader(r'''
toggleFieldbookPassage = async () => {throw new Error('synthetic trail failure');};
toggleDeskPassage = async () => {throw new Error('synthetic desk failure');};
assert.equal(press('s'), true);
assert.equal(press('D', {shiftKey: true}), true);
await Promise.resolve();
assert.deepEqual(calls, [
  ['trail-status', 'Could not update reading trail: synthetic trail failure'],
  ['desk-status', 'Could not update reading desk: synthetic desk failure'],
]);
''')
