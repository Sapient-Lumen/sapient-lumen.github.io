/* End-to-end Node mock of the actual functions.exec pump and Python host. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const cp = require('node:child_process');
const crypto = require('node:crypto');
const {runGitHubDelivery} = require('../tools/github_delivery_runner.js');
const project = path.resolve(__dirname, '..');
const helper = path.join(project, 'tools/delivery_runner.py');
const hash = (kind, bytes) => crypto.createHash('sha1').update(Buffer.from(kind+' '+bytes.length+'\0')).update(bytes).digest('hex');
const blob = bytes => hash('blob', bytes);
const wrapped = obj => ({structuredContent:{content:JSON.stringify(obj)},isError:false});
function makeTree(files) {
  const dirs = new Set(['']);
  for (const file of Object.keys(files)) {
    let d = path.posix.dirname(file);
    while (d !== '.') {dirs.add(d); d = path.posix.dirname(d);}
  }
  const all = {...files}; let root;
  for (const dir of [...dirs].sort((a,b)=>b.split('/').length-a.split('/').length || b.length-a.length)) {
    const children=Object.entries(all).filter(([name])=>path.posix.dirname(name)===(dir||'.'));
    children.sort(([a,av],[b,bv])=>Buffer.compare(Buffer.from(path.posix.basename(a)+(av.type==='tree'?'/':'')),Buffer.from(path.posix.basename(b)+(bv.type==='tree'?'/':''))));
    const raw=Buffer.concat(children.map(([name,row])=>Buffer.concat([Buffer.from((row.type==='tree'?'40000':row.mode)+' '+path.posix.basename(name)+'\0'),Buffer.from(row.sha,'hex')])));
    const sha=hash('tree',raw);
    if (dir) all[dir]={type:'tree',mode:'040000',sha}; else root=sha;
  }
  return {sha:root,truncated:false,tree:Object.entries(all).sort(([a],[b])=>a.localeCompare(b)).map(([p,r])=>({path:p,...r}))};
}
class Remote {
  constructor() {
    this.repos={}; this.counts={}; this.fail=null; this.corrupt=null; this.beforeUpdate=null;
    for (const scope of ['private','public']) {
      const name='example/'+scope;
      const bytes=Buffer.from('preserve unrelated homepage '+scope);
      const files={'index.html':{type:'blob',mode:'100644',sha:blob(bytes),size:bytes.length}};
      const tree=makeTree(files); const sha=crypto.createHash('sha1').update(scope).digest('hex');
      this.repos[name]={private:scope==='private',head:sha,trees:{[tree.sha]:tree},blobs:{[blob(bytes)]:bytes},commits:{[sha]:{sha,tree:{sha:tree.sha},parents:[],message:'initial'}}};
    }
  }
  async call(tool,args) {
    const type=tool.split('github_')[1]; this.counts[type]=(this.counts[type]||0)+1;
    const url=args.url && new URL(args.url);
    const repo=args.repository_full_name||(url && url.pathname.split('/').slice(2,4).join('/'));
    const r=this.repos[repo]; assert(r,repo);
    let result;
    if(type==='fetch') {
      const suffix=url.pathname.split('/').slice(4).join('/');
      if(!suffix) result={full_name:repo,private:r.private};
      else if(suffix==='actions/runs') result={workflow_runs:[{id:100,run_number:1,run_attempt:1,path:'dynamic/pages/pages-build-deployment',head_sha:url.searchParams.get('head_sha'),head_branch:'main',status:this.pagesPending?'in_progress':'completed',conclusion:this.pagesPending?null:'success',html_url:'https://github.com/'+repo+'/actions/runs/100'}]};
      else if(suffix==='git/ref/heads/main') result={ref:'refs/heads/main',object:{type:'commit',sha:r.head}};
      else if(suffix.startsWith('git/commits/')) result=r.commits[suffix.slice(12)];
      else if(suffix.startsWith('git/trees/')) result=r.trees[suffix.slice(10)];
      else if(suffix.startsWith('git/blobs/')) {const sha=suffix.slice(10), bytes=r.blobs[sha]; result=bytes&&{sha,encoding:'base64',content:bytes.toString('base64')};}
      if(!result) return {isError:true,structuredContent:{error:'404 mock'}};
      result=wrapped(result);
    } else if(type==='create_blob') {
      const bytes=Buffer.from(args.content,'base64'),sha=blob(bytes); r.blobs[sha]=bytes; result={structuredContent:{sha}};
    } else if(type==='create_tree') {
      assert(args.base_tree_sha, 'explicit base required');
      const files=Object.fromEntries(r.trees[args.base_tree_sha].tree.filter(x=>x.type!=='tree').map(({path,...x})=>[path,x]));
      for(const row of args.tree_elements) {assert(row.sha,'no deletion');const {path,...rest}=row; files[path]={...rest,size:r.blobs[row.sha].length};}
      const tree=makeTree(files); r.trees[tree.sha]=tree; result={structuredContent:tree};
    } else if(type==='create_commit') {
      const sha=crypto.createHash('sha1').update(JSON.stringify(args)+this.counts[type]).digest('hex');
      const commit={sha,tree:{sha:args.tree_sha},parents:[{sha:args.parent_sha}],message:args.message};
      r.commits[sha]=commit; this.lastCommit={repo,sha}; result={structuredContent:{sha}};
    } else if(type==='update_ref') {
      assert.equal(args.force,false);
      if(this.beforeUpdate) {const hook=this.beforeUpdate;this.beforeUpdate=null;hook(r);}
      assert.equal(r.commits[args.sha].parents[0].sha,r.head,'nonfastforward rejected');
      r.head=args.sha;result={structuredContent:{success:true}};
    } else if(type==='fetch_file') {
      assert(r.commits[args.ref], 'immutable ref');const tree=r.trees[r.commits[args.ref].tree.sha];const row=tree.tree.find(x=>x.path===args.path);
      result={structuredContent:{sha:row.sha,encoding:'base64',content:r.blobs[row.sha].toString('base64')}};
    } else throw new Error('unexpected tool '+type);
    if(this.corrupt===type) {this.corrupt=null;result.structuredContent.content='corrupted';}
    if(this.fail===type) {this.fail=null;throw new Error('simulated acknowledgement loss AFTER remote action');}
    return result;
  }
}
function execute(cmd) {
  const r=cp.spawnSync('bash',['-c',cmd],{encoding:'utf8',maxBuffer:64*1024*1024});
  return {exit_code:r.status,output:r.stdout};
}
function setup() {
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'lumen-runner-test-'));
  const script=`import sys\nsys.path.insert(0,${JSON.stringify(path.join(project,'tests'))})\nimport test_delivery as t\nimport delivery as d\nfrom pathlib import Path\nx=t.DeliveryTests(); x.setUp()\nx.args.output=${JSON.stringify(path.join(dir,'bundle'))}\nx.args.part_bytes=160000\np=d.load(x.profile); p['public']['primary_alias']='preview/site.html'; d.save(x.profile,d.encoded(p))\nx.prepare()\nx.tearDown()\n`;
  const p=cp.spawnSync('python3',['-c',script],{encoding:'utf8'});assert.equal(p.status,0,p.stderr);
  return {dir,run:path.join(dir,'run'),bundle:path.join(dir,'bundle'),helper,projectId:'synthetic'};
}
function rpc(o,request) {
  const r=cp.spawnSync('python3',[helper,'rpc','--run',o.run],{input:JSON.stringify(request),encoding:'utf8'});
  try{return JSON.parse(r.stdout);}catch(e){throw new Error(r.stdout+r.stderr);}
}
function host(remote) {
  const tools={exec_command:async args=>execute(args.cmd)};
  for(const type of ['fetch','fetch_file','create_blob','create_tree','create_commit','update_ref']) tools['mcp__codex_apps__github_'+type]=args=>remote.call('github_'+type,args);
  return tools;
}
async function scenario(name,fn) {
  const o=setup(), remote=new Remote();
  try {await fn(o,remote,host(remote));console.log('PASS '+name);}
  finally {fs.rmSync(o.dir,{recursive:true,force:true});}
}
async function main() {
  await scenario('private boundary; resume all; replay preserves receipt bytes and no new commits; alias blob dedup',async(o,r,t)=>{
    assert.equal((await runGitHubDelivery(t,{...o,stopAfter:'private'})).status,'boundary');
    assert.equal(r.counts.create_commit,1);
    const receipt=fs.readFileSync(path.join(o.run,'finalization/private-VERIFIED.json'));
    assert.equal((await runGitHubDelivery(t,o)).status,'complete');
    assert.equal(r.counts.create_commit,4);
    const counts={...r.counts};
    assert.equal((await runGitHubDelivery(t,o)).status,'complete');
    assert.equal(r.counts.create_commit,counts.create_commit);
    assert.deepEqual(fs.readFileSync(path.join(o.run,'finalization/private-VERIFIED.json')),receipt);
    const inventory=JSON.parse(fs.readFileSync(path.join(o.bundle,'DELIVERY.json')));
    assert.equal(r.counts.create_blob, new Set(inventory.private_inventory.map(x=>x.git_blob_sha)).size+new Set(inventory.public_inventory.map(x=>x.git_blob_sha)).size+2);
    for(const repo of Object.values(r.repos)) assert(repo.trees[repo.commits[repo.head].tree.sha].tree.some(x=>x.path==='index.html'));
  });
  for (const kind of ['create_blob','create_tree','update_ref']) await scenario('lost '+kind+' acknowledgement reconciles without repeating mutation',async(o,r,t)=>{
    r.fail=kind;assert.equal((await runGitHubDelivery(t,o)).status,'paused');const count=r.counts[kind];
    const retry=rpc(o,{command:'reconcile'});assert.equal(retry.status,'action');
    assert.equal((await runGitHubDelivery(t,o)).status,'complete');
    // One private/public/pointer tree/ref each; all unique blobs exactly once.
    if(kind!=='create_blob') assert.equal(r.counts[kind],4);
    else assert(r.counts[kind]>count);
  });
  await scenario('lost commit acknowledgement pauses; exact adoption resumes without duplicate',async(o,r,t)=>{
    r.fail='create_commit';assert.equal((await runGitHubDelivery(t,o)).status,'paused');
    assert.equal((await runGitHubDelivery(t,o)).status,'paused');assert.equal(r.counts.create_commit,1);
    assert.equal(rpc(o,{command:'adopt-commit',sha:r.lastCommit.sha}).status,'action');
    assert.equal((await runGitHubDelivery(t,o)).status,'complete');assert.equal(r.counts.create_commit,4);
  });
  await scenario('private success retained when public permission fails',async(o,r,t)=>{
    assert.equal((await runGitHubDelivery(t,{...o,stopAfter:'pointer'})).status,'boundary');
    const original=t.mcp__codex_apps__github_create_blob;
    t.mcp__codex_apps__github_create_blob=async args=>args.repository_full_name==='example/public'?{isError:true,structuredContent:{error:'permission denied'}}:original(args);
    assert.equal((await runGitHubDelivery(t,o)).status,'paused');
    const status=rpc(o,{command:'status'});assert.equal(status.outcomes.private.status,'returned-bytes-verified');assert.equal(status.outcomes.pointer.status,'returned-bytes-verified');
    assert.equal(status.outcomes.public.status,'pending');
  });
  await scenario('fresh journal on existing stable ID refuses duplicate commits',async(o,r,t)=>{
    assert.equal((await runGitHubDelivery(t,o)).status,'complete');const commits=r.counts.create_commit;
    const again=await runGitHubDelivery(t,{...o,run:path.join(o.dir,'other-run')});
    assert.equal(again.status,'paused');assert.match(again.reason,/stable release ID/);assert.equal(r.counts.create_commit,commits);
  });
  await scenario('corrupt immutable readback stops before finalization; explicit read retry works',async(o,r,t)=>{
    r.corrupt='fetch_file';assert.equal((await runGitHubDelivery(t,o)).status,'blocked');
    assert(!fs.existsSync(path.join(o.run,'finalization/private-VERIFIED.json')));
    assert.equal(rpc(o,{command:'retry-read'}).status,'read-retry-enabled');
    assert.equal((await runGitHubDelivery(t,o)).status,'complete');
  });
  await scenario('response persisted before state crash is consumed without duplicate commit',async(o,r,t)=>{
    const real=t.exec_command;let captured=false;
    t.exec_command=async args=>{
      if(!captured && args.cmd.includes('"command":"accept"')) {
        const state=rpc(o,{command:'status'});
        if(state.pending.step==='created_commit') {captured=true;throw new Error('simulated local loss before accept');}
      }
      return real(args);
    };
    await assert.rejects(runGitHubDelivery(t,o)); assert(captured);
    assert.equal((await runGitHubDelivery({...t,exec_command:real},o)).status,'complete');assert.equal(r.counts.create_commit,4);
  });
  await scenario('wrong orphan adoption may be corrected; transient reconciliation read may retry',async(o,r,t)=>{
    r.fail='create_commit';assert.equal((await runGitHubDelivery(t,o)).status,'paused');const correct=r.lastCommit.sha;
    const bad=r.repos['example/private'].head;
    assert.equal(rpc(o,{command:'adopt-commit',sha:bad}).status,'action');
    assert.equal((await runGitHubDelivery(t,o)).status,'blocked');
    assert.equal(rpc(o,{command:'adopt-commit',sha:correct}).status,'action');
    const saved=t.mcp__codex_apps__github_fetch;let once=true;
    t.mcp__codex_apps__github_fetch=async a=>{if(once&&a.url.includes('/git/commits/'+correct)){once=false;return {isError:true};}return saved(a);};
    assert.equal((await runGitHubDelivery(t,o)).status,'paused');
    assert.equal(rpc(o,{command:'retry-read'}).status,'read-retry-enabled');
    assert.equal((await runGitHubDelivery(t,o)).status,'complete');assert.equal(r.counts.create_commit,4);
  });
  await scenario('branch advance before update stops; explicit replan preserves frozen artifacts',async(o,r,t)=>{
    const saved=t.mcp__codex_apps__github_fetch;let advanced=false;
    t.mcp__codex_apps__github_fetch=async a=>{
      if(!advanced && r.counts.create_commit===1 && a.url.endsWith('/git/ref/heads/main')) {
        advanced=true;const repo=r.repos['example/private'];const original=repo.commits[repo.head];
        const sha='f'.repeat(40);repo.commits[sha]={sha,tree:original.tree,parents:[{sha:repo.head}],message:'concurrent unrelated commit'};repo.head=sha;
      }
      return saved(a);
    };
    const before=fs.readFileSync(path.join(o.bundle,'DELIVERY.json'));
    const result=await runGitHubDelivery(t,o);assert.equal(result.status,'paused');assert.match(result.reason,/concurrent branch/);
    assert.equal(r.counts.update_ref,undefined);
    assert.equal(rpc(o,{command:'replan',scope:'private'}).status,'replan-enabled');
    assert.equal((await runGitHubDelivery(t,o)).status,'complete');
    assert.deepEqual(fs.readFileSync(path.join(o.bundle,'DELIVERY.json')),before);
  });
  await scenario('resuming after a stopped preflight refreshes head before any ref write',async(o,r,t)=>{
    let state;
    for(let attempts=0;attempts<30;attempts++) {
      await runGitHubDelivery(t,{...o,maxActions:1});
      state=JSON.parse(fs.readFileSync(path.join(o.run,'STATE.json')));
      if(state.phases.private.pre_ref&&!state.pending) break;
    }
    assert(state.phases.private.pre_ref&&!state.pending);assert.equal(r.counts.update_ref,undefined);
    const repo=r.repos['example/private'],old=repo.commits[repo.head],sha='d'.repeat(40);
    repo.commits[sha]={sha,tree:old.tree,parents:[{sha:repo.head}],message:'advanced while pump stopped'};repo.head=sha;
    const result=await runGitHubDelivery(t,o);assert.equal(result.status,'paused');assert.match(result.reason,/concurrent branch/);
    assert.equal(r.counts.update_ref,undefined);
  });
  await scenario('existing release with newer public alias causes zero mutations',async(o,r,t)=>{
    assert.equal((await runGitHubDelivery(t,o)).status,'complete');const mutations=['create_blob','create_tree','create_commit','update_ref'];const counts={...r.counts};
    const repo=r.repos['example/public'];const old=repo.commits[repo.head];
    const files=Object.fromEntries(repo.trees[old.tree.sha].tree.filter(x=>x.type==='blob').map(({path,...v})=>[path,v]));
    const bytes=Buffer.from('newer alias');const sha=blob(bytes);repo.blobs[sha]=bytes;files['preview/site.html']={type:'blob',mode:'100644',sha,size:bytes.length};
    const tree=makeTree(files);repo.trees[tree.sha]=tree;const commit='e'.repeat(40);repo.commits[commit]={sha:commit,tree:{sha:tree.sha},parents:[{sha:repo.head}],message:'newer release'};repo.head=commit;
    // Completed journal replay must not roll a newer alias back.
    assert.equal((await runGitHubDelivery(t,o)).status,'complete');
    // Force only PUBLIC state to be absent, keeping custody/pointer receipts.
    const statePath=path.join(o.run,'STATE.json');const state=JSON.parse(fs.readFileSync(statePath));state.phases.public={generation:1};delete state.phases.evidence;fs.writeFileSync(statePath,JSON.stringify(state));
    const result=await runGitHubDelivery(t,o);assert.equal(result.status,'paused');assert.equal(result.scope,'public');
    assert.equal((await runGitHubDelivery(t,{...o,run:path.join(o.dir,'fresh')})).status,'paused');
    for(const key of mutations) assert.equal(r.counts[key],counts[key]);assert.equal(repo.head,commit);
  });
  await scenario('optional Pages pending and CDN lag resume to exact live bytes and saved outcome',async(o,r,t)=>{
    o.pagesUrl='https://example.github.io';r.pagesPending=true;
    const normal=t.exec_command;let lag=true;
    t.exec_command=async args=>{
      if(!args.cmd.includes('"command":"live-download"')) return normal(args);
      const request=JSON.parse(args.cmd.split('\n')[1]);
      const script=`import sys,json\nsys.path.insert(0,${JSON.stringify(path.join(project,'tools'))})\nimport delivery_runner as r\nfrom pathlib import Path\nfrom urllib.parse import urlsplit,unquote\nr.Runner.download_exact_limit=staticmethod(lambda url,size: ${lag?"b'older CDN bytes'":`(Path(${JSON.stringify(o.bundle)})/'public'/unquote(urlsplit(url).path.lstrip('/'))).read_bytes()`})\nprint(json.dumps(r.rpc(${JSON.stringify(o.run)},${JSON.stringify(request)})))\n`;
      const result=cp.spawnSync('python3',['-c',script],{encoding:'utf8'});return {exit_code:result.status,output:result.stdout};
    };
    assert.equal((await runGitHubDelivery(t,o)).status,'pending');assert.equal(r.counts.create_commit,3);
    r.pagesPending=false;
    assert.equal((await runGitHubDelivery(t,o)).status,'pending');assert.equal(r.counts.create_commit,3);
    lag=false;assert.equal((await runGitHubDelivery(t,o)).status,'complete');assert.equal(r.counts.create_commit,4);
    const evidence=JSON.parse(fs.readFileSync(path.join(o.run,'evidence-payload/backups/test-1/DELIVERY-OUTCOME.json')));
    assert.equal(evidence.pages.status,'live-bytes-verified');assert.equal(evidence.pages.files.length,2);
    const calls={...r.counts};assert.equal((await runGitHubDelivery(t,o)).status,'complete');assert.deepEqual(r.counts,calls);
  });
  await scenario('completed returned-byte or verification-receipt corruption fails closed',async(o,r,t)=>{
    assert.equal((await runGitHubDelivery(t,o)).status,'complete');
    const files=JSON.parse(fs.readFileSync(path.join(o.bundle,'DELIVERY.json'))).private_inventory;
    const target=path.join(o.run,'private/0/returned',files[0].path), original=fs.readFileSync(target);
    const counts={...r.counts};fs.writeFileSync(target,'corrupt');
    assert.equal((await runGitHubDelivery(t,o)).status,'blocked');assert.deepEqual(r.counts,counts);
    fs.writeFileSync(target,original);
    const receipt=path.join(o.run,'finalization/private-VERIFIED.json'),saved=fs.readFileSync(receipt);
    const value=JSON.parse(saved);value.commit='0'.repeat(40);fs.writeFileSync(receipt,JSON.stringify(value));
    assert.equal((await runGitHubDelivery(t,o)).status,'blocked');assert.deepEqual(r.counts,counts);
    fs.writeFileSync(receipt,saved);assert.equal((await runGitHubDelivery(t,o)).status,'complete');
  });
  await scenario('async exec session is polled, never started twice',async(o,r,t)=>{
    let polled=0;
    t.exec_command=async()=>({session_id:42,output:''});
    t.write_stdin=async args=>{assert.equal(args.session_id,42);polled++;return {exit_code:0,output:JSON.stringify({status:'boundary'})};};
    assert.equal((await runGitHubDelivery(t,{helper:o.helper,run:o.run})).status,'boundary');assert.equal(polled,1);
  });
  await scenario('truncated local stdout stops rather than interpreting partial JSON',async(o,r,t)=>{
    t.exec_command=async()=>({exit_code:0,output:'{"status":'});
    await assert.rejects(runGitHubDelivery(t,o),/truncated/);assert.equal(r.counts.create_commit,undefined);
  });
}
module.exports={Remote,setup,rpc,host,makeTree,wrapped,execute,scenario};
if(require.main===module) main().catch(e=>{console.error(e);process.exitCode=1;});
