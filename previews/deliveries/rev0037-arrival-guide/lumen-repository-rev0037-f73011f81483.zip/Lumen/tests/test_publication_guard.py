from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("publication_guard", ROOT / "tools/publication_guard.py")
guard = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(guard)


def blob(text="hello", mode="100644", width=40):
    raw = text.encode()
    digest = hashlib.sha1 if width == 40 else hashlib.sha256
    return {"mode": mode, "type": "blob", "sha": digest(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()}


def snapshot(leaves, width=40):
    """Build fixture trees bottom-up; independently encode the Git wire format."""
    entries = copy.deepcopy(leaves)
    directories = {""}
    for path in leaves:
        components = path.split("/")[:-1]
        directories.update("/".join(components[:i]) for i in range(1, len(components) + 1))
    digest = hashlib.sha1 if width == 40 else hashlib.sha256
    for directory in sorted(directories, key=lambda p: p.count("/") + bool(p), reverse=True):
        members = [(p.rsplit("/", 1)[-1], v) for p, v in entries.items() if p.rpartition("/")[0] == directory]
        members.sort(key=lambda pair: (pair[0] + ("/" if pair[1]["type"] == "tree" else "")).encode())
        body = b"".join((v["mode"].lstrip("0") + " " + name).encode() + b"\0" + bytes.fromhex(v["sha"]) for name, v in members)
        sha = digest(b"tree " + str(len(body)).encode() + b"\0" + body).hexdigest()
        if directory:
            entries[directory] = {"mode": "040000", "type": "tree", "sha": sha}
    return {"sha": sha, "truncated": False, "tree": [{"path": p, **v} for p, v in entries.items()]}


class PublicationGuardTests(unittest.TestCase):
    def setUp(self):
        self.leaves = {"README.md": blob(), "src/a.txt": blob("a"), "src/deep/b.txt": blob("b")}
        self.base = snapshot(self.leaves)

    def check(self, candidate=None, changes=None, base=None, manifest=Ellipsis, **pins):
        base = self.base if base is None else base
        candidate = base if candidate is None else candidate
        plan = {"schema_version": 1, "baseline_tree_sha": base["sha"], "candidate_tree_sha": candidate["sha"], "changes": changes or []}
        return guard.verify(base, candidate, plan if manifest is Ellipsis else manifest,
                            baseline_tree_sha=pins.get("baseline_tree_sha", base["sha"]),
                            candidate_tree_sha=pins.get("candidate_tree_sha", candidate["sha"]))

    def test_unchanged_preserves_every_entry(self):
        self.assertEqual(self.check()["preserved_entries"], 3)

    def test_empty_root_and_known_git_empty_hash(self):
        tree = snapshot({})
        self.assertEqual(tree["sha"], "4b825dc642cb6eb9a060e54bf8d69288fbee4904")
        self.assertEqual(self.check(base=tree)["approved_changes"], 0)

    def test_approved_add_modify_remove_and_mode(self):
        leaves = {"README.md": blob("updated"), "src/a.txt": blob("a", "100755"), "new/file": blob("new")}
        changes = [{"path": p, "before": self.leaves.get(p), "after": leaves.get(p)} for p in sorted(self.leaves.keys() | leaves.keys())]
        result = self.check(snapshot(leaves), changes)
        self.assertEqual(result["approved_changes"], 4)
        self.assertEqual(result["preserved_entries"], 0)

    def test_omitted_base_tree_receipts_only_regression(self):
        receipt = blob("receipt")
        with self.assertRaisesRegex(guard.GuardError, "unapproved"):
            self.check(snapshot({"receipt.json": receipt}), [{"path": "receipt.json", "before": None, "after": receipt}])

    def test_unplanned_add_modify_remove_or_mode(self):
        for action in ("add", "modify", "remove", "mode"):
            leaves = copy.deepcopy(self.leaves)
            if action == "add": leaves["unexpected"] = blob()
            if action == "modify": leaves["README.md"] = blob("other")
            if action == "remove": del leaves["README.md"]
            if action == "mode": leaves["README.md"]["mode"] = "100755"
            with self.subTest(action=action), self.assertRaisesRegex(guard.GuardError, "unapproved"):
                self.check(snapshot(leaves))

    def test_wrong_planned_blob_mode_type_or_before(self):
        leaves = {**self.leaves, "new": blob("new")}
        for key, value in (("sha", "0" * 40), ("mode", "100755"), ("type", "commit")):
            planned = {**leaves["new"], key: value}
            with self.subTest(key=key), self.assertRaises(guard.GuardError):
                self.check(snapshot(leaves), [{"path": "new", "before": None, "after": planned}])
        with self.assertRaises(guard.GuardError):
            self.check(snapshot(leaves), [{"path": "new", "before": blob(), "after": leaves["new"]}])

    def test_duplicate_and_noop_manifest_entries(self):
        change = {"path": "new", "before": None, "after": blob()}
        with self.assertRaisesRegex(guard.GuardError, "duplicate"):
            self.check(snapshot({**self.leaves, "new": blob()}), [change, change])
        for before, after in ((None, None), (blob(), blob())):
            with self.subTest(before=before), self.assertRaises(guard.GuardError):
                self.check(changes=[{"path": "README.md" if before else "absent", "before": before, "after": after}])

    def test_pin_mismatch_and_missing_or_short_pins(self):
        for pin in (None, "", "a" * 7, "A" * 40, "g" * 40, "a" * 40, "a" * 64):
            with self.subTest(pin=pin), self.assertRaises(guard.GuardError):
                self.check(baseline_tree_sha=pin)
        with self.assertRaises(guard.GuardError):
            self.check(candidate_tree_sha="b" * 40)

    def test_missing_tree_fields_and_truncated(self):
        for key in ("sha", "tree", "truncated"):
            tree = copy.deepcopy(self.base)
            del tree[key]
            with self.subTest(key=key), self.assertRaises(guard.GuardError):
                guard.complete_tree(tree, self.base["sha"], "test")
        for value in (True, None, 0, "false"):
            with self.subTest(value=value), self.assertRaises(guard.GuardError):
                self.check(base={**self.base, "truncated": value})

    def test_false_complete_claim_detected_by_hash(self):
        for index in range(len(self.base["tree"])):
            tree = copy.deepcopy(self.base)
            del tree["tree"][index]
            with self.subTest(index=index), self.assertRaises(guard.GuardError):
                self.check(base=tree)

    def test_duplicate_tree_paths(self):
        tree = copy.deepcopy(self.base)
        tree["tree"].append(tree["tree"][0])
        with self.assertRaisesRegex(guard.GuardError, "duplicate"):
            self.check(base=tree)

    def test_invalid_paths(self):
        for path in ("", "/a", "a/", "a//b", ".", "a/../b", "a/./b", "a\\b", "a\0b", "a\nb", "\ud800", 12):
            tree = copy.deepcopy(self.base)
            tree["tree"][0]["path"] = path
            with self.subTest(path=repr(path)), self.assertRaises(guard.GuardError):
                self.check(base=tree)

    def test_malformed_entries(self):
        for entry in (None, [], {}, {"path": "a"}, {"path": "a", **blob(), "unexpected": 1}):
            with self.subTest(entry=entry), self.assertRaises(guard.GuardError):
                self.check(base={**self.base, "tree": [entry]})
        for mode, kind in (("100664", "blob"), (100644, "blob"), ([], "blob"), ("040000", "blob"), ("100644", "tree")):
            with self.subTest(mode=mode), self.assertRaises(guard.GuardError):
                self.check(base={**self.base, "tree": [{"path": "a", **blob(), "mode": mode, "type": kind}]})

    def test_blob_size_and_url_are_validated(self):
        for key, value in (("size", -1), ("size", True), ("size", "1"), ("url", 42)):
            tree = copy.deepcopy(self.base)
            tree["tree"][0][key] = value
            with self.subTest(key=key, value=value), self.assertRaises(guard.GuardError):
                self.check(base=tree)

    def test_file_directory_collision(self):
        tree = snapshot({"file": blob(), "file/child": blob()})
        tree["tree"] = [dict(e, **blob()) if e["path"] == "file" else e for e in tree["tree"]]
        with self.assertRaises(guard.GuardError):
            self.check(base=tree)

    def test_subtree_sha_tampering(self):
        tree = copy.deepcopy(self.base)
        next(e for e in tree["tree"] if e["type"] == "tree")["sha"] = "1" * 40
        with self.assertRaises(guard.GuardError):
            self.check(base=tree)

    def test_reordering_does_not_change_identity(self):
        tree = copy.deepcopy(self.base)
        tree["tree"].reverse()
        self.assertEqual(self.check(candidate=tree)["status"], "ok")

    def test_git_directory_sort_order_known_fixture(self):
        # Golden ID obtained with git hash-object -t tree --stdin, not this guard.
        sha = "1" * 40
        entries = [("foo0", {"mode": "100644", "type": "blob", "sha": sha}),
                   ("foo", {"mode": "040000", "type": "tree", "sha": sha}),
                   ("foo.bar", {"mode": "100644", "type": "blob", "sha": sha})]
        self.assertEqual(guard.tree_hash(entries, 40), "1f07b3d352ed6917e0d442eee333392b8c3ce1df")
        tree = snapshot({"foo/child": blob(), "foo.bar": blob(), "foo0": blob()})
        self.assertEqual(self.check(base=tree)["status"], "ok")

    def test_sha256_and_mixed_algorithm_rejection(self):
        tree = snapshot({"a": blob(width=64)}, width=64)
        self.assertEqual(self.check(base=tree)["status"], "ok")
        tree["tree"][0]["sha"] = "0" * 40
        with self.assertRaises(guard.GuardError):
            self.check(base=tree)

    def test_symlink_and_submodule_preserved(self):
        tree = snapshot({"link": blob("target", "120000"), "module": {"mode": "160000", "type": "commit", "sha": "a" * 40}})
        self.assertEqual(self.check(base=tree)["preserved_entries"], 2)

    def test_file_to_directory_requires_explicit_deletion(self):
        tree = snapshot({"README.md/child": blob(), "src/a.txt": blob("a"), "src/deep/b.txt": blob("b")})
        changes = [{"path": "README.md/child", "before": None, "after": blob()}]
        with self.assertRaises(guard.GuardError):
            self.check(tree, changes)
        changes.append({"path": "README.md", "before": blob(), "after": None})
        self.assertEqual(self.check(tree, changes)["preserved_entries"], 2)

    def test_empty_subtrees_rejected(self):
        tree = snapshot({"empty": {"mode": "040000", "type": "tree", "sha": snapshot({})["sha"]}})
        with self.assertRaisesRegex(guard.GuardError, "empty subtree"):
            self.check(base=tree)

    def test_malformed_manifest(self):
        valid = {"schema_version": 1, "baseline_tree_sha": self.base["sha"], "candidate_tree_sha": self.base["sha"], "changes": []}
        invalid = [None, [], {}, {**valid, "extra": 1}, {**valid, "schema_version": True}, {**valid, "changes": {}}, {**valid, "changes": [{}]}, {**valid, "baseline_tree_sha": "0" * 40}]
        for manifest in invalid:
            with self.subTest(manifest=manifest), self.assertRaises(guard.GuardError):
                self.check(manifest=manifest)

    def test_json_duplicate_keys_and_nonfinite_constants_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "input.json"
            for text in ('{"tree":[],"tree":[]}', '{"nested":{"a":1,"a":2}}', '{"n":NaN}', '{"n":Infinity}', '{bad'):
                path.write_text(text)
                with self.subTest(text=text), self.assertRaises((guard.GuardError, json.JSONDecodeError)):
                    guard.load_json(str(path))

    def test_cli_success_rejection_and_required_pins(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            manifest = {"schema_version": 1, "baseline_tree_sha": self.base["sha"], "candidate_tree_sha": self.base["sha"], "changes": []}
            for name, value in (("base", self.base), ("next", self.base), ("plan", manifest)):
                (root / name).write_text(json.dumps(value))
            command = [sys.executable, str(ROOT / "tools/publication_guard.py"), "--baseline", str(root / "base"), "--candidate", str(root / "next"), "--manifest", str(root / "plan")]
            result = subprocess.run(command, capture_output=True, text=True)
            self.assertEqual(result.returncode, 2)
            command += ["--baseline-tree-sha", self.base["sha"], "--candidate-tree-sha", self.base["sha"]]
            result = subprocess.run(command, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout)["status"], "ok")
            original = (root / "base").read_bytes()
            (root / "next").write_text('{}')
            result = subprocess.run(command, capture_output=True, text=True)
            self.assertEqual(result.returncode, 1)
            self.assertIn("REJECTED", result.stderr)
            self.assertEqual(result.stdout, "")
            self.assertEqual((root / "base").read_bytes(), original)


if __name__ == "__main__":
    unittest.main()
