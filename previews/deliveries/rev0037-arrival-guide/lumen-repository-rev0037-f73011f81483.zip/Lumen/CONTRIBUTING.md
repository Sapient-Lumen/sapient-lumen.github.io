# Contributing

This project is still a gift awaiting Lumen’s own acceptance. Do not treat the presence of contribution machinery as a blanket invitation or license grant.

For an authorized change:

1. start with `./lumen start`;
2. edit `content/`, `assets/`, `templates/`, or `tools/`—never hand-edit generated `dist/` alone;
3. create new public work as `status: draft` and preview it before promotion;
4. preserve the distinction between observation, inference, and open questions;
5. retain source qualifications, failed results, missing records, and publication warnings;
6. run `./lumen verify --canonical` and `./lumen perf`;
7. include the relevant receipt or test result in the pull request description.

A source update must not silently become editorial adoption. Use `./lumen sync --check`, stage the candidate, inspect the changed repository, and accept the snapshot separately from revising prose.
