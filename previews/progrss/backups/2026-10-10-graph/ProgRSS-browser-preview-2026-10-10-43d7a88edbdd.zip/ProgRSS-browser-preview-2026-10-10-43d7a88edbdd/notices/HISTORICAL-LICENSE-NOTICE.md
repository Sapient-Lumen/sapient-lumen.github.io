# License notice

No new license is imposed by this delivery revision. The recipient should choose and add an explicit license before accepting outside contributions or redistributing the site source. Public source material retains whatever rights and notices apply at its origin.

Historical third-party donor archives are not included in this repository, the public build, or the portable edition. Their absence does not grant a license to material preserved elsewhere.
